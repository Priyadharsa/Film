"""Original practical storyboard grammar; every recommendation remains a draft."""
from __future__ import annotations
import re


def recommend(heading:str,beat:str,index:int,total:int)->dict:
    t=(beat or '').lower(); heading=(heading or '').lower()
    interior=heading.lstrip().startswith('int'); night=any(x in heading for x in ('night','dusk','midnight'))
    outdoors=any(x in heading for x in ('ext','highway','ocean','forest','street','field'))
    tension=bool(re.search(r'\b(silence|whisper|hidden|shadow|fear|dark|stares|waits|watching|secret|gun|knife)\b',t))
    emotion=bool(re.search(r'\b(cry|tears|smil|looks|gaze|face|realiz|hesitat|confess|angry)\w*',t))
    action=bool(re.search(r'\b(run|sprint|rush|chase|drives|fight|hits|jump|escapes|falls)\w*',t))
    detail=bool(re.search(r'\b(letter|key|phone|photograph|clock|finger|hand|note|blood|map|screen)\b',t))
    dialogue=bool(re.search(r'(?m)^[A-Z][A-Z ]{2,24}\n',beat or '')) or ('\"' in beat)
    if index==0:shot,angle,lens,movement,purpose='Wide shot','Eye level',24,'Static','Establish geography and relationships before tighter coverage'
    elif detail:shot,angle,lens,movement,purpose='Insert','Eye level',85,'Static','Make the story-critical prop or clue readable'
    elif action:shot,angle,lens,movement,purpose='Tracking shot','Eye level',35,'Controlled tracking','Preserve direction of movement, geography and safe action spacing'
    elif emotion:shot,angle,lens,movement,purpose='Close-up','Eye level',85,'Gentle push','Reveal the emotional change in the character\'s expression'
    elif dialogue:shot,angle,lens,movement,purpose='Over-the-shoulder','Eye level',50,'Static','Keep eyelines and the 180-degree screen axis coherent'
    elif tension:shot,angle,lens,movement,purpose='Medium shot','Low angle',50,'Static','Use negative space and delayed information to create tension'
    else:shot,angle,lens,movement,purpose='Medium shot','Eye level',50,'Static','Track the beat through clear blocking and composition'
    if night:lighting='Night: motivated practical key, restrained fill, separated silhouettes; maintain realistic contrast'
    elif outdoors:lighting='Day exterior: sun/sky as key, reflected fill, horizon and depth layers'
    elif interior:lighting='Interior: window or practical motivated key, soft fill, controllable background separation'
    else:lighting='Soft motivated key; foreground, midground and background depth'
    if tension:lighting+='; deliberate pools of darkness and negative space'
    return {'shot_type':shot,'camera_angle':angle,'camera_movement':movement,'lens_mm':lens,
            'lighting_plan':lighting,'composition_plan':'Thirds and purposeful negative space; orient foreground, midground and background; keep the action axis consistent',
            'purpose':purpose,'continuity_notes':'Match set geography, wardrobe, lighting direction and eyelines across adjacent shots',
            'image_prompt':f'One original cinematic 16:9 storyboard frame. {heading}. {beat[:750]}. {shot}, {angle}, {lens} mm. {lighting}. {purpose}. Clear actor blocking, coherent eyelines, no lettering or collage.'}
