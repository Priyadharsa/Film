"""FramePilot AI application package."""
