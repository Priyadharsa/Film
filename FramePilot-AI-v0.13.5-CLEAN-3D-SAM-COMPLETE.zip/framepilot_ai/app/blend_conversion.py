"""Opt-in localhost-only .blend to .glb conversion.

Blender opens untrusted binary files. Never enable this in a public service.
Use an isolated conversion worker/container for internet-facing deployments.
"""
from __future__ import annotations
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

BLEND_MAX_BYTES = 80 * 1024 * 1024


def convert_blend(raw: bytes) -> bytes:
    if not raw.startswith(b'BLENDER'):
        raise ValueError('Not a Blender .blend file.')
    exe = os.getenv('FRAMEPILOT_BLENDER_BIN') or shutil.which('blender')
    if not exe:
        raise RuntimeError('Blender is not installed or not on PATH. Install Blender or export .glb manually.')
    with tempfile.TemporaryDirectory(prefix='fp_blend_') as tmp:
        folder = Path(tmp)
        source = folder / 'source.blend'
        target = folder / 'output.glb'
        script = folder / 'export.py'
        source.write_bytes(raw)
        script.write_text("import bpy\nbpy.ops.export_scene.gltf(filepath=bpy.path.abspath('//output.glb'), export_format='GLB', use_selection=False)\n")
        command = [str(exe), '--background', '--factory-startup', '--disable-autoexec', str(source), '--python-exit-code', '75', '--python', str(script)]
        try:
            result = subprocess.run(command, cwd=tmp, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                    timeout=120, check=False)
        except subprocess.TimeoutExpired as e:
            raise RuntimeError('Blender conversion timed out; simplify the scene or export GLB manually.') from e
        if result.returncode != 0 or not target.is_file():
            detail = result.stderr.decode('utf-8', 'replace')[-800:]
            raise RuntimeError('Blender could not convert this project. Export a GLB in Blender. ' + detail)
        if target.stat().st_size > 30 * 1024 * 1024:
            raise ValueError('Converted GLB exceeds 30 MiB; simplify the scene.')
        return target.read_bytes()
