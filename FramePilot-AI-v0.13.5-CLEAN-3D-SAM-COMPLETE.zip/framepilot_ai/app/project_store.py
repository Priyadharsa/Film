"""SQLite project persistence. Local-only instance; requests are serialized per worker."""
from __future__ import annotations
import copy
import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Callable
from fastapi import HTTPException
from .auth import actor

class ProjectStore:
    def __init__(self, folder: Path):
        self.folder=Path(folder)
        self.folder.mkdir(parents=True,exist_ok=True)
        self.db=self.folder/'projects.sqlite3'
        self.lock=threading.RLock()
        with self._connect() as c:
            c.execute('CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, title TEXT NOT NULL, data TEXT NOT NULL, revision INTEGER NOT NULL, updated REAL NOT NULL)')
            fields={row['name'] for row in c.execute('PRAGMA table_info(projects)')}
            if 'owner_id' not in fields:
                c.execute("ALTER TABLE projects ADD COLUMN owner_id TEXT NOT NULL DEFAULT 'local'")

    def _connect(self):
        con=sqlite3.connect(str(self.db), timeout=15)
        con.row_factory=sqlite3.Row
        return con

    def create(self,title:str,scenes:list,source:dict,pid:str|None=None,pages:list|None=None,owner_id:str|None=None):
        now=time.time(); pid=pid or uuid.uuid4().hex[:12]
        project={"id":pid,"title":title[:160] or 'Untitled Film',"scenes":scenes,"pages":pages or [],"source":source,"created_at":now,"updated_at":now,"revision":1,"format_version":1}
        with self.lock,self._connect() as c:
            c.execute('INSERT OR IGNORE INTO projects(id,title,data,revision,updated,owner_id) VALUES (?,?,?,?,?,?)',(pid,project['title'],json.dumps(project),1,now,owner_id or actor()))
        return self.get(pid) or project

    def list(self):
        with self._connect() as c:
            rows=c.execute('SELECT id,title,revision,updated,data FROM projects WHERE owner_id=? ORDER BY updated DESC LIMIT 50',(actor(),)).fetchall() if actor()!='system' else c.execute('SELECT id,title,revision,updated,data FROM projects ORDER BY updated DESC LIMIT 50').fetchall()
        return [{"id":r['id'],"title":r['title'],"revision":r['revision'],"updated_at":r['updated'],"scenes":len(json.loads(r['data'])['scenes'])} for r in rows]

    def get(self,pid):
        with self._connect() as c:
            row=c.execute('SELECT data FROM projects WHERE id=?',(pid,)).fetchone() if actor()=='system' else c.execute('SELECT data FROM projects WHERE id=? AND owner_id=?',(pid,actor())).fetchone()
        return json.loads(row['data']) if row else None

    def mutate(self,pid, mutator:Callable[[dict],None]):
        with self.lock:
            project=self.get(pid)
            if project is None:
                raise KeyError('Project not found')
            mutator(project)
            old_revision=project['revision']
            project['revision']+=1
            project['updated_at']=time.time()
            with self._connect() as c:
                # Compare-and-swap prevents silent overwrites when separate API
                # workers edit the same film concurrently. The UI must refresh
                # after a 409 instead of silently losing another editor's work.
                if actor()=='system':
                    cursor=c.execute('UPDATE projects SET title=?,data=?,revision=?,updated=? WHERE id=? AND revision=?',
                      (project['title'],json.dumps(project),project['revision'],project['updated_at'],pid,old_revision))
                else:
                    cursor=c.execute('UPDATE projects SET title=?,data=?,revision=?,updated=? WHERE id=? AND revision=? AND owner_id=?',
                      (project['title'],json.dumps(project),project['revision'],project['updated_at'],pid,old_revision,actor()))
                if cursor.rowcount!=1:
                    raise HTTPException(status_code=409, detail='This film changed in another editor. Refresh and retry to avoid overwriting changes.')
            return project

    def actor_has_asset(self, filename: str) -> bool:
        if actor()=='system':return True
        # Match the complete URL fragment within owned serialized project data.
        # This prevents another profile from fetching a guessed storyboard filename.
        with self._connect() as db:
            result=bool(db.execute('SELECT 1 FROM projects WHERE owner_id=? AND instr(data,?)>0 LIMIT 1',
                       (actor(),'/static/generated/'+filename)).fetchone())
        if result:return True
        # Standalone Studio generated frames may exist before being assigned to a shot.
        from .auth import check_asset
        try:check_asset('generated',filename);return True
        except Exception:return False


def find_scene(project,sid):
    for scene in project['scenes']:
        if scene['id']==sid:return scene
    raise KeyError('Scene not found')

def find_shot(project,sid,shid):
    scene=find_scene(project,sid)
    for shot in scene['shots']:
        if shot['id']==shid:return scene,shot
    raise KeyError('Shot not found')
