"""Deterministic, non-destructive SAM selection operations.

The SAM Model API supplies a cropped binary mask + source pixel box. Muse Image is
used separately for generative changes. The operations here use a local OpenCV-based fill for removal, which is approximate in complex backgrounds.
"""
from __future__ import annotations
import base64
import binascii
from pathlib import Path
from PIL import Image, ImageChops, ImageEnhance, ImageFilter, ImageOps

MAX_PIXELS = 16_000_000
MAX_MASK_BYTES = 16_000_000
OPERATIONS = frozenset({'isolate', 'focus', 'accent', 'silhouette', 'outline', 'soften', 'erase_heal', 'erase_transparent', 'target_tint', 'background_tint', 'replace_subject', 'replace_background'})
REPLACEMENT_OPERATIONS = frozenset({'replace_subject', 'replace_background'})


def decode_mask(selection: dict, image_size: tuple[int,int]) -> Image.Image:
    """Validate and place a SAM ROI raster onto a full-frame L mask.

    The official SAM parser decodes and validates the wire grammar before this
    function receives the bytes. This step independently validates user input.
    """
    if not isinstance(selection,dict):
        raise ValueError('Select an object identified by SAM first.')
    W,H = image_size
    if W <= 0 or H <= 0 or W*H > MAX_PIXELS:
        raise ValueError('Frame exceeds the 16 megapixel layer editor limit.')
    try:
        x1,y1,x2,y2=(int(selection[k]) for k in ('left','top','right','bottom'))
        mw,mh=(int(selection[k]) for k in ('mask_width','mask_height'))
        data=selection['mask_base64']
    except (KeyError,ValueError,TypeError) as exc:
        raise ValueError('SAM mask data is incomplete.') from exc
    if not (0<=x1<x2<=W and 0<=y1<y2<=H):
        raise ValueError('SAM selection box lies outside the current frame.')
    if not (0<mw<=W and 0<mh<=H and mw*mh<=MAX_MASK_BYTES):
        raise ValueError('SAM selection mask has invalid dimensions.')
    if not isinstance(data,str) or len(data)>((MAX_MASK_BYTES+2)//3*4+8):
        raise ValueError('SAM selection mask is too large.')
    try:
        raw=base64.b64decode(data,validate=True)
    except (ValueError,binascii.Error) as exc:
        raise ValueError('SAM mask is not valid base64.') from exc
    if len(raw)!=mw*mh or any(pixel not in (0,1) for pixel in raw):
        raise ValueError('SAM mask must contain one binary pixel per location.')
    roi=Image.frombytes('L',(mw,mh),bytes(255 if v else 0 for v in raw))
    if roi.size!=(x2-x1,y2-y1):
        roi=roi.resize((x2-x1,y2-y1),Image.Resampling.NEAREST)
    full=Image.new('L',(W,H),0)
    full.paste(roi,(x1,y1))
    if not full.getbbox():
        raise ValueError('SAM selected an empty mask. Choose another object.')
    return full


def process_layer(image_path: Path, selection: dict, operation: str, out_path: Path, *,
                  replacement_path: Path | None = None, tint: str = '#008d82') -> None:
    """Use mask for a real pixel operation. Never overwrite source."""
    if operation not in OPERATIONS:
        raise ValueError('Unknown SAM layer operation.')
    with Image.open(image_path) as image:
        image.load()
        image=ImageOps.exif_transpose(image).convert('RGBA')
    if image.width*image.height>MAX_PIXELS:
        raise ValueError('Frame exceeds the 16 megapixel layer editor limit.')
    mask=decode_mask(selection,image.size)
    base=image.convert('RGB')
    if operation in REPLACEMENT_OPERATIONS and replacement_path is None:
        raise ValueError('Upload a replacement picture first.')
    if operation in {'target_tint', 'background_tint'}:
        import re
        if not isinstance(tint, str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', tint):
            raise ValueError('Choose a six-digit hexadecimal color.')
        rgb=tuple(bytes.fromhex(tint[1:]))
        overlay=Image.new('RGB',image.size,rgb)
        tinted=Image.blend(base,overlay,0.55)
        apply_mask=mask if operation=='target_tint' else ImageOps.invert(mask)
        result=Image.composite(tinted,base,apply_mask).convert('RGBA')
    elif operation=='erase_transparent':
        result=image.copy()
        alpha=ImageChops.multiply(image.getchannel('A'),ImageOps.invert(mask))
        result.putalpha(alpha)
    elif operation in REPLACEMENT_OPERATIONS:
        # This is a fast 2D composite; depth, perspective and occluded detail are
        # not reconstructed. The input reference remains private and read-only.
        with Image.open(replacement_path) as ref:
            if ref.width*ref.height>MAX_PIXELS:
                raise ValueError('Replacement image is too large.')
            ref=ImageOps.exif_transpose(ref).convert('RGBA')
        if operation=='replace_subject':
            bounds=mask.getbbox()
            if not bounds:
                raise ValueError('Select the object again.')
            x1,y1,x2,y2=bounds
            patch=ImageOps.fit(ref,(x2-x1,y2-y1),method=Image.Resampling.LANCZOS,centering=(0.5,0.5))
            replacement=Image.new('RGBA',image.size,(0,0,0,0))
            replacement.paste(patch,(x1,y1))
            alpha=ImageChops.multiply(mask,replacement.getchannel('A'))
        else:
            replacement=ImageOps.fit(ref,image.size,method=Image.Resampling.LANCZOS)
            alpha=ImageChops.multiply(ImageOps.invert(mask),replacement.getchannel('A'))
        result=Image.composite(replacement,image,alpha)
    elif operation=='erase_heal':
        # SAM supplies the exact target region; Telea inpainting estimates nearby
        # pixels. It is intentionally local/offline and cannot reconstruct unseen
        # structures or complicated objects. The original image is never replaced.
        try:
            import cv2
            import numpy as np
        except ImportError as exc:
            raise ValueError('Local Remove & Heal requires opencv-python-headless. Install project requirements and retry.') from exc
        pixels=np.asarray(base)
        selected=np.asarray(mask,dtype=np.uint8)
        expanded=cv2.dilate(selected,np.ones((5,5),np.uint8),iterations=1)
        filled=cv2.inpaint(cv2.cvtColor(pixels,cv2.COLOR_RGB2BGR),expanded,5,cv2.INPAINT_TELEA)
        result=Image.fromarray(cv2.cvtColor(filled,cv2.COLOR_BGR2RGB),'RGB').convert('RGBA')
    elif operation=='isolate':
        result=image.copy();result.putalpha(ImageChops.multiply(image.getchannel('A'),mask))
    elif operation=='focus':
        blurred=base.filter(ImageFilter.GaussianBlur(11))
        result=Image.composite(base,blurred,mask).convert('RGBA')
    elif operation=='accent':
        enhanced=ImageEnhance.Color(base).enhance(2.1)
        enhanced=ImageEnhance.Contrast(enhanced).enhance(1.17)
        result=Image.composite(enhanced,base,mask).convert('RGBA')
    elif operation=='silhouette':
        shadow=Image.new('RGB',image.size,(23,31,42))
        result=Image.composite(shadow,base,mask).convert('RGBA')
    elif operation=='soften':
        blurred=base.filter(ImageFilter.GaussianBlur(10))
        result=Image.composite(blurred,base,mask).convert('RGBA')
    else:  # outlined target for director's visual selection notes
        dilation=mask.filter(ImageFilter.MaxFilter(9))
        border=ImageChops.subtract(dilation,mask.filter(ImageFilter.MinFilter(3)))
        ink=Image.new('RGBA',image.size,(67,225,222,255))
        result=Image.composite(ink,image,border)
    out_path.parent.mkdir(parents=True,exist_ok=True)
    result.save(out_path,format='PNG',optimize=True)
