"""Small, original compositional storyboard thumbnails, generated without inference.

Used only as a clearly identified draft when a shot has no image or drawing.
A diagram is not a photograph or a Muse result. Cinematography metadata remains editable.
"""
from __future__ import annotations
from reportlab.lib import colors

INK=colors.HexColor('#254b50'); LINE=colors.HexColor('#91b4ae'); LIGHT=colors.HexColor('#e5f0ec'); TEAL=colors.HexColor('#137b79')

def draw_schematic(canvas,x:float,y:float,w:float,h:float,shot:dict):
    """Draw a self-contained 16:9 frame inside a canvas bounding box."""
    c=canvas;c.saveState()
    try:
        c.translate(x,y)
        clip=c.beginPath();clip.rect(0,0,w,h);c.clipPath(clip,stroke=0,fill=0)
        c.setFillColor(LIGHT);c.rect(0,0,w,h,fill=1,stroke=0)
        kind=str(shot.get('shot_type','wide')).lower()
        light=str(shot.get('lighting_plan','')).lower()
        scene=str(shot.get('description','')).lower()
        # Geographical horizon and visual perspective guides.
        c.setStrokeColor(LINE);c.setLineWidth(.5)
        for a in (w/3,2*w/3):c.line(a,0,a,h)
        for b in (h/3,2*h/3):c.line(0,b,w,b)
        c.setStrokeColor(INK)
        if 'night' in light:
            c.setFillColor(colors.HexColor('#244c50'));c.rect(0,h*.7,w,h*.3,fill=1,stroke=0)
            c.setStrokeColor(colors.HexColor('#8fbab7'));c.circle(w*.8,h*.83,min(w,h)*.06,stroke=1,fill=0)
        else:
            c.line(0,h*.49,w,h*.49)
            c.setFillColor(colors.HexColor('#cde1d9'));c.rect(0,0,w,h*.25,fill=1,stroke=0)
        # Motivated staging, simply indicated for editorial discussion.
        def actor(cx,base,scale):
            r=min(w,h)*.075*scale
            c.setStrokeColor(INK);c.setLineWidth(1.3)
            c.circle(cx,base+r*5.3,r,stroke=1,fill=0)
            c.line(cx,base+r*4.3,cx,base+r*1.8)
            c.line(cx,base+r*3.7,cx-r*1.6,base+r*2.6)
            c.line(cx,base+r*3.7,cx+r*1.6,base+r*2.6)
            c.line(cx,base+r*1.8,cx-r*1.25,base)
            c.line(cx,base+r*1.8,cx+r*1.25,base)
        if 'insert' in kind or 'detail' in kind:
            c.setStrokeColor(TEAL);c.setLineWidth(2);c.roundRect(w*.33,h*.28,w*.35,h*.42,5,fill=0,stroke=1)
            c.circle(w*.5,h*.49,min(w,h)*.085,stroke=1,fill=0)
            c.line(w*.35,h*.3,w*.65,h*.7)
        elif 'close' in kind:
            c.setStrokeColor(INK);c.setLineWidth(2)
            c.ellipse(w*.33,h*.13,w*.7,h*.9,stroke=1,fill=0)
            c.circle(w*.44,h*.57,2,fill=1,stroke=0);c.circle(w*.61,h*.57,2,fill=1,stroke=0)
            c.line(w*.46,h*.35,w*.6,h*.35)
        elif 'shoulder' in kind:
            c.setFillColor(colors.HexColor('#d0ddd7'));c.ellipse(-w*.12,-h*.3,w*.4,h*.75,fill=1,stroke=1)
            actor(w*.72,h*.12,.75)
            c.setStrokeColor(TEAL);c.line(w*.25,h*.52,w*.63,h*.52)
        else:
            scale=.75 if ('wide' in kind or 'establish' in kind) else 1.0
            actor(w*.38,h*.12,scale);actor(w*.67,h*.12,scale*.9)
            if 'tracking' in kind:
                c.setStrokeColor(TEAL);c.setLineWidth(1.5);c.line(w*.13,h*.16,w*.27,h*.16)
                c.line(w*.24,h*.2,w*.27,h*.16);c.line(w*.24,h*.12,w*.27,h*.16)
            if 'street' in scene or 'road' in scene:
                c.line(w*.50,h*.16,w*.58,h*.04)
        c.setStrokeColor(INK);c.setLineWidth(1);c.rect(1,1,w-2,h-2,fill=0,stroke=1)
        c.setFillColor(INK);c.setFont('Helvetica',min(7,h*.075))
        c.drawString(6,5,f"DRAFT COMPOSITION / {str(shot.get('shot_type','Shot'))[:21].upper()}")
    finally:c.restoreState()
