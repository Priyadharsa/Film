"""One-project filmmaking workflow. Run locally; private files stay off public Git."""
from __future__ import annotations
import io
import json
import logging
import re
import shutil
import uuid
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field
from PIL import Image, ImageOps

from .screenplay_parser import parse_scenes, extract_pdf_text, normalize, _shot_template, page_records, connect_pages
from .storyboard_planner import expand_scenes
from .project_store import ProjectStore, find_scene, find_shot
from .production_pdf import export_production_book
from .comic_pdf import export_comic_pdf
from .shot_grammar import PATTERNS,create_pattern
from .schemas import SceneBreakdown, Shot, ReferenceUsage
from .styles import resolve_style
from .art_layers import process_layer, OPERATIONS, REPLACEMENT_OPERATIONS
from .meta_client import generate_storyboard_image, analyze_screenplay
from .auth import check_asset

logger=logging.getLogger('framepilot.workspace')
ROOT=Path(__file__).resolve().parent.parent
GENERATED=ROOT/'static'/'generated'
REFERENCES=ROOT/'private_uploads'
STORE=ProjectStore(REFERENCES)
router=APIRouter(prefix='/api/projects', tags=['Project workspace'])
MAX_UPLOAD=55*1024*1024
MAX_IMAGE=8*1024*1024


def get_project(pid):
    project=STORE.get(pid)
    if project is None:raise HTTPException(404,'Project not found')
    if not project.get('pages') and project.get('scenes'):
        # Convert v0.7 projects to editable logical pages, without changing shot IDs.
        def migrate(p):
            p['pages']=[{'number':i,'text':s['slugline']+'\n\n'+s['text'],
                         'scene_ids':[s['id']],'notes':'','migrated_from_scene':True}
                        for i,s in enumerate(p['scenes'],1)]
        project=STORE.mutate(pid,migrate)
    return project


def _locate(project,sid,shid=None):
    try:
        if shid is not None:return find_shot(project,sid,shid)
        return find_scene(project,sid)
    except KeyError as exc:
        raise HTTPException(404,str(exc)) from exc


def _update(pid, fn):
    try:return STORE.mutate(pid,fn)
    except KeyError as exc:raise HTTPException(404,str(exc)) from exc


def _generated_url_ok(url):
    return url is None or bool(isinstance(url,str) and re.fullmatch(r'/static/generated/shot-[0-9]+-[a-f0-9]{10}\.(png|jpg|webp)',url))


class ShotPatch(BaseModel):
    name: Optional[str]=Field(None,max_length=100)
    shot_type:Optional[str]=Field(None,max_length=70)
    camera_angle:Optional[str]=Field(None,max_length=100)
    camera_movement:Optional[str]=Field(None,max_length=100)
    description:Optional[str]=Field(None,max_length=1600)
    purpose:Optional[str]=Field(None,max_length=700)
    notes:Optional[str]=Field(None,max_length=1000)
    duration_s:Optional[float]=Field(None,ge=0,le=900)
    lens_mm:Optional[int]=Field(None,ge=12,le=350)
    status:Optional[str]=Field(None,pattern='^(Draft|Review|Approved)$')
    style_preset:Optional[str]=Field(None,max_length=40)
    style_custom:Optional[str]=Field(None,max_length=300)
    references:Optional[list[ReferenceUsage]]=Field(None,max_length=8)
    image_url:Optional[str]=None
    sketch_url:Optional[str]=None
    camera:Optional[dict[str,Any]]=None

class RenderRequest(BaseModel):
    use_sketch:bool=True
    style_preset:Optional[str]=Field(None,max_length=40)
    style_custom:str=Field('',max_length=300)

class ScenePatch(BaseModel):
    slugline:Optional[str]=Field(None,max_length=160)
    text:Optional[str]=Field(None,max_length=150000)
    notes:Optional[str]=Field(None,max_length=2000)
    approved:Optional[bool]=None


@router.get('')
def projects_index():return {'projects':STORE.list()}

@router.post('/import')
async def import_script(file:UploadFile|None=File(None),title:str=Form(''),screenplay_text:str=Form(''),ocr:bool=Form(True)):
    if not file and not screenplay_text.strip():
        raise HTTPException(422,'Choose a screenplay PDF or paste screenplay text.')
    source={'filename':'Pasted screenplay','pages':None,'ocr_used':False}
    if file:
        raw=await file.read(MAX_UPLOAD+1)
        if len(raw)>MAX_UPLOAD:raise HTTPException(413,'Screenplay PDF exceeds 55 MB.')
        try:content, meta=extract_pdf_text(raw,ocr=ocr,include_pages=True)
        except ValueError as exc:raise HTTPException(422,str(exc)) from exc
        source={'filename':Path(file.filename or 'screenplay.pdf').name[:128],**meta}
        if not title.strip():title=Path(file.filename or 'Untitled Film').stem
    else:content=normalize(screenplay_text)
    try:
        texts=source.pop('page_texts',None)
        pages=page_records(content,texts)
        scenes=parse_scenes(content,[pg['text'] for pg in pages])
        coverage=expand_scenes(scenes,fresh=True)
        source['storyboard_plan']=coverage
        pages=connect_pages(pages,scenes)
    except ValueError as exc:raise HTTPException(422,str(exc)) from exc
    project=STORE.create(title.strip() or 'Untitled Film',scenes,source,pages=pages)
    return {'project':project,'message':f"Imported {len(scenes)} scenes. Shot coverage is a working draft; review before production."}


@router.post('/{pid}/plan-entire-book')
def plan_entire_book(pid:str):
    """Idempotent, free draft generation. No Meta API calls are made."""
    stats={}
    def expand(project):
        nonlocal stats
        try:stats=expand_scenes(project['scenes'])
        except ValueError as exc:raise HTTPException(422,str(exc)) from exc
        project.setdefault('source',{})['storyboard_plan']=stats
    project=_update(pid,expand)
    return {'project':project,'coverage':stats,'model_calls':0}


class PagePatch(BaseModel):
    text: str = Field(max_length=30000)
    notes: str = Field(default='',max_length=2000)

@router.get('/{pid}/pages')
def pages_index(pid:str,offset:int=0,limit:int=100):
    """Bounded page metadata endpoint; keeps page navigation independent of a giant scene list."""
    project=get_project(pid)
    pages=project.get('pages',[])
    if offset<0 or limit<1 or limit>200:raise HTTPException(422,'Invalid page range')
    batch=[{'number':p['number'],'scene_ids':p.get('scene_ids',[]),'preview':p.get('text','')[:120]}
           for p in pages[offset:offset+limit]]
    return {'total':len(pages),'pages':batch}

@router.get('/{pid}/pages/{number}')
def page_detail(pid:str,number:int):
    project=get_project(pid)
    pages=project.get('pages',[])
    if number<1 or number>len(pages):raise HTTPException(404,'Page not found')
    return {'page':pages[number-1]}

@router.patch('/{pid}/pages/{number}')
def page_patch(pid:str,number:int,body:PagePatch):
    def apply(p):
        pages=p.get('pages',[])
        if number<1 or number>len(pages):raise HTTPException(404,'Page not found')
        pages[number-1]['text']=body.text
        pages[number-1]['notes']=body.notes
        pages[number-1]['edited']=True
        # Keep related scene drafts intact. Re-scene detection requires deliberate user action.
    updated=_update(pid,apply)
    return {'page':updated['pages'][number-1], 'revision':updated['revision']}

@router.post('/{pid}/rebuild-scenes')
def rebuild_scenes(pid:str):
    """Re-detect scene boundaries from edited book pages, retaining known shot IDs.

    Users explicitly request this destructive interpretation; it never runs
    while merely typing in a page. Match heading + occurrence to preserve shots.
    """
    def apply(p):
        pages=p.get('pages',[])
        if not pages:raise HTTPException(422,'This project has no imported pages.')
        texts=[page.get('text','') for page in pages]
        total='\n\n'.join(texts)
        newly=parse_scenes(total,texts)
        existing={}
        for old in p['scenes']:
            existing.setdefault(old['slugline'],[]).append(old)
        for new in newly:
            matches=existing.get(new['slugline'],[])
            if matches:
                old=matches.pop(0)
                new['id']=old['id']
                new['shots']=old['shots']
                new['notes']=old.get('notes','')
                new['approved']=False
        p['scenes']=newly
        connect_pages(pages,newly)
    result=_update(pid,apply)
    return {'project':result}

@router.post('/demo')
def demo_project():
    script='''INT. CLOSED TEA SHOP - NIGHT

The last fluorescent tube flickers above a metal counter. Rain taps the shutter.

MIRA, wearing a rain-soaked coat, slides a cassette into a steel box.

ARUN steps inside, hesitates at the doorway, then approaches the table.

MIRA
I thought you destroyed it.

ARUN
There is one copy left.

She looks toward the door. Someone is listening.

EXT. TEA SHOP - NIGHT

An unseen figure stands across the road beneath a narrow awning. Headlights sweep the wet pavement. The figure turns and disappears into the crowd.'''
    pages=page_records(script)
    scenes=parse_scenes(script,[pg['text'] for pg in pages])
    # Original demo sketches are bundled and copied into the non-destructive frame store.
    originals=[(0,0,'demo-master.png'),(0,2,'demo-cassette.png'),(1,0,'demo-street.png')]
    demo_dir=ROOT/'static'/'demo'
    GENERATED.mkdir(parents=True,exist_ok=True)
    for scene_idx,shot_idx,src_name in originals:
        src=demo_dir/src_name
        if not src.is_file():continue
        sh=scenes[scene_idx]['shots'][shot_idx]
        filename=f"shot-{sh['number']}-{uuid.uuid4().hex[:10]}.png"
        shutil.copyfile(src,GENERATED/filename)
        sh['image_url']='/static/generated/'+filename
        sh['history']=[{'kind':'Original illustrated demo','url':sh['image_url']}]
        sh['status']='Review'
    project=STORE.create('The Last Signal · Demo',scenes,{'filename':'Original demo screenplay','pages':None,'ocr_used':False},pages=connect_pages(pages,scenes))
    return {'project':project}

@router.get('/{pid}')
def project_detail(pid:str):return {'project':get_project(pid)}

class NewScene(BaseModel):
    slugline:str=Field(min_length=3,max_length=160)
    text:str=Field(default='',max_length=150000)
    source_page:Optional[int]=Field(default=None,ge=1)

@router.post('/{pid}/scenes')
def create_scene(pid:str,body:NewScene):
    def apply(p):
        if len(p['scenes'])>=10000:raise HTTPException(422,'This volume has reached 10,000 scenes.')
        scene=parse_scenes(f"{body.slugline.strip()}\n\n{body.text}")[0]
        scene['slugline']=body.slugline.strip()
        scene['number']=len(p['scenes'])+1
        if body.source_page is not None:
            pages=p.get('pages',[])
            if body.source_page>len(pages):raise HTTPException(422,'Source page is outside this book.')
            scene['source_pages']=[body.source_page]
            pages[body.source_page-1].setdefault('scene_ids',[]).append(scene['id'])
        p['scenes'].append(scene)
    return {'project':_update(pid,apply)}

@router.patch('/{pid}/scenes/{sid}')
def patch_scene(pid:str,sid:str,body:ScenePatch):
    updates=body.model_dump(exclude_unset=True)
    def apply(p):
        sc=_locate(p,sid)
        sc.update(updates)
        sc['approved']=False if ('text' in updates or 'slugline' in updates) else sc['approved']
    return {'project':_update(pid,apply)}

@router.patch('/{pid}/scenes/{sid}/shots/{shid}')
def patch_shot(pid:str,sid:str,shid:str,body:ShotPatch):
    update=body.model_dump(exclude_unset=True)
    if 'style_preset' in update and update['style_preset'] is not None:
        try:resolve_style(update['style_preset'])
        except ValueError as exc:raise HTTPException(422,str(exc)) from exc
    for k in ['image_url','sketch_url']:
        if k in update and not _generated_url_ok(update[k]):raise HTTPException(422,'Only locally generated images may be assigned to shots.')
    if 'camera' in update and update['camera'] is not None:
        camera=update['camera']
        if len(json.dumps(camera))>24000:raise HTTPException(422,'Camera setup is too large.')
    if 'references' in update and update['references'] is not None:
        # Pydantic model_dump() already converted ReferenceUsage instances into dicts.
        # v0.8.2 attempted `.reference_id` on these dicts, causing HTTP 500
        # on every image-reference attachment.
        vals=update['references']
        ids=[item['reference_id'] for item in vals]
        if len(set(ids))!=len(ids):
            raise HTTPException(422,'Duplicate reference IDs are not allowed.')
        for reference_id in ids:
            check_asset('reference', reference_id)
            if not any(path.is_file() for path in REFERENCES.glob(f'{reference_id}.*')
                       if path.suffix.lower() in ('.png','.jpg','.webp')):
                raise HTTPException(404,'Reference image not found; upload it again.')
        # Keep normalized dicts, so SQLite JSON serialization is reliable.
        update['references']=vals
    def apply(p):
        sc,shot=_locate(p,sid,shid)
        for key,value in update.items():
            if key in ('image_url','sketch_url') and value and shot.get(key)!=value:
                if key == 'image_url':
                    shot.pop('muse_last_response_id',None)
                    shot.pop('muse_last_image_url',None)
                shot.setdefault('history',[]).append({'kind':key,'url':value})
                shot['history']=shot['history'][-30:]
            shot[key]=value
        sc['approved']=False
    return {'project':_update(pid,apply)}

class MuseRefineRequest(BaseModel):
    instruction: str = Field(min_length=5, max_length=600)
    target: str = Field(default='', max_length=100)
    selected_box: tuple[int,int,int,int] | None = None
    selection: dict[str,Any] | None = None
    style_preset: str | None = Field(default=None,max_length=40)
    style_custom: str = Field(default='',max_length=300)


@router.post('/{pid}/scenes/{sid}/shots/{shid}/muse-refine')
def refine_saved_shot(pid:str,sid:str,shid:str,body:MuseRefineRequest):
    """Keep one ongoing Muse image conversation scoped to an owned saved shot.

    Restore an older revision or use a local edit and chaining is reset safely.
    Every successful call saves a new revision. Failed calls leave the shot intact.
    """
    project=get_project(pid)  # account ownership enforced by ProjectStore
    scene,shot=_locate(project,sid,shid)
    source=shot.get('image_url')
    if not _generated_url_ok(source) or not source:
        raise HTTPException(422,'Generate, draw, or capture this shot before refining it.')
    image_path=GENERATED / source.rsplit('/',1)[-1]
    if not image_path.is_file():raise HTTPException(404,'Current shot image was not found.')
    from .auth import auth_on
    if auth_on():check_asset('generated',image_path.name)
    from .image_edit import edit_storyboard_frame
    from .art_layers import decode_mask
    from .meta_client import _image_data_url
    from PIL import Image
    from .styles import resolve_style
    box=body.selected_box
    if body.selection is not None or box is not None:
        with Image.open(image_path) as im:
            size=im.size
            if body.selection is not None:
                try:decode_mask(body.selection,size)
                except ValueError as exc:raise HTTPException(422,str(exc)) from exc
            if box is not None and not (0<=box[0]<box[2]<=size[0] and 0<=box[1]<box[3]<=size[1]):
                raise HTTPException(422,'SAM selection lies outside the current shot. Detect again.')
    try:style=resolve_style(body.style_preset,body.style_custom) if body.style_preset else ''
    except ValueError as exc:raise HTTPException(422,str(exc)) from exc
    references=[]
    for ref in shot.get('references',[]):
        rid=ref['reference_id']
        check_asset('reference',rid)
        found=next((path for path in (REFERENCES/(rid+ext) for ext in ('.png','.jpg','.webp')) if path.is_file()),None)
        if found is None:raise HTTPException(404,'An attached visual reference is missing.')
        references.append({'path':found,'role':ref.get('role','other'),
                           'label':ref.get('label','Reference'),
                           'instruction':ref.get('instruction','')})
    chain=(shot.get('muse_last_response_id') if shot.get('muse_last_image_url')==source else None)
    try:
        filename,model,response_id=edit_storyboard_frame(
            image_path,body.instruction,body.target,box,
            reference_images=references,style_instruction=style,selection=body.selection,
            previous_response_id=chain,include_response_id=True)
    except ValueError as exc:raise HTTPException(422,str(exc)) from exc
    except Exception as exc:
        logger.exception('Muse refinement failed for shot=%s',shid)
        message=str(exc).lower()
        if 'auth' in message or '401' in message or 'invalid_api_key' in message:
            raise HTTPException(401,'Meta authentication failed. Check your API key.') from exc
        if '429' in message or 'rate limit' in message or 'quota' in message:
            raise HTTPException(429,'Meta rate limit or usage quota reached. Retry later.') from exc
        raise HTTPException(502,'Muse editing failed; your original frame is unchanged.') from exc
    from .auth import register_asset
    register_asset('generated',filename)
    url='/static/generated/'+filename
    def commit(p):
        sc,sh=_locate(p,sid,shid)
        if sh.get('image_url')!=source:
            raise HTTPException(409,'Shot changed during editing. Your original is safe; reopen the shot.')
        sh.setdefault('history',[]).append({'kind':'Muse edit · '+body.instruction[:75], 'url':url})
        sh['history']=sh['history'][-100:]
        sh['image_url']=url
        sh['muse_last_response_id']=response_id
        sh['muse_last_image_url']=url
        sh.setdefault('muse_turns',[]).append({'instruction':body.instruction, 'image_url':url})
        sh['muse_turns']=sh['muse_turns'][-100:]
        sh['status']='Review'
        sc['approved']=False
    changed=_update(pid,commit)
    return {'project':changed,'image_url':url,'model':model,'chained':bool(chain),
            'message':'Muse refinement saved as a new shot version.'}


@router.post('/{pid}/scenes/{sid}/shots')
def add_shot(pid:str,sid:str):
    def apply(p):
        sc=_locate(p,sid)
        if len(sc['shots'])>=500:raise HTTPException(422,'Maximum 500 shots per scene.')
        shot=_shot_template(sc['slugline'],sc['text'],len(sc['shots']))
        sc['shots'].append(shot)
        sc['approved']=False
    return {'project':_update(pid,apply)}

@router.get('/shot-patterns/list')
def shot_patterns():
    return {'patterns':[{'id':name,'label':name.title(),'shots':len(seq)}
                        for name,seq in PATTERNS.items()]}

@router.post('/{pid}/scenes/{sid}/shot-patterns/{name}')
def apply_shot_pattern(pid:str,sid:str,name:str):
    if name not in PATTERNS:raise HTTPException(404,'Unknown shot sequence.')
    def apply(p):
        sc=_locate(p,sid)
        if len(sc['shots'])+len(PATTERNS[name])>500:
            raise HTTPException(422,'Maximum 500 shots per scene.')
        sc['shots'].extend(create_pattern(sc['slugline'],sc['text'],len(sc['shots']),name))
        sc['approved']=False
    return {'project':_update(pid,apply)}

@router.delete('/{pid}/scenes/{sid}/shots/{shid}')
def delete_shot(pid:str,sid:str,shid:str):
    def apply(p):
        sc,shot=_locate(p,sid,shid)
        sc['shots']=[x for x in sc['shots'] if x['id']!=shid]
        for i,sh in enumerate(sc['shots']):sh['number']=i+1
        sc['approved']=False
    return {'project':_update(pid,apply)}

@router.post('/{pid}/scenes/{sid}/ai-breakdown')
def ai_scene_breakdown(pid:str,sid:str):
    project=get_project(pid);sc=_locate(project,sid)
    screenplay=f"{sc['slugline']}\n\n{sc['text']}"[:14000]
    if len(screenplay)<40:raise HTTPException(422,'Add enough screenplay text first.')
    try:analysis=analyze_screenplay(screenplay)
    except ModuleNotFoundError as exc:
        logger.exception('Required AI client dependency missing')
        raise HTTPException(503,'AI client dependency is missing. Run START_FRAMEPILOT.bat to install the project dependencies.') from exc
    except Exception as exc:
        logger.exception('Model scene breakdown failed')
        message=str(exc)
        if 'MODEL_API_KEY' in message or 'API key' in message:
            raise HTTPException(503,'Meta API key is missing or rejected. Check your local .env and Meta account access.') from exc
        raise HTTPException(502,'Muse Spark breakdown failed. Check Meta API access, credits and model permissions. See the PowerShell server log.') from exc
    def apply(p):
        target=_locate(p,sid)
        new=[]
        for i,item in enumerate(analysis.shots[:10]):
            sh=_shot_template(target['slugline'],target['text'],i)
            sh.update({'name':item.beat[:100] or sh['name'],'shot_type':item.shot_type,
                'camera_angle':item.camera_angle,'camera_movement':item.camera_movement,
                'description':item.visual_description,'purpose':item.director_purpose,
                'image_prompt':item.image_prompt})
            new.append(sh)
        target['shots']=new
        target['source']='Muse Spark (review required)';target['approved']=False
    return {'project':_update(pid,apply)}


def _resolved_refs(items):
    refs=[];seen=set()
    for r in items:
        ref=ReferenceUsage.model_validate(r)
        if ref.reference_id in seen:raise HTTPException(422,'Duplicate reference IDs.')
        seen.add(ref.reference_id)
        hits=list(REFERENCES.glob(ref.reference_id+'.*'))
        hits=[p for p in hits if p.suffix.lower() in ('.png','.jpg','.webp') and p.is_file()]
        if not hits:raise HTTPException(404,'Reference not found. Upload it again.')
        check_asset('reference',ref.reference_id)
        refs.append({'path':hits[0],'role':ref.role,'label':ref.label,'instruction':ref.instruction})
    return refs

class SAMLayerRequest(BaseModel):
    source_filename:str=Field(pattern=r'^shot-[0-9]+-[a-f0-9]{10}\.(?:png|jpg|webp)$')
    selection:dict[str,Any]
    operation:str=Field(max_length=32)
    replacement_reference_id:Optional[str]=Field(None,pattern=r'^[a-f0-9]{32}$')
    tint:str=Field('#008d82',pattern=r'^#[0-9a-fA-F]{6}$')

@router.post('/{pid}/scenes/{sid}/shots/{shid}/sam-layer')
def sam_layer(pid:str,sid:str,shid:str,body:SAMLayerRequest):
    """Apply a real SAM raster selection locally; retain all prior versions.

    Generative replacement/removal is intentionally handled by Muse Image,
    which accepts selection hints but does not guarantee hard-mask inpainting.
    """
    project=get_project(pid)
    _scene,shot=_locate(project,sid,shid)
    source_url=shot.get('image_url')
    if not source_url or source_url.rsplit('/',1)[-1]!=body.source_filename:
        raise HTTPException(409,'This frame has changed. Detect the object again before editing.')
    if body.operation not in OPERATIONS:
        raise HTTPException(422,'Choose a supported SAM operation.')
    original=GENERATED/body.source_filename
    if not original.is_file():
        raise HTTPException(404,'Source frame not found.')
    replacement_path=None
    if body.operation in REPLACEMENT_OPERATIONS:
        if not body.replacement_reference_id:
            raise HTTPException(422,'Upload a replacement image before applying this effect.')
        # Request-scoped ownership protects images from another signed-in user.
        check_asset('reference',body.replacement_reference_id)
        matches=[p for p in REFERENCES.glob(f'{body.replacement_reference_id}.*') if p.suffix in ('.png','.jpg','.webp')]
        if len(matches)!=1:
            raise HTTPException(404,'Replacement picture is not available. Upload it again.')
        replacement_path=matches[0]
    filename=f"shot-{shot['number']}-{uuid.uuid4().hex[:10]}.png"
    output=GENERATED/filename
    try:
        process_layer(original,body.selection,body.operation,output,
                      replacement_path=replacement_path,tint=body.tint)
    except (ValueError,OSError) as exc:
        output.unlink(missing_ok=True)
        raise HTTPException(422,str(exc)) from exc
    new_url='/static/generated/'+filename
    def apply(p):
        sc,sh=_locate(p,sid,shid)
        if sh.get('image_url')!=source_url:
            raise HTTPException(409,'Shot changed during edit; reload and retry.')
        sh.setdefault('history',[]).append({'kind':'SAM layer · '+body.operation,'url':new_url})
        sh['history']=sh['history'][-30:]
        sh['image_url']=new_url
        sc['approved']=False
    try:
        return {'project':_update(pid,apply),'image_url':new_url,'method':'local-sam-layer'}
    except Exception:
        output.unlink(missing_ok=True)
        raise


@router.post('/{pid}/scenes/{sid}/shots/{shid}/sam-stage-cutout')
def sam_stage_cutout(pid:str,sid:str,shid:str,body:SAMLayerRequest):
    """Extract a masked foreground to an independent transparent stage card.

    This is a camera-facing 2.5D card, not a rigged volumetric character.
    The current storyboard frame and its history are unchanged.
    """
    project=get_project(pid)
    _scene,shot=_locate(project,sid,shid)
    source_url=shot.get('image_url')
    if not source_url or source_url.rsplit('/',1)[-1]!=body.source_filename:
        raise HTTPException(409,'Frame changed. Detect the object again before staging it.')
    original=GENERATED/body.source_filename
    if not original.is_file(): raise HTTPException(404,'Source frame not found.')
    filename=f"shot-{shot['number']}-{uuid.uuid4().hex[:10]}.png"
    output=GENERATED/filename
    try: process_layer(original,body.selection,'isolate',output)
    except (ValueError,OSError) as exc:
        output.unlink(missing_ok=True)
        raise HTTPException(422,str(exc)) from exc
    from .auth import register_asset
    register_asset('generated',filename)
    return {'cutout_url':'/static/generated/'+filename,
            'source_frame':source_url,'kind':'cutout',
            'message':'Transparent actor/object card ready. Position it in Cinema 3D, then Save scene.'}

@router.post('/{pid}/scenes/{sid}/shots/{shid}/render')
def render_shot(pid:str,sid:str,shid:str,request:RenderRequest):
    project=get_project(pid); scene,shot=_locate(project,sid,shid)
    try:style=resolve_style(request.style_preset or shot.get('style_preset','graphite'),
                            request.style_custom if request.style_preset else shot.get('style_custom',''))
    except ValueError as exc:raise HTTPException(422,str(exc)) from exc
    refs=_resolved_refs(shot.get('references',[]))
    if request.use_sketch and shot.get('sketch_url'):
        name=shot['sketch_url'].split('/')[-1]
        sketch=GENERATED/name
        if sketch.is_file():
            if len(refs)>=8:raise HTTPException(422,'Maximum 8 references including the drawing. Remove one before generating.')
            refs.append({'path':sketch,'role':'composition','label':'Director hand-drawn composition',
                         'instruction':'Treat this drawing as the spatial and camera blocking guide. Respect its arrangement, not its incidental marks.'})
    cam=shot.get('camera') or {}
    geometry=f"Geometry guide: camera position ({cam.get('x',0)}, {cam.get('y',1.65)}, {cam.get('z',5.7)}) metres, pan {cam.get('pan',0)} degrees, tilt {cam.get('tilt',-3)} degrees, {shot.get('lens_mm',35)}mm full-frame lens. Actor blocking: {json.dumps(cam.get('actors',[]))[:600]}."
    text=f"{shot.get('description','')} {geometry}"
    image_shot=Shot(shot_number=shot['number'],beat=shot.get('name',''),shot_type=shot.get('shot_type',''),camera_angle=shot.get('camera_angle',''),camera_movement=shot.get('camera_movement',''),visual_description=text[:2000],director_purpose=shot.get('purpose',''),image_prompt=(shot.get('image_prompt') or text)[:2000])
    try:
        filename,model=generate_storyboard_image(shot=image_shot,scene_title=scene['slugline'],visual_style=style,
            output_dir=GENERATED,scene_summary=scene['text'][:1100],location_time=scene['slugline'],
            reference_images=refs)
    except ModuleNotFoundError as exc:
        logger.exception('Required AI client dependency missing')
        raise HTTPException(503,'AI client dependency is missing. Run START_FRAMEPILOT.bat to install project dependencies.') from exc
    except Exception as exc:
        logger.exception('Render failed')
        message=str(exc)
        if 'MODEL_API_KEY' in message or 'API key' in message:
            raise HTTPException(503,'Meta API key is missing or rejected. Check your local .env and Meta account access.') from exc
        raise HTTPException(502,'Muse Image generation failed. Check Meta API access, billing and model permissions. See the PowerShell server log.') from exc
    url='/static/generated/'+filename
    def apply(p):
        s,sh=_locate(p,sid,shid)
        sh['image_url']=url
        if request.style_preset:
            sh['style_preset']=request.style_preset;sh['style_custom']=request.style_custom
        sh.setdefault('history',[]).append({'kind':'AI render','url':url,'model':model})
        sh['history']=sh['history'][-30:]
        sh['status']='Review';s['approved']=False
    result=_update(pid,apply)
    return {'project':result,'image_url':url,'model':model}

@router.post('/{pid}/scenes/{sid}/shots/{shid}/artwork')
async def save_artwork(pid:str,sid:str,shid:str,file:UploadFile=File(...),kind:str=Form('sketch')):
    project=get_project(pid);sc,sh=_locate(project,sid,shid)
    if kind not in ('sketch','frame'):raise HTTPException(422,'kind must be sketch or frame')
    raw=await file.read(MAX_IMAGE+1)
    if len(raw)>MAX_IMAGE:raise HTTPException(413,'Image exceeds 8 MB.')
    try:
        with Image.open(io.BytesIO(raw)) as im:
            im.verify()
        with Image.open(io.BytesIO(raw)) as im:
            im=ImageOps.exif_transpose(im)
            if im.width*im.height>14_000_000:raise HTTPException(422,'Image is too large in pixel dimensions.')
            im=im.convert('RGB')
            out=io.BytesIO();im.save(out,'PNG',optimize=True)
    except HTTPException:raise
    except Exception as exc:raise HTTPException(415,'Upload a valid JPEG, PNG or WebP image.') from exc
    GENERATED.mkdir(parents=True,exist_ok=True)
    name=f"shot-{sh['number']}-{uuid.uuid4().hex[:10]}.png"
    (GENERATED/name).write_bytes(out.getvalue())
    url='/static/generated/'+name
    def apply(p):
        s,shot=_locate(p,sid,shid)
        shot['sketch_url' if kind=='sketch' else 'image_url']=url
        shot.setdefault('history',[]).append({'kind':'hand drawing' if kind=='sketch' else 'uploaded frame','url':url})
        shot['history']=shot['history'][-30:];shot['status']='Review';s['approved']=False
    return {'project':_update(pid,apply),'image_url':url}

def ensure_export_complete(project:dict):
    """Refuse a misleading 'complete' export from previously truncated scan imports."""
    source=project.get('source') or {}
    original=source.get('pages')
    try:original=int(original)
    except (TypeError,ValueError):return
    actual=len(project.get('pages') or [])
    if original>=9 and actual<original*.8:
        raise HTTPException(409,
            f'Only {actual} of {original} PDF screenplay pages were imported. Re-import the original PDF with automatic OCR before exporting a complete production book.')

def export_volume(project:dict, first:int=1, last:int=0):
    ensure_export_complete(project)
    total=len(project.get('scenes',[]))
    if total<1:raise HTTPException(422,'There are no screenplay scenes to export.')
    if first<1 or first>total:raise HTTPException(422,'Invalid first scene.')
    if last<=0 and total-first+1>250:
        raise HTTPException(422,'This film has more than 250 scenes. Use Complete screenplay ZIP for every scene, or specify an explicit 250-scene PDF volume.')
    if last<=0:last=min(total,first+249)
    if last<first or last-first>=250:raise HTTPException(422,'Export at most 250 scenes per PDF volume.')
    subset=dict(project)
    subset['scenes']=project['scenes'][first-1:last]
    return subset

@router.get('/{pid}/comic.pdf')
def comic_export(pid:str,from_scene:int=1,to_scene:int=0):
    project=export_volume(get_project(pid),from_scene,to_scene)
    try:
        blob=export_comic_pdf(project,GENERATED)
    except Exception as exc:
        logger.exception('Comic export failed for project %s',pid)
        raise HTTPException(500,'Could not build comic PDF. Inspect the PowerShell server log.') from exc
    return Response(blob,media_type='application/pdf',headers={
        'Content-Disposition':'attachment; filename="framepilot-comic-book.pdf"',
        'Cache-Control':'no-store'})

@router.get('/{pid}/export.pdf')
def export_pdf(pid:str,from_scene:int=1,to_scene:int=0):
    project=export_volume(get_project(pid),from_scene,to_scene)
    try:blob=export_production_book(project,GENERATED)
    except Exception as exc:
        logger.exception('Export failed')
        raise HTTPException(500,'Could not build production PDF. Inspect the server logs.') from exc
    filename=re.sub(r'[^a-zA-Z0-9_-]+','-',project['title']).strip('-')[:50] or 'film'
    return Response(blob,media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="{filename}-production-book.pdf"','Cache-Control':'no-store'})

@router.get('/{pid}/export.json')
def export_json(pid:str):
    project=get_project(pid)
    return Response(json.dumps(project,indent=2),media_type='application/json',headers={'Content-Disposition':'attachment; filename="framepilot-project.json"','Cache-Control':'no-store'})

@router.get('/{pid}/production-pack.zip')
def export_production_pack(pid:str,from_scene:int=1,to_scene:int=0):
    """Download every scene and referenced generated frame in one portable ZIP.

    PDF volumes have at most 250 scenes each. Explicit scene ranges retain the
    existing ability to export a selected volume, but the default covers all scenes.
    All files are generated on disk, and the ZIP is streamed to the client.
    """
    import tempfile, zipfile
    from fastapi.responses import FileResponse
    from starlette.background import BackgroundTask

    full=get_project(pid)
    ensure_export_complete(full)
    total=len(full.get('scenes',[]))
    if total<1:raise HTTPException(422,'There are no screenplay scenes to export.')
    if from_scene<1 or from_scene>total:raise HTTPException(422,'Invalid first scene.')
    # Omitted to_scene=0 means *the rest of the screenplay*, not 250 scenes.
    last=to_scene if to_scene>0 else total
    if last<from_scene or last>total:raise HTTPException(422,'Invalid last scene.')
    path=None
    try:
        with tempfile.NamedTemporaryFile(prefix='fp-production-',suffix='.zip',delete=False) as f:
            path=Path(f.name)
        name=re.sub(r'[^a-zA-Z0-9_-]+','-',full['title']).strip('-')[:50] or 'Film'
        ranges=[(i,min(last,i+249)) for i in range(from_scene,last+1,250)]
        artwork=set()
        missing=[]
        with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as z:
            for n,(first,end) in enumerate(ranges,1):
                volume=export_volume(full,first,end)
                suffix='' if len(ranges)==1 else f'-volume-{n:03d}'
                z.writestr(f'{name}/production-book{suffix}.pdf',export_production_book(volume,GENERATED))
                z.writestr(f'{name}/comic-book{suffix}.pdf',export_comic_pdf(volume,GENERATED))
            # Current selected frames, drawings and revisions are part of the
            # deliverable; the original editable project remains unmodified.
            for sc in full['scenes'][from_scene-1:last]:
                for sh in sc.get('shots',[]):
                    candidates=[sh.get('image_url'),sh.get('sketch_url')]
                    candidates += [h.get('url') for h in sh.get('history',[]) if isinstance(h,dict)]
                    for url in candidates:
                        if not isinstance(url,str) or not _generated_url_ok(url):continue
                        filename=url.rsplit('/',1)[-1]
                        if filename in artwork:continue
                        artwork.add(filename)
                        file=GENERATED/filename
                        if file.is_file() and file.stat().st_size<=25*1024*1024:
                            z.write(file,f'{name}/artwork/{filename}')
                        else:
                            missing.append(filename)
            from .production_hub import _pdf as _production_pdf
            for doc_type in ('call-sheet','shot-list','script-breakdown','shooting-schedule','contacts','tasks','calendar','moodboard'):
                try:z.writestr(f'{name}/planning/{doc_type}.pdf',_production_pdf(pid,doc_type))
                except Exception:logger.exception('Optional %s planning PDF not added',doc_type)
            z.writestr(f'{name}/project.json',json.dumps(full,indent=2,ensure_ascii=False))
            manifest={'project_id':pid,'total_scenes':total,'exported_scenes':last-from_scene+1,
                      'volumes':[{'first_scene':f,'last_scene':t} for f,t in ranges],
                      'artwork_files':len(artwork)-len(missing),'missing_artwork':sorted(missing)}
            z.writestr(f'{name}/manifest.json',json.dumps(manifest,indent=2))
            z.writestr(f'{name}/README.txt',
                'FRAMEPILOT COMPLETE PRODUCTION PACK\n\nPDF volumes include all selected screenplay scenes.\n'
                'The artwork folder includes generated frames and revisions available on this server.\n'
                'The full editable project.json contains the complete screenplay and shot plan.\n'
                'Check manifest.json for omitted or missing artwork.\n'
                'Original private reference uploads and credentials are not included.\n')
        return FileResponse(path,filename=f'{name}-production-pack.zip',media_type='application/zip',
                            background=BackgroundTask(lambda:path.unlink(missing_ok=True)),
                            headers={'Cache-Control':'no-store'})
    except Exception as exc:
        if path:path.unlink(missing_ok=True)
        logger.exception('Production pack failed for project=%s',pid)
        raise HTTPException(500,'Could not create the production pack; check the server log.') from exc
