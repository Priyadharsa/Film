from typing import List, Optional, Literal
from pydantic import BaseModel, Field, ConfigDict


class Character(BaseModel):
    model_config = ConfigDict(extra="ignore")
    name: str = "Unnamed character"
    description: str = ""
    objective: str = ""
    emotional_state: str = ""


class StoryBeat(BaseModel):
    model_config = ConfigDict(extra="ignore")
    beat_number: int = 1
    label: str = "Story beat"
    description: str = ""
    emotional_shift: str = ""


class Shot(BaseModel):
    model_config = ConfigDict(extra="ignore")
    shot_number: int = 1
    beat: str = ""
    shot_type: str = "Medium shot"
    camera_angle: str = "Eye level"
    camera_movement: str = "Static"
    visual_description: str = ""
    director_purpose: str = ""
    image_prompt: str = ""


class SceneBreakdown(BaseModel):
    model_config = ConfigDict(extra="ignore")
    scene_title: str = "Untitled scene"
    logline: str = ""
    genre_mood: str = ""
    scene_summary: str = ""
    location_time: str = ""
    characters: List[Character] = Field(default_factory=list)
    props: List[str] = Field(default_factory=list)
    story_beats: List[StoryBeat] = Field(default_factory=list)
    shots: List[Shot] = Field(default_factory=list)


class AnalyzeRequest(BaseModel):
    screenplay: str = Field(min_length=40, max_length=14000)


class ReferenceUsage(BaseModel):
    """One selected asset with instructions specific to the shot."""
    reference_id: str = Field(pattern=r"^[a-f0-9]{32}$")
    role: Literal["character", "face", "body", "costume", "location", "prop", "pose", "composition", "palette", "style", "other"] = "character"
    label: str = Field(default="Reference", min_length=1, max_length=80)
    instruction: str = Field(default="", max_length=240)


class StoryboardRequest(BaseModel):
    scene_title: str = Field(default="Untitled scene", max_length=160)
    visual_style: str = Field(default="cinematic graphite storyboard illustration", max_length=160)
    style_preset: str = Field(default="graphite", max_length=40)
    style_custom: str = Field(default="", max_length=300)
    reference_images: List[ReferenceUsage] = Field(default_factory=list, max_length=8)
    shot: Shot
    characters: List[Character] = Field(default_factory=list, max_length=12)
    character_reference_id: Optional[str] = Field(default=None, pattern=r"^[a-f0-9]{32}$")
    reference_character: str = Field(default="Main character", max_length=80)
    scene_summary: str = Field(default="", max_length=1200)
    location_time: str = Field(default="", max_length=240)
    props: List[str] = Field(default_factory=list, max_length=30)


class StoryboardResponse(BaseModel):
    image_url: str
    shot_number: int
    model: str
    reference_used: bool = False
    reference_count: int = 0
    style_preset: str = "graphite"


class CharacterReferenceResponse(BaseModel):
    reference_id: str
    filename: str
    content_type: str


class SegmentRequest(BaseModel):
    image_filename: str = Field(min_length=1, max_length=140, pattern=r"^shot-[0-9]+-[a-f0-9]{10}\.(png|jpg|webp)$")
    prompt: str = Field(min_length=1, max_length=100)


class SegmentedObject(BaseModel):
    object_id: str
    left: int
    top: int
    right: int
    bottom: int
    mask_width: int
    mask_height: int
    mask_base64: str
    confidence: float | None = None


class SegmentResponse(BaseModel):
    model: str
    prompt: str
    objects: List[SegmentedObject] = Field(default_factory=list)
    message: str = ""


class ImageEditRequest(BaseModel):
    image_filename: str = Field(min_length=1, max_length=140, pattern=r"^shot-[0-9]+-[a-f0-9]{10}\.(png|jpg|webp)$")
    instruction: str = Field(min_length=5, max_length=600)
    target: str = Field(default="", max_length=100)
    use_sam: bool = False
    selected_box: Optional[tuple[int,int,int,int]] = None  # confirmed SAM mask box; avoids a duplicate paid SAM call
    selection: Optional[dict] = None  # optional actual binary mask for visual grounding
    style_preset: Optional[str] = Field(default=None, max_length=40)
    style_custom: str = Field(default="", max_length=300)
    reference_images: List[ReferenceUsage] = Field(default_factory=list, max_length=8)


class ImageEditResponse(BaseModel):
    image_url: str
    model: str
    sam_grounded: bool = False
    message: str
