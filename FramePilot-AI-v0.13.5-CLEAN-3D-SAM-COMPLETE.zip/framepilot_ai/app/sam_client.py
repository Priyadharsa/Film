"""Meta SAM 3.1 image segmentation integration for FramePilot AI."""

import base64
import os
from pathlib import Path
from typing import Any


from .meta_client import _extract_text
from .meta_resilience import call_responses

BASE_URL = "https://api.meta.ai/v1"


def _sam_client():
    from openai import OpenAI
    api_key = os.getenv("MODEL_API_KEY", "").strip()
    if not api_key or api_key == "replace_with_your_meta_model_api_key":
        raise RuntimeError(
            "MODEL_API_KEY is missing. Add your Meta Model API key to the .env file."
        )
    return OpenAI(base_url=BASE_URL, api_key=api_key, timeout=180.0, max_retries=0)


def segment_image_objects(image_path: Path, prompt: str) -> dict[str, Any]:
    """Segment one noun-phrase concept from a generated storyboard image.

    Returns decoded row-major binary masks along with source-pixel bounding boxes.
    The official Meta parser validates and decodes the SAM mask payload.
    """
    try:
        from meta_sam_parser import (
            CompletedOutcome,
            SegmentationBoxRecord,
            SegmentationMaskRecord,
            decode_mask_to_raster,
            image_segmentation_format,
        )
    except ImportError as exc:  # pragma: no cover - depends on installation
        raise RuntimeError(
            "SAM parser is not installed. Run: pip install meta-sam-parser"
        ) from exc

    if not image_path.is_file():
        raise FileNotFoundError("Storyboard image not found. Generate the frame again.")

    suffix = image_path.suffix.lower()
    mime_types = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".webp": "image/webp",
    }
    mime_type = mime_types.get(suffix)
    if not mime_type:
        raise ValueError("SAM segmentation supports PNG, JPEG and WebP storyboard images.")

    image_b64 = base64.b64encode(image_path.read_bytes()).decode("ascii")
    image_data_url = f"data:{mime_type};base64,{image_b64}"

    # SAM concept prompts must be short noun phrases naming exactly one object.
    clean_prompt = " ".join(prompt.split())
    if not clean_prompt or len(clean_prompt) > 100:
        raise ValueError("Enter one short object name, such as 'woman' or 'cassette'.")

    client = _sam_client()
    model = os.getenv("SAM_MODEL", "sam-3.1")
    response = call_responses(client, 
        model=model,
        input=[
            {
                "type": "message",
                "role": "user",
                "content": [
                    {"type": "input_text", "text": clean_prompt},
                    {"type": "input_image", "image_url": image_data_url},
                ],
            }
        ],
        metadata={
            "mask_encoding": "one_bit",
            "include_confidence": "true",
        },
    )

    output_text = _extract_text(response)
    if not output_text.strip():
        return {
            "model": model,
            "prompt": clean_prompt,
            "objects": [],
            "message": f"SAM 3.1 found no matches for '{clean_prompt}'. Try a more concrete object name.",
        }

    # The Python parser consumes the special-token output and strictly validates
    # each mask before decode_mask_to_raster converts it to row-major 0/1 bytes.
    parser_format = image_segmentation_format()
    parser = parser_format.create_parser()
    parser.push(output_text)
    parsed = parser.finish(CompletedOutcome()).result

    boxes = {
        record.object_id: record
        for record in parsed.records
        if isinstance(record, SegmentationBoxRecord)
    }
    mask_records = [
        record
        for record in parsed.records
        if isinstance(record, SegmentationMaskRecord)
    ]

    objects: list[dict[str, Any]] = []
    for mask_record in mask_records:
        box = boxes.get(mask_record.object_id)
        if box is None:
            continue

        raster = decode_mask_to_raster(mask_record.mask)
        mask_width = mask_record.mask.width
        mask_height = mask_record.mask.height
        if len(raster) != mask_width * mask_height:
            continue

        objects.append(
            {
                "object_id": mask_record.object_id,
                "left": box.left,
                "top": box.top,
                "right": box.right,
                "bottom": box.bottom,
                "mask_width": mask_width,
                "mask_height": mask_height,
                "mask_base64": base64.b64encode(raster).decode("ascii"),
                "confidence": box.confidence,
            }
        )

    return {
        "model": model,
        "prompt": clean_prompt,
        "objects": objects,
        "message": (
            f"SAM 3.1 segmented {len(objects)} matching object(s)."
            if objects
            else f"No decodable masks returned for '{clean_prompt}'. Try a simpler noun phrase."
        ),
    }
