"""Original comic-style board export with readable, artist-controlled page layouts."""
from __future__ import annotations
import io
import html
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from PIL import Image as PILImage
from .production_pdf import _asset_path
from .storyboard_schematic import draw_schematic

PAPER=colors.HexColor('#faf4e8'); INK=colors.HexColor('#202825')


def export_comic_pdf(project:dict, generated_dir:Path) -> bytes:
    buffer=io.BytesIO(); c=canvas.Canvas(buffer,pagesize=A4,pageCompression=1)
    w,h=A4; margin=31; page_no=0
    def first_page():
        nonlocal page_no
        page_no+=1
        c.setFillColor(PAPER);c.rect(0,0,w,h,stroke=0,fill=1)
        c.setStrokeColor(colors.HexColor('#c4b9a3'));c.line(margin,h-36,w-margin,h-36)
        c.setFillColor(INK);c.setFont('Helvetica-Bold',9)
        c.drawString(margin,h-28,'FRAMEPILOT  /  COMIC EDITION')
        c.drawRightString(w-margin,h-28,f'{page_no:03d}')
        c.setFont('Helvetica',8)
        c.drawString(margin,18,str(project['title'])[:75])
    first_page()
    c.setFont('Helvetica-Bold',30);c.drawCentredString(w/2,h*.75,'FRAMEPILOT')
    c.setFont('Helvetica',16);c.drawCentredString(w/2,h*.70,'AN ORIGINAL COMIC SHOTBOOK')
    c.setFont('Helvetica',11);c.drawCentredString(w/2,h*.61,project['title'][:58])
    c.setFont('Helvetica',9);c.drawCentredString(w/2,h*.56,'One frame per shot; edited scene text and camera metadata')
    c.showPage()
    gap=13;pw=(w-2*margin-gap)/2;ph=(h-110-2*gap)/2
    for scene in project.get('scenes',[]):
        shots=scene.get('shots',[])
        if not shots:continue
        for start in range(0,len(shots),4):
            first_page()
            c.setFillColor(INK);c.setFont('Helvetica-Bold',11)
            slug=scene.get('slugline','SCENE')
            c.drawString(margin,h-58,f"SCENE {scene['number']:03d} / {slug}"[:82])
            for idx,shot in enumerate(shots[start:start+4]):
                col=idx%2;row=idx//2
                x=margin+col*(pw+gap); y=h-94-(row+1)*ph-row*gap
                art_h=ph-56
                c.setFillColor(colors.HexColor('#efeadf'));c.rect(x,y+56,pw,art_h,stroke=0,fill=1)
                path=_asset_path(shot.get('image_url') or shot.get('sketch_url'), generated_dir)
                if path:
                    try:
                        with PILImage.open(path) as image: iw,ih=image.size
                        ratio=min((pw-10)/iw,(art_h-10)/ih)
                        iw*=ratio;ih*=ratio
                        c.drawImage(str(path),x+(pw-iw)/2,y+56+(art_h-ih)/2,iw,ih,preserveAspectRatio=True,mask='auto')
                    except Exception:pass
                else:
                    draw_schematic(c,x,y+56,pw,art_h,shot)
                c.setStrokeColor(INK);c.setLineWidth(1.7);c.rect(x,y+56,pw,art_h,stroke=1,fill=0)
                c.setFillColor(INK);c.setFont('Helvetica-Bold',9)
                c.drawString(x+4,y+43,f"SHOT {shot['number']:02d}  /  {shot.get('shot_type','Wide')[:20]}")
                c.setFont('Helvetica',8)
                description=' '.join(shot.get('description','').split())
                for j in range(2):
                    t=description[j*56:(j+1)*56]
                    if t:c.drawString(x+4,y+30-j*11,t)
                c.setFont('Helvetica',7)
                c.drawRightString(x+pw-4,y+5,f"{shot.get('lens_mm',35)} mm · {shot.get('duration_s',5)}s")
            c.showPage()
    c.save();return buffer.getvalue()
