"""Bounded per-process admission for the local/preview deployment.

This protects one Python process from sudden bursts. It is NOT a distributed rate
limiter. Production must additionally use edge/CDN quotas and a shared rate limiter.
"""
from __future__ import annotations

import hashlib
import os
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Optional

from starlette.responses import JSONResponse


@dataclass(frozen=True)
class Decision:
    accepted: bool
    reason: str = ""
    retry_after: int = 0


class TrafficGate:
    def __init__(self, max_inflight: int = 128, max_per_minute: int = 0, max_tracked: int = 10_000):
        if max_inflight < 1 or max_per_minute < 0 or max_tracked < 1:
            raise ValueError('Invalid traffic gate settings')
        self.max_inflight = max_inflight
        self.max_per_minute = max_per_minute
        self.max_tracked = max_tracked
        self.active = 0
        self.admitted = 0
        self.rejected_capacity = 0
        self.rejected_rate = 0
        self._lock = threading.Lock()
        # Fixed one-minute window; bounded cardinality, process-local.
        self._limits: OrderedDict[str, tuple[int, float]] = OrderedDict()

    def enter(self, key: str, now: Optional[float] = None) -> Decision:
        now = time.monotonic() if now is None else now
        with self._lock:
            if self.max_per_minute:
                count, start = self._limits.get(key, (0, now))
                if now - start >= 60:
                    count, start = 0, now
                self._limits[key] = count, start
                self._limits.move_to_end(key)
                while len(self._limits) > self.max_tracked:
                    self._limits.popitem(last=False)
                if count >= self.max_per_minute:
                    self.rejected_rate += 1
                    return Decision(False, 'rate', max(1, int(61-(now-start))))
            if self.active >= self.max_inflight:
                self.rejected_capacity += 1
                return Decision(False, 'capacity', 1)
            if self.max_per_minute:
                count, start = self._limits[key]
                self._limits[key] = count+1, start
            self.active += 1
            self.admitted += 1
            return Decision(True)

    def leave(self):
        with self._lock:
            if self.active == 0:
                raise RuntimeError('Unbalanced traffic gate release')
            self.active -= 1

    def snapshot(self):
        with self._lock:
            return {
                'active_requests': self.active,
                'max_inflight_per_process': self.max_inflight,
                'admitted_total': self.admitted,
                'rejected_capacity_total': self.rejected_capacity,
                'rejected_rate_total': self.rejected_rate,
                'rate_limit_per_minute_per_identity': self.max_per_minute,
                'tracked_identities': len(self._limits),
                'scope': 'single process only',
            }


def identity(scope) -> str:
    # Hash the cookie instead of storing the raw session in the gate's ledger.
    headers = dict(scope.get('headers', []))
    cookie = headers.get(b'cookie', b'')
    if cookie:
        for part in cookie.split(b';'):
            if part.strip().startswith(b'fp_session='):
                session = part.strip().split(b'=', 1)[1]
                if len(session) <= 160:
                    return 'session:'+hashlib.sha256(session).hexdigest()[:24]
    client = scope.get('client') or ('unknown', 0)
    return 'ip:'+str(client[0])


class TrafficControlMiddleware:
    def __init__(self, app, gate: TrafficGate):
        self.app = app
        self.gate = gate

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.app(scope, receive, send)
        path = scope.get('path', '')
        # Probes must remain responsive even when the API is under load.
        if path in ('/health', '/health/live', '/health/ready'):
            return await self.app(scope, receive, send)
        decision = self.gate.enter(identity(scope))
        if not decision.accepted:
            code = 429 if decision.reason == 'rate' else 503
            message = 'Request rate limit reached. Retry after the indicated delay.' if code == 429 else 'Server is busy. Retry shortly.'
            response = JSONResponse({'detail': message}, status_code=code,
                                    headers={'Retry-After': str(decision.retry_after), 'Cache-Control':'no-store'})
            return await response(scope, receive, send)
        try:
            return await self.app(scope, receive, send)
        finally:
            self.gate.leave()


def gate_from_env() -> TrafficGate:
    return TrafficGate(
        max_inflight=int(os.getenv('FRAMEPILOT_MAX_INFLIGHT', '128')),
        # Default disabled for local tests; set at the edge and on staging.
        max_per_minute=int(os.getenv('FRAMEPILOT_PER_IDENTITY_RPM', '0')),
    )
