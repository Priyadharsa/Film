"""Bounded retry policy for temporary Meta Model API failures.

One application-level retry layer is used instead of stacking SDK retries.
Authentication and malformed requests are never retried. An ambiguous upstream 5xx
may have performed work before returning an error; retries can incur usage.
"""
from __future__ import annotations
import logging
import random
import time
from typing import Callable, Any

log = logging.getLogger('framepilot.meta')
RETRYABLE = frozenset({429, 500, 502, 503, 504})


def _status(exc: Exception) -> int | None:
    code = getattr(exc, 'status_code', None)
    if code is None:
        code = getattr(getattr(exc, 'response', None), 'status_code', None)
    try:
        return int(code) if code is not None else None
    except (TypeError, ValueError):
        return None


def _retry_after(exc: Exception) -> float | None:
    response = getattr(exc, 'response', None)
    headers = getattr(response, 'headers', {}) or {}
    raw = headers.get('retry-after') or headers.get('Retry-After')
    try:
        return max(0.0, min(float(raw), 15.0)) if raw is not None else None
    except (TypeError, ValueError):
        return None


def call_responses(client: Any, *, max_attempts: int = 3,
                   sleep: Callable[[float], None] = time.sleep,
                   jitter: Callable[[], float] = random.random, **kwargs: Any):
    """Create a response with 3 total attempts and exponential bounded backoff."""
    if not 1 <= max_attempts <= 5:
        raise ValueError('max_attempts must be between 1 and 5')
    for attempt in range(max_attempts):
        try:
            return client.responses.create(**kwargs)
        except Exception as exc:
            status = _status(exc)
            # The SDK may report transport failures without an HTTP status.
            transport = exc.__class__.__name__ in {'APIConnectionError', 'APITimeoutError'}
            if attempt + 1 >= max_attempts or (status not in RETRYABLE and not transport):
                raise
            delay = _retry_after(exc)
            if delay is None:
                delay = min(6.0, 0.7 * (2 ** attempt)) + max(0, min(float(jitter()), 1)) * 0.3
            log.warning('Meta temporary response status=%s attempt=%s/%s backoff=%.1fs',
                        status or 'transport', attempt + 1, max_attempts, delay)
            sleep(delay)
    raise AssertionError('unreachable')
