"""HTTP upload control plane. Never mount directly on the public Internet without authentication."""
from __future__ import annotations

from pathlib import Path
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from .upload_core import UploadService, UploadError, MAX_UPLOAD_BYTES

BASE = Path(__file__).resolve().parent.parent/'private_uploads'/'ingest'
SERVICE = UploadService(BASE)
router = APIRouter(prefix='/api/uploads',tags=['Resumable uploads'])


class UploadStart(BaseModel):
    filename: str = Field(min_length=1,max_length=160)
    size: int = Field(ge=1)
    kind: str = 'screenplay'
    title: str = Field(default='',max_length=160)
    ocr: bool = True


class RemotePart(BaseModel):
    part_index: int = Field(ge=0)
    etag: str


class UploadComplete(BaseModel):
    parts: list[RemotePart] | None = None


def wrap(fn,*args,**kwargs):
    try:return fn(*args,**kwargs)
    except UploadError as exc:raise HTTPException(status_code=exc.status,detail=str(exc)) from exc


@router.post('')
def create_upload(body: UploadStart):
    return wrap(SERVICE.create,body.filename,body.size,body.kind,body.title,body.ocr)


@router.get('/{ident}')
def upload_status(ident: str):
    return wrap(SERVICE.status,ident)


@router.get('/{ident}/parts/{index}/sign')
def sign_s3_part(ident: str,index:int):
    return wrap(SERVICE.presign,ident,index)


@router.put('/{ident}/parts/{index}')
async def put_local_part(ident: str,index:int,request:Request):
    try:return await SERVICE.save_part(ident,index,request.stream(),request.headers.get('x-content-sha256'))
    except UploadError as exc:raise HTTPException(status_code=exc.status,detail=str(exc)) from exc


@router.post('/{ident}/complete')
def finish_upload(ident:str,body:UploadComplete|None=None):
    return wrap(SERVICE.complete,ident,[p.model_dump() for p in body.parts] if body and body.parts else None)


@router.delete('/{ident}')
def cancel_upload(ident:str):
    return wrap(SERVICE.cancel,ident)
