"""Production Hub: scene-linked production planning and export.

Local-first, account scoped through ProjectStore. Simple CRUD intended for an indie film
MVP, not an email delivery, crew permissions or conflict resolution service.
"""
from __future__ import annotations

import csv
import io
import re
import uuid
from datetime import datetime
from html import escape
from typing import Literal

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether

from .project_store import ProjectStore
from .workspace_api import REFERENCES

STORE = ProjectStore(REFERENCES)
router = APIRouter(prefix='/api/production', tags=['Production Hub'])
COLLECTIONS = {'contacts','tasks','calendar','shoot_days','breakdown','moodboard','call_sheets'}
DOCS = {'call-sheet','script-sides','shot-list','script-breakdown','shooting-schedule','av-script','contacts','tasks','calendar','moodboard'}
MAX_ROWS=3000
FIELDS = {
 'contacts': {'name','role','department','phone','email','notes','call_time'},
 'tasks': {'title','department','owner','status','priority','due_date','scene_id','notes'},
 'calendar': {'title','date','start_time','end_time','location','description','scene_id'},
 'shoot_days': {'date','start_time','location','scene_ids','notes','unit','status','call_time'},
 'breakdown': {'scene_id','category','name','quantity','notes','department'},
 'moodboard': {'title','image_url','notes','category','scene_id'},
 'call_sheets': {'shoot_day_id','title','parking','weather','hospital','emergency','general_call','notes'},
}

class Record(BaseModel):
    data: dict = Field(default_factory=dict)


def _project(pid):
    p=STORE.get(pid)
    if p is None:raise HTTPException(404,'Film not found or access denied')
    return p


def _validate(category, payload, *, patch=False):
    if category not in COLLECTIONS:raise HTTPException(404,'Unknown planning collection')
    if not isinstance(payload,dict):raise HTTPException(422,'Expected a planning record')
    if set(payload)-FIELDS[category]:raise HTTPException(422,'Unknown fields in planning record')
    try:
        size=len(__import__('json').dumps(payload))
    except (TypeError,ValueError):raise HTTPException(422,'Invalid field values')
    if size>12000:raise HTTPException(413,'Planning record is too large')
    clean={}
    for k,v in payload.items():
        if k=='scene_ids':
            if not isinstance(v,list) or len(v)>1000 or any(not isinstance(x,str) or len(x)>60 for x in v):raise HTTPException(422,'Invalid scene IDs')
            clean[k]=list(dict.fromkeys(v));continue
        if not isinstance(v,str) or len(v)>4000:raise HTTPException(422,f'Invalid {k}')
        clean[k]=v.strip()
    if 'image_url' in clean and clean['image_url'] and not re.fullmatch(r'/static/generated/[a-zA-Z0-9._-]{1,120}|/api/reference/[a-f0-9]{32}/preview',clean['image_url']):
        raise HTTPException(422,'Mood-board images must be uploaded into FramePilot first')
    if 'date' in clean and clean['date']:
        try:datetime.strptime(clean['date'],'%Y-%m-%d')
        except ValueError:raise HTTPException(422,'Use date YYYY-MM-DD')
    if 'due_date' in clean and clean['due_date']:
        try:datetime.strptime(clean['due_date'],'%Y-%m-%d')
        except ValueError:raise HTTPException(422,'Use date YYYY-MM-DD')
    return clean


def _get_records(p,category):return p.get('production',{}).get(category,[])

@router.get('/{pid}')
def overview(pid:str):
    p=_project(pid)
    scenes=[]
    for s in p.get('scenes',[]):
        scenes.append({'id':s['id'],'number':s.get('number',len(scenes)+1),'slugline':s.get('slugline','Untitled scene'),
                       'page_start':s.get('page_start',s.get('source_page',0)), 'shots':[
                           {'id':sh['id'],'name':sh.get('name','Shot'),'shot_type':sh.get('shot_type',''),
                            'camera_angle':sh.get('camera_angle',''),'lens_mm':sh.get('lens_mm',50),
                            'duration_s':sh.get('duration_s',0),'status':sh.get('status','Draft'),
                            'image_url':sh.get('image_url') or sh.get('sketch_url'),
                            'description':sh.get('description','')[:500]} for sh in s.get('shots',[])]})
    return {'project_id':p['id'],'title':p['title'],'revision':p['revision'],'scenes':scenes,
            'production':{category:_get_records(p,category) for category in sorted(COLLECTIONS)},
            'pages':len(p.get('pages',[]))}

@router.post('/{pid}/{category}',status_code=201)
def add_record(pid:str,category:str,record:Record):
    data=_validate(category,record.data)
    out={'id':uuid.uuid4().hex[:12],**data}
    def do(p):
        rows=p.setdefault('production',{}).setdefault(category,[])
        if len(rows)>=MAX_ROWS:raise HTTPException(413,'Too many records in this collection')
        if category=='shoot_days':
            invalid=[sid for sid in out.get('scene_ids',[]) if sid not in {s['id'] for s in p['scenes']}]
            if invalid:raise HTTPException(422,'Choose scenes from this film')
        rows.append(out)
    STORE.mutate(pid,do) if _project(pid) else None
    return {'record':out}

@router.patch('/{pid}/{category}/{rid}')
def edit_record(pid:str,category:str,rid:str,record:Record):
    data=_validate(category,record.data,patch=True)
    result={}
    def do(p):
        for item in p.setdefault('production',{}).setdefault(category,[]):
            if item['id']==rid:
                if category=='shoot_days' and 'scene_ids' in data:
                    valid={s['id'] for s in p['scenes']}
                    if any(sid not in valid for sid in data['scene_ids']):raise HTTPException(422,'Invalid scene ID')
                item.update(data);result.update(item);return
        raise HTTPException(404,'Record not found')
    _project(pid);STORE.mutate(pid,do)
    return {'record':result}

@router.delete('/{pid}/{category}/{rid}')
def delete_record(pid:str,category:str,rid:str):
    if category not in COLLECTIONS:raise HTTPException(404,'Unknown collection')
    def do(p):
        rows=p.setdefault('production',{}).setdefault(category,[])
        new=[item for item in rows if item['id']!=rid]
        if len(new)==len(rows):raise HTTPException(404,'Record not found')
        p['production'][category]=new
    _project(pid);STORE.mutate(pid,do)
    return {'deleted':rid}


def _pdf(pid,kind,scene_id='',shoot_day_id=''):
    p=_project(pid)
    if kind not in DOCS:raise HTTPException(404,'Unsupported PDF document')
    plan=p.get('production',{})
    scenes=p.get('scenes',[])
    if scene_id:scenes=[s for s in scenes if s['id']==scene_id]
    if scene_id and not scenes:raise HTTPException(404,'Scene not found')
    selected_day=next((d for d in plan.get('shoot_days',[]) if d['id']==shoot_day_id),None) if shoot_day_id else None
    if shoot_day_id and not selected_day:raise HTTPException(404,'Shoot day not found')
    if selected_day:scenes=[s for s in scenes if s['id'] in selected_day.get('scene_ids',[])]
    buffer=io.BytesIO()
    doc=SimpleDocTemplate(buffer,pagesize=A4,rightMargin=17*mm,leftMargin=17*mm,topMargin=17*mm,bottomMargin=16*mm)
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='FPtitle',parent=styles['Title'],fontName='Helvetica-Bold',fontSize=20,spaceAfter=13,textColor=colors.HexColor('#203942')))
    styles.add(ParagraphStyle(name='FPsection',parent=styles['Heading2'],fontSize=12,spaceBefore=12,spaceAfter=5,textColor=colors.HexColor('#285566')))
    styles.add(ParagraphStyle(name='FPbody',parent=styles['BodyText'],fontSize=9,leading=12,spaceAfter=5))
    styles.add(ParagraphStyle(name='FPtiny',parent=styles['BodyText'],fontSize=8,leading=10))
    story=[Paragraph(escape(p['title']),styles['FPtitle']),Paragraph(escape(kind.replace('-',' ').upper()),styles['FPsection']),Spacer(1,4*mm)]
    def section(title):story.append(Paragraph(escape(title),styles['FPsection']))
    def line(label,val):story.append(Paragraph('<b>'+escape(str(label))+'</b> '+escape(str(val or '—')),styles['FPbody']))
    def table(headers,rows,widths=None):
        data=[[Paragraph('<b>'+escape(str(v))+'</b>',styles['FPtiny']) for v in headers]]
        for row in rows[:3000]:data.append([Paragraph(escape(str(v or '—'))[:1300],styles['FPtiny']) for v in row])
        if len(data)==1:story.append(Paragraph('No records yet.',styles['FPbody']));return
        t=Table(data,repeatRows=1,colWidths=widths,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#DCECEF')),('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#8BA7AF')),('LINEBELOW',(0,1),(-1,-1),.2,colors.HexColor('#E1E9EB'))]))
        story.append(t)
    if kind=='call-sheet':
        days=[selected_day] if selected_day else plan.get('shoot_days',[])
        d=days[0] if days else {}
        sheet=next((x for x in plan.get('call_sheets',[]) if x.get('shoot_day_id')==d.get('id')), {})
        line('Shoot date:',d.get('date','Unscheduled'))
        line('General call:',sheet.get('general_call') or d.get('call_time') or d.get('start_time','TBD'))
        line('Location:',d.get('location','TBD'))
        line('Parking:',sheet.get('parking',''))
        line('Nearest hospital:',sheet.get('hospital',''))
        line('Emergency contact:',sheet.get('emergency',''))
        line('Weather / considerations:',sheet.get('weather',''))
        section('SCENES / SETUPS')
        table(['Scene','Location / time','Shots'],[(s.get('number',''),s.get('slugline',''),len(s.get('shots',[]))) for s in scenes])
        section('CAST & CREW CONTACTS')
        table(['Name','Role / dept','Phone','Call'],[(x.get('name'),x.get('role') or x.get('department'),x.get('phone'),x.get('call_time')) for x in plan.get('contacts',[])])
        line('Additional notes:',sheet.get('notes',''))
    elif kind=='script-sides':
        for s in scenes[:1000]:
            section(f"Scene {s.get('number','')} · {s.get('slugline','')}")
            story.append(Paragraph(escape(s.get('text','')[:40000]).replace('\n','<br/>') or 'No scene text',styles['FPbody']))
    elif kind=='shot-list':
        for s in scenes[:1000]:
            section(f"Scene {s.get('number','')} · {s.get('slugline','')}")
            table(['Shot','Type','Lens','Duration','Status'],[(x.get('name'),x.get('shot_type'),str(x.get('lens_mm',''))+'mm',str(x.get('duration_s',''))+'s',x.get('status')) for x in s.get('shots',[])])
    elif kind=='script-breakdown':
        for s in scenes[:1000]:
            section(f"Scene {s.get('number','')} · {s.get('slugline','')}")
            entries=[e for e in plan.get('breakdown',[]) if e.get('scene_id')==s.get('id')]
            table(['Category','Item','Qty','Department'],[(x.get('category'),x.get('name'),x.get('quantity'),x.get('department')) for x in entries])
    elif kind=='shooting-schedule':
        for day in plan.get('shoot_days',[]):
            section(f"{day.get('date','TBD')} · {day.get('location','')}")
            line('Call time:',day.get('call_time') or day.get('start_time'))
            table(['Scene','Location / time','Shots'],[(s.get('number',''),s.get('slugline',''),len(s.get('shots',[]))) for s in p['scenes'] if s['id'] in day.get('scene_ids',[])])
            line('Production notes:',day.get('notes',''))
    elif kind=='av-script':
        for s in scenes[:1000]:
            section(f"Scene {s.get('number','')} · {s.get('slugline','')}")
            shots=s.get('shots',[])
            visual='\n'.join(f"{x.get('shot_type','Shot')}: {x.get('description','')[:160]}" for x in shots[:25])
            table(['VISUAL / CAMERA','AUDIO / SCRIPT'],[(visual,s.get('text','')[:1600])],[82*mm,92*mm])
    elif kind=='moodboard':
        table(['Title','Category','Creative notes'],[(r.get('title'),r.get('category'),r.get('notes')) for r in plan.get('moodboard',[])])
    elif kind=='contacts':
        table(['Name','Role','Email','Phone'],[(x.get('name'),x.get('role'),x.get('email'),x.get('phone')) for x in plan.get('contacts',[])])
    elif kind=='tasks':
        table(['Task','Owner','Status','Due'],[(x.get('title'),x.get('owner'),x.get('status'),x.get('due_date')) for x in plan.get('tasks',[])])
    elif kind=='calendar':
        table(['Date','Event','Time','Location'],[(x.get('date'),x.get('title'),x.get('start_time'),x.get('location')) for x in plan.get('calendar',[])])
    def footer(canv,doc):
        canv.setFont('Helvetica',8);canv.setFillColor(colors.HexColor('#63727B'))
        canv.drawString(17*mm,11*mm,'FRAMEPILOT · PRODUCTION HUB')
        canv.drawRightString(A4[0]-17*mm,11*mm,f'Page {doc.page}')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return buffer.getvalue()

@router.get('/{pid}/export/{kind}.pdf')
def export_pdf(pid:str,kind:str,scene_id:str='',shoot_day_id:str=''):
    raw=_pdf(pid,kind,scene_id,shoot_day_id)
    return Response(content=raw,media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="framepilot-{kind}.pdf"','Cache-Control':'private,no-store'})

@router.get('/{pid}/export/{kind}.csv')
def export_csv(pid:str,kind:str):
    if kind not in COLLECTIONS:raise HTTPException(404,'Unknown collection')
    p=_project(pid);rows=_get_records(p,kind)
    out=io.StringIO();fields=['id',*sorted(FIELDS[kind])];writer=csv.DictWriter(out,fieldnames=fields,extrasaction='ignore');writer.writeheader()
    for r in rows:
        values={k:(' '.join(v) if isinstance(v,list) else ('\''+v if v and v[0] in ('=','+','-','@') else v) if isinstance(v,str) else v) for k,v in r.items()}
        writer.writerow(values)
    return Response(content=out.getvalue(),media_type='text/csv',headers={'Content-Disposition':f'attachment; filename="framepilot-{kind}.csv"','Cache-Control':'private,no-store'})
