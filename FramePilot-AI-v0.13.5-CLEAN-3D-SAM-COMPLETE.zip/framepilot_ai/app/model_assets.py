"""Local-only Blender GLB asset library for the lightweight 3D director.

Do not expose this unauthenticated router on a public network. Cloud deployments
must add tenant IDs, authorization, antivirus and glTF sandboxing.
"""
from __future__ import annotations
import json
import os
import shutil
import struct
import uuid
from pathlib import Path
from fastapi import APIRouter, File, HTTPException, UploadFile, Request
from fastapi.responses import FileResponse
from .auth import register_asset, check_asset
from .blend_conversion import convert_blend, BLEND_MAX_BYTES

ROOT = Path(__file__).resolve().parent.parent
FOLDER = ROOT / 'private_uploads' / 'models'
FOLDER.mkdir(parents=True, exist_ok=True)
MAX_GLB_BYTES = 30 * 1024 * 1024
router = APIRouter(prefix='/api/models', tags=['3D props'])


def validate_glb(data: bytes) -> None:
    if len(data) < 20 or data[:4] != b'glTF':
        raise ValueError('Export a binary .glb from Blender (glTF 2.0).')
    version, length = struct.unpack_from('<II', data, 4)
    if version != 2 or length != len(data):
        raise ValueError('The GLB version or file length is invalid.')
    chunk_length, chunk_type = struct.unpack_from('<I4s', data, 12)
    if chunk_type != b'JSON' or chunk_length > 2 * 1024 * 1024 or chunk_length + 20 > len(data):
        raise ValueError('GLB must have a valid, bounded JSON header.')
    try:
        graph = json.loads(data[20:20 + chunk_length].decode('utf-8'))
    except (UnicodeError, ValueError) as exc:
        raise ValueError('Invalid glTF scene graph.') from exc
    if graph.get('asset', {}).get('version') != '2.0':
        raise ValueError('Only glTF 2.0 assets are supported.')
    if len(graph.get('nodes', [])) > 2000 or len(graph.get('meshes', [])) > 2000:
        raise ValueError('Model scene is too complex; simplify the Blender export.')
    # Embedded GLB buffers only. External fetches are deliberately disallowed.
    for collection in ('buffers','images'):
        for obj in graph.get(collection, []):
            if obj.get('uri'):
                raise ValueError('External files and URLs are not supported. Embed textures in the GLB export.')



@router.get('/capabilities')
def model_capabilities(request: Request):
    # Report the local conversion capabilities without leaking filesystem paths.
    local=request.client is not None and request.client.host in ('127.0.0.1','::1','localhost','testclient')
    configured=os.getenv('FRAMEPILOT_BLENDER_BIN','')
    installed=Path(configured).is_file() if configured else bool(shutil.which('blender'))
    enabled=os.getenv('FRAMEPILOT_ENABLE_LOCAL_BLEND','0')=='1' and local
    return {'glb':True,'blend':enabled and installed,'blend_enabled':enabled,
            'blender_installed':installed,'blend_max_mib':80,'glb_max_mib':30,
            'notes':'Blender conversion requires explicit local opt-in; use GLB for public deployments.'}

@router.post('')
async def upload_model(request: Request, file: UploadFile = File(...)):
    filename = (file.filename or '').lower()
    if filename.endswith('.blend'):
        if os.getenv('FRAMEPILOT_ENABLE_LOCAL_BLEND','0') != '1' or request.client is None or request.client.host not in ('127.0.0.1','::1','localhost','testclient'):
            raise HTTPException(403,'Blender project conversion is disabled. Use .glb, or enable local conversion in .env on your own computer.')
        raw_blend = await file.read(BLEND_MAX_BYTES + 1)
        if len(raw_blend) > BLEND_MAX_BYTES:
            raise HTTPException(413,'.blend projects must be 80 MiB or smaller for local conversion.')
        try:
            raw = convert_blend(raw_blend)
        except ValueError as exc:
            raise HTTPException(422,str(exc)) from exc
        except RuntimeError as exc:
            raise HTTPException(503,str(exc)) from exc
    elif filename.endswith('.glb'):
        raw = await file.read(MAX_GLB_BYTES + 1)
        if len(raw) > MAX_GLB_BYTES:
            raise HTTPException(413,'3D models must be 30 MiB or smaller.')
    else:
        raise HTTPException(415,'Choose a .glb model or a locally convertible .blend project.')
    try: validate_glb(raw)
    except ValueError as exc: raise HTTPException(422,str(exc)) from exc
    name = uuid.uuid4().hex
    (FOLDER / f'{name}.glb').write_bytes(raw)
    register_asset('model',name)
    return {'asset_id':name,'url':f'/api/models/{name}','filename':Path(file.filename).name[:120]}


@router.get('/{asset_id}')
def load_model(asset_id:str):
    if len(asset_id) != 32 or any(c not in '0123456789abcdef' for c in asset_id):
        raise HTTPException(404,'Model not found')
    check_asset('model',asset_id)
    model=FOLDER / f'{asset_id}.glb'
    if not model.is_file():raise HTTPException(404,'Model not found')
    return FileResponse(model,media_type='model/gltf-binary',headers={'Cache-Control':'private, max-age=3600'})
