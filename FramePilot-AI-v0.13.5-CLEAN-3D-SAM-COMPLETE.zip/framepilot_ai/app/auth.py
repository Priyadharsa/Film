"""Optional self-hosted accounts and request-scoped project ownership.

Not a managed identity provider or cloud storage service. To use over the Internet,
place behind HTTPS, provision persistent database/object storage and audit deployment.
"""
from __future__ import annotations
import contextvars
import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import time
import uuid
from pathlib import Path
from fastapi import APIRouter, HTTPException, Request, Response
from pydantic import BaseModel, Field

ROOT=Path(__file__).resolve().parent.parent
from dotenv import load_dotenv
load_dotenv(ROOT/'.env')
DB=ROOT/'private_uploads'/'accounts.sqlite3'
AUTH_MODE=os.getenv('FRAMEPILOT_AUTH_MODE','local').strip().lower()
actor_id=contextvars.ContextVar('framepilot_actor',default='local')


def actor():return actor_id.get()
def auth_on():return AUTH_MODE=='accounts'

def connect():
    DB.parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(DB,timeout=15)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA busy_timeout=15000')
    c.executescript('''CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,salt BLOB NOT NULL,secret BLOB NOT NULL,created REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS failed_signins(email TEXT NOT NULL,created REAL NOT NULL);''')
    return c


def pwd_hash(password:str,salt:bytes)->bytes:
    return hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),salt,500_000)


def public_user(row):return {'id':row['id'],'email':row['email'],'name':row['name']}


def session_user(request:Request):
    if not auth_on():return {'id':'local','name':'Local workspace','email':''}
    cookie=request.cookies.get('fp_session','')
    if not cookie or len(cookie)>160:return None
    token=hashlib.sha256(cookie.encode()).hexdigest()
    with connect() as db:
        row=db.execute('''SELECT u.id,u.email,u.name FROM sessions s JOIN users u ON u.id=s.user_id
            WHERE s.token_hash=? AND s.expires>?''',(token,time.time())).fetchone()
    return public_user(row) if row else None


def secure_cookie(request):
    return os.getenv('FRAMEPILOT_COOKIE_SECURE','').lower() in ('true','1','yes') or request.url.scheme=='https'

class Register(BaseModel):
    email:str=Field(min_length=5,max_length=254)
    name:str=Field(min_length=1,max_length=80)
    password:str=Field(min_length=12,max_length=128)

class Login(BaseModel):
    email:str
    password:str

router=APIRouter(prefix='/api/auth',tags=['Local accounts'])

@router.get('/me')
def me(request:Request):
    return {'mode':AUTH_MODE,'user':session_user(request),'cloud_connected':False}

@router.post('/register',status_code=201)
def register(body:Register,request:Request,response:Response):
    if not auth_on():raise HTTPException(409,'Enable FRAMEPILOT_AUTH_MODE=accounts and restart to use profiles.')
    email=body.email.strip().lower()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email):raise HTTPException(422,'Enter a valid email address.')
    if not body.name.strip():raise HTTPException(422,'Enter a display name.')
    if len(body.password)<12 or len(body.password)>128:raise HTTPException(422,'Password must be 12-128 characters.')
    salt=secrets.token_bytes(16)
    user_id=uuid.uuid4().hex
    with connect() as db:
        try:
            db.execute('INSERT INTO users(id,email,name,salt,secret,created) VALUES(?,?,?,?,?,?)',
                   (user_id,email,body.name.strip(),salt,pwd_hash(body.password,salt),time.time()))
        except sqlite3.IntegrityError as exc:raise HTTPException(409,'Email already registered.') from exc
    # First registration signs in immediately. Previously the next project request
    # returned 401 because the browser had no session cookie until a second form.
    _start_session(response,request,user_id)
    return {'registered':True,'user':{'id':user_id,'email':email,'name':body.name.strip()},
            'cloud_connected':False,'message':'Account created and signed in on this server.'}

def _start_session(response: Response, request: Request, user_id: str):
    token=secrets.token_urlsafe(36)
    with connect() as db:
        db.execute('INSERT INTO sessions(token_hash,user_id,expires) VALUES(?,?,?)',
                   (hashlib.sha256(token.encode()).hexdigest(),user_id,time.time()+7*86400))
    response.set_cookie('fp_session',token,max_age=7*86400,httponly=True,
                        samesite='strict',secure=secure_cookie(request),path='/')


@router.post('/login')
def login(body:Login,request:Request,response:Response):
    if not auth_on():raise HTTPException(409,'Local workspace mode does not require sign-in.')
    email=body.email.strip().lower()
    now=time.time()
    with connect() as db:
        recent=db.execute('SELECT count(*) AS n FROM failed_signins WHERE email=? AND created>?',(email,now-900)).fetchone()['n']
        if recent>=8:raise HTTPException(429,'Too many attempts. Try again later.')
        row=db.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
        matched=bool(row and hmac.compare_digest(pwd_hash(body.password,row['salt']),row['secret']))
        if not matched:
            db.execute('INSERT INTO failed_signins(email,created) VALUES(?,?)',(email,now))
            db.execute('DELETE FROM failed_signins WHERE created<?',(now-86400,))
            raise HTTPException(401,'Incorrect email or password.')
        db.execute('DELETE FROM failed_signins WHERE email=?',(email,))
    _start_session(response,request,row['id'])
    return {'user':public_user(row),'cloud_connected':False}

@router.get('/diagnostics')
def auth_diagnostics(request:Request):
    user=session_user(request)
    return {'mode':AUTH_MODE, 'session_cookie_present':bool(request.cookies.get('fp_session')),
            'session_valid':bool(user), 'using_https':request.url.scheme=='https',
            'cloud_connected':False}

class ProfilePatch(BaseModel):
    name:str=Field(min_length=1,max_length=80)

@router.patch('/profile')
def change_profile(body:ProfilePatch,request:Request):
    if not auth_on():raise HTTPException(409,'Enable account mode to edit profiles.')
    user=session_user(request)
    if not user:raise HTTPException(401,'Sign in to edit your profile.')
    name=body.name.strip()
    if not name:raise HTTPException(422,'Display name cannot be blank.')
    with connect() as db:
        db.execute('UPDATE users SET name=? WHERE id=?',(name,user['id']))
    return {'user':{'id':user['id'],'email':user['email'],'name':name},'cloud_connected':False}

@router.post('/logout')
def logout(request:Request,response:Response):
    cookie=request.cookies.get('fp_session')
    if cookie:
        with connect() as db:db.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(cookie.encode()).hexdigest(),))
    response.delete_cookie('fp_session',path='/')
    return {'ok':True}


def register_asset(kind:str,asset_id:str):
    """Make references and models private to their uploading profile."""
    with connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS assets (kind TEXT,id TEXT,owner_id TEXT,PRIMARY KEY(kind,id))')
        db.execute('INSERT OR REPLACE INTO assets(kind,id,owner_id) VALUES(?,?,?)',(kind,asset_id,actor()))


def check_asset(kind:str,asset_id:str):
    if not auth_on() or actor()=='system':return
    with connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS assets (kind TEXT,id TEXT,owner_id TEXT,PRIMARY KEY(kind,id))')
        row=db.execute('SELECT 1 FROM assets WHERE kind=? AND id=? AND owner_id=?',(kind,asset_id,actor())).fetchone()
        if not row:raise HTTPException(404,'Asset not found.')
