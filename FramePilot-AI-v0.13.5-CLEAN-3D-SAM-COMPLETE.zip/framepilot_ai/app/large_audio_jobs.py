"""Local-first large recording ingestion for Muse Voice Transcribe.

Up to 500 MiB of common audio/video formats. Uploads stream to private disk,
FFmpeg extracts audio into <10 minute / <32 MB supported WAV segments, and
Meta receives those segments one at a time with bounded upstream retries.

This in-process queue is a *local prototype*, not a distributed durable queue.
For multi-instance production use object storage and an authenticated durable
worker queue; the files here are private and removed after job completion.
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse

from .auth import session_user
from .voice_storyboard import transcribe_wav

log = logging.getLogger('framepilot.audio_jobs')
router = APIRouter(prefix='/api/voice-storyboard/jobs', tags=['Voice to storyboard'])
ROOT = Path(__file__).resolve().parent.parent
WORK_ROOT = ROOT / 'private_uploads' / 'voice_jobs'
MAX_AUDIO_BYTES = 500 * 1024 * 1024
CHUNK_BYTES = 4 * 1024 * 1024
MAX_CLIP_BYTES = 30 * 1024 * 1024  # Meta has 32 MB total multipart cap
CLIP_SECONDS = 480             # 8 min, raw 16kHz mono PCM is ~15.4 MB
EXTENSIONS = {'.wav','.wave','.mp3','.m4a','.m4b','.aac','.aif','.aiff',
              '.ogg','.oga','.opus','.flac','.wma','.amr','.caf','.ac3',
              '.webm','.mp4','.mov','.mkv','.3gp','.mpeg','.mpg','.ts'}

# Separate job ids and owner ids, never expose paths or arbitrary filenames.
_lock = threading.RLock()
_jobs: dict[str, dict] = {}
_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix='fp-voice')
TRANSCRIPT_RETENTION_SECONDS = 24 * 3600


def ffmpeg_binary():
    """Use system ffmpeg or the cross-platform binary from imageio-ffmpeg."""
    system = shutil.which('ffmpeg')
    if system:
        return system
    try:
        import imageio_ffmpeg
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        if exe and Path(exe).is_file():
            return exe
    except (ImportError, OSError, RuntimeError):
        pass
    return None


def segment_audio(source: Path, folder: Path, *, ffmpeg_exe: str | None = None) -> list[Path]:
    """Decode any supported media containing audio into Meta-safe WAV files.

    Input is a local private file; never use shell=True or user-derived output
    patterns. Segment muxer cuts on timestamps, yielding 8-minute PCM WAVs.
    """
    exe = ffmpeg_exe or ffmpeg_binary()
    if not exe:
        raise HTTPException(503, 'Audio conversion is unavailable. Install FFmpeg or reinstall dependencies (imageio-ffmpeg).')
    output = folder / 'segment_%05d.wav'
    cmd = [exe, '-hide_banner', '-loglevel', 'error', '-nostdin',
           '-protocol_whitelist', 'file,pipe', '-i', str(source), '-map', '0:a:0', '-vn', '-sn', '-dn',
           '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', '-map_metadata', '-1',
           '-f', 'segment', '-segment_time', str(CLIP_SECONDS),
           '-segment_format', 'wav', '-reset_timestamps', '1', str(output)]
    try:
        completed = subprocess.run(cmd, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.PIPE, timeout=3600, check=False)
    except subprocess.TimeoutExpired:
        raise HTTPException(422, 'Audio conversion took too long. Try splitting this recording into smaller files.') from None
    except OSError:
        raise HTTPException(503, 'Unable to start the audio converter.') from None
    clips = sorted(folder.glob('segment_*.wav'))
    if completed.returncode or not clips:
        reason = (completed.stderr or b'').decode('utf-8', 'replace')[:240]
        log.warning('FFmpeg conversion failed: %s', reason)
        raise HTTPException(422, 'The file could not be decoded or has no usable audio track. Try another encoding.')
    if any(clip.stat().st_size > MAX_CLIP_BYTES for clip in clips):
        raise HTTPException(422, 'A converted audio segment exceeds the Meta request limit.')
    return clips


def current_owner(request: Request) -> str:
    user = session_user(request)
    if not user:
        raise HTTPException(401, 'Sign in before using private audio jobs.')
    return user['id']


def _cleanup_finished_jobs():
    cutoff = time.time() - TRANSCRIPT_RETENTION_SECONDS
    with _lock:
        stale = [jid for jid, j in _jobs.items() if j.get('created', time.time()) < cutoff and j['state'] in ('completed', 'failed', 'cancelled')]
        for jid in stale:
            _jobs.pop(jid, None)
    for jid in stale:
        shutil.rmtree(WORK_ROOT / jid, ignore_errors=True)


def _snapshot(job: dict) -> dict:
    with _lock:
        return {k: job.get(k) for k in ('job_id','state','bytes_received',
                'parts_done','parts_total','error','duration_seconds','transcript_preview',
                'download_ready','created')}


def _job_for(request: Request, job_id: str) -> dict:
    owner = current_owner(request)
    _cleanup_finished_jobs()
    with _lock:
        job = _jobs.get(job_id)
        if not job or job.get('owner') != owner:
            raise HTTPException(404, 'Audio job not found.')
        return job


def _run_job(job_id: str, source: Path, folder: Path, key: str, *, segmenter=None, transcriber=None):
    segmenter = segmenter or segment_audio
    transcriber = transcriber or transcribe_wav
    with _lock:
        job = _jobs[job_id]
        job['state'] = 'converting'
    try:
        clips = segmenter(source, folder)
        with _lock:
            job['parts_total'] = len(clips)
            job['state'] = 'transcribing'
        transcript_path = folder / 'transcript.txt'
        total_duration = 0.0
        with transcript_path.open('w', encoding='utf-8') as final:
            for idx, clip in enumerate(clips):
                with _lock:
                    if job['cancel_requested']:
                        job['state'] = 'cancelled'
                        break
                # A segment is ~15MB, not the original 500MB file.
                with clip.open('rb') as f:
                    result = transcriber(f.read(), key)
                content = result.get('transcript', '').strip()
                if not content:
                    raise HTTPException(422, 'No speech detected in a segment of the recording.')
                final.write(content + '\n\n')
                total_duration += float(result.get('duration_seconds') or 0)
                with _lock:
                    job['parts_done'] = idx + 1
                clip.unlink(missing_ok=True)
        with _lock:
            if job['state'] != 'cancelled':
                job['transcript_preview'] = transcript_path.read_text('utf-8')[:24000]
                job['duration_seconds'] = round(total_duration, 2)
                job['download_ready'] = True
                job['state'] = 'completed'
    except HTTPException as exc:
        with _lock:
            job['state'] = 'failed'
            job['error'] = str(exc.detail)
    except Exception:
        log.exception('Audio worker error job_id=%s', job_id)
        with _lock:
            job['state'] = 'failed'
            job['error'] = 'Audio transcription failed; check the server log.'
    finally:
        # Raw media must never outlive processing. Keep downloadable text briefly.
        source.unlink(missing_ok=True)
        for clip in folder.glob('segment_*.wav'):
            clip.unlink(missing_ok=True)


@router.post('', status_code=202)
async def upload_audio(request: Request, file: UploadFile = File(...)):
    owner = current_owner(request)
    _cleanup_finished_jobs()
    suffix = Path(file.filename or '').suffix.lower()
    if suffix not in EXTENSIONS:
        raise HTTPException(415, 'Unsupported recording type. Try MP3, WAV, M4A, FLAC, OGG, WebM, MP4, MOV or another common audio/video format.')
    with _lock:
        pending = sum(1 for j in _jobs.values() if j['owner'] == owner and j['state'] not in ('completed','failed','cancelled'))
        if pending >= 2 or len([j for j in _jobs.values() if j['state'] not in ('completed','failed','cancelled')]) >= 6:
            raise HTTPException(429, 'Too many active recordings. Finish an existing transcription first.')
    job_id = uuid.uuid4().hex
    directory = WORK_ROOT / job_id
    directory.mkdir(mode=0o700, parents=True, exist_ok=False)
    source = directory / ('source' + suffix)
    count = 0
    try:
        with source.open('wb') as out:
            while True:
                chunk = await file.read(CHUNK_BYTES)
                if not chunk:
                    break
                count += len(chunk)
                if count > MAX_AUDIO_BYTES:
                    raise HTTPException(413, 'Maximum audio/video upload is 500 MiB (524,288,000 bytes).')
                out.write(chunk)
        if not count:
            raise HTTPException(422, 'The recording is empty.')
        key = os.getenv('MODEL_API_KEY', '').strip()
        if not key or key.startswith('replace_with_'):
            raise HTTPException(503, 'MODEL_API_KEY is not configured in your local .env.')
        if not ffmpeg_binary():
            raise HTTPException(503, 'FFmpeg could not be found. Reinstall requirements to include imageio-ffmpeg, or install FFmpeg.')
    except Exception:
        shutil.rmtree(directory, ignore_errors=True)
        raise
    with _lock:
        _jobs[job_id] = {'job_id':job_id,'owner':owner,'created':time.time(),
                         'state':'queued','bytes_received':count,'parts_total':0,
                         'parts_done':0,'error':None,'duration_seconds':0,
                         'transcript_preview':'','download_ready':False,
                         'cancel_requested':False}
    _pool.submit(_run_job, job_id, source, directory, key)
    return _snapshot(_jobs[job_id])


@router.get('/{job_id}')
def job_status(request: Request, job_id: str):
    return _snapshot(_job_for(request, job_id))


@router.post('/{job_id}/cancel')
def stop_job(request: Request, job_id: str):
    job = _job_for(request, job_id)
    with _lock:
        if job['state'] not in ('completed','failed','cancelled'):
            job['cancel_requested'] = True
    return _snapshot(job)


@router.get('/{job_id}/transcript')
def download_transcript(request: Request, job_id: str):
    job = _job_for(request, job_id)
    if job['state'] != 'completed' or not job['download_ready']:
        raise HTTPException(409, 'Transcription has not completed.')
    path = WORK_ROOT / job_id / 'transcript.txt'
    if not path.is_file():
        raise HTTPException(410, 'Transcript expired; start a new job.')
    return FileResponse(path, media_type='text/plain; charset=utf-8', filename='framepilot-transcript.txt')
