"""Meta Muse Image edit workflow for previously generated FramePilot stills.

This is prompt-guided image editing, not pixel-perfect mask inpainting. Optional
SAM geometry is used as a localization hint, not as a guaranteed hard mask.
"""
import base64
import os
import re
import uuid
from pathlib import Path
from typing import Any, Sequence
from io import BytesIO
from PIL import Image
from .art_layers import decode_mask

from .meta_client import _client, _image_data_url
from .meta_resilience import call_responses


def edit_storyboard_frame(image_path: Path, instruction: str, target: str = '', bbox: tuple[int, int, int, int] | None = None,
                          reference_images: Sequence[dict[str, Any]] | None = None,
                          style_instruction: str = '', selection: dict[str, Any] | None = None,
                          previous_response_id: str | None = None, include_response_id: bool = False) -> tuple[str, str] | tuple[str, str, str | None]:
    model = os.getenv('MUSE_IMAGE_MODEL', 'muse-image-1.0')
    if not image_path.is_file():
        raise FileNotFoundError('Generated frame does not exist.')
    shot_match = re.fullmatch(r'shot-(\d+)-[a-f0-9]{10}\.(?:png|jpg|webp)', image_path.name)
    if not shot_match:
        raise ValueError('Invalid generated storyboard file name.')
    where = ''
    if target:
        where += f'\nTarget object/character to change: {target}. '
    if bbox is not None:
        where += f'\nSAM 3.1 localized a possible target at pixel box (left, top, right, bottom) {bbox}. '
        where += 'Use this location to disambiguate the target; it is not an exact inpainting mask. '
    prompt = (
        'You are modifying an EXISTING single film storyboard image, not starting a new storyboard. '
        'Follow the requested edit while keeping everything unrelated unchanged. '
        'Preserve aspect ratio, camera angle, framing, lens perspective, environment, lighting, '
        'the faces and costumes of all unchanged characters, and all unmentioned props. '
        'Do not add borders, text, labels, split screens, or watermarks.\n'
        f'EDIT REQUEST: {instruction.strip()}\n{where}\n'
        + (f'RENDERING STYLE: {style_instruction}\n' if style_instruction else '') +
        'Return one edited image only.'
    )
    content = [{'type': 'input_text', 'text': prompt}]
    # An existing Muse conversation already carries the current image. For a
    # restored version or a manually uploaded frame, send the frame again.
    if not previous_response_id:
        content.append({'type': 'input_image', 'image_url': _image_data_url(image_path)})
    if selection is not None:
        # Supply a separately labelled visual selection guide to Muse Image.
        # The cyan overlay is not a hard editing mask; the model may still
        # alter other pixels. The original clean image remains input #1.
        with Image.open(image_path) as original:
            source=original.convert('RGB')
        mask=decode_mask(selection,source.size)
        tint=Image.new('RGB',source.size,(0,210,197))
        alpha=mask.point(lambda x:int(x*0.5))
        overlay=Image.composite(tint,source,alpha)
        output=BytesIO();overlay.save(output,format='PNG')
        guide='data:image/png;base64,'+base64.b64encode(output.getvalue()).decode('ascii')
        content.append({'type':'input_text','text':
            'The NEXT image is a target selection GUIDE: cyan pixels mark the exact item to modify. '
            'Use this guide to distinguish overlapping objects. Cyan is NOT part of the intended final artwork. '
            'Never reproduce the selection overlay in the final image.'})
        content.append({'type':'input_image','image_url':guide})
    for index, ref in enumerate(reference_images or [], start=1):
        content.append({'type': 'input_text', 'text': (
            f"Additional reference {index}: {ref['role']} / {ref['label']}. "
            f"{ref.get('instruction') or 'Apply only this reference role without changing unrelated details.'}")})
        content.append({'type': 'input_image', 'image_url': _image_data_url(ref['path'])})
    request = {'model': model, 'input': [{'role': 'user', 'content': content}]}
    if previous_response_id:
        request['previous_response_id'] = previous_response_id
    response = call_responses(_client(), **request)
    image_item = next((item for item in (getattr(response, 'output', []) or [])
                       if getattr(item, 'type', None) == 'image_generation_call' and getattr(item, 'result', None)), None)
    if image_item is None:
        raise ValueError('Muse Image returned no edited image. Check Meta model access and retry.')
    raw = base64.b64decode(image_item.result, validate=True)
    if raw.startswith(b'\x89PNG\r\n\x1a\n'):
        ext = 'png'
    elif raw.startswith(b'\xff\xd8\xff'):
        ext = 'jpg'
    elif raw[:4] == b'RIFF' and raw[8:12] == b'WEBP':
        ext = 'webp'
    else:
        raise ValueError('Muse Image response did not contain a supported image.')
    filename = f'shot-{shot_match.group(1)}-{uuid.uuid4().hex[:10]}.{ext}'
    (image_path.parent / filename).write_bytes(raw)
    if include_response_id:
        response_id = getattr(response, 'id', None)
        return filename, model, (response_id if isinstance(response_id, str) and len(response_id) <= 160 else None)
    return filename, model
