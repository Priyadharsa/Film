"""Original, illustrated production book: screenplay + technical shot cards + frames.

Informed by the interleaved script / image format of traditional illustrated
screenplay books, without reproducing third-party artwork or page designs.
"""
from __future__ import annotations
import html
import io
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak, Table, TableStyle, KeepTogether, Image, HRFlowable, Flowable
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image as PILImage
from .storyboard_schematic import draw_schematic

PAPER=colors.HexColor('#f6f0e4')
INK=colors.HexColor('#1b2428')
ACCENT=colors.HexColor('#ac6a39')
MID=colors.HexColor('#6f7775')
PALE=colors.HexColor('#e7ddca')

for name,path in [('FPSerif','/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'),('FPSans','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')]:
    try:pdfmetrics.registerFont(TTFont(name,path))
    except Exception:pass
SERIF='FPSerif' if 'FPSerif' in pdfmetrics.getRegisteredFontNames() else 'Times-Roman'
SANS='FPSans' if 'FPSans' in pdfmetrics.getRegisteredFontNames() else 'Helvetica'

STY={
 'cover_kicker':ParagraphStyle('coverkick',fontName=SANS,fontSize=10,leading=15,textColor=ACCENT,spaceAfter=18),
 'cover_title':ParagraphStyle('covertitle',fontName=SERIF,fontSize=36,leading=45,textColor=INK,spaceAfter=16),
 'cover_sub':ParagraphStyle('coversub',fontName=SANS,fontSize=12,leading=20,textColor=MID),
 'scene':ParagraphStyle('sceneh',fontName=SERIF,fontSize=19,leading=25,textColor=INK,spaceAfter=14),
 'eyebrow':ParagraphStyle('eyebrow',fontName=SANS,fontSize=8,leading=12,textColor=ACCENT,spaceBefore=12,spaceAfter=7),
 'script':ParagraphStyle('scriptbody',fontName=SERIF,fontSize=8.2,leading=13.2,textColor=INK,spaceAfter=5),
 'small':ParagraphStyle('small',fontName=SANS,fontSize=8,leading=12,textColor=MID),
 'tech':ParagraphStyle('tech',fontName=SANS,fontSize=8.2,leading=13.5,textColor=INK),
 'shot':ParagraphStyle('shot',fontName=SERIF,fontSize=12,leading=17,textColor=INK),
 'toc':ParagraphStyle('toc',fontName=SANS,fontSize=9.5,leading=17,textColor=INK),
}

def P(s,sty='small'):
    return Paragraph(html.escape(str(s)).replace('\n','<br/>'), STY[sty])

class CoverDrawing(Flowable):
    def __init__(self,width=470,height=255):super().__init__();self.width=width;self.height=height
    def draw(self):
        c=self.canv; w,h=self.width,self.height
        c.setStrokeColor(ACCENT);c.setLineWidth(.8)
        for i in range(10):
            c.line(w*.5,h*.28, i*w/9,h*.98)
        c.setStrokeColor(INK);c.setLineWidth(2.2)
        c.roundRect(18,h*.16,w-36,h*.72,10,fill=0,stroke=1)
        c.line(18,h*.52,w-18,h*.52)
        c.setStrokeColor(ACCENT);c.setLineWidth(1.4)
        c.circle(w*.5,h*.52,52,stroke=1,fill=0)
        c.circle(w*.5,h*.52,30,stroke=1,fill=0)
        c.circle(w*.5,h*.52,6,stroke=1,fill=0)
        c.setFont(SANS,9);c.setFillColor(INK)
        c.drawCentredString(w*.5,10,'STORY  /  SPACE  /  CAMERA  /  FRAME')

class FrameArt(Flowable):
    def __init__(self, img_path=None,width=253,height=142,shot=None):
        super().__init__();self.width=width;self.height=height;self.img_path=img_path;self.shot=shot or {}
    def draw(self):
        c=self.canv;w,h=self.width,self.height
        c.setFillColor(colors.HexColor('#ebe3d6'));c.rect(0,0,w,h,fill=1,stroke=0)
        c.setStrokeColor(MID);c.setLineWidth(.65);c.rect(0,0,w,h,fill=0,stroke=1)
        if self.img_path and self.img_path.is_file():
            try:
                with PILImage.open(self.img_path) as im: iw,ih=im.size
                s=min(w/iw,h/ih);pw,ph=iw*s,ih*s
                c.drawImage(str(self.img_path),(w-pw)/2,(h-ph)/2,pw,ph,preserveAspectRatio=True,mask='auto')
                return
            except Exception:pass
        # An original, shot-specific blocking sketch, never labelled as Muse artwork.
        draw_schematic(c,0,0,w,h,self.shot)

class BookDoc(BaseDocTemplate):
    def __init__(self,buffer, title):
        BaseDocTemplate.__init__(self,buffer,pagesize=A4,leftMargin=19*mm,rightMargin=19*mm,topMargin=22*mm,bottomMargin=20*mm,
                                 title=title+' - FramePilot Production Book',author='FramePilot AI')
        fr=Frame(self.leftMargin,self.bottomMargin,self.width,self.height,leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
        self.addPageTemplates(PageTemplate(id='page',frames=fr,onPage=self.decorate))
    def decorate(self,c,doc):
        w,h=A4;c.setFillColor(PAPER);c.rect(0,0,w,h,fill=1,stroke=0)
        c.setStrokeColor(PALE);c.setLineWidth(.8);c.line(19*mm,h-14*mm,w-19*mm,h-14*mm)
        c.line(19*mm,14*mm,w-19*mm,14*mm)
        c.setFont(SANS,7.1);c.setFillColor(MID)
        c.drawString(19*mm,10*mm,'FRAMEPILOT  /  PRODUCTION BOOK')
        c.drawRightString(w-19*mm,10*mm,f'{doc.page:03d}   ·   DIRECTOR EDITION')


def _asset_path(url:str|None,generated_dir:Path):
    if not url or not isinstance(url,str):return None
    name=url.split('?')[0].split('/')[-1]
    if not name or name in ('.','..') or '/' in name or '\\' in name:return None
    path=generated_dir/name
    try:path.resolve().relative_to(generated_dir.resolve())
    except ValueError:return None
    return path if path.is_file() else None


def shot_card(shot,generated_dir):
    info=[P(f"SHOT {shot['number']:02d}  /  {shot.get('name','Coverage')}",'shot'),Spacer(1,7)]
    fields=[
        ('FRAMING',shot.get('shot_type','—')),
        ('ANGLE',shot.get('camera_angle','—')),
        ('MOVEMENT',shot.get('camera_movement','—')),
        ('LENS',f"{shot.get('lens_mm',35)} mm"),
        ('DURATION',f"{shot.get('duration_s',5)} s"),
        ('STYLE',shot.get('style_preset','graphite')),
        ('STATUS',shot.get('status','Draft')),
    ]
    camera=shot.get('camera') or {}
    if camera:
        fields.append(('CAMERA XYZ',f"{camera.get('x',0)} / {camera.get('y',1.65)} / {camera.get('z',5.7)} m"))
        fields.append(('PAN / TILT',f"{camera.get('pan',0)}° / {camera.get('tilt',-3)}°"))
        if camera.get('objects'):
            fields.append(('3D OBJECTS',str(len(camera.get('objects',[])))))
    for label,value in fields:
        info.append(P(f'{label}: {value}','tech'))
    image_path=_asset_path(shot.get('image_url') or shot.get('sketch_url'),generated_dir)
    art=FrameArt(image_path,shot=shot)
    inner=Table([[art,info]],colWidths=[259,221],hAlign='LEFT')
    inner.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
    narrative=P(shot.get('description',''),'script')
    purpose=P('DIRECTOR INTENT  /  '+shot.get('purpose',''),'small')
    notes=P('NOTES  /  '+shot.get('notes',''),'small') if shot.get('notes') else Spacer(1,1)
    return KeepTogether([inner, Spacer(1,7), narrative, purpose, notes, Spacer(1,12),HRFlowable(width='100%',color=PALE,thickness=.8)])


def export_production_book(project:dict, generated_dir:Path)->bytes:
    buf=io.BytesIO()
    doc=BookDoc(buf,project['title'])
    story=[]
    story += [Spacer(1,33*mm),P('AN ILLUSTRATED PRE-PRODUCTION DOCUMENT','cover_kicker'),P(project['title'].upper(),'cover_title'),
              P('THE DIRECTOR’S PRODUCTION BOOK','cover_sub'),Spacer(1,24),CoverDrawing(width=480,height=250),Spacer(1,40),
              P(f"{len(project['scenes'])} SCENES   /   {sum(len(x['shots']) for x in project['scenes'])} SHOTS   /   CAMERA · REFERENCE · ANNOTATION",'eyebrow'),
              P('Exported from FramePilot. AI imagery and technical plans are working drafts until explicitly approved by the production team.','small'),PageBreak()]
    story += [P('CONTENTS / SCENE INDEX','scene')]
    for sc in project['scenes']:
        story.append(P(f"{sc['number']:02d}     {sc['slugline']}     ·     {len(sc['shots'])} shots",'toc'))
    story += [Spacer(1,15),HRFlowable(width='100%',thickness=1,color=ACCENT),Spacer(1,10),P('An original production-book layout combining screenplay text with shot sketches, generated frames, lens notes and scene coverage.','small')]
    for scene in project['scenes']:
        story += [PageBreak(),P(f"SCENE {scene['number']:02d} / SCREENPLAY & VISUAL COVERAGE",'eyebrow'),P(scene['slugline'],'scene'),
                  P(f"{len(scene['shots'])} SHOTS  ·  {scene.get('source','manual').upper()} BREAKDOWN  ·  {'APPROVED' if scene.get('approved') else 'DRAFT'}",'small'),
                  P('SOURCE PAGE(S) / '+(', '.join(str(i) for i in scene.get('source_pages',[])[:12]) or 'NOT LINKED'),'small'),
                  Spacer(1,7),HRFlowable(width='100%',thickness=1,color=ACCENT),P('SCREENPLAY','eyebrow')]
        # Preserve actual screenplay scene text (including paragraphs) without fabricating dialogue.
        lines=scene.get('text','').splitlines()
        if not any(line.strip() for line in lines):story.append(P('No screenplay lines for this scene.','small'))
        else:
            chunk=[]
            for line in lines:
                if not line.strip():
                    if chunk:story.append(P('\n'.join(chunk),'script'));chunk=[]
                else:chunk.append(line)
            if chunk:story.append(P('\n'.join(chunk),'script'))
        story += [Spacer(1,5),P('VISUAL SHOT SEQUENCE','eyebrow')]
        for shot in scene['shots']:
            story.append(shot_card(shot,generated_dir))
    doc.build(story)
    return buf.getvalue()
