"""Screenplay text extraction and conservative scene parsing.

A deterministic parser is used by default: scene/shot guesses are explicitly drafts.
Scanned scripts need an opt-in OCR fallback; no text is fabricated.
"""
from __future__ import annotations

import os
import re
import uuid
# Tesseract can start dozens of OpenMP threads per page and stall large scanned PDFs.
os.environ.setdefault("OMP_THREAD_LIMIT", "1")
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

SLUG = re.compile(r"^\s*(?:\d+[.\s]+)?((?:INT\.?\s*/\s*EXT\.?|EXT\.?\s*/\s*INT\.?|INT\.?|EXT\.?|I/E\.?|EST\.?)(?:\s+|\.\s*)(?:[^\n]{2,130}))\s*$", re.I)
MAX_SCRIPT_CHARS = 5_000_000
MAX_PAGES = 10000
MAX_OCR_PAGES = 250


def normalize(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    text = re.sub(r"[\t\u00a0]+", " ", text)
    text = re.sub(r"\n{5,}", "\n\n\n", text)
    if len(text) > MAX_SCRIPT_CHARS:
        raise ValueError(f"Screenplay contains more than {MAX_SCRIPT_CHARS:,} characters. Split into separate screenplay volumes.")
    return text.strip()


def _ocr_page_bytes(index: int, pixel_bytes: bytes, size: tuple[int, int]) -> tuple[int, str]:
    """Isolated text recognition; never invents missing screenplay lines."""
    import pytesseract
    from PIL import Image
    image = Image.frombytes('RGB', size, pixel_bytes)
    try:
        return index, pytesseract.image_to_string(image, lang='eng', config='--psm 6', timeout=30).strip()
    except Exception as exc:
        raise ValueError(f'OCR failed on page {index+1}; check the Tesseract installation or scan quality: {type(exc).__name__}') from exc


def _extract_doc(doc, *, ocr: bool = True, include_pages: bool = False) -> tuple[str, dict]:
    """Read *every* PDF page. A scanned screenplay may not silently import as two pages.

    OCR is attempted only for image-bearing pages with insufficient selectable text.
    The binary Tesseract is a runtime prerequisite, not an API service.
    """
    if doc.needs_pass:
        raise ValueError('Encrypted PDF: export an unlocked copy before importing.')
    if len(doc) > MAX_PAGES:
        raise ValueError(f'PDF exceeds {MAX_PAGES} pages; split into smaller parts.')
    chunks, image_pages = [], []
    total = 0
    for index, page in enumerate(doc):
        part = page.get_text('text', sort=True).strip()
        if len(part) < 35 and bool(page.get_images(full=True)):
            image_pages.append(index)
        total += len(part)
        if total > MAX_SCRIPT_CHARS:
            raise ValueError('Extracted screenplay text is too long; split the document.')
        chunks.append(part)
    count = len(image_pages)
    if count and not ocr:
        raise ValueError(
            f'Incomplete screenplay: {count} of {len(doc)} PDF pages contain scanned images '
            'without readable text. Turn ON OCR before importing; do not render this partial script.'
        )
    if count:
        if count > MAX_OCR_PAGES:
            raise ValueError(f'OCR is limited to {MAX_OCR_PAGES} scanned pages per import; divide into volumes.')
        try:
            import pytesseract
            from PIL import Image
            pytesseract.get_tesseract_version()
        except Exception as exc:
            raise ValueError(
                f'This PDF has {count} scanned pages. Install Tesseract OCR and restart FramePilot, '
                'or upload a searchable PDF. FramePilot will not create incomplete storyboards.'
            ) from exc
        # Each page is rendered within a strict pixel cap; Tesseract runs as a bounded
        # subprocess in a separate thread so 100+ page scans do not serialize fully.
        def recognize(index: int) -> tuple[int, str]:
            import fitz
            import pytesseract
            from PIL import Image
            pix = doc[index].get_pixmap(matrix=fitz.Matrix(1.35, 1.35), alpha=False)
            if pix.width * pix.height > 12_000_000:
                raise ValueError(f'OCR page {index+1} is too large to rasterize safely.')
            image = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
            return index, pytesseract.image_to_string(image, lang='eng', config='--psm 6', timeout=35).strip()
        # PDF page rasterizing must be serialized when sharing a fitz.Document instance;
        # preload at most a few pages at a time instead of sharing it across threads.
        def batch_pages(indices: list[int]):
            import fitz
            from PIL import Image
            rendered = []
            for index in indices:
                pix = doc[index].get_pixmap(matrix=fitz.Matrix(1.35, 1.35), alpha=False)
                if pix.width * pix.height > 12_000_000:
                    raise ValueError(f'OCR page {index+1} is too large to rasterize safely.')
                rendered.append((index, pix.samples, (pix.width, pix.height)))
            with ThreadPoolExecutor(max_workers=2) as pool:
                futures = [pool.submit(_ocr_page_bytes, *item) for item in rendered]
                for future in as_completed(futures):
                    index, content = future.result()
                    chunks[index] = content
        # Bound decoded pixel memory to batches of 4 pages.
        for offset in range(0, count, 4):
            batch_pages(image_pages[offset:offset+4])
        unreadable = [i+1 for i in image_pages if len(chunks[i].strip()) < 30]
        # A small number of blank/visual pages is normal; widespread failure isn't.
        if len(unreadable) > max(2, int(count * 0.10)):
            raise ValueError(
                f'OCR could not read {len(unreadable)} of {count} scanned pages '
                f'(examples: {unreadable[:6]}). Try a higher-resolution searchable PDF.'
            )
    if sum(len(chunk) for chunk in chunks) < 50:
        raise ValueError('PDF contains too little readable screenplay text. If the pages are scanned, use OCR; verify the PDF contains a screenplay.')
    if count > 0 and sum(bool(t.strip()) for t in chunks) < len(doc) - max(3, len(doc)//10):
        raise ValueError('Import would omit too many screenplay pages. Please rescan or OCR the PDF.')
    return normalize('\n\n'.join(chunks)), {
        **({'page_texts': chunks} if include_pages else {}),
        'pages': len(doc), 'image_only_pages': count,
        'ocr_used': bool(count and ocr),
        'extraction': 'PDF text + OCR' if count else 'PDF text',
        'pages_with_text': sum(bool(chunk.strip()) for chunk in chunks),
        'extraction_complete': True,
    }


def extract_pdf_text(raw: bytes, *, ocr: bool = True, include_pages: bool = False) -> tuple[str, dict]:
    """Compatibility for small existing uploads; new 1GiB ingestion uses the file path API."""
    import fitz
    if not raw.startswith(b'%PDF-'):
        raise ValueError('This is not a PDF. Choose a screenplay PDF file.')
    try:
        with fitz.open(stream=raw,filetype='pdf') as doc:
            return _extract_doc(doc,ocr=ocr,include_pages=include_pages)
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError('Could not read this PDF. Check corruption or protection.') from exc


def extract_pdf_file(path: Path, *, ocr: bool = True, include_pages: bool = False) -> tuple[str, dict]:
    """Open a PDF from disk without loading the entire (up-to-1GiB) file into RAM."""
    import fitz
    with Path(path).open('rb') as stream:
        if stream.read(5) != b'%PDF-':
            raise ValueError('This is not a PDF.')
    try:
        with fitz.open(filename=str(path),filetype='pdf') as doc:
            return _extract_doc(doc,ocr=ocr,include_pages=include_pages)
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError('Could not read this PDF. Check corruption or protection.') from exc

def _shot_template(scene_heading: str, scene_text: str, sequence: int) -> dict:
    label = ['ESTABLISHING', 'CHARACTER / COVERAGE', 'DETAIL / REACTION'][sequence % 3]
    shot_types = ['Wide shot', 'Medium shot', 'Close-up']
    excerpt = ' '.join(scene_text.split())[:240] or scene_heading
    types = shot_types[sequence % 3]
    purposes = ['Establish environment and geography', 'Clarify character action and eyelines', 'Emphasize an important detail or emotional reaction']
    return {
        'id': uuid.uuid4().hex[:12],
        'number': sequence + 1,
        'name': label.title(),
        'shot_type': types, 'camera_angle': 'Eye level',
        'camera_movement': 'Static', 'lens_mm': [24, 50, 85][sequence % 3],
        'duration_s': 5, 'description': f"{label}: {excerpt}",
        'purpose': purposes[sequence % 3],
        'notes': '', 'status': 'Draft', 'references': [],
        'style_preset': 'graphite', 'style_custom': '', 'image_url': None,
        'sketch_url': None, 'history': [], 'camera': {
            'x': 0, 'y': 1.65, 'z': 5.7, 'pan': 0, 'tilt': -3,
            'lens': [24, 50, 85][sequence % 3], 'view': 'camera',
            'actors': [{'name': 'Actor A', 'x': -1, 'z': 0}, {'name': 'Actor B', 'x': 1, 'z': 0}],
        }
    }


def page_records(text: str, page_texts: list[str] | None = None) -> list[dict]:
    """Create separately editable book leaves. PDF pages are preserved; text uses logical leaves."""
    if page_texts is None:
        # Separate text into readable book leaves, without an artificial 240-scene cutoff.
        source = normalize(text).splitlines(keepends=True)
        chunks, current = [], []
        for line in source:
            if current and (len(''.join(current)) >= 3200 or len(current) >= 54):
                chunks.append(''.join(current).rstrip()); current = []
            current.append(line)
        if current or not chunks: chunks.append(''.join(current).rstrip())
    else:
        chunks = [str(t) for t in page_texts]
    return [{'number': n, 'text': chunk, 'scene_ids': [], 'notes': ''}
            for n, chunk in enumerate(chunks, 1)]


def parse_scenes(text: str, page_texts: list[str] | None = None) -> list[dict]:
    """Split a whole screenplay into scene drafts, retaining source PDF-page provenance.

    No small arbitrary scene limit. Each page can be opened even if it does not
    introduce a new scene. For very large projects, avoid multiplying shots.
    """
    text = normalize(text)
    if not text:
        raise ValueError('The screenplay text is empty.')
    if page_texts is None:
        entries = [(line, 0, i) for i, line in enumerate(text.splitlines(), 1)]
    else:
        entries = [(line, page, i) for page, contents in enumerate(page_texts, 1)
                   for i, line in enumerate(str(contents).splitlines(), 1)]
    groups = []
    heading = 'SCENE 1 · UNTITLED'
    body = []
    pages: set[int] = set()
    start_line = 1
    has_heading = False
    def flush():
        if has_heading or any(x.strip() for x in body):
            groups.append((heading, '\n'.join(body).strip(), sorted(pages), start_line))
    for line, page, line_no in entries:
        match = SLUG.fullmatch(line.strip())
        if match and len(line.strip()) < 145:
            if has_heading or not groups and not any(x.strip() for x in body):
                flush()
            # Title-page material before the first real scene is retained in book pages,
            # but it should not create a false narrative scene.
            heading = match.group(1).strip().upper()
            body = []
            pages = {page} if page else set()
            start_line = line_no
            has_heading = True
        else:
            body.append(line)
            if page: pages.add(page)
    flush()
    if len(groups) > 10000:
        raise ValueError('The screenplay has over 10,000 scene headings. Use a project per volume.')
    shots_per_scene = 3 if len(groups) <= 160 else 1
    scenes=[]
    for n, (slugline, scene_text, source_pages, first_line) in enumerate(groups, 1):
        shots = [_shot_template(slugline, scene_text, i) for i in range(shots_per_scene)]
        for sh in shots: sh['source_page'] = source_pages[0] if source_pages else None
        scenes.append({
            'id': uuid.uuid4().hex[:12], 'number': n, 'slugline': slugline,
            'text': scene_text[:150000], 'shots': shots,
            'source': 'template', 'approved': False,
            'notes': '', 'source_pages': source_pages, 'source_line': first_line,
            'estimated_pages': max(1, round(len(scene_text) / 1700, 1)),
        })
    return scenes


def connect_pages(pages: list[dict], scenes: list[dict]) -> list[dict]:
    """Annotate each original page with the scenes that touch it.

    If a page has no script heading (title, illustration or blank) retain it
    as its own editable page; users can attach a new scene later.
    """
    by_page = {page['number']: [] for page in pages}
    for scene in scenes:
        for no in scene.get('source_pages', []):
            if no in by_page: by_page[no].append(scene['id'])
    for page in pages: page['scene_ids'] = by_page[page['number']]
    return pages
