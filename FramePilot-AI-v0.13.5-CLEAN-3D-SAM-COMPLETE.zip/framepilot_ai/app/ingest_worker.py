"""Separate persistent import worker: python -m app.ingest_worker.

For local demo runs this is a second process. For cloud, use an isolated worker
container with queue/DB credentials and resource limits. No model API calls here.
"""
from __future__ import annotations

import argparse
import logging
import tempfile
import time
import threading
from pathlib import Path

from .upload_core import UploadService, UploadError, verify_magic
from .auth import actor_id
from .project_store import ProjectStore
from .screenplay_parser import extract_pdf_file, normalize, parse_scenes, page_records, connect_pages, MAX_SCRIPT_CHARS
from .storyboard_planner import expand_scenes

ROOT=Path(__file__).resolve().parent.parent
from dotenv import load_dotenv
load_dotenv(ROOT/'.env')
LOGGER=logging.getLogger('framepilot.ingest')


def process_one(service:UploadService|None=None,project_store:ProjectStore|None=None):
    service=service or UploadService(ROOT/'private_uploads'/'ingest')
    project_store=project_store or ProjectStore(ROOT/'private_uploads')
    worker_token=actor_id.set('system')
    row=service.claim()
    if row is None:
        actor_id.reset(worker_token)
        return False
    ident=row['id'];temp=None
    stop_heartbeat=threading.Event()
    def renew():
        while not stop_heartbeat.wait(30):
            try:service.renew_lease(ident)
            except Exception:LOGGER.exception('Lease renewal failed for %s',ident)
    heart=threading.Thread(target=renew,daemon=True)
    heart.start()
    try:
        # Stable project identifier makes retries idempotent after worker crashes.
        pid=ident[:12]
        exists=project_store.get(pid)
        if exists:
            service.mark_success(ident,pid)
            return True
        if row['backend']=='s3':
            with tempfile.NamedTemporaryFile(prefix='fp-ingest-',suffix=row['ext'],delete=False) as t:
                temp=Path(t.name)
            service.download_s3(row,temp)
            path=temp
        else:path=service.local_path(row)
        verify_magic(path,row['ext'])
        if row['ext']=='.pdf':
            text,info=extract_pdf_file(path,ocr=bool(row['ocr']),include_pages=True)
        elif row['ext']=='.txt':
            if row['size']>MAX_SCRIPT_CHARS*4:
                raise ValueError('This text screenplay exceeds the parser limit. Split the screenplay into volumes.')
            try:text=path.read_text(encoding='utf-8-sig')
            except UnicodeDecodeError:raise ValueError('Text file must be UTF-8.')
            text=normalize(text)
            info={'pages':None,'extraction':'UTF-8 screenplay text','ocr_used':False}
        else:raise ValueError('Screenplay uploads must be PDF or TXT.')
        source_pages=info.pop('page_texts',None)
        pages=page_records(text,source_pages)
        scenes=parse_scenes(text,[pg['text'] for pg in pages])
        coverage=expand_scenes(scenes,fresh=True)
        pages=connect_pages(pages,scenes)
        original={'filename':row['filename'], 'upload_id':ident, 'size_bytes':row['size'],
                  'backend':row['backend'], 'sha256':row['digest'], 'storyboard_plan':coverage, **info}
        project=project_store.create(row['title'] or Path(row['filename']).stem,scenes,original,pid=pid,pages=pages,owner_id=row['owner_id'])
        service.mark_success(ident,project['id'])
    except Exception as exc:
        LOGGER.exception('Import failed for upload %s', ident)
        # Validation errors are deterministic: do not make users wait for retry backoff.
        service.mark_failure(ident,f'{type(exc).__name__}: {exc}',permanent=isinstance(exc,(UploadError,ValueError)))
    finally:
        stop_heartbeat.set()
        heart.join(timeout=1)
        if temp:temp.unlink(missing_ok=True)
        actor_id.reset(worker_token)
    return True


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--once',action='store_true',help='Process a single queued job and exit')
    parser.add_argument('--cleanup',action='store_true',help='Remove stale upload files and exit')
    parser.add_argument('--poll-seconds',type=float,default=2.0)
    args=parser.parse_args()
    logging.basicConfig(level=logging.INFO)
    service=UploadService(ROOT/'private_uploads'/'ingest')
    store=ProjectStore(ROOT/'private_uploads')
    if args.cleanup:
        print(f'Cleaned {service.cleanup()} expired/stale source uploads')
        return
    last_cleanup=time.monotonic()
    while True:
        worked=process_one(service,store)
        if time.monotonic()-last_cleanup>3600:
            service.cleanup()
            last_cleanup=time.monotonic()
        if args.once:break
        if not worked:time.sleep(max(0.2,args.poll_seconds))


if __name__=='__main__':main()
