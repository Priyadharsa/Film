"""Director-editable draft shot sequences, NOT automatic narrative understanding."""
from __future__ import annotations
from .screenplay_parser import _shot_template

PATTERNS={
'introduction': [('Geography reveal','Wide shot','Establish where the character enters.'),('Silhouette entrance','Medium shot','Reveal the character through blocking.'),('Identity reveal','Close-up','Land the introduction on a meaningful expression.')],
'romance': [('Shared space','Two-shot','Establish the relationship within the location.'),('Eyeline connection','Over-the-shoulder','Show one perspective and the response.'),('Intimate detail','Insert','Find a specific emotional gesture from the script.')],
'fight': [('Action geography','Wide shot','Make fighters and exits readable.'),('Anticipation','Medium shot','Show intention before impact.'),('Impact and response','Close-up','Highlight a legible action-reaction beat.'),('Consequence','Wide shot','Re-establish spatial continuity after the action.')],
'suspense': [('Isolated environment','Wide shot','Establish hiding places and negative space.'),('Ambiguous signal','Insert','Highlight a concrete scripted clue.'),('Character discovery','Close-up','Show the reaction before revealing the source.')],
'climax': [('Converging positions','Wide shot','Clarify where all players stand.'),('Irreversible choice','Medium shot','Focus on the decisive action.'),('Consequence','Close-up','Hold the emotional cost of the decision.'),('Resolution image','Wide shot','Conclude with a meaningful visual transformation.')],
'interval': [('False security','Wide shot','Establish the apparent balance.'),('Reversal','Medium shot','Reveal the change in information or power.'),('Unanswered image','Close-up','End on a specific narrative question, not a random cliffhanger.')],
'comedy': [('Setup','Wide shot','Establish visible expectations.'),('Misdirection','Medium shot','Let the audience anticipate the wrong outcome.'),('Payoff','Close-up','Capture the surprise or character response.')],
'emotion': [('Quiet geography','Wide shot','Use environmental distance to express mood.'),('Gesture','Insert','Find a revealing detail, not exposition.'),('Reaction','Close-up','Allow the emotional turn to read.')],
'montage': [('Opening motif','Wide shot','Set a recurring visual idea.'),('Process detail','Insert','Show one change in time or action.'),('Progress image','Medium shot','Show a visible shift.'),('Final motif','Wide shot','End with a changed version of the opening image.')],
}

def create_pattern(slug:str,scene_text:str,existing:int,name:str)->list[dict]:
    sequence=PATTERNS[name]
    result=[]
    for idx,(label,shot_type,purpose) in enumerate(sequence):
        sh=_shot_template(slug,scene_text,idx)
        sh['number']=existing+idx+1
        sh.update(name=label,shot_type=shot_type,purpose=purpose,
                  description=f'{label}: {purpose} Ground the blocking in this scene: '+ ' '.join(scene_text.split())[:240],
                  status='Draft')
        result.append(sh)
    return result
