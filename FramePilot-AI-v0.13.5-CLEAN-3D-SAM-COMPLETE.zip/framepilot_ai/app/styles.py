"""Curated visual languages for film stills; styles are descriptions, not guaranteed filters."""

STYLE_PRESETS: dict[str, dict[str, str]] = {
    "graphite": {"label": "Graphite storyboard", "family": "Storyboard", "prompt": "professional graphite pencil storyboard drawing, clean confident lines, soft gray values, production-ready shot readability"},
    "technical": {"label": "Technical line drawing", "family": "Storyboard", "prompt": "engineering-style precise perspective line art with architectural construction lines and light gray hatching, cinematic floor-plan-aware perspective, monochrome"},
    "ink_bw": {"label": "Black & white ink", "family": "Storyboard", "prompt": "black-and-white ink illustration, bold contour lines, deep shadows, expressive crosshatching, crisp tonal separation"},
    "charcoal": {"label": "Charcoal", "family": "Traditional", "prompt": "expressive black charcoal drawing on textured paper, dramatic rubbed shadows, restrained highlights"},
    "watercolor": {"label": "Watercolor", "family": "Traditional", "prompt": "hand-painted watercolor illustration on cold-press paper, expressive transparent pigments, delicate wet-on-wet washes"},
    "oil": {"label": "Oil painting", "family": "Traditional", "prompt": "cinematic traditional oil painting with visible brush strokes, rich pigments, layered paint texture, atmospheric light"},
    "pastel": {"label": "Soft pastel", "family": "Traditional", "prompt": "soft pastel illustration on toothy paper, subtle powdered pigment grain, textured strokes, warm highlights"},
    "photoreal": {"label": "Live-action film still", "family": "Cinema", "prompt": "photorealistic live-action film still, natural skin textures, motivated cinematic lighting, plausible production design, high-quality cinematography"},
    "noir": {"label": "Black & white film noir", "family": "Cinema", "prompt": "1940s-inspired black-and-white film noir still, hard chiaroscuro lighting, expressive shadow patterns, silver gelatin tonality"},
    "anime": {"label": "2D anime · cel shaded", "family": "Animation", "prompt": "original hand-drawn Japanese-style 2D animation frame, elegant cel shading, defined clean contours, cinematic anime lighting, expressive faces, consistent character design"},
    "manga": {"label": "Manga · monochrome", "family": "Animation", "prompt": "original monochrome manga illustration with precise ink linework, screentone shading, dynamic perspective, detailed black-and-white backgrounds; one full-frame illustration, no comic panels"},
    "animation_2d": {"label": "Hand-drawn 2D animation", "family": "Animation", "prompt": "original expressive hand-drawn 2D feature animation still, flowing clean linework, flat painted areas, cohesive character proportions"},
    "cartoon": {"label": "Western cartoon", "family": "Animation", "prompt": "stylized original Western 2D cartoon animation frame, appealing shape language, clear silhouettes, bold readable poses, vibrant graphic colors"},
    "animation_3d": {"label": "Stylized 3D animation", "family": "Animation", "prompt": "original stylized 3D animated film still, dimensional characters with appealing proportions, physically plausible soft materials, art-directed lighting"},
    "stop_motion": {"label": "Stop-motion clay", "family": "Animation", "prompt": "handmade stop-motion clay animation set, sculpted clay character textures, handcrafted props, miniature cinematography, tactile materials"},
    "comic": {"label": "Graphic novel / comic", "family": "Illustration", "prompt": "single frame from an original graphic novel, graphic ink linework, bold color blocks, dramatic graphic shadows, restrained halftone texture, no panels"},
    "concept": {"label": "Cinematic concept art", "family": "Illustration", "prompt": "high-end film concept art, cinematic digital painting, readable environmental storytelling, dramatic atmospheric depth"},
    "pixel": {"label": "Pixel art", "family": "Illustration", "prompt": "meticulously detailed cinematic pixel-art scene with deliberate limited palette, crisp raster edges, coherent pixel scale"},
}


# Additional original visual-language presets; they are prompts, not deterministic filters.
STYLE_PRESETS.update({
    'blueprint': {"label": 'Architectural blueprint', "family": 'Storyboard', "prompt": 'blue-white architectural blueprint, measured perspective construction, object silhouettes, plan-elevation details, extremely clean linework'},
    'storyboard_marker': {"label": 'Storyboard marker', "family": 'Storyboard', "prompt": 'professional storyboard marker drawings, bold brush pen, gray marker wash, readable silhouettes'},
    'storyboard_thumbnails': {"label": 'Loose thumbnail sketches', "family": 'Storyboard', "prompt": 'fast cinematic thumbnail sketches, gestural composition, decisive arrows for action and camera movement'},
    'stippling': {"label": 'Stippling ink', "family": 'Storyboard', "prompt": 'high detail black ink stippling, pointillist shadow structure and pen-and-ink contours'},
    'woodcut': {"label": 'Woodcut print', "family": 'Traditional', "prompt": 'traditional woodcut relief-print aesthetic with bold black carve marks, graphic negative space'},
    'linocut': {"label": 'Linocut poster', "family": 'Traditional', "prompt": 'hand-carved linocut print, thick simplified ink shapes, high contrast and imperfect edges'},
    'gouache': {"label": 'Opaque gouache', "family": 'Traditional', "prompt": 'opaque gouache painting, matte richly layered color blocks, visible brush texture'},
    'acrylic': {"label": 'Acrylic canvas', "family": 'Traditional', "prompt": 'acrylic painting with crisp expressive bold brushwork and luminous color'},
    'tempera': {"label": 'Egg tempera', "family": 'Traditional', "prompt": 'traditional egg tempera painting, fine subtle hatching, muted jewel pigment'},
    'ink_wash': {"label": 'Sumi ink wash', "family": 'Traditional', "prompt": 'expressive monochrome sumi ink wash, soft bleeding edges and restrained gesture'},
    'colored_pencil': {"label": 'Colored pencil', "family": 'Traditional', "prompt": 'colored pencil illustration on textured paper, layered soft strokes and controlled linework'},
    'ballpoint': {"label": 'Ballpoint drawing', "family": 'Traditional', "prompt": 'crosshatched ballpoint-pen sketch, delicate blue ink and expressive tonal build-up'},
    'chalk': {"label": 'Sidewalk chalk', "family": 'Traditional', "prompt": 'chalk pastel on rough dark paper, handmade gradients and dusty edges'},
    'impasto': {"label": 'Van Gogh-inspired impasto', "family": 'Traditional', "prompt": 'original post-impressionist inspired painting, swirling expressive impasto brushwork, vibrant complementary colors, dynamic night skies'},
    'impressionist': {"label": 'Impressionist plein air', "family": 'Traditional', "prompt": 'impressionist outdoor oil painting, broken colored brushmarks, shifting natural light and painterly edges'},
    'expressionist': {"label": 'Expressionist painting', "family": 'Traditional', "prompt": 'emotive expressionist color painting, angular strokes, subjective saturated color'},
    'surreal': {"label": 'Surreal dream painting', "family": 'Traditional', "prompt": 'dreamlike surreal painting, impossible yet coherent cinematic perspective and symbolic elements'},
    'minimal': {"label": 'Minimalist flat illustration', "family": 'Illustration', "prompt": 'restrained flat 2D editorial illustration, minimalist shapes, limited palette, precise composition'},
    'vector': {"label": 'Crisp vector', "family": 'Illustration', "prompt": 'clean vector art, scalable graphic shapes, controlled gradients, polished contours'},
    'risograph': {"label": 'Risograph', "family": 'Illustration', "prompt": 'misregistered two-color risograph print, soy ink grain, nostalgic print texture'},
    'screenprint': {"label": 'Screenprint poster', "family": 'Illustration', "prompt": 'vintage silkscreen poster, chunky graphic ink layers, bold limited colors'},
    'halftone': {"label": 'Halftone comic noir', "family": 'Illustration', "prompt": 'dramatic halftone comic print, expressive black shadows, restrained red accent and vintage paper'},
    'ligne_claire': {"label": 'Clear-line comic', "family": 'Illustration', "prompt": 'original clear-line European comic illustration, even elegant outlines and carefully detailed backgrounds'},
    'newspaper_comic': {"label": 'Newspaper comic', "family": 'Illustration', "prompt": 'original newspaper comic strip illustration style, bold ink contours and flat muted print colors, single image no text'},
    'webtoon': {"label": 'Webtoon color', "family": 'Animation', "prompt": 'contemporary original full-color digital webcomic illustration, polished character faces, cinematic framing'},
    'shoujo': {"label": 'Romantic manga', "family": 'Animation', "prompt": 'original romantic shoujo manga-inspired ink illustration, expressive delicate linework, atmospheric screentones'},
    'seinen': {"label": 'Dramatic mature manga', "family": 'Animation', "prompt": 'original dramatic mature manga black-and-white illustration, intricate pen hatching, shadow depth and grounded anatomy'},
    'action_manga': {"label": 'Action manga', "family": 'Animation', "prompt": 'original energetic action manga still, strong foreshortening, speed lines, expressive monochrome ink'},
    'chibi': {"label": 'Chibi animation', "family": 'Animation', "prompt": 'original chibi 2D cartoon frame, compact expressive proportions, charming flat colors'},
    'retro_anime': {"label": 'Retro cel animation', "family": 'Animation', "prompt": 'original analog-era cel animation still, hand painted backgrounds, warm film grain and classic clean contours'},
    'anime_watercolor': {"label": 'Watercolor anime', "family": 'Animation', "prompt": 'original soft watercolor Japanese-style animation background, delicate pigments and expressive cel-character linework'},
    'paper_cutout': {"label": 'Cut-paper animation', "family": 'Animation', "prompt": 'layered colored-paper stop-motion animation, visible cut edges, tactile paper texture'},
    'puppet': {"label": 'Puppet theatre animation', "family": 'Animation', "prompt": 'miniature puppet theatre aesthetic, handmade cloth figures and practical stage lighting'},
    'lowpoly': {"label": 'Low-poly 3D', "family": 'Animation', "prompt": 'coherent low-polygon stylized 3D animated shot, angular geometry, flat shaded materials'},
    'voxel': {"label": 'Voxel diorama', "family": 'Animation', "prompt": 'cinematic voxel diorama, tiny block-built actors, controlled volumetric lighting'},
    'toon3d': {"label": 'Toon-shaded 3D', "family": 'Animation', "prompt": 'three-dimensional cel-shaded original characters, ink-like contour rendering, readable silhouette'},
    'retro_game': {"label": 'Retro adventure game', "family": 'Animation', "prompt": '90s adventure game cutscene aesthetic, painted 2D backgrounds and original pixel-light character design'},
    'isometric': {"label": 'Isometric diorama', "family": 'Illustration', "prompt": 'precise isometric miniature set, detailed production design, readable space and object layout'},
    'miniature': {"label": 'Practical miniature', "family": 'Cinema', "prompt": 'photographed physical-scale miniature film set with handcrafted props and macro-lens cinematography'},
    'anamorphic': {"label": 'Anamorphic cinematic', "family": 'Cinema', "prompt": 'cinematic anamorphic widescreen still, organic oval bokeh, controlled horizontal flare, dramatic practical light'},
    'vintage_16mm': {"label": 'Vintage 16mm film', "family": 'Cinema', "prompt": 'naturalistic 16mm analog film still, organic grain, soft halation, period-accurate cinematic color'},
    'polaroid': {"label": 'Instant film', "family": 'Cinema', "prompt": 'instant film photography, gentle pastel fading, subtle chemistry artifacts and soft highlights'},
    'cyanotype': {"label": 'Cyanotype', "family": 'Traditional', "prompt": 'cyanotype photographic print with deep Prussian blue and luminous white image details'},
    'sepia': {"label": 'Sepia silent cinema', "family": 'Cinema', "prompt": 'sepia monochrome silent-era cinematic still, rich midtones and soft diffuse contrast'},
    'neon': {"label": 'Neon cyberpunk', "family": 'Cinema', "prompt": 'original futuristic neon-lit cinematic environment, magenta cyan practical lighting and mist'},
    'fantasy': {"label": 'Painterly fantasy', "family": 'Illustration', "prompt": 'original fantastical painterly environment, richly detailed fabrics, dramatic light and atmospheric depth'},
    'gothic': {"label": 'Gothic illustration', "family": 'Illustration', "prompt": 'gothic dark fantasy original ink painting, ornate silhouettes, moonlit architectural forms'},
    'storybook': {"label": 'Children storybook', "family": 'Illustration', "prompt": 'original inviting hand-painted storybook illustration, soft watercolor and simple readable character design'},
    'collage': {"label": 'Mixed-media collage', "family": 'Illustration', "prompt": 'cut magazine textures and handmade drawing arranged as original mixed-media collage, legible composition'},
    'architectural': {"label": 'Architectural visualization', "family": 'Storyboard', "prompt": 'realistic architecture previsualization, accurate scale, neutral materials, clean controlled perspective'},
})

# V0.12.5: distinct preproduction illustration treatments; all art is generated,
# not a deterministic filter, and visual identity must be reviewed shot by shot.
STYLE_PRESETS.update({
    'grease_pencil': {'label':'Blender Grease Pencil look','family':'Storyboard','prompt':'original rough 3D-aware grease pencil drawing with gestural construction strokes, clear actor blocking and sparse gray washes'},
    'color_script': {'label':'Animation color-script frame','family':'Animation','prompt':'professional animation color-script painting focused on mood progression, simple readable staging and evocative controlled color harmony'},
    'layout_pencil': {'label':'Animation layout pencil','family':'Animation','prompt':'hand-drawn animation layout frame, clean perspective grids, readable character silhouettes and detailed environment staging'},
    'production_paintover': {'label':'Film production paintover','family':'Storyboard','prompt':'cinematic set-design paintover with believable practical materials, legible composition, production-realistic lighting and unobtrusive note-free detail'},
    'scratchboard': {'label':'Scratchboard engraving','family':'Traditional','prompt':'original black scratchboard illustration, intricate light carved from deep inky shadows, precise dramatic silhouettes'},
    'film_pastel_noir': {'label':'Pastel noir concept','family':'Illustration','prompt':'pastel and charcoal film noir concept illustration, muted limited palette, spatially clear blocking and theatrical shadow bands'},
    'cutpaper_noir': {'label':'Cut-paper film noir','family':'Animation','prompt':'handcrafted black-and-white cut-paper animation still, dramatic layered silhouette staging, practical-paper shadow depth'},
    'stopmotion_fabric': {'label':'Textile stop-motion','family':'Animation','prompt':'original fabric and felt stop-motion still, handmade stitched textures, miniature film sets and controlled studio lighting'},
    'architectural_ink': {'label':'Architectural ink previsualization','family':'Storyboard','prompt':'director-friendly fine-line architectural ink perspective, accurate prop spacing, clear eyelines and confident monochrome hatching'},
    'neon_risograph': {'label':'Neon risograph illustration','family':'Illustration','prompt':'original two-ink risograph print illustration, fluorescent cyan and pink spot colors, expressive registration and sharp cinematic composition'},
    'ink_brush_action': {'label':'Dynamic action brush ink','family':'Storyboard','prompt':'original fluid black brush ink fight choreography storyboard, clear action vectors, bold readable silhouettes and spatial continuity'},
    'paper_gouache': {'label':'Painted paper gouache','family':'Traditional','prompt':'original layered cut-paper and gouache illustration, textured edges, luminous handmade pigments, cinematic focal hierarchy'},
})

DEFAULT_STYLE = "graphite"


def resolve_style(preset: str, custom: str = "") -> str:
    base = STYLE_PRESETS.get(preset)
    if not base:
        raise ValueError(f"Unsupported style preset: {preset}")
    requested = custom.strip()
    if requested:
        return f"{base['prompt']}. Additional art direction: {requested}"
    return base["prompt"]
