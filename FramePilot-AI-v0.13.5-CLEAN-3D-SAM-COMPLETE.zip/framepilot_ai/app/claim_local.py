"""Offline operator-only migration of local projects into a registered profile.

Stop FramePilot and back up the private_uploads directory before running.
python -m app.claim_local --email your@email.example
"""
import argparse
import json
import sqlite3
import shutil
from pathlib import Path
from .auth import connect, DB
from .project_store import ProjectStore

ROOT=Path(__file__).resolve().parent.parent

def claim(email:str):
    store=ProjectStore(ROOT/'private_uploads')
    with connect() as db:
        user=db.execute('SELECT id FROM users WHERE email=?',(email.strip().lower(),)).fetchone()
        if not user:raise ValueError('Account not found. Create the account first.')
    backup=store.db.with_suffix('.before-claim.sqlite3')
    if backup.exists():raise ValueError('A backup already exists. Check the earlier migration before retrying.')
    with sqlite3.connect(store.db) as db, sqlite3.connect(backup) as copy:
        db.backup(copy)
    with store._connect() as db:
        rows=db.execute("SELECT data FROM projects WHERE owner_id='local'").fetchall()
        count=db.execute("UPDATE projects SET owner_id=? WHERE owner_id='local'",(user['id'],)).rowcount
    from .auth import register_asset, actor_id
    token=actor_id.set(user['id'])
    try:
        for row in rows:
            project=json.loads(row['data'])
            for scene in project.get('scenes',[]):
                for shot in scene.get('shots',[]):
                    for ref in shot.get('references',[]):
                        rid=ref.get('reference_id')
                        if rid:register_asset('reference',rid)
                    for obj in shot.get('camera',{}).get('objects',[]):
                        asset=obj.get('asset_id')
                        if asset:register_asset('model',asset)
    finally:actor_id.reset(token)
    return count,str(backup)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--email',required=True);args=p.parse_args()
    count,backup=claim(args.email)
    print(f'Claimed {count} local project(s). Backup: {backup}')
