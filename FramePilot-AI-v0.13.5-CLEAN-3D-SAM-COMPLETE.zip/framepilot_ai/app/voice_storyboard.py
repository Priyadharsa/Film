"""Audio -> editable shot concept through Muse Voice Transcribe.

Meta Voice is *speech to text*, not audio-to-image. FramePilot routes the reviewed
transcript into existing scene/shot and Muse Image workflows. Audio is never stored.
"""
from __future__ import annotations

import io
import json
import logging
import os
import shutil
import subprocess
import time
import wave
from pathlib import Path
from typing import Callable

import requests
from fastapi import APIRouter, File, HTTPException, UploadFile

log = logging.getLogger('framepilot.voice')
router = APIRouter(prefix='/api/voice-storyboard', tags=['Voice to storyboard'])
MAX_INPUT_BYTES = 30 * 1024 * 1024
MAX_DURATION_SECONDS = 600
ASR_ENDPOINT = 'https://api.meta.ai/v1/asr/transcribe'
TRANSIENT = {429, 500, 502, 503, 504}
VALID_EXTENSIONS = {'.wav', '.mp3', '.m4a', '.ogg', '.webm', '.mp4'}


def normalize_audio(data: bytes, filename: str, *, converter: str | None = None) -> tuple[bytes, float]:
    """Return a supported mono 16-bit 16kHz WAV or a clear 4xx error.

    Conversion is optional and requires ffmpeg on the PATH. Limit both input
    duration and output size; never pass any filename to a shell.
    """
    suffix = Path(filename or '').suffix.lower()
    if suffix not in VALID_EXTENSIONS:
        raise HTTPException(415, 'Upload WAV, MP3, M4A, OGG, WebM or MP4 audio.')
    if not data:
        raise HTTPException(422, 'Choose a non-empty audio recording.')
    if len(data) > MAX_INPUT_BYTES:
        raise HTTPException(413, 'Choose an audio recording under 30 MB and 10 minutes.')

    def inspect_wav(b: bytes) -> float | None:
        try:
            with wave.open(io.BytesIO(b), 'rb') as f:
                if f.getnchannels() != 1 or f.getsampwidth() != 2 or f.getframerate() not in (16000, 24000) or f.getcomptype() != 'NONE':
                    return None
                duration = f.getnframes() / f.getframerate()
                return duration
        except (wave.Error, EOFError, ValueError):
            return None

    if suffix == '.wav':
        duration = inspect_wav(data)
        if duration is not None:
            if duration > MAX_DURATION_SECONDS:
                raise HTTPException(422, 'Recording exceeds 10 minutes. Split it into shorter clips.')
            if duration <= 0:
                raise HTTPException(422, 'Recording contains no audio samples.')
            return data, duration

    executable = converter if converter is not None else shutil.which('ffmpeg')
    if not executable:
        raise HTTPException(422, 'This recording needs conversion. Install FFmpeg or export mono 16-bit PCM WAV at 16 kHz.')
    try:
        result = subprocess.run([
            executable, '-hide_banner', '-loglevel', 'error', '-nostdin',
            '-i', 'pipe:0', '-vn', '-t', '600', '-ac', '1', '-ar', '16000',
            '-sample_fmt', 's16', '-f', 'wav', 'pipe:1'
        ], input=data, capture_output=True, timeout=90, check=False)
    except (OSError, subprocess.TimeoutExpired):
        raise HTTPException(422, 'Could not convert audio. Try a smaller WAV clip or check FFmpeg.') from None
    if result.returncode or not result.stdout:
        raise HTTPException(422, 'Audio could not be decoded. Export a valid WAV or MP3.')
    wav_data = result.stdout
    duration = inspect_wav(wav_data)
    if not duration or duration > MAX_DURATION_SECONDS:
        raise HTTPException(422, 'Recording exceeds the 10-minute limit or is unsupported.')
    if len(wav_data) > MAX_INPUT_BYTES:
        raise HTTPException(413, 'Converted WAV exceeds the 30 MB safety limit.')
    return wav_data, duration


def transcribe_wav(wav_data: bytes, api_key: str, *, post: Callable = requests.post,
                   sleep: Callable[[float], None] = time.sleep, attempts: int = 2) -> dict:
    """Bounded upstream retry; never retry 401/403 or malformed audio (400)."""
    if not api_key or api_key.startswith('replace_with_'):
        raise HTTPException(503, 'MODEL_API_KEY is not configured in .env.')
    for attempt in range(attempts):
        try:
            res = post(
                ASR_ENDPOINT,
                headers={'Authorization': f'Bearer {api_key}', 'Accept': 'application/json'},
                files={
                    'request': (None, json.dumps({'model':'muse-voice-transcribe-1.0',
                                                   'audioEncoding':'WAV','mode':'DIARIZATION'}), 'application/json'),
                    'audio': ('recording.wav', wav_data, 'audio/wav'),
                }, timeout=(12, 180),
            )
        except requests.RequestException:
            if attempt + 1 < attempts:
                sleep(0.7 * (attempt + 1))
                continue
            raise HTTPException(502, 'Meta transcription connection failed. Try again.') from None
        if res.status_code == 200:
            try:
                response = res.json()
            except ValueError:
                raise HTTPException(502, 'Meta returned an invalid transcription response.') from None
            transcript = response.get('transcript')
            if not isinstance(transcript, str) or not transcript.strip():
                raise HTTPException(422, 'No speech detected. Try a clearer recording.')
            turns = response.get('turns', [])
            clean_turns = []
            if isinstance(turns, list):
                for turn in turns[:250]:
                    if isinstance(turn, dict):
                        clean_turns.append({'speaker': str(turn.get('speaker') or '')[:24],
                                            'start_ms': int(turn.get('startMs') or 0),
                                            'end_ms': int(turn.get('endMs') or 0),
                                            'text': str(turn.get('transcript') or '')[:4000]})
            return {'transcript': transcript[:24000], 'turns': clean_turns,
                    'duration_seconds': round(float(response.get('audioDurationMs') or 0)/1000,2),
                    'model':'muse-voice-transcribe-1.0'}
        if res.status_code in (401,403):
            raise HTTPException(401, 'Meta Voice authentication failed. Check MODEL_API_KEY and model access.')
        if res.status_code in (400,413,415):
            raise HTTPException(422, 'Meta Voice rejected this audio clip. Use mono PCM WAV and clips under 10 minutes.')
        if res.status_code in TRANSIENT and attempt + 1 < attempts:
            delay = 0.7 * (attempt + 1)
            try:
                delay = min(5.0, max(delay, float(res.headers.get('Retry-After','0'))))
            except (ValueError, TypeError):
                pass
            log.warning('Meta Voice transient error status=%s attempt=%s',res.status_code,attempt+1)
            sleep(delay)
            continue
        if res.status_code == 429:
            raise HTTPException(429, 'Meta Voice is rate-limited; retry later.')
        raise HTTPException(502, 'Meta Voice could not transcribe this clip. Try again later.')
    raise HTTPException(502, 'Meta Voice transcription failed.')


@router.post('/transcribe')
async def transcribe(file: UploadFile = File(...)):
    # The route must not persist user audio or expose tokens. Only edited text is
    # saved when the user creates a scene in their authenticated film project.
    raw = await file.read(MAX_INPUT_BYTES + 1)
    if len(raw) > MAX_INPUT_BYTES:
        raise HTTPException(413, 'Choose an audio recording under 30 MB.')
    wav_data, duration = normalize_audio(raw, file.filename or '')
    result = transcribe_wav(wav_data, os.getenv('MODEL_API_KEY','').strip())
    result['duration_seconds'] = result['duration_seconds'] or round(duration, 2)
    return result
