import logging
from logging.handlers import RotatingFileHandler
import time
import uuid
import os
import sqlite3
import shutil
from pathlib import Path
import io
from PIL import Image, UnidentifiedImageError, ImageOps

from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, UploadFile, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .meta_client import analyze_screenplay, generate_storyboard_image
from .sam_client import segment_image_objects
from .image_edit import edit_storyboard_frame
from .art_layers import decode_mask
from .styles import STYLE_PRESETS, resolve_style
from .workspace_api import router as workspace_router
from .model_assets import router as model_assets_router
from .environment_media import router as environment_media_router
from .generation_jobs import router as jobs_router, interrupt_on_restart
from .auth import router as auth_router, auth_on, session_user, actor_id, actor, register_asset, check_asset
from .project_store import ProjectStore
from .upload_api import router as upload_router
from .production_hub import router as production_hub_router
from .director_assistant import router as director_router
from .voice_storyboard import router as voice_router
from .large_audio_jobs import router as large_audio_router
from .traffic_controls import TrafficControlMiddleware, gate_from_env
from .schemas import (
    AnalyzeRequest,
    CharacterReferenceResponse,
    SceneBreakdown,
    StoryboardRequest,
    StoryboardResponse,
    SegmentRequest,
    SegmentResponse,
    ImageEditRequest,
    ImageEditResponse,
)

load_dotenv()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("framepilot")

ROOT = Path(__file__).resolve().parent.parent
STATIC_DIR = ROOT / "static"
GENERATED_DIR = STATIC_DIR / "generated"
PRIVATE_REFERENCE_DIR = ROOT / "private_uploads"
GENERATED_DIR.mkdir(parents=True, exist_ok=True)
PRIVATE_REFERENCE_DIR.mkdir(parents=True, exist_ok=True)
# Private rotating log keeps traceback details out of browser error messages.
try:
    log_folder = PRIVATE_REFERENCE_DIR / "logs"
    log_folder.mkdir(parents=True, exist_ok=True)
    file_handler = RotatingFileHandler(log_folder / "framepilot.log", maxBytes=5_000_000, backupCount=2, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    logging.getLogger().addHandler(file_handler)
except OSError:
    logger.warning("File logging unavailable; check PowerShell output for server errors")
MAX_REFERENCE_BYTES = 5 * 1024 * 1024

app = FastAPI(title="FramePilot AI", version="0.13.5")
traffic_gate = gate_from_env()
app.add_middleware(TrafficControlMiddleware, gate=traffic_gate)
interrupt_on_restart()

@app.middleware("http")
async def trace_requests(request: Request, call_next):
    """Attach a troubleshooting ID to every response without exposing internal details.

    Catches unexpected exceptions so operators can match a user's 500 to server logs.
    This is local diagnostics, not a replacement for authentication or observability.
    """
    request_id = uuid.uuid4().hex[:12]
    started = time.monotonic()
    user=session_user(request)
    uri=request.url.path
    protected=uri.startswith(('/api/projects','/api/production','/api/uploads','/api/jobs','/api/reference','/api/edit','/api/segment','/api/storyboard','/api/analyze','/api/models','/api/environment-media','/api/director','/api/voice-storyboard','/static/generated/'))
    if auth_on() and protected and user is None:
        return JSONResponse(status_code=401,content={'detail':'Sign in to access this workspace.'})
    if request.method in ('POST','PUT','PATCH','DELETE') and auth_on() and protected:
        origin=request.headers.get('origin')
        if origin:
            from urllib.parse import urlparse
            source=urlparse(origin)
            if source.hostname!=request.url.hostname or source.scheme not in ('http','https'):
                return JSONResponse(status_code=403,content={'detail':'Cross-origin write rejected.'})
    context=actor_id.set(user['id'] if user else 'local')
    try:
        if auth_on() and uri.startswith('/static/generated/'):
            filename=uri.rsplit('/',1)[-1]
            if not ProjectStore(PRIVATE_REFERENCE_DIR).actor_has_asset(filename):
                return JSONResponse(status_code=404,content={'detail':'Frame not found.'})
        response = await call_next(request)
    except Exception:
        logger.exception("Unhandled HTTP error request_id=%s path=%s method=%s",
                         request_id, request.url.path, request.method)
        response = JSONResponse(status_code=500, content={
            "detail": "Unexpected server error. Copy the request ID and inspect the PowerShell server log.",
            "request_id": request_id,
        })
    finally:
        actor_id.reset(context)
    duration_ms = int((time.monotonic() - started) * 1000)
    response.headers["X-Request-ID"] = request_id
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['X-Frame-Options'] = 'DENY'
    if uri.startswith('/api/'):
        response.headers.setdefault('Cache-Control','no-store')
    if request.url.scheme == 'https':
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains' 
    if response.status_code >= 500:
        logger.error("Failed HTTP request id=%s code=%s method=%s path=%s duration_ms=%s",
                     request_id, response.status_code, request.method, request.url.path, duration_ms)
    return response
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.include_router(workspace_router)
app.include_router(model_assets_router)
app.include_router(environment_media_router)
app.include_router(upload_router)
app.include_router(auth_router)
app.include_router(jobs_router)
app.include_router(production_hub_router)
app.include_router(director_router)
app.include_router(voice_router)
app.include_router(large_audio_router)


def _resolved_references(items):
    """Validate every reference before making a potentially billable image call."""
    ids = [item.reference_id for item in items]
    if len(ids) != len(set(ids)):
        raise HTTPException(status_code=422, detail="Each selected reference may appear only once.")
    return [{"path": _validated_reference(item.reference_id), "role": item.role,
             "label": item.label, "instruction": item.instruction} for item in items]


def _validated_reference(reference_id: str) -> Path:
    # The strict ID format prevents path traversal and only accepts server-created references.
    if len(reference_id) != 32 or any(char not in "0123456789abcdef" for char in reference_id):
        raise HTTPException(status_code=400, detail="Invalid character reference ID.")
    check_asset('reference',reference_id)
    matches = list(PRIVATE_REFERENCE_DIR.glob(f"{reference_id}.*"))
    if not matches or not matches[0].is_file():
        raise HTTPException(status_code=404, detail="Character reference not found. Upload it again.")
    return matches[0]


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(STATIC_DIR / "book.html")


@app.get("/workspace", include_in_schema=False)
def unified_workspace():
    return FileResponse(STATIC_DIR / "book.html")

@app.get("/book", include_in_schema=False)
def book():
    return FileResponse(STATIC_DIR / "book.html")

@app.get("/production", include_in_schema=False)
def production_hub_page():
    return FileResponse(STATIC_DIR / "production.html")


@app.get("/advanced", include_in_schema=False)
def advanced():
    return FileResponse(STATIC_DIR / "workspace.html")


@app.get("/legacy", include_in_schema=False)
def legacy_script_studio():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/shotlab", include_in_schema=False)
def shotlab():
    return FileResponse(STATIC_DIR / "shotlab.html")


@app.get("/studio", include_in_schema=False)
def studio():
    return FileResponse(STATIC_DIR / "studio.html")


@app.get("/api/styles")
def list_styles():
    return {"styles": [{"id": key, "label": item["label"], "family": item["family"]}
                       for key, item in STYLE_PRESETS.items()]}


@app.get("/health")
def health():
    return {"status": "ok", "service": "FramePilot AI", "version": "0.13.5", "studio": "/book", "legacy_studio": "/studio"}


@app.get('/health/live', include_in_schema=False)
def health_live():
    return {'status': 'alive'}


@app.get('/health/ready', include_in_schema=False)
def health_ready():
    """Readiness for one local worker; never certifies multi-node readiness."""
    errors=[]
    try:
        PRIVATE_REFERENCE_DIR.mkdir(parents=True, exist_ok=True)
        probe=PRIVATE_REFERENCE_DIR / f'.probe-{uuid.uuid4().hex}'
        try:
            probe.write_bytes(b'ready')
            probe.unlink()
        finally:
            probe.unlink(missing_ok=True)
        db=sqlite3.connect(PRIVATE_REFERENCE_DIR / 'projects.sqlite3', timeout=1)
        try:db.execute('SELECT 1').fetchone()
        finally:db.close()
        free_mb=shutil.disk_usage(PRIVATE_REFERENCE_DIR).free // (1024*1024)
        if free_mb < int(os.getenv('FRAMEPILOT_MIN_FREE_MB','256')):
            errors.append('low_disk_space')
    except (OSError, sqlite3.Error):
        errors.append('local_persistence_unavailable')
    mode=os.getenv('FRAMEPILOT_DEPLOYMENT_PROFILE','local').lower()
    if mode == 'distributed':
        errors.append('distributed_metadata_and_workers_not_configured')
    return JSONResponse({'status':'ready' if not errors else 'not_ready',
                         'deployment_profile':mode, 'checks':errors},
                        status_code=503 if errors else 200,
                        headers={'Cache-Control':'no-store'})


@app.get('/api/ops/capacity', include_in_schema=False)
def local_capacity(request: Request):
    """Operational counters are private; not exposed without an operator token."""
    import hmac
    token=os.getenv('FRAMEPILOT_OPERATIONS_TOKEN','')
    supplied=request.headers.get('x-ops-token','')
    if not token or not hmac.compare_digest(token,supplied):
        raise HTTPException(404,'Not found')
    return traffic_gate.snapshot()


@app.post("/api/reference", response_model=CharacterReferenceResponse)
async def upload_character_reference(file: UploadFile = File(...)):
    """Store one private character reference image for reuse in storyboard generations."""
    raw = await file.read(MAX_REFERENCE_BYTES + 1)
    if not raw:
        raise HTTPException(status_code=400, detail="Choose a non-empty image file.")
    if len(raw) > MAX_REFERENCE_BYTES:
        raise HTTPException(status_code=413, detail="Reference images must be 5 MB or smaller.")

    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        extension, content_type = ".png", "image/png"
    elif raw.startswith(b"\xff\xd8\xff"):
        extension, content_type = ".jpg", "image/jpeg"
    elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        extension, content_type = ".webp", "image/webp"
    else:
        raise HTTPException(status_code=415, detail="Use a PNG, JPEG or WebP image.")

    # File signature alone is not enough: malformed PNG/JPEG headers previously
    # passed upload and later failed in the viewer or image-generation call.
    try:
        with Image.open(io.BytesIO(raw)) as image:
            image.verify()
        with Image.open(io.BytesIO(raw)) as image:
            if not 0 < image.width * image.height <= 16_000_000:
                raise HTTPException(status_code=422, detail="Reference image exceeds 16 megapixels.")
            if image.format not in ("PNG", "JPEG", "WEBP"):
                raise HTTPException(status_code=415, detail="Use a PNG, JPEG or WebP image.")
    except HTTPException:
        raise
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError) as exc:
        raise HTTPException(status_code=415, detail="Image is corrupted or unsupported. Export as PNG, JPEG or WebP and try again.") from exc

    reference_id = uuid.uuid4().hex
    destination = PRIVATE_REFERENCE_DIR / f"{reference_id}{extension}"
    try:
        destination.write_bytes(raw)
    except OSError as exc:
        logger.exception("Could not save character reference")
        raise HTTPException(status_code=500, detail="Could not save the reference image.") from exc

    register_asset('reference',reference_id)
    safe_name = Path(file.filename or "character-reference").name[:120]
    return CharacterReferenceResponse(
        reference_id=reference_id,
        filename=safe_name,
        content_type=content_type,
    )


@app.get("/api/reference/{reference_id}/preview", include_in_schema=False)
def reference_thumbnail(reference_id: str):
    return FileResponse(_validated_reference(reference_id), headers={"Cache-Control":"private, max-age=600"})


@app.post("/api/analyze", response_model=SceneBreakdown)
def analyze(request: AnalyzeRequest):
    try:
        return analyze_screenplay(request.screenplay)
    except Exception as exc:
        logger.exception("Screenplay analysis failed")
        message = str(exc)
        if "MODEL_API_KEY" in message:
            raise HTTPException(status_code=503, detail=message) from exc
        if "authentication" in message.lower() or "api key" in message.lower():
            raise HTTPException(status_code=401, detail="Meta API authentication failed. Verify MODEL_API_KEY.") from exc
        if "rate limit" in message.lower() or "quota" in message.lower():
            raise HTTPException(status_code=429, detail="Meta API rate limit or credit limit reached. Check your Meta billing dashboard.") from exc
        raise HTTPException(status_code=502, detail=f"Scene analysis failed: {message}") from exc


@app.post("/api/storyboard", response_model=StoryboardResponse)
def storyboard(request: StoryboardRequest):
    try:
        style = resolve_style(request.style_preset, request.style_custom)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    selected_refs = _resolved_references(request.reference_images)
    reference_path = None
    if request.character_reference_id:
        reference_path = _validated_reference(request.character_reference_id)
        if request.character_reference_id not in {ref["path"].stem for ref in selected_refs}:
            if len(selected_refs) >= 8:
                raise HTTPException(status_code=422, detail="Choose at most 8 reference images.")
            selected_refs.append({"path": reference_path, "role": "character", "label": request.reference_character,
                                  "instruction": "Keep this character's identity consistent."})
    try:
        filename, model = generate_storyboard_image(
            shot=request.shot,
            scene_title=request.scene_title,
            visual_style=style,
            output_dir=GENERATED_DIR,
            characters=request.characters,
            character_reference_path=reference_path,
            reference_character=request.reference_character,
            scene_summary=request.scene_summary,
            location_time=request.location_time,
            props=request.props,
            reference_images=selected_refs,
        )
        register_asset('generated',filename)
        return StoryboardResponse(
            image_url=f"/static/generated/{filename}",
            shot_number=request.shot.shot_number,
            model=model,
            reference_used=bool(selected_refs),
            reference_count=len(selected_refs),
            style_preset=request.style_preset,
        )
    except Exception as exc:
        logger.exception("Storyboard generation failed")
        message = str(exc)
        if "MODEL_API_KEY" in message:
            raise HTTPException(status_code=503, detail=message) from exc
        if "authentication" in message.lower() or "api key" in message.lower():
            raise HTTPException(status_code=401, detail="Meta API authentication failed. Verify MODEL_API_KEY.") from exc
        if "rate limit" in message.lower() or "quota" in message.lower():
            raise HTTPException(status_code=429, detail="Meta API rate limit or credit limit reached. Check your Meta billing dashboard.") from exc
        raise HTTPException(status_code=502, detail=f"Storyboard generation failed: {message}") from exc


@app.post("/api/segment", response_model=SegmentResponse)
def segment_storyboard_image(request: SegmentRequest):
    """Detect and segment one prompted object in a FramePilot-generated image."""
    image_path = GENERATED_DIR / request.image_filename
    # Pydantic enforces the generated-image filename grammar; this extra check
    # ensures the resolved file remains inside the generated storyboard folder.
    try:
        image_path.resolve().relative_to(GENERATED_DIR.resolve())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid storyboard image path.") from exc
    if not image_path.is_file():
        raise HTTPException(status_code=404, detail="Storyboard image not found. Generate the frame again.")
    if auth_on() and not ProjectStore(PRIVATE_REFERENCE_DIR).actor_has_asset(request.image_filename):
        raise HTTPException(status_code=404,detail='Frame not found.')

    try:
        result = segment_image_objects(image_path, request.prompt)
        return SegmentResponse(**result)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("SAM 3.1 segmentation failed")
        message = str(exc)
        if "MODEL_API_KEY" in message:
            raise HTTPException(status_code=503, detail=message) from exc
        if "authentication" in message.lower() or "api key" in message.lower():
            raise HTTPException(status_code=401, detail="Meta API authentication failed. Verify MODEL_API_KEY.") from exc
        if "rate limit" in message.lower() or "quota" in message.lower():
            raise HTTPException(status_code=429, detail="Meta API rate limit or credit limit reached. Check your Meta billing dashboard.") from exc
        if "model_not_found" in message or "not found" in message.lower() and "model" in message.lower():
            raise HTTPException(status_code=502, detail="SAM 3.1 is unavailable for this API key or project. Verify model access in Meta Model API.") from exc
        raise HTTPException(status_code=502, detail=f"SAM 3.1 segmentation failed: {message}") from exc


@app.post("/api/edit", response_model=ImageEditResponse)
def edit_storyboard(request: ImageEditRequest):
    """Non-destructive Muse Image edit; optional SAM selection supplies bounding hint."""
    image_path = GENERATED_DIR / request.image_filename
    try:
        image_path.resolve().relative_to(GENERATED_DIR.resolve())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid image path.") from exc
    if not image_path.is_file():
        raise HTTPException(status_code=404, detail="Storyboard frame not found.")
    if auth_on() and not ProjectStore(PRIVATE_REFERENCE_DIR).actor_has_asset(request.image_filename):
        raise HTTPException(status_code=404,detail='Frame not found.')
    selected_refs = _resolved_references(request.reference_images)
    style_instruction = ""
    if request.style_preset:
        try:
            style_instruction = resolve_style(request.style_preset, request.style_custom)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
    bbox = None
    if request.selection is not None:
        from PIL import Image
        try:
            with Image.open(image_path) as im:
                decode_mask(request.selection,im.size)
        except ValueError as exc:
            raise HTTPException(422,str(exc)) from exc
    if request.selected_box is not None:
        # A selected SAM object has already been explicitly presented to the user.
        # Reuse its source pixel box instead of making a second billable SAM call.
        from PIL import Image
        with Image.open(image_path) as im:
            W,H=im.size
        x1,y1,x2,y2=request.selected_box
        if not (0<=x1<x2<=W and 0<=y1<y2<=H):
            raise HTTPException(422,'Selection lies outside the frame. Detect again.')
        bbox=(x1,y1,x2,y2)
    if request.use_sam and bbox is None:
        if not request.target.strip():
            raise HTTPException(status_code=422, detail="Provide an object label to localize with SAM 3.1.")
        try:
            result = segment_image_objects(image_path, request.target.strip())
            objects = result.get('objects') or []
            if not objects:
                raise HTTPException(status_code=422, detail="SAM could not find that object. Try an ordinary edit or a more specific label.")
            # Use the highest-confidence detected instance. All coordinates are pixel-space.
            obj = max(objects, key=lambda o: o.get('confidence') or 0)
            bbox = (obj['left'], obj['top'], obj['right'], obj['bottom'])
        except HTTPException:
            raise
        except Exception as exc:
            logger.exception("SAM edit grounding failed")
            raise HTTPException(status_code=502, detail="SAM localization failed. Uncheck SAM grounding to try prompt-only editing.") from exc
    try:
        filename, model = edit_storyboard_frame(
            image_path, request.instruction, request.target.strip(), bbox,
            reference_images=selected_refs, style_instruction=style_instruction,
            selection=request.selection
        )
        register_asset('generated',filename)
        return ImageEditResponse(
            image_url=f"/static/generated/{filename}", model=model,
            sam_grounded=bbox is not None,
            message="Edited version created. Compare with the original; precise local changes are not guaranteed.",
        )
    except Exception as exc:
        logger.exception("Muse Image editing failed")
        message = str(exc)
        if "MODEL_API_KEY" in message:
            raise HTTPException(status_code=503, detail=message) from exc
        if "authentication" in message.lower() or "api key" in message.lower():
            raise HTTPException(status_code=401, detail="Meta API authentication failed. Verify MODEL_API_KEY.") from exc
        if "rate limit" in message.lower() or "quota" in message.lower():
            raise HTTPException(status_code=429, detail="Meta API rate limit or credit limit reached.") from exc
        raise HTTPException(status_code=502, detail=f"Muse Image editing failed: {message}") from exc
