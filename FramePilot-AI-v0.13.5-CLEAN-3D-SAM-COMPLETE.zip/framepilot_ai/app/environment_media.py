"""Private environment image/video assets used as visual backplates in Cinema 3D.

These are *2D backgrounds*, not automatic reconstruction into textured geometry.
Uploads stream to disk, are magic-byte checked and tenant-scoped through auth assets.
For multi-node deployments, move bytes to tenant-scoped object storage and transcode
untrusted video in isolated workers before playback.
"""
from __future__ import annotations

import os
import uuid
from pathlib import Path
from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from PIL import Image, UnidentifiedImageError
from .auth import register_asset, check_asset

ROOT = Path(__file__).resolve().parent.parent
MEDIA_DIR = ROOT / 'private_uploads' / 'environment_media'
MEDIA_DIR.mkdir(parents=True, exist_ok=True)
MAX_MEDIA_BYTES = 160 * 1024 * 1024  # intentionally smaller than screenplay uploads
CHUNK_BYTES = 1024 * 1024
TYPES = {
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
    '.webp': 'image/webp', '.mp4': 'video/mp4', '.webm': 'video/webm',
}
router = APIRouter(prefix='/api/environment-media',tags=['Cinema environment assets'])


def _check_magic(path:Path, extension:str)->None:
    with path.open('rb') as f: head=f.read(32)
    if extension=='.mp4':
        if len(head)<12 or head[4:8]!=b'ftyp':
            raise ValueError('Invalid MP4 file header.')
    elif extension=='.webm':
        if not head.startswith(b'\x1a\x45\xdf\xa3'):
            raise ValueError('Invalid WebM file header.')
    else:
        try:
            with Image.open(path) as im:
                if im.width*im.height>50_000_000 or im.width<16 or im.height<16:
                    raise ValueError('Image dimensions outside safe limits.')
                actual=im.format
                im.verify()
            if actual not in {'PNG' if extension=='.png' else 'JPEG' if extension in ('.jpg','.jpeg') else 'WEBP'}:
                raise ValueError('Image contents do not match the filename extension.')
        except (UnidentifiedImageError,OSError,Image.DecompressionBombError) as exc:
            raise ValueError('Invalid or truncated image file.') from exc


@router.post('', status_code=201)
async def upload_environment_media(file:UploadFile=File(...)):
    original=Path(file.filename or '').name
    extension=Path(original).suffix.lower()
    if extension not in TYPES:
        raise HTTPException(415,'Choose PNG, JPG, WebP, MP4 or WebM. GLB models use the Blender importer.')
    if file.content_type and file.content_type not in (TYPES[extension], 'application/octet-stream'):
        raise HTTPException(415,'File type does not match its extension.')
    name=uuid.uuid4().hex
    temporary=MEDIA_DIR/f'.{name}.part'
    size=0
    try:
        with temporary.open('wb') as output:
            while data:=await file.read(CHUNK_BYTES):
                size+=len(data)
                if size>MAX_MEDIA_BYTES:
                    raise HTTPException(413,'Environment media must be 160 MiB or smaller.')
                output.write(data)
        if not size:raise HTTPException(400,'Choose a non-empty environment file.')
        try:_check_magic(temporary,extension)
        except ValueError as exc:raise HTTPException(422,str(exc)) from exc
        final=MEDIA_DIR/f'{name}{extension}'
        os.replace(temporary,final)
        register_asset('environment_media',name)
        return {'media_id':name,'kind':'video' if extension in ('.mp4','.webm') else 'image',
                'url':f'/api/environment-media/{name}','content_type':TYPES[extension],
                'filename':original[:120],'bytes':size}
    finally:
        temporary.unlink(missing_ok=True)
        await file.close()


@router.get('/{media_id}')
def read_environment_media(media_id:str):
    if len(media_id)!=32 or any(c not in '0123456789abcdef' for c in media_id):
        raise HTTPException(404,'Environment media not found.')
    check_asset('environment_media',media_id)
    files=[x for x in MEDIA_DIR.glob(f'{media_id}.*') if x.suffix.lower() in TYPES]
    if len(files)!=1:raise HTTPException(404,'Environment media not found.')
    return FileResponse(files[0],media_type=TYPES[files[0].suffix.lower()],
                        headers={'Cache-Control':'private,max-age=3600','Accept-Ranges':'bytes',
                                 'X-Content-Type-Options':'nosniff'})
