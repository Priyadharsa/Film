import base64
import json
import os
import re
import uuid
from pathlib import Path
from typing import Any, Optional, Sequence


from .schemas import Character, SceneBreakdown, Shot
from .meta_resilience import call_responses

BASE_URL = "https://api.meta.ai/v1"


def _client():
    from openai import OpenAI
    api_key = os.getenv("MODEL_API_KEY", "").strip()
    if not api_key or api_key == "replace_with_your_meta_model_api_key":
        raise RuntimeError(
            "MODEL_API_KEY is missing. Copy .env.example to .env and add your Meta Model API key."
        )
    return OpenAI(base_url=BASE_URL, api_key=api_key, timeout=180.0, max_retries=0)


def _extract_text(response: Any) -> str:
    """Read the assistant text from a Responses API object."""
    direct = getattr(response, "output_text", None)
    if direct:
        return direct

    chunks: list[str] = []
    for item in getattr(response, "output", []) or []:
        if getattr(item, "type", None) == "message":
            for content in getattr(item, "content", []) or []:
                if getattr(content, "type", None) == "output_text":
                    chunks.append(getattr(content, "text", ""))
    return "\n".join(chunks).strip()


def _parse_json(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)

    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError:
        start = cleaned.find("{")
        if start < 0:
            raise ValueError("Muse Spark did not return a JSON object. Please retry the scene analysis.")
        parsed, _ = json.JSONDecoder().raw_decode(cleaned[start:])

    if not isinstance(parsed, dict):
        raise ValueError("Muse Spark returned an unexpected response format. Please retry.")
    return parsed


def analyze_screenplay(screenplay: str) -> SceneBreakdown:
    client = _client()
    model = os.getenv("MUSE_SPARK_MODEL", "muse-spark-1.3")
    prompt = f"""You are FramePilot, an experienced film director and assistant director.
Turn the screenplay excerpt below into a precise, practical pre-production breakdown.
Return ONLY valid JSON. Do not use Markdown fences or prose outside the JSON.
Do not invent plot events. You may make clearly reasonable visual inferences from the text.
Create 4 to 6 distinct shots in screenplay order. Each shot must be filmable and must advance
story, tension, character, or spatial clarity. Vary shot size and angle only when motivated.
Keep each named character's visual appearance fixed across every shot. Reuse the same clothing,
hairstyle, age range, distinguishing features, and props unless the screenplay explicitly changes them.
image_prompt must describe one single 16:9 storyboard frame, not a collage, with no lettering or captions.

Required JSON shape:
{{
  "scene_title": "short title",
  "logline": "one sentence",
  "genre_mood": "genre and visual/emotional mood",
  "scene_summary": "2-4 sentences",
  "location_time": "INT/EXT, location, time of day",
  "characters": [{{"name":"...","description":"stable visual identity including face, hair, clothing and distinguishing details","objective":"what they want in this scene","emotional_state":"..."}}],
  "props": ["important visible props"],
  "story_beats": [{{"beat_number":1,"label":"...","description":"...","emotional_shift":"..."}}],
  "shots": [{{"shot_number":1,"beat":"...","shot_type":"Wide/Medium/Close-up/etc.","camera_angle":"...","camera_movement":"...","visual_description":"what is visible in the frame","director_purpose":"why this shot matters","image_prompt":"detailed single-frame image prompt with fixed character identity"}}]
}}

SCREENPLAY EXCERPT:
{screenplay}
"""
    response = call_responses(client, model=model, input=prompt)
    output_text = _extract_text(response)
    if not output_text:
        raise ValueError("Muse Spark returned no text. Check the API dashboard and retry.")
    data = _parse_json(output_text)
    breakdown = SceneBreakdown.model_validate(data)
    if not breakdown.shots:
        raise ValueError("Muse Spark returned no shots. Please retry with a complete scene.")
    for shot in breakdown.shots:
        if not shot.image_prompt.strip():
            shot.image_prompt = (
                f"{shot.visual_description}. {shot.shot_type}, {shot.camera_angle}, "
                f"{shot.camera_movement}. Cinematic storyboard frame."
            )
    return breakdown


def _character_bible(characters: Sequence[Character]) -> str:
    if not characters:
        return "No named characters were identified. Preserve any visible identity consistently within this scene."
    lines = []
    for character in characters:
        identity = character.description.strip() or "No detailed appearance specified."
        lines.append(f"- {character.name}: {identity}")
    return "\n".join(lines)


def _image_data_url(reference_path: Path) -> str:
    suffix = reference_path.suffix.lower()
    mime_by_suffix = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}
    mime = mime_by_suffix.get(suffix)
    if not mime:
        raise ValueError("Unsupported character reference image format.")
    encoded = base64.b64encode(reference_path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def generate_storyboard_image(
    shot: Shot,
    scene_title: str,
    visual_style: str,
    output_dir: Path,
    characters: Optional[Sequence[Character]] = None,
    character_reference_path: Optional[Path] = None,
    reference_character: str = "Main character",
    scene_summary: str = "",
    location_time: str = "",
    props: Optional[Sequence[str]] = None,
    reference_images: Optional[Sequence[dict[str, Any]]] = None,
) -> tuple[str, str]:
    client = _client()
    model = os.getenv("MUSE_IMAGE_MODEL", "muse-image-1.0")
    character_bible = _character_bible(characters or [])
    prop_text = ", ".join(props or []) or "No key props specified."

    prompt = f"""Create ONE professional film storyboard frame for the scene: {scene_title}.
Visual style: {visual_style}.
Scene context: {scene_summary or 'Maintain continuity with the described scene.'}
Location and time: {location_time or 'As described by the shot.'}
Character continuity bible (treat these descriptions as fixed production design):
{character_bible}
Important scene props: {prop_text}

Shot {shot.shot_number}: {shot.shot_type}; camera angle: {shot.camera_angle};
movement: {shot.camera_movement}.
What the frame depicts: {shot.visual_description}
Story beat: {shot.beat}
Director's intention: {shot.director_purpose}
Additional visual direction: {shot.image_prompt}

Continuity rules: preserve each character's face, age, hairstyle, build, costume, accessories,
and distinguishing features across every shot in this scene. Do not redesign characters between
frames. Keep the location layout, time of day, lighting logic, and prop appearance coherent.
Only change pose, expression, blocking, framing, and camera position when the shot requires it.

Composition requirements: single widescreen 16:9 horizontal frame; clear readable staging;
cinematic composition and lighting; expressive but realistic human proportions; one coherent
moment in time; visually specific location and props. No contact sheet, no split panels,
no speech bubbles, no captions, no written words, no logos, no watermark.
"""

    selected_refs = list(reference_images or [])
    # Reference roles are part of the director's character/location bible.
    # Each uploaded character must have its own label. Never merge distinct actors.
    if selected_refs:
        prompt += ("\nIMPORTANT: The supplied references define separate face, body, costume and "
                   "environment constraints. Match a face reference ONLY to its named person, "
                   "retain character silhouette across all shots, and keep the location's layout "
                   "consistent. The script and selected camera shot determine action and framing. ")
    if character_reference_path and all(item["path"] != character_reference_path for item in selected_refs):
        selected_refs.append({"path": character_reference_path, "role": "character",
                              "label": reference_character, "instruction": "Preserve face and costume."})
    if selected_refs:
        # Use the official Responses API mixed content structure: each reference is
        # preceded by its intended role to prevent subject/style/background confusion.
        user_content = [{"type": "input_text", "text": prompt}]
        for index, ref in enumerate(selected_refs, start=1):
            role = ref["role"]
            label = ref["label"]
            special = ref.get("instruction", "").strip()
            constraints = {
                "character": "Match this named person's visible identity, face and build across shots. Do not transfer identity to anyone else.",
                "face": "Use only this person's face and distinguishing facial features for the named character, while honoring the shot's pose and expression. Do not copy another person's face.",
                "body": "Use this character's visible proportions, build, silhouette and posture, but do not transfer face, clothing or background unless requested.",
                "costume": "Use clothing and accessories, not this reference background or pose.",
                "location": "Use this environment layout and architecture, not unrelated people.",
                "prop": "Match the object's shape and appearance, not the rest of the reference.",
                "pose": "Use body pose and blocking without changing canonical character identity.",
                "composition": "Use framing and spatial organization, but follow the new shot's narrative.",
                "palette": "Use color relationships and lighting mood, not the reference objects.",
                "style": "Use rendering language and medium, not its depicted subject.",
                "other": "Use only the visual qualities explicitly described by the director.",
            }.get(role, "Follow the director's reference instruction.")
            user_content.append({"type": "input_text", "text":
                f"REFERENCE {index} — ROLE: {role}; LABEL: {label}. {constraints} "
                f"Additional instruction: {special or 'Use the reference only for the stated role.'}"})
            user_content.append({"type": "input_image", "image_url": _image_data_url(ref["path"])})
        user_content.append({"type": "input_text", "text":
            "Compose all supplied references into ONE coherent new frame. The requested shot geometry "
            "takes precedence over reference camera angles unless explicitly told otherwise. "
            "Maintain the chosen art style throughout the full image; do not make a collage."})
        response = call_responses(client, model=model, input=[{"role": "user", "content": user_content}])
    else:
        response = call_responses(client, model=model, input=prompt)

    image_item = next(
        (item for item in (getattr(response, "output", []) or [])
         if getattr(item, "type", None) == "image_generation_call"),
        None,
    )
    if image_item is None or not getattr(image_item, "result", None):
        raise ValueError("Muse Image did not return an image. Check model access and retry.")

    output_dir.mkdir(parents=True, exist_ok=True)
    image_bytes = base64.b64decode(image_item.result, validate=True)
    if image_bytes.startswith(b"\x89PNG\r\n\x1a\n"):
        extension = ".png"
    elif image_bytes.startswith(b"\xff\xd8\xff"):
        extension = ".jpg"
    elif image_bytes[:4] == b"RIFF" and image_bytes[8:12] == b"WEBP":
        extension = ".webp"
    else:
        extension = ".png"
    image_name = f"shot-{shot.shot_number}-{uuid.uuid4().hex[:10]}{extension}"
    image_path = output_dir / image_name
    try:
        image_path.write_bytes(image_bytes)
    except OSError as exc:
        raise ValueError("Could not save the generated storyboard image.") from exc
    return image_name, model
