"""Deterministic, credit-free whole-screenplay shot draft generation.

Every nonempty screenplay paragraph is represented by a shot beat.  This is
an editable planning pass, NOT a claim that Muse has generated finished images.
No private user screenplay data is sent to an LLM at this stage.
"""
from __future__ import annotations
import re
from .screenplay_parser import _shot_template
from .cinematic_grammar import recommend

MAX_PLAN_SHOTS=25000
MIN_BEAT_CHARS=145
MAX_BEAT_CHARS=480


def split_beats(text:str)->list[str]:
    """Conservatively partition every non-whitespace character into bounded beats."""
    paragraphs=[p.strip() for p in re.split(r'\n\s*\n', text or '') if p.strip()]
    bits=[]
    for p in paragraphs:
        if len(p)<=MAX_BEAT_CHARS:
            bits.append(p)
            continue
        # Split long blocks at word boundaries, without discarding screenplay dialogue.
        words=p.split()
        b=''
        for word in words:
            if b and len(b)+len(word)+1>MAX_BEAT_CHARS:
                bits.append(b);b=''
            b=f'{b} {word}'.strip()
        if b:bits.append(b)
    merged=[]
    for b in bits:
        if merged and len(merged[-1])<MIN_BEAT_CHARS and len(merged[-1])+len(b)+2<=MAX_BEAT_CHARS:
            merged[-1]+='\n\n'+b
        else:merged.append(b)
    return merged or ['(Scene description to be added)']


def shot_for_beat(scene:dict,beat:str,index:int,total:int)->dict:
    shot=_shot_template(scene['slugline'],beat,index)
    film=recommend(scene.get('slugline',''),beat,index,total)
    kind=film['shot_type']
    shot.update(film)
    shot.update(
        number=index+1,
        name=f'Beat {index+1:03d} · {kind}',
        shot_type=kind,
        description=beat[:1250],
        purpose=film['purpose'],
        source_beat_id=f"{scene['id']}:{index+1}",
        source_beat_number=index+1,
        auto_plan=True,
        planning_status='unreviewed',
    )
    src_pages=scene.get('source_pages',[])
    if src_pages:
        shot['source_page']=src_pages[min(len(src_pages)-1, int(index*len(src_pages)/max(1,total)))]
    return shot


def expand_scenes(scenes:list[dict], *, fresh:bool=False)->dict:
    """Create one editable shot per narrative beat, preserving user edits on repeat runs."""
    proposed=[split_beats(scene.get('text','')) for scene in scenes]
    count=sum(map(len,proposed))
    if count>MAX_PLAN_SHOTS:
        raise ValueError(f'Screenplay would create {count:,} beats (limit {MAX_PLAN_SHOTS:,}); divide into film volumes.')
    added=0
    for scene,beats in zip(scenes,proposed):
        old=scene.get('shots',[])
        # Initial imported template shots contain no creative edits, and may be safely
        # replaced with the more complete beat coverage. Never discard saved artwork.
        if fresh or (old and all(not sh.get('auto_plan') and not sh.get('image_url') and not sh.get('sketch_url') and not sh.get('references') and sh.get('status')=='Draft' for sh in old)):
            old=[]
        existing={sh.get('source_beat_id') for sh in old}
        for i,beat in enumerate(beats):
            key=f"{scene['id']}:{i+1}"
            if key in existing:continue
            old.append(shot_for_beat(scene,beat,i,len(beats)))
            added+=1
        for i,shot in enumerate(old):shot['number']=i+1
        scene['shots']=old
    return {'scenes':len(scenes),'total_shots':sum(len(s.get('shots',[])) for s in scenes),'added':added,
            'status':'draft','ai_images_generated':0}
