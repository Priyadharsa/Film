"""Persisted storyboard generation jobs.

A single browser action can enqueue a complete screenplay. The local executor
intentionally processes a small bounded number of model calls; cloud deployments
need PostgreSQL + a durable distributed queue + rate-limit-aware workers.
Failed or interrupted requests are never automatically retried because inference
may already have been billed upstream.
"""
from __future__ import annotations
import json
import logging
import os
import sqlite3
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .auth import actor, actor_id
from .workspace_api import get_project

logger=logging.getLogger('framepilot.jobs')
ROOT=Path(__file__).resolve().parent.parent
DB=ROOT/'private_uploads'/'generation_jobs.sqlite3'
MAX_BATCH=int(os.getenv('FRAMEPILOT_MAX_BATCH_SHOTS','32'))
MAX_BOOK=int(os.getenv('FRAMEPILOT_MAX_BOOK_SHOTS','25000'))
MAX_PARALLEL=max(1,min(8,int(os.getenv('FRAMEPILOT_MAX_PARALLEL_RENDERERS','8'))))
POOL=ThreadPoolExecutor(max_workers=max(1,min(2,int(os.getenv('FRAMEPILOT_GENERATION_WORKERS','2')))),thread_name_prefix='fp-muse')
LOCK=threading.Lock()
# Eight is a *local* upper bound; rate pacing may result in fewer concurrent calls.
# The semaphore is shared across local jobs. Multiple processes need Redis/global quotas.
INFERENCE_PERMITS=threading.BoundedSemaphore(MAX_PARALLEL)
CALL_RPM=max(1,min(150,int(os.getenv('FRAMEPILOT_IMAGE_RPM','90'))))
PACE_LOCK=threading.Lock()
NEXT_CALL_AT=0.0

def pace_inference():
    """Avoid dispatching an unbounded wave of paid model requests from one host."""
    global NEXT_CALL_AT
    with PACE_LOCK:
        now=time.monotonic()
        slot=max(now,NEXT_CALL_AT)
        NEXT_CALL_AT=slot+60.0/CALL_RPM
    remaining=slot-time.monotonic()
    if remaining>0:time.sleep(remaining)



def conn():
    DB.parent.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(str(DB),timeout=30)
    db.row_factory=sqlite3.Row
    db.execute('PRAGMA busy_timeout=30000')
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('''CREATE TABLE IF NOT EXISTS generation_jobs (
      id TEXT PRIMARY KEY,owner_id TEXT NOT NULL,project_id TEXT NOT NULL,
      state TEXT NOT NULL,total INTEGER NOT NULL,done INTEGER NOT NULL,
      failures INTEGER NOT NULL,tasks TEXT NOT NULL,results TEXT NOT NULL,
      created REAL NOT NULL,updated REAL NOT NULL)''')
    db.execute('''CREATE TABLE IF NOT EXISTS generation_job_items (
      job_id TEXT NOT NULL,seq INTEGER NOT NULL,scene_id TEXT NOT NULL,
      shot_id TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'pending',
      message TEXT NOT NULL DEFAULT '',updated REAL NOT NULL,
      PRIMARY KEY (job_id,seq))''')
    fields={r['name'] for r in db.execute('PRAGMA table_info(generation_jobs)')}
    if 'options' not in fields:db.execute("ALTER TABLE generation_jobs ADD COLUMN options TEXT NOT NULL DEFAULT '{}'")
    db.execute('CREATE INDEX IF NOT EXISTS generation_items_lookup ON generation_job_items(job_id,state,seq)')
    return db


def status(job_id:str,owner:str|None=None):
    who=owner or actor()
    with conn() as db:
        row=db.execute('SELECT * FROM generation_jobs WHERE id=? AND owner_id=?',(job_id,who)).fetchone()
        if not row:raise HTTPException(404,'Generation job not found.')
        items=db.execute("SELECT scene_id,shot_id,state,message FROM generation_job_items WHERE job_id=? AND state IN ('done','failed') ORDER BY seq DESC LIMIT 24",(job_id,)).fetchall()
    results=[{'scene_id':r['scene_id'],'shot_id':r['shot_id'],'ok':r['state']=='done','message':r['message']} for r in reversed(items)]
    if not results and row['results']!='[]':
        results=json.loads(row['results'])[-24:]  # older version job compatibility
    options=json.loads(row['options'] or '{}')
    elapsed=max(0,time.time()-row['created'])
    completed=row['done']+row['failures']
    remaining=max(0,row['total']-completed)
    eta=int(remaining/(completed/elapsed)) if completed>=12 and elapsed>=30 and remaining else None
    return {'id':row['id'],'project_id':row['project_id'],'state':row['state'],
        'coverage':options.get('coverage','all'),'workers':options.get('workers',1),'style_preset':options.get('style_preset'),
        'elapsed_seconds':round(elapsed,1),'estimated_remaining_seconds':eta,
        'total':row['total'],'done':row['done'],'failures':row['failures'],
        'completed':row['done']+row['failures'],'pending':max(0,row['total']-row['done']-row['failures']),
        'results':results}


def _claim(job_id:str):
    """Atomic task claim prevents multiple local threads taking the same shot."""
    with conn() as db:
        db.execute('BEGIN IMMEDIATE')
        job=db.execute('SELECT state FROM generation_jobs WHERE id=?',(job_id,)).fetchone()
        if not job or job['state']!='running':return None
        item=db.execute("SELECT * FROM generation_job_items WHERE job_id=? AND state='pending' ORDER BY seq LIMIT 1",(job_id,)).fetchone()
        if item:
            db.execute("UPDATE generation_job_items SET state='running',updated=? WHERE job_id=? AND seq=? AND state='pending'",(time.time(),job_id,item['seq']))
        return dict(item) if item else None


def _consume(job_id:str,owner:str,pid:str,options:dict):
    token=actor_id.set(owner)
    try:
        while True:
            item=_claim(job_id)
            if not item:return
            try:
                from .workspace_api import render_shot, RenderRequest
                with INFERENCE_PERMITS:
                    pace_inference()
                    # A cancellation after pacing must not initiate another paid call.
                    with conn() as db:
                        row=db.execute('SELECT state FROM generation_jobs WHERE id=?',(job_id,)).fetchone()
                    if not row or row['state']!='running':
                        with conn() as db:
                            db.execute("UPDATE generation_job_items SET state='pending',updated=? WHERE job_id=? AND seq=?",(time.time(),job_id,item['seq']))
                        return
                    render_shot(pid,item['scene_id'],item['shot_id'],RenderRequest(
                        use_sketch=True,style_preset=options.get('style_preset'),
                        style_custom=options.get('style_custom','')))
                ok=True;message='Frame saved'
            except Exception as exc:
                logger.exception('Muse generation failed job=%s shot=%s',job_id,item['shot_id'])
                ok=False;message=str(getattr(exc,'detail','Generation failed. Check server logs.'))[:180]
            with conn() as db:
                db.execute("UPDATE generation_job_items SET state=?,message=?,updated=? WHERE job_id=? AND seq=?",
                           ('done' if ok else 'failed',message,time.time(),job_id,item['seq']))
                db.execute('UPDATE generation_jobs SET done=done+?,failures=failures+?,updated=? WHERE id=?',
                           (int(ok),int(not ok),time.time(),job_id))
    finally:
        actor_id.reset(token)


def _run(job_id:str,owner:str):
    token=actor_id.set(owner)
    try:
        with conn() as db:
            job=db.execute('SELECT * FROM generation_jobs WHERE id=?',(job_id,)).fetchone()
            if not job or job['state'] not in ('queued','running'):return
            db.execute("UPDATE generation_jobs SET state='running',updated=? WHERE id=? AND state='queued'",(time.time(),job_id))
            pid=job['project_id'];options=json.loads(job['options'] or '{}')
        parallel=max(1,min(MAX_PARALLEL,int(options.get('workers',8))))
        with ThreadPoolExecutor(max_workers=parallel,thread_name_prefix='fp-shot') as executor:
            futures=[executor.submit(_consume,job_id,owner,pid,options) for _ in range(parallel)]
            for future in futures:future.result()
        with conn() as db:
            job=db.execute('SELECT state,done,failures,total FROM generation_jobs WHERE id=?',(job_id,)).fetchone()
            if job['state']=='cancel_requested':state='cancelled'
            elif job['done']+job['failures']>=job['total']:
                state='completed_with_errors' if job['failures'] else 'completed'
            else:state='interrupted'
            db.execute('UPDATE generation_jobs SET state=?,updated=? WHERE id=?',(state,time.time(),job_id))
    except Exception:
        logger.exception('Generation worker crashed id=%s',job_id)
        with conn() as db:db.execute("UPDATE generation_jobs SET state='failed',updated=? WHERE id=?",(time.time(),job_id))
    finally:
        actor_id.reset(token)


router=APIRouter(prefix='/api/jobs',tags=['Generation jobs'])

class BatchRequest(BaseModel):
    project_id:str=Field(min_length=1,max_length=60)
    scope:str=Field(pattern='^(page|scene|book)$')
    page:int|None=Field(default=None,ge=1)
    scene_id:str|None=None
    skip_rendered:bool=True
    coverage:str=Field(default='all',pattern='^(all|scene_first|first_12)$')
    style_preset:str|None=Field(default=None,max_length=40)
    style_custom:str=Field(default='',max_length=300)
    workers:int=Field(default=8,ge=1,le=8)
    confirmed_count:int|None=Field(default=None,ge=0)


def choose_shots(project:dict,request:BatchRequest):
    if request.scope=='page':
        pages=project.get('pages',[])
        if request.page is None or request.page>len(pages):raise HTTPException(422,'Choose an existing screenplay page.')
        ids=set(pages[request.page-1].get('scene_ids',[]))
        scenes=[x for x in project['scenes'] if x['id'] in ids]
    elif request.scope=='book':
        scenes=project['scenes']
    else:
        scenes=[x for x in project['scenes'] if x['id']==request.scene_id]
        if not scenes:raise HTTPException(404,'Scene not found.')
    if request.coverage=='first_12':scenes=scenes[:12]
    tasks=[]
    for s in scenes:
        shots=s.get('shots',[])
        if request.coverage in ('scene_first','first_12'):shots=shots[:1]
        tasks.extend({'scene_id':s['id'],'shot_id':sh['id']} for sh in shots
                     if not request.skip_rendered or not sh.get('image_url'))
    if request.scope=='book' and request.coverage=='all':
        # Give directors a view of the entire film before rendering scene 1's
        # remaining angles. No extra image requests and no lost coverage.
        first={s['shots'][0]['id'] for s in scenes if s.get('shots')}
        tasks.sort(key=lambda x: 0 if x['shot_id'] in first else 1)
    limit=MAX_BOOK if request.scope=='book' else MAX_BATCH
    if len(tasks)>limit:
        raise HTTPException(422,f'{len(tasks)} shots found. Current safety limit is {limit}; split into volumes.')
    return tasks


@router.get('/estimate')
def estimate(project_id:str,scope:str='book',page:int|None=None,scene_id:str|None=None,skip_rendered:bool=True,
             coverage:str='all',style_preset:str|None=None,style_custom:str='',workers:int=8):
    request=BatchRequest(project_id=project_id,scope=scope,page=page,scene_id=scene_id,skip_rendered=skip_rendered,
                         coverage=coverage,style_preset=style_preset,style_custom=style_custom,workers=workers)
    p=get_project(request.project_id)
    tasks=choose_shots(p,request)
    if request.style_preset:
        from .styles import resolve_style
        try:resolve_style(request.style_preset,request.style_custom)
        except ValueError as exc:raise HTTPException(422,str(exc)) from exc
    return {'project_id':p['id'],'scope':scope,'coverage':request.coverage,'workers':request.workers,'pages':len(p.get('pages',[])),
            'scenes':len(p.get('scenes',[])),'all_draft_shots':sum(len(s.get('shots',[])) for s in p['scenes']),
            'model_calls':len(tasks),'credits_required':len(tasks)>0,
            'message':'Each image may be billable. This is a queued job, not instantaneous rendering.'}


@router.post('/generate',status_code=202)
def start_batch(request:BatchRequest):
    project=get_project(request.project_id)
    tasks=choose_shots(project,request)
    if request.workers>MAX_PARALLEL:raise HTTPException(422,f'Local server allows at most {MAX_PARALLEL} parallel render workers.')
    if request.style_preset:
        from .styles import resolve_style
        try:resolve_style(request.style_preset,request.style_custom)
        except ValueError as exc:raise HTTPException(422,str(exc)) from exc
    if not tasks:raise HTTPException(422,'No unrendered shots found for this scope.')
    if request.scope=='book' and request.confirmed_count!=len(tasks):
        raise HTTPException(422,'Confirm the exact number of model calls returned by /api/jobs/estimate before starting whole-book generation.')
    who=actor()
    with LOCK,conn() as db:
        active=db.execute("SELECT id FROM generation_jobs WHERE owner_id=? AND project_id=? AND state IN ('queued','running','cancel_requested')",(who,request.project_id)).fetchone()
        if active:raise HTTPException(409,'A generation job is already active for this film.')
        job_id=uuid.uuid4().hex;now=time.time()
        # Store tasks in a normalized queue. Avoid rewriting a giant JSON array on each image.
        options={'coverage':request.coverage,'style_preset':request.style_preset,
                 'style_custom':request.style_custom,'workers':request.workers}
        db.execute('''INSERT INTO generation_jobs
          (id,owner_id,project_id,state,total,done,failures,tasks,results,created,updated,options)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
          (job_id,who,request.project_id,'queued',len(tasks),0,0,'[]','[]',now,now,json.dumps(options)))
        db.executemany('INSERT INTO generation_job_items (job_id,seq,scene_id,shot_id,state,updated) VALUES (?,?,?,?,?,?)',
                       [(job_id,i,x['scene_id'],x['shot_id'],'pending',now) for i,x in enumerate(tasks)])
    POOL.submit(_run,job_id,who)
    return status(job_id,who)


@router.get('/{job_id}')
def job_detail(job_id:str):return status(job_id)


@router.post('/{job_id}/cancel')
def job_cancel(job_id:str):
    job=status(job_id)
    if job['state'] in ('queued','running'):
        with conn() as db:db.execute("UPDATE generation_jobs SET state='cancel_requested',updated=? WHERE id=?",(time.time(),job_id))
    return status(job_id)


@router.post('/{job_id}/retry-failed', status_code=202)
def retry_failed_frames(job_id: str):
    '''Explicitly start a new tracked job for failed frames only.

    A transient Meta failure may already have been charged, so no automatic
    re-billing; user must review count and approve. Old successful shots stay.
    '''
    who=actor()
    with LOCK, conn() as db:
        prior=db.execute('SELECT * FROM generation_jobs WHERE id=? AND owner_id=?',(job_id,who)).fetchone()
        if not prior: raise HTTPException(404,'Generation job not found.')
        if prior['state'] not in ('completed_with_errors','failed','interrupted','cancelled'):
            raise HTTPException(409,'Wait for the render to finish before retrying.')
        active=db.execute("SELECT id FROM generation_jobs WHERE owner_id=? AND project_id=? AND state IN ('queued','running','cancel_requested')",(who,prior['project_id'])).fetchone()
        if active: raise HTTPException(409,'Another render is already active for this film.')
        items=db.execute("SELECT scene_id,shot_id FROM generation_job_items WHERE job_id=? AND state='failed' ORDER BY seq",(job_id,)).fetchall()
        if not items: raise HTTPException(422,'No failed frames to retry. Uncertain in-flight requests are not retried automatically.')
        # Validate project ownership and skip frames already rendered in the interim.
        film=get_project(prior['project_id'])
        current={(scene['id'],shot['id']):shot for scene in film['scenes'] for shot in scene.get('shots',[])}
        tasks=[{'scene_id':item['scene_id'],'shot_id':item['shot_id']} for item in items
               if (item['scene_id'],item['shot_id']) in current
               and not current[item['scene_id'],item['shot_id']].get('image_url')]
        if not tasks: raise HTTPException(422,'Failed shots already have artwork or are no longer in this film.')
        now=time.time();new_id=uuid.uuid4().hex
        options=json.loads(prior['options'] or '{}')
        options['retry_of']=job_id
        db.execute('''INSERT INTO generation_jobs
          (id,owner_id,project_id,state,total,done,failures,tasks,results,created,updated,options)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
          (new_id,who,prior['project_id'],'queued',len(tasks),0,0,'[]','[]',now,now,json.dumps(options)))
        db.executemany('INSERT INTO generation_job_items (job_id,seq,scene_id,shot_id,state,updated) VALUES (?,?,?,?,?,?)',
                       [(new_id,i,t['scene_id'],t['shot_id'],'pending',now) for i,t in enumerate(tasks)])
    POOL.submit(_run,new_id,who)
    return status(new_id,who)


def interrupt_on_restart():
    # Don't blindly rebill work possibly completed just before a crash.
    with conn() as db:
        db.execute("UPDATE generation_jobs SET state='interrupted',updated=? WHERE state IN ('queued','running','cancel_requested')",(time.time(),))
        db.execute("UPDATE generation_job_items SET state='uncertain' WHERE state='running'")
