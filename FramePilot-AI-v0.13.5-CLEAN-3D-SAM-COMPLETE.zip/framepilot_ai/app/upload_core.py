"""Durable upload control plane. Local chunk store for a single host; optional S3 multipart.

No untrusted upload path is ever taken from the client; all paths use server-generated IDs.
The worker owns expensive PDF parsing. API workers never load complete uploaded files.
"""
from __future__ import annotations

import hashlib
import math
import os
import re
import sqlite3
import tempfile
import time
import uuid
from pathlib import Path
from .auth import actor, auth_on

MAX_UPLOAD_BYTES = 1024 * 1024 * 1024     # 1 GiB per file
CHUNK_SIZE = 8 * 1024 * 1024            # 8 MiB, also valid S3 multipart part size
READ_BLOCK = 1024 * 1024
MAX_ACTIVE_RESERVED = int(os.getenv('FRAMEPILOT_ACTIVE_UPLOAD_QUOTA_GIB', '4')) * MAX_UPLOAD_BYTES
ALLOWED = {'.pdf', '.txt', '.png', '.jpg', '.jpeg', '.webp', '.mp4', '.mov', '.mp3', '.wav'}
SCRIPT_EXTENSIONS = {'.pdf', '.txt'}
MIMES = {'.pdf':'application/pdf', '.txt':'text/plain', '.png':'image/png', '.jpg':'image/jpeg',
         '.jpeg':'image/jpeg', '.webp':'image/webp', '.mp4':'video/mp4', '.mov':'video/quicktime',
         '.mp3':'audio/mpeg', '.wav':'audio/wav'}
UUID_RE = re.compile(r'^[0-9a-f]{32}$')


class UploadError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status


def extension_for(filename: str, kind: str):
    if not filename or len(filename) > 160 or '\x00' in filename or ':' in filename:
        raise UploadError(422, 'Filename is invalid or too long.')
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED or (kind == 'screenplay' and ext not in SCRIPT_EXTENSIONS):
        raise UploadError(415, 'Unsupported file. Scripts: PDF/TXT. Media: PNG/JPEG/WebP/MP4/MOV/MP3/WAV.')
    return ext


def verify_magic(path: Path, ext: str):
    with path.open('rb') as stream:
        b = stream.read(32)
    matched = {
        '.pdf': b.startswith(b'%PDF-'), '.png': b.startswith(b'\x89PNG\r\n\x1a\n'),
        '.jpg': b.startswith(b'\xff\xd8\xff'), '.jpeg': b.startswith(b'\xff\xd8\xff'),
        '.webp': b[:4] == b'RIFF' and b[8:12] == b'WEBP',
        '.wav': b[:4] == b'RIFF' and b[8:12] == b'WAVE',
        '.mp3': b[:3] == b'ID3' or (len(b) >= 2 and b[0] == 0xff and (b[1] & 0xe0) == 0xe0),
        '.mp4': b[4:8] == b'ftyp', '.mov': b[4:8] == b'ftyp',
        '.txt': b'\x00' not in b,
    }[ext]
    if not matched:
        raise UploadError(415, f'The file content does not match its {ext} extension.')


class UploadService:
    def __init__(self, folder: Path, backend: str | None = None):
        self.folder = Path(folder).resolve()
        self.folder.mkdir(parents=True, exist_ok=True)
        self.chunks_dir = self.folder/'chunks'
        self.objects_dir = self.folder/'objects'
        self.chunks_dir.mkdir(exist_ok=True)
        self.objects_dir.mkdir(exist_ok=True)
        self.db = self.folder/'uploads.sqlite3'
        self.backend = (backend or os.getenv('FRAMEPILOT_UPLOAD_BACKEND', 'local')).lower()
        if self.backend not in {'local', 's3'}:
            raise RuntimeError('FRAMEPILOT_UPLOAD_BACKEND must be local or s3')
        self.bucket = os.getenv('FRAMEPILOT_S3_BUCKET', '')
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS uploads (
                    id TEXT PRIMARY KEY, filename TEXT NOT NULL, ext TEXT NOT NULL,
                    kind TEXT NOT NULL, size INTEGER NOT NULL, title TEXT NOT NULL,
                    ocr INTEGER NOT NULL DEFAULT 0, backend TEXT NOT NULL,
                    remote_id TEXT, object_key TEXT, status TEXT NOT NULL,
                    created REAL NOT NULL, updated REAL NOT NULL,
                    digest TEXT, project_id TEXT, error TEXT,
                    retries INTEGER NOT NULL DEFAULT 0,
                    available_at REAL NOT NULL DEFAULT 0,
                    lease_until REAL NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS parts (
                    upload_id TEXT NOT NULL, part_index INTEGER NOT NULL,
                    length INTEGER NOT NULL, digest TEXT NOT NULL,
                    PRIMARY KEY(upload_id, part_index),
                    FOREIGN KEY(upload_id) REFERENCES uploads(id)
                );
                CREATE INDEX IF NOT EXISTS idx_upload_jobs ON uploads(status, available_at, lease_until);
            ''')
            fields={r['name'] for r in db.execute('PRAGMA table_info(uploads)')}
            if 'owner_id' not in fields:
                db.execute("ALTER TABLE uploads ADD COLUMN owner_id TEXT NOT NULL DEFAULT 'local'")

    def connect(self):
        c = sqlite3.connect(str(self.db), timeout=30)
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA busy_timeout=30000')
        c.execute('PRAGMA journal_mode=WAL')
        return c

    def s3(self):
        if not self.bucket:
            raise UploadError(503, 'FRAMEPILOT_S3_BUCKET is required for S3 uploads.')
        try:
            import boto3
        except ImportError as exc:
            raise UploadError(503, 'Install the optional boto3 dependency for S3 multipart uploads.') from exc
        return boto3.client('s3', endpoint_url=os.getenv('FRAMEPILOT_S3_ENDPOINT') or None,
                            region_name=os.getenv('AWS_REGION', 'us-east-1'))

    def create(self, filename: str, size: int, kind: str = 'screenplay', title: str = '', ocr: bool = True):
        if kind not in {'screenplay', 'asset'}:
            raise UploadError(422, 'kind must be screenplay or asset.')
        ext = extension_for(filename, kind)
        if size < 1 or size > MAX_UPLOAD_BYTES:
            raise UploadError(413, 'Files must be nonempty and no larger than 1 GiB (1,073,741,824 bytes).')
        ident = uuid.uuid4().hex
        now = time.time()
        key = f'framepilot/uploads/{ident}{ext}'
        # Reserve quota in one SQLite write transaction, not a check-then-insert race.
        initial_status = 'initializing' if self.backend == 's3' else 'uploading'
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            reserved = db.execute("SELECT COALESCE(SUM(size),0) AS b FROM uploads WHERE status IN ('initializing','uploading','assembling','queued','processing')").fetchone()['b']
            if reserved + size > MAX_ACTIVE_RESERVED:
                raise UploadError(429, 'Upload quota exceeded. Complete or cancel existing uploads.')
            db.execute('INSERT INTO uploads(id,filename,ext,kind,size,title,ocr,backend,remote_id,object_key,status,created,updated,owner_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                       (ident, Path(filename).name, ext, kind, size, title[:160], int(ocr), self.backend,
                        None, key if self.backend == 's3' else None, initial_status, now, now, actor()))
        if self.backend == 's3':
            try:
                remote_id = self.s3().create_multipart_upload(Bucket=self.bucket, Key=key,
                          ContentType=MIMES[ext], ServerSideEncryption='AES256')['UploadId']
            except Exception:
                with self.connect() as db:
                    db.execute("UPDATE uploads SET status='failed',error='S3 multipart setup failed' WHERE id=?",(ident,))
                raise
            with self.connect() as db:
                db.execute("UPDATE uploads SET remote_id=?,status='uploading',updated=? WHERE id=?",
                           (remote_id,time.time(),ident))
        return self.status(ident)

    def _row(self, ident):
        if not UUID_RE.fullmatch(ident):
            raise UploadError(404, 'Upload not found.')
        with self.connect() as db:
            row = db.execute('SELECT * FROM uploads WHERE id=?', (ident,)).fetchone()
        if row is None or (auth_on() and actor()!='system' and row['owner_id']!=actor()):
            raise UploadError(404, 'Upload not found.')
        return row

    def _part_count(self, row):
        return math.ceil(row['size']/CHUNK_SIZE)

    def _part_size(self, row, index):
        if index < 0 or index >= self._part_count(row):
            raise UploadError(422, 'Part number out of range.')
        return min(CHUNK_SIZE, row['size'] - index*CHUNK_SIZE)

    def status(self, ident):
        row = self._row(ident)
        if row['backend'] == 'local':
            with self.connect() as db:
                parts = [r['part_index'] for r in db.execute('SELECT part_index FROM parts WHERE upload_id=? ORDER BY part_index', (ident,))]
        elif row['status'] == 'uploading':
            s3 = self.s3()
            parts = []
            etags = {}
            marker = 0
            while True:
                response = s3.list_parts(Bucket=self.bucket, Key=row['object_key'], UploadId=row['remote_id'], PartNumberMarker=marker)
                parts.extend(p['PartNumber'] - 1 for p in response.get('Parts', []))
                etags.update({str(p['PartNumber']-1):p['ETag'] for p in response.get('Parts', [])})
                if not response.get('IsTruncated'): break
                marker = response['NextPartNumberMarker']
        else:
            parts = list(range(self._part_count(row)))
        return {'id':row['id'], 'filename':row['filename'], 'kind':row['kind'], 'size':row['size'],
                'part_size':CHUNK_SIZE, 'parts_total':self._part_count(row), 'received':parts,
                'backend':row['backend'], 'status':row['status'], 'project_id':row['project_id'],
                'error':row['error'], 'retries':row['retries'], 'sha256':row['digest'],
                'etags':etags if row['backend']=='s3' and row['status']=='uploading' else {}}

    def _validate_active(self, ident, index):
        row = self._row(ident)
        if row['status'] != 'uploading':
            raise UploadError(409, 'Upload already finalized or not accepting parts.')
        self._part_size(row, index)
        return row

    def presign(self, ident, index):
        row = self._validate_active(ident, index)
        if row['backend'] != 's3':
            raise UploadError(409, 'Direct presigning only applies to S3 uploads.')
        url = self.s3().generate_presigned_url('upload_part', Params={
                'Bucket':self.bucket, 'Key':row['object_key'], 'UploadId':row['remote_id'],
                'PartNumber':index+1}, ExpiresIn=900, HttpMethod='PUT')
        return {'url':url, 'method':'PUT', 'part_index':index, 'expires_seconds':900}

    async def save_part(self, ident, index, byte_stream, expected_digest: str | None = None):
        row = self._validate_active(ident, index)
        if row['backend'] != 'local':
            raise UploadError(409, 'S3 uploads must send parts directly to the signed S3 URL.')
        expected = self._part_size(row, index)
        if expected_digest and not re.fullmatch(r'[0-9a-f]{64}', expected_digest.lower()):
            raise UploadError(422, 'Invalid SHA-256 digest.')
        folder = self.chunks_dir/ident
        folder.mkdir(parents=True, exist_ok=True)
        final = folder/f'{index:05}.chunk'
        temp = folder/f'.{index:05}.{uuid.uuid4().hex}.tmp'
        count = 0
        h = hashlib.sha256()
        try:
            with temp.open('wb') as out:
                async for block in byte_stream:
                    count += len(block)
                    if count > expected:
                        raise UploadError(413, 'Part is larger than the required size.')
                    h.update(block)
                    out.write(block)
                out.flush()
                os.fsync(out.fileno())
            if count != expected:
                raise UploadError(422, f'Incorrect part length: expected {expected}, received {count}.')
            digest = h.hexdigest()
            if expected_digest and expected_digest.lower() != digest:
                raise UploadError(422, 'Part checksum mismatch. Retry this part.')
            with self.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                state = db.execute('SELECT status FROM uploads WHERE id=?', (ident,)).fetchone()
                if not state or state['status'] != 'uploading':
                    raise UploadError(409, 'Upload was finalized while this part was in progress.')
                old = db.execute('SELECT digest FROM parts WHERE upload_id=? AND part_index=?', (ident,index)).fetchone()
                if old and old['digest'] != digest:
                    raise UploadError(409, 'Conflicting part content. Restart the upload.')
                os.replace(temp, final)
                db.execute('INSERT OR REPLACE INTO parts(upload_id,part_index,length,digest) VALUES(?,?,?,?)',
                           (ident,index,count,digest))
                db.execute('UPDATE uploads SET updated=? WHERE id=?', (time.time(),ident))
            return {'part_index':index, 'size':count, 'sha256':digest}
        finally:
            temp.unlink(missing_ok=True)

    def complete(self, ident, remote_parts: list[dict] | None = None):
        row = self._row(ident)
        if row['status'] in ('queued','processing','completed','stored'):
            return self.status(ident)
        if row['status'] != 'uploading':
            raise UploadError(409, f'Upload is {row["status"]}.')
        count = self._part_count(row)
        sha = None
        if row['backend'] == 'local':
            with self.connect() as db:
                parts = db.execute('SELECT part_index,length,digest FROM parts WHERE upload_id=? ORDER BY part_index', (ident,)).fetchall()
            if len(parts) != count or any(p['part_index'] != i or p['length'] != self._part_size(row,i) for i,p in enumerate(parts)):
                raise UploadError(409, 'Some upload parts are missing. Resume before completing.')
            source = self.objects_dir/f'{ident}{row["ext"]}'
            temp = self.objects_dir/f'.{ident}.assembling'
            hasher = hashlib.sha256()
            try:
                with temp.open('wb') as output:
                    for i,p in enumerate(parts):
                        with (self.chunks_dir/ident/f'{i:05}.chunk').open('rb') as inp:
                            ph = hashlib.sha256()
                            while block := inp.read(READ_BLOCK):
                                ph.update(block); hasher.update(block); output.write(block)
                        if ph.hexdigest() != p['digest']:
                            raise UploadError(422, 'Stored part checksum mismatch. Retry the upload.')
                    output.flush();os.fsync(output.fileno())
                if temp.stat().st_size != row['size']:
                    raise UploadError(422, 'Assembled length does not match declared length.')
                verify_magic(temp, row['ext'])
                os.replace(temp, source)
            finally:
                temp.unlink(missing_ok=True)
            sha = hasher.hexdigest()
        else:
            if remote_parts is None or len(remote_parts) != count:
                raise UploadError(409, 'All S3 part ETags are required to finalize the upload.')
            parts = []
            for i,p in enumerate(remote_parts):
                if p.get('part_index') != i or not re.fullmatch(r'"?[a-fA-F0-9]{32}(?:-[0-9]{1,5})?"?',str(p.get('etag',''))):
                    raise UploadError(422,'Invalid or unordered S3 part ETags.')
                parts.append({'PartNumber':i+1,'ETag':p['etag']})
            s3 = self.s3()
            try:
                s3.complete_multipart_upload(Bucket=self.bucket,Key=row['object_key'],UploadId=row['remote_id'],
                                             MultipartUpload={'Parts':parts})
            except Exception:
                # A lost response can mean the object was already finalized; verify before retrying.
                try:
                    head = s3.head_object(Bucket=self.bucket,Key=row['object_key'])
                    if head['ContentLength'] != row['size']:raise
                except Exception:
                    raise
            head = s3.head_object(Bucket=self.bucket,Key=row['object_key'])
            if head['ContentLength'] != row['size']:
                raise UploadError(422, 'S3 final object size mismatch.')
        status = 'queued' if row['kind']=='screenplay' else 'stored'
        with self.connect() as db:
            db.execute('UPDATE uploads SET status=?,digest=?,updated=?,error=NULL WHERE id=? AND status=\'uploading\'',
                       (status,sha,time.time(),ident))
        if row['backend']=='local':
            for p in (self.chunks_dir/ident).glob('*.chunk'):p.unlink(missing_ok=True)
            try:(self.chunks_dir/ident).rmdir()
            except OSError: pass
        return self.status(ident)

    def claim(self, lease_seconds=3600):
        now = time.time()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('''SELECT * FROM uploads WHERE kind='screenplay' AND
                 ((status='queued' AND available_at<=?) OR
                  (status='processing' AND lease_until<?))
                 ORDER BY created LIMIT 1''', (now,now)).fetchone()
            if row is None:return None
            db.execute("UPDATE uploads SET status='processing',lease_until=?,updated=? WHERE id=?",
                       (now+lease_seconds,now,row['id']))
            return dict(row)

    def renew_lease(self, ident, lease_seconds=3600):
        """Heartbeat for a long-running import, preventing duplicate work on slow OCR."""
        with self.connect() as db:
            db.execute("UPDATE uploads SET lease_until=?,updated=? WHERE id=? AND status='processing'",
                       (time.time()+lease_seconds,time.time(),ident))

    def mark_success(self, ident, project_id):
        with self.connect() as db:
            db.execute("UPDATE uploads SET status='completed',project_id=?,error=NULL,lease_until=0,updated=? WHERE id=?",
                       (project_id,time.time(),ident))

    def mark_failure(self, ident, message, permanent=False):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT retries FROM uploads WHERE id=?', (ident,)).fetchone()
            retry = row['retries']+1
            status = 'failed' if permanent or retry>=3 else 'queued'
            db.execute('UPDATE uploads SET status=?,retries=?,error=?,available_at=?,lease_until=0,updated=? WHERE id=?',
                       (status,retry,str(message)[:500],time.time()+min(60*2**retry,900),time.time(),ident))

    def local_path(self, row):
        if row['backend']=='local':
            p = self.objects_dir/f'{row["id"]}{row["ext"]}'
            if not p.is_file():raise FileNotFoundError('Uploaded file is missing.')
            return p
        return None

    def download_s3(self, row, path: Path):
        body = self.s3().get_object(Bucket=self.bucket,Key=row['object_key'])['Body']
        size = 0
        try:
            with path.open('wb') as out:
                while chunk := body.read(READ_BLOCK):
                    size += len(chunk)
                    if size > row['size']:raise UploadError(422, 'Downloaded object exceeded declared size.')
                    out.write(chunk)
            if size != row['size']:raise UploadError(422, 'Incomplete S3 object.')
        finally:
            body.close()
        verify_magic(path, row['ext'])

    def cancel(self, ident):
        row = self._row(ident)
        if row['status'] == 'processing':raise UploadError(409,'Cannot cancel an import that is processing.')
        if row['status'] not in ('uploading','queued'):
            raise UploadError(409,'Only uploading or queued files can be canceled.')
        if row['backend']=='s3':
            if row['status']=='uploading':
                self.s3().abort_multipart_upload(Bucket=self.bucket,Key=row['object_key'],UploadId=row['remote_id'])
            else:self.s3().delete_object(Bucket=self.bucket,Key=row['object_key'])
        else:
            folder=self.chunks_dir/ident
            for p in folder.glob('*'):p.unlink(missing_ok=True)
            try:folder.rmdir()
            except OSError:pass
            (self.objects_dir/f'{ident}{row["ext"]}').unlink(missing_ok=True)
        with self.connect() as db:
            db.execute("UPDATE uploads SET status='canceled',updated=? WHERE id=?",(time.time(),ident))
        return self.status(ident)

    def cleanup(self, *, max_age_seconds=2*86400, completed_retention_seconds=7*86400):
        """Reclaim abandoned multipart staging files and old completed source uploads.

        Local mode: called by worker periodically. For S3 also configure bucket lifecycle
        AbortIncompleteMultipartUpload; this method is best-effort, not a substitute.
        """
        now=time.time()
        with self.connect() as db:
            rows=[dict(x) for x in db.execute("SELECT * FROM uploads WHERE (status IN ('uploading','initializing','failed','canceled') AND updated<?) OR (status IN ('completed','stored') AND updated<?)",
                (now-max_age_seconds,now-completed_retention_seconds))]
        count=0
        for row in rows:
            ident=row['id'];ext=row['ext']
            try:
                if row['backend']=='s3':
                    if row['status'] in ('uploading','initializing') and row['remote_id']:
                        self.s3().abort_multipart_upload(Bucket=self.bucket,Key=row['object_key'],UploadId=row['remote_id'])
                    elif row['status'] in ('completed','stored'):
                        self.s3().delete_object(Bucket=self.bucket,Key=row['object_key'])
                else:
                    folder=self.chunks_dir/ident
                    for part in folder.glob('*'):part.unlink(missing_ok=True)
                    if folder.exists():folder.rmdir()
                    (self.objects_dir/f'{ident}{ext}').unlink(missing_ok=True)
                with self.connect() as db:
                    db.execute("UPDATE uploads SET status=CASE WHEN status IN ('uploading','initializing') THEN 'expired' ELSE status END,updated=? WHERE id=?",
                               (now,ident))
                count+=1
            except Exception:
                # One bad S3 object must not prevent other uploads from being cleaned up.
                continue
        return count
