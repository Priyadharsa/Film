# FramePilot v0.12 — Director AI + account and inference reliability

FramePilot remains an **editable local filmmaking app**; this release adds an
AI-assisted director's desk inside the same screen. A single shot can be
reviewed and improved without changing the screenplay or generating an image.

## Open it

1. Open `/book` and select **Original demo** or an imported film.
2. Choose the scene and shot on the timeline.
3. Select **DIRECTOR AI** in the editor tabs.
4. Start from a film-specific prompt (romance, dialogue, fight, suspense,
   character introduction, interval, climax or montage), or describe a custom
   direction. Choose **Muse Spark** or **Offline creative draft**.
5. Select **Propose shot improvements**. This step **never modifies the film**.
6. Review the shot, camera, lighting, sound, continuity, safety, 3D objects and
   sketch composition guides. Click **Apply shot + 3D edits** to save the accepted
   proposal. Switch to **3D SET** to view and edit the updated camera and props.
7. Click **Add guides to drawing** to place composition guides on the 2D sketch.
   Click **Save sketch** in DRAW if you want them persisted as an image.
8. Choose **Undo last AI apply** to restore shot details and 3D geometry.

The app validates a strict proposal schema: camera coordinates/lenses and object
transforms are bounded; only known primitive object kinds are accepted; and no
LLM-generated code or shell commands can run in the server. Each proposal
belongs to a specific scene and shot. An outdated project revision returns
HTTP 409 rather than silently overwriting another edit.

## What is Muse Code here?

Meta's **Muse Code** is a coding assistant for a developer's terminal. It is
not a general film-planning SDK. In FramePilot, the **Director AI** uses **Muse
Spark through Meta Model API**, the same underlying model family as Muse Code.
The **Copy brief for Muse Code CLI** button prepares a developer-facing request
for work on FramePilot's source code. It does not launch a shell or grant the
web application code-execution privileges.

Meta docs: https://dev.meta.ai/docs/overview and https://dev.meta.ai/docs/muse-code

## Meta errors and retries

Responses API calls use **3 total attempts** (including the original), with
bounded exponential backoff and jitter when Meta returns 429, 500, 502, 503 or
504, or a connection/timeout failure. Responses API SDK automatic retries are
disabled to avoid stacking two retry layers. HTTP 400, 401 and 403 are **not**
retried. Repeated 5xx responses are reported to the UI rather than leaving an
endless loading spinner. The client must still respect the Meta account's RPM,
TPM and billing limits. For an ambiguous upstream 5xx, the service may have
already processed the request before failing; retries can incur usage.

## Why account creation previously returned 401 later

In v0.11 the register endpoint returned 201 but did not create a session. A
following `/api/projects` request returned 401 until the user separately
logged in. In v0.12 a successful registration creates a 7-day, HttpOnly,
SameSite=Strict session cookie and returns the signed-in user. A truly invalid
email/password still returns HTTP 401, intentionally. The cookie is Secure
when running under HTTPS or when `FRAMEPILOT_COOKIE_SECURE=1` is configured.

If profiles are wanted on your own machine, set `FRAMEPILOT_AUTH_MODE=accounts`
in `.env`, restart and use Profile → Create account. If the browser still
reports 401:

- Open `/api/auth/diagnostics` in the *same browser* and check
  `session_cookie_present` and `session_valid`.
- Use `http://127.0.0.1:8016` consistently; switching between `localhost`
  and `127.0.0.1` creates different cookie origins.
- On HTTP localhost do not force `FRAMEPILOT_COOKIE_SECURE=1`, which requires
  HTTPS. With cloud deployment, use real HTTPS and persistent storage.
- A local profile does **not** automatically sync to Meta, GitHub or another
  cloud provider. Never upload `.env` or `accounts.sqlite3` to Git.

## Testing

```bash
python -m pytest -q
npm test
```

Coverage includes provider retry policy, no-retry 401, registration/session,
private project isolation, typed proposal validation, human-approved apply,
conflict detection, and undo. Static Chromium layout checks are **not** a live
WebGL or Model API test. The local application has not been deployed or certified
at massive concurrency.
