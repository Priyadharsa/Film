# v0.8.3 reliability and test coverage

## Confirmed defect and regression test

In v0.8.2, `PATCH /api/projects/{project_id}/scenes/{scene_id}/shots/{shot_id}` called `model_dump(exclude_unset=True)` on a `ShotPatch`. Pydantic converted references into plain dictionaries. The code then used `item.reference_id` and later `item.model_dump()`, both of which crash for a dict. Because the UI first uploads via `/api/reference` then attaches with the PATCH route, users saw a misleading "upload image 500" even when the first POST succeeded. v0.8.3 reads `item['reference_id']`, performs duplicate and existence checks, and persists the reference dictionaries.

## Automated tests

- Python: image upload JPEG/PNG/WebP, attach to shot, edit roles, remove references, 8-reference boundary, missing/duplicated IDs, corrupt payload, invalid MIME signatures, over-limit payload, artwork upload, shot histories, PDF and comic exports, demo create, extra scene/shot, style discovery, versions and error IDs.
- Existing suites: chunked upload and resume, PDF parser/scene indexing, page editing and scene rebuild, PDF exports, model assets, reference studio, layout endpoints and error handling.
- Node: camera geometry, camera redraw recursion regression, viewport mode bindings and DOM structure, filmstrip controls.
- Chromium used with `page.set_content` to inspect actual HTML/CSS at 1660x1020, switch Art Studio/Studio/Focus modes, and verify computed bounding boxes. This is not a live end-to-end WebGL test.

## Not tested or not production-ready

- Chromium navigation to the test server was blocked by environment policy, so no claim of a browser-against-server E2E run.
- Meta API was mocked, not used for charged model calls. GPU/WebGL and CDN access depend on the target Windows machine.
- A real 1 GiB upload soak test, multiple concurrent editors, multi-tenant authorization, deployment of S3/Postgres/workers, AI throughput, virus scanning, and load tests have **not** been run.
- Current SQLite project blobs and whole-project response payloads do not scale to millions of users; the production target requires relational project/scene/shot rows, paged APIs, revision concurrency controls, object storage and queue-based generation.

## Windows smoke checklist after upgrading

1. Stop v0.8.2; back up `.env`, `private_uploads`, `static/generated`.
2. Apply v0.8.3 hotfix and start port 8007.
3. Open `/book` and hard-refresh Chrome.
4. Create an **Original demo** test project, choose a shot and open **Art Studio**.
5. Upload a PNG reference; it must show a thumbnail and appear in the shot after reopening the project.
6. Upload a JPEG and a WebP; attach, edit the roles, remove a reference.
7. Open **3D Set**: add an actor, move X/Z, save the set and reload.
8. Open **Draw**: make a sketch, save as a frame, view history, open full-size preview.
9. Navigate page numbers and shots; export production and comic PDFs.
10. For any failed action, run `./CHECK_FRAMEPILOT.ps1 -RequestId '<request id>'` in PowerShell and inspect the traceback. Do not share secrets.

## Scaling path after the demo

0. Keep local development bound to 127.0.0.1; do **not** expose the current API to the internet.
1. Add authenticated users with per-project authorization and audit logs; establish tenant isolation and malware scanning.
2. Split the SQLite document into Postgres film/scene/shot and job tables, use optimistic revision locking and cursor-paginated lists.
3. Move originals and generated assets to encrypted object storage, return signed URLs, use direct browser-to-S3 multipart upload.
4. Queue import/OCR/AI render operations, enforce per-user quotas and rate limits, idempotency keys and retries with DLQ.
5. Observability: OpenTelemetry traces, latency histograms, image jobs status, circuit breakers, cost per shot and alerting.
6. Verify 1 GiB resumability, failure injection, 100-1000 concurrent editors, SLO and GPU budget via real cloud load tests before raising supported capacity claims.
