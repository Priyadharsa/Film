# FramePilot Clear Workspace · v0.13.3

## Navigation

1. Top bar: choose film, import, profile and **Download film**. More export types remain available separately.
2. Choose **Split view**, **Script only**, or **Shot studio**. The default split view keeps source and active shot together.
3. Pick a scene and shot. Six editing tools are always visible with descriptive labels: **3D scene**, **Drawing**, **Art & Muse**, **AI director**, **Voice**, **Versions**.
4. The primary workspace shows the frame and shot details before advanced controls. The currently selected tool opens below without affecting the source scene/shot.
5. In 3D, the inspector has direct jump links to **Environment**, **Add objects**, **Transform**, **Camera**, and **Lighting**. Sections are visible and independently scrollable, not collapsed.
6. **Full-film generation** is in a separate labelled section beneath the shot editor. Click **Render all shots** to jump there. Rendering makes billable Meta calls only when confirmed.

## Constraints

No model inference, account data migration, or backend changes are made by this release. It is a usability update over v0.13.2. WebGL, live Muse inference, and macOS/Windows GUI integration still require native validation.
