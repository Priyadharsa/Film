# FramePilot Cinema 3D — User Guide (v0.8.4)

## What it is

An editable Three.js film previsualization workspace built directly into the screenplay-to-shot Editor. This is **not Blender** and **not Unreal Engine** running inside the browser; its native scene graph uses Three.js. It exchanges portable GLB 2.0 assets with those applications.

## Opening and maximizing

Open the book workspace, select **Original demo** (or your film), choose **3D SET**, and click **Maximize 3D**. The whole window becomes the stage and its properties panel. **Restore 3D** exits. **Hide inspector** expands the viewport; **Show inspector** restores it. Press `F` to maximize/restore, `Esc` to restore and `G/R/S` to move/rotate/scale the selected object when not typing in a field. `C` selects camera POV. Press `Delete` to remove the selected object.

## Scene, actors and props

Add and select actors, boxes, spheres, cylinders, tables, chairs, walls, doors, windows and beds. Use the object list or click a mesh to select it. Transform gizmos move, rotate or scale a selected object; numeric X/Y/Z/yaw/scale controls provide engineering-graphics-style placement. Grid snapping is optional. Editable set starters: cafe, interrogation, street, bedroom, fight choreography or blank. The starters **add** objects rather than clearing the current set.

## Camera and cinematography

Perspective, orthographic top and cinematic camera POV; camera controls X/Y/Z in metres, pan, tilt, roll and lens in mm. Angle presets: establishing, wide, medium, close, over the shoulder, low/high, dutch, bird's eye. Delivery aspect ratio: 16:9, 2.39:1, 4:3, 1:1 and 9:16, with letterboxed/pillarboxed camera preview. Safe guides and camera movement annotations are available. FPS/f-stop fields are **metadata only**, not physical motion blur or depth-of-field simulation.

## Lighting

Daylight, golden-hour, moonlight, film noir, interrogation, romance and neutral studio moods. Adjust key/fill/rim intensities and light color. These change the Three.js preview and the camera snapshot. This is fast previsualization lighting, not path-traced photorealism.

## Shot pipeline

1. Choose a screenplay page and shot.
2. Construct the set, import assets, position actors and camera, set lighting.
3. Click **Save scene** to persist geometry and lighting to the selected shot. Changes are local to the shot until saved.
4. Click **Capture camera frame**. This temporarily renders camera POV regardless of the current editor view, omits the grid, and stores the resulting PNG in the shot history.
5. Switch to Art Studio for references, custom art styles and generative refinements.
6. Export production PDF or comic PDF from the Film toolbar.

## Blender / Unreal interchange

- **Blender → FramePilot:** Blender File > Export > glTF 2.0, choose GLB binary and embed images. Import the `.glb` using **Import Blender / Unreal .GLB**. Uploaded models are capped at **30 MiB**; complex scene meshes may need simplification.
- **FramePilot → Blender:** **Export .GLB**, then Blender File > Import > glTF 2.0 (.glb/.gltf). Separately export **Scene JSON** for precise camera metadata and shot-blocking notes.
- **FramePilot → Unreal:** Export GLB and use a compatible version of Unreal Engine's Interchange **Import Into Level** option, following Unreal documentation. Confirm coordinate, units, camera, and materials in the target editor; conversion is not always lossless.

Native `.blend`, `.fbx`, `.uasset`, and `.uproject` authoring, Skeletal Animation, Niagara VFX, Sequencer, Nanite/Lumen and Unreal Remote Control are **not implemented**. A future native integration can use separate Blender add-ons/Unreal plugins.

## Reliability and security

The Three.js module and addons are currently fetched from a CDN, so the 3D viewport requires working internet and WebGL. Other screenplay, PDF and drawing features remain usable if 3D fails. On Windows, open `http://127.0.0.1:8008/book` after `START_FRAMEPILOT.bat`.

The current local app must not be exposed directly to public internet or used for multi-tenant production. Uploaded 3D assets and scripts are private local files; deploy behind authentication, quotas, virus scanning, and appropriate infrastructure before public use.
