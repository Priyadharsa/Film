# FramePilot v0.13.2 — Minimal film workspace

## Design principles

- Original white-and-teal visual language (not a Meta, Adobe, or Unreal clone).
- Scene and shot context shared by script, 3D, sketch, Muse/SAM, Director AI, audio, and production files.
- Primary film actions prominent; advanced framing and set controls remain in the inspector.
- Studio view expands the editor; fullscreen camera stage has a separately scrolling inspector.
- Screenplay notes, scene selection, and navigation remain non-overlapping on laptop and mobile widths.
- All actions still use v0.13.0 backend routes; cosmetic changes do not alter saved projects.

## 3D Blender import

GLB: Import directly as a 3D actor, prop, or environment. `.blend`: optional local-only conversion into GLB. You must install Blender and set `FRAMEPILOT_ENABLE_LOCAL_BLEND=1` on the local server. `.blend` is limited to 80 MiB; generated GLB to 30 MiB. The process runs with `--disable-autoexec`, a timeout, bounded result size, and requires a loopback connection. **This is not a sandbox**; do not turn it on for internet-facing deployments or accept untrusted `.blend` files. For a public cloud, isolate conversion in restricted workers with malware scanning and no network/filesystem permissions.

## What was actually verified

- Static desktop/mobile CSS layout from real Chromium (without application scripts and without external CDN).
- Python and Node regression tests against auth, PDF imports/exports, SAM workflows, 3D data and controls, profiles, render queue and OCR rejection.
- `.blend` route: disabled-by-default response; mocked conversion to valid GLB; private retrieval.

## What still needs live verification

- Native Windows and macOS interaction, WebGL with the three.js CDN loaded, live SAM/Muse inference, headless Blender conversion with a real installed Blender executable, and multi-host load.
- Ten-minute completion of hundreds of real Muse image requests cannot be guaranteed; the app prioritizes scene overview and offers credit-free composition drafts.
- Accounts are self-hosted only. Cloud persistence, durability and millions of concurrent requests require a real distributed deployment.
