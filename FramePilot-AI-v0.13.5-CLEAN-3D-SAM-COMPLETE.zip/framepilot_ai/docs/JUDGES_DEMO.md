# FramePilot AI — 3-minute competition walkthrough

**One-sentence pitch:** Turn a screenplay into a single connected director's workspace: block the shot in 3D, draw or revise artwork, segment a character with SAM, refine the same frame with Muse, and export practical production documents.

**Suggested live walkthrough (original material; does not require a copyrighted feature screenplay):**

- **0:00–0:25 — The script is the source of truth.** Open `/book`, click **Original demo**, choose the tea-shop scene and point out the same scene/shot identity carried across every editor.
- **0:25–0:55 — Camera and blocking.** Open **3D SET**, add/move an actor and a prop or load a prepared GLB, choose a lens and camera view, and capture a frame.
- **0:55–1:25 — Draw and improve.** Open **DRAW**; sketch a desired composition. Save it as a guide or send it to Art Studio.
- **1:25–2:00 — SAM + Muse control.** In **ART STUDIO**, show a reference image and a SAM object mask; refine mask edges, remove/heal a prop or stage a cutout. If the Meta API is working, perform one targeted Muse edit and show revision history. If not, demonstrate saved versions from the original demo and explain that the provider call is temporarily unavailable.
- **2:00–2:30 — Whole-film production.** Point out free shot planning, Quick reel / Scene overview / Complete coverage, job progress, stop/retry-failed controls, and explicit cost confirmation. Do not trigger hundreds of billable calls for the demo.
- **2:30–3:00 — Deliverable and production planning.** Export the complete production ZIP. Open `/production` for shot list, breakdown and call-sheet views. Close with the user outcome: a tangible storyboard/shot plan instead of a collection of unrelated AI images.

**Distinguishing claim:** Director-controlled, **script-linked** edits across 2D, 3D, segmentation, image generation, and practical production planning.

**Evidence to mention, but never exaggerate:** Automated local Python/JavaScript tests are bundled; the demo includes original storyboard art; live Meta credentials, WebGL hardware and full SaaS-scale infrastructure need separate checks. It is a local-first prototype; no guarantee of a competition award.

**Prior to submission:** Record a screen capture that opens successfully, verify your public GitHub repository and video URLs from an incognito window, remove `.env` and private files, and submit before the organizer's deadline.
