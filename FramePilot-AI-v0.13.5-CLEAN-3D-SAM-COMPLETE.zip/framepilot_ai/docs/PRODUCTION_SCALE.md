# FramePilot: 10M-user deployment architecture (engineering blueprint, not shipped)

## What the v0.8 release proves

A **local, single-host prototype** with a separate file-import process, a persisted chunk-upload protocol, per-scene draft shots, page-level editing, 3D actor/primitive/GLB objects, reference-based image generation, 68 styles and volume-limited PDF export. Automated tests cover correctness and API boundaries, not throughput or multi-tenant security.

**The release is not safe to expose publicly as a multi-user SaaS.** It has no identity provider, no tenant authorization, image URLs are accessible under a public static path, and mutable project state is a full JSON document inside SQLite. These must be replaced for production. The 1 GiB figure is a **transfer ceiling**, not a promise to process every arbitrary document: a large scanned PDF can still exceed OCR, page, and text-processing limits. Blender GLB editing is a small previsualization tool, not the Blender engine.

## Requirements / semantics to validate before sizing

- Does “10M users” mean registered accounts, monthly active users, daily active users, or concurrent users? Those produce drastically different workloads.
- Does “2M tokens/min” describe a global AI-generation budget, a peak account rate, or one user's request? A globally allocated 2,000,000 tokens/min equates to approximately 33,333 tokens/s; compare that with **actual** model quotas and costs before launch. Token pricing differs from image generation.
- Instrument p50/p95/p99 of upload initialization, chunk transfer, scene parsing, one-shot render, 3D asset load, and PDF export. Set explicit targets only after benchmarking; do not promise 99.99% availability based on local tests.

## Target architecture

```text
Browsers / CDN / Web application
    |  OAuth/OIDC + bot protection + API gateway + per-user rate limiting
    v
Film Projects API (stateless, autoscaled) --------> PostgreSQL
    |                                               (tenant-owned pages, scenes,
    |                                                shots, revisions and ACLs)
    +-- Upload control plane -- signed URLs ------> S3-compatible object storage
    |                                               (scripts, source pages, drawings,
    |                                                GLB, generated images, PDF volumes)
    +-- Orchestrator / job state ------------------> SQS/Kafka + DLQ
                                                    |
     PDF parsing / OCR workers <--------------------+
     AI-shot rendering workers <--------------------+
     PDF/comic assembly workers <-------------------+
     Optional high-performance preview rendering <+

Model gateway: admission control, concurrency limits, caching, quotas,
     automatic retries with bounded budgets, billing and audit logs.

Telemetry: traces, metrics, structured logs, per-tenant model spend,
     cost budgets, error budgets, alerts and performance dashboards.
```

## Database and collaboration

- Normalize `films`, `source_pages`, `scenes`, `shots`, `shot_revisions`, `assets`, `referenced_assets`, `render_jobs`, `exports`, `user_memberships`, `usage_ledger`, `audit_log` rather than storing entire films as one JSON blob.
- Enforce tenant membership on every read/write and **every asset download**. Prevent guessable public image URLs; issue short-lived signed URLs or authenticated asset streams. Use PostgreSQL RLS as defense in depth, never as a sole authorization mechanism.
- For concurrent edits, use `If-Match`/ETag optimistic concurrency with `revision` or `updated_at` and return `409 Conflict` when another editor saved first; offer diff and merge. Preserve immutable storyboard frame versions and explicit approvals.
- Scene/shot/page list APIs must be cursor-paginated; never return 10,000 scenes, frames and thumbnails in a single response. Virtualize UI lists and fetch just one open book page with nearby pages prefetched.

## Reliable 1 GiB uploads

- S3 multipart or equivalent object-store upload from browser with signed part URLs. Client encrypts transit over TLS, validates SHA-256 on finished object and persists an upload session ID for resumption.
- Never accept a 1 GiB request body in one API process. Enforce user quota, MIME+magic signatures, encrypted PDF policy, image pixel caps, GLB asset limits, content scan, source archive-bomb detection, retention policy, upload expiration and object lifecycle cleanup.
- Quarantine untrusted files; parse PDF/glTF in locked-down worker containers without unnecessary outbound networking; impose CPU, RAM, timeout and storage limits. The local worker is NOT a security sandbox.
- Each workflow item is idempotent by `(tenant_id, upload_id, stage)`. Workers use leases, retries with jitter, dead-letter queues and visible job states: queued / processing / succeeded / failed / cancelled.
- A “successful upload” means the source bytes were stored durably; it does **not** mean all scenes were parsed or models rendered. Surface independent status per stage.

## AI requests and economics

- Scene splitting should be deterministic and local first. Invoke LLM only for targeted, user-approved scenes or shot beats, not 1 GiB of PDF wholesale.
- Use a model gateway with context packing, per-user token quotas and request scheduling. Store only necessary text chunks and summaries; do not inject untrusted screenplay instructions into system prompts.
- Use 3D scene geometry as the structured source of truth; image generation is a creative suggestion, not a measured camera simulator. Validate output consistency and charge only on accepted API calls according to provider billing.
- Track input/output token costs and image-model costs separately. Require a monthly project spend cap and user confirmation for high-volume renders.

## Rollout gates

1. Identity provider, RBAC, tenant resource ownership, data deletion/export, abuse handling and privacy policy.
2. PostgreSQL migrations + normalized project model; concurrency tests for stale edits and double-submitted render jobs.
3. Authenticated S3 assets, virus scanning and content-security policy; removal of public generated-image routes.
4. Job queue + isolated parsers/renderers with leases, deadlines, observable retries, billing limits and cancellation.
5. Load tests at 10, 100, 1k, 10k concurrent sessions before any 10M-account claim; 1 GiB upload soak and interrupted multipart tests in a deployed environment.
6. Disaster recovery: restore drills, backups, multi-region decisions according to measured business needs, incident runbooks, logging and security assessment.
7. Rights management: only ingest licensed/owned source scripts and art; do not bundle book scans or unauthorized imagery as demo assets.

## References

- Three.js recommends glTF/GLB as a runtime asset format, including Blender exports: https://threejs.org/manual/pages/loading-3d-models.html
- GLTFLoader docs: https://threejs.org/docs/pages/GLTFLoader
- OWASP File Upload Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html
- AWS S3 multipart upload documentation: https://docs.aws.amazon.com/AmazonS3/latest/userguide/mpuoverview.html
