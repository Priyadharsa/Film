# FramePilot production architecture / ADR-007 — 1 GiB upload path

## Current implementation (v0.7, verifiable)

- **Data-plane:** browser slices PDF/TXT into 8 MiB parts (max 128 per 1 GiB), hashes each part, retries failed parts (bounded), remembers session in localStorage. The backend checks declared size <= 1,073,741,824 bytes before allocating a session. Local backend streams each part, computes SHA-256, writes outside the static directory, and renames atomically. Complete verifies every part by checksum, checks magic bytes, and computes whole-file SHA-256. Status resumes after refresh or process restart.
- **Control-plane:** `POST /api/uploads`, `GET /api/uploads/{id}`, `PUT /api/uploads/{id}/parts/{index}`, `POST /api/uploads/{id}/complete`, `DELETE /api/uploads/{id}`. Optional S3: `GET /api/uploads/{id}/parts/{index}/sign`, direct PUT to S3 and completion using ETags. S3 needs CORS allowing PUT from your website domain and exposing `ETag`; use short-lived URLs and a private bucket. Use SSE and least-privilege IAM. Multipart aborted on cancel; configure lifecycle abort for abandoned S3 multipart uploads.
- **Import-plane:** independent worker process, persistent SQLite queue state, lease-based claiming and retry with backoff. It opens PDFs by **filename** rather than loading a 1 GiB byte array, and limits parser work (2,000 pages, 250 OCR pages, 900,000 extracted characters, 240 scenes). Project creation is idempotent by upload ID prefix. Import status is queryable; it never silently drops errors.
- **Limitations:** local SQLite and a local filesystem need a single shared host. Worker leases have no heartbeat yet, and expensive imports may need a shorter max page count to bound CPU. A one-GiB file may exceed the document parser's semantic limits, OCR quality is variable, and disk usage needs quotas and cleanup. These limits should be explicit, not hidden.

## Production-grade multi-user topology (deployment target, NOT shipped and load-tested)

```text
Browser/desktop clients
     | OIDC + rate limit + per-tenant quota
API gateway / WAF / CDN
     | control-plane only (small JSON)
Stateless FastAPI pods ----------------> PostgreSQL (tenant + projects + upload sessions)
     | presign 8 MiB parts                | outbox event
     v                                  v
Private S3 / object storage       SQS / Redis Streams / durable queue
     |                                  |
     |                           Sandbox ingest workers (AV/CDR; PDF/OCR)
     |                                  |
     +-----------------------------+----+---> generated image/render workers
                                       |        (AI cost/quotas)
                                       +-----> final storyboard objects / PDF
Observability: OTEL traces, metrics, logging, alerts, DLQ, backup + restore tests
```

## Rollout gates / why a 1 GiB API limit is not enough

1. **Identity + authorization:** implement OIDC, organization/project RBAC, tenant-scoped object keys, access logs, CSRF policy, signed download URLs and scoped permissions. Current local app does NOT implement these. Do not expose port 8004 to the public Internet.
2. **Object storage:** prefer direct-to-S3 multipart for 100 MiB+ objects. Keep the backend off the byte path. Use bucket versioning, SSE/KMS as needed, lifecycle expiration, retention policies, multipart abort, ETag/checksum handling, CORS, malware scan + PDF sanitization, and storage quota enforcement.
3. **Queue and DB:** migrate SQLite to Postgres for multi-pod coordination, use SQS or Redis Streams for durable jobs with outbox/inbox idempotency; ack only after persisted state. Use heartbeat/lease extension, dead-letter queue, replay, exponential backoff, task-timeout and bounded concurrency. Separate AI render job concurrency from OCR/parse.
4. **Isolation:** untrusted PDFs in sandboxed workers with CPU/memory/time limits, non-root UID, no outbound network except approved endpoints, content size/page/pixel limits, virus scanning and CDR. Use bounded per-tenant processing queues.
5. **Correctness:** revisioned scene/shot writes with optimistic locking, project asset manifests and media permissions, transactional writes, checksum verification, export version snapshots, backup/restore, and data-deletion workflows.
6. **Scalability:** auto-scale stateless API by latency and queues by age; use CDN for public safe assets and signed URLs for private media; cache immutable frames. S3 PUT traffic bypasses API. Test with many parallel 1 GiB uploads and worker restarts.
7. **Operations:** p50/p95/p99 API latency, error budget and SLO, capacity forecast, per-tenant quotas, dashboards, alerts, worker retry queue depth, PDF failure causes, cloud cost ceilings, audit trail and incident runbooks.

## Architectural principles mapped to the DEV article

The linked author lists 11 titles; the article is **not the full books**. The following are engineering interpretations based on its descriptions and general industry practice:
- **Designing Data-Intensive Applications:** state durability, queues, idempotency, retryable imports, eventual consistency boundaries.
- **Software Engineering at Google:** sustainable tests, migrations, long-lived codebase and rollout discipline.
- **Clean Architecture / Head First Software Architecture:** isolate storage and processing from API and UI; predictable dependencies.
- **Fundamentals of Software Architecture:** choose architectural characteristics (durability, security, operability) as explicit constraints and tradeoffs.
- **Head First Design Patterns:** storage adapter for local vs S3; worker and parser separation.
- **System Design Interview / Hacking the System Design Interview:** presigned multipart, object storage, load balancing, queues, caches, gateways and CDNs.
- **Systems Analysis and Design titles (Scott Tilley; Dennis/Wixom/Roth; Valacich/George):** requirements, use cases, security actors, lifecycle, acceptance criteria.

## Acceptance and load tests to perform before any 'production-ready' claim

- 1,073,741,824-byte PDF multipart transfer end-to-end, network interruption, retry with missing chunk, duplicate/concurrent part, server restart, invalid magic and invalid checksum, cancellation, upload TTL cleanup, disk exhaustion.
- 100 simultaneous 1 GiB uploads; check upload P95, error rates, DB saturation, and cloud cost. Do not attempt on a laptop unless it has adequate free space.
- Malware/PDF fuzzing, zip bomb (archives disallowed), 5xx S3, malformed ETags, expired presigned URL, IAM denial, bucket CORS misconfiguration, queue replay and dead letter.
- PDF extraction cap and OCR resource usage; image renderer and model API are separately rate-limited.

## S3 setup outline

1. `pip install -r requirements-s3.txt`.
2. Set `FRAMEPILOT_UPLOAD_BACKEND=s3`, `FRAMEPILOT_S3_BUCKET=...`, `AWS_REGION=...`, and credential provider (role preferred; never embed secrets in Git).
3. Configure bucket CORS: AllowedMethods `["PUT"]`, AllowedOrigins `["https://your-app.example"]`, AllowedHeaders `["*"]`, ExposeHeaders `["ETag"]`. Configure lifecycle to abort incomplete multipart uploads.
4. API `create` returns backend=s3; browser requests signed PUT per 8 MiB part, sends direct to S3, records ETags, and calls complete. Worker streams object from S3 to its sandbox scratch disk for PyMuPDF.
5. Current S3 path still relies on the local SQLite queue; migrate to Postgres + durable queue **before** horizontally scaling API/worker pods.

## Security and data classification

Uploaded scripts and reference art are private user content. No uploaded PDFs or keys should appear in a public repo or static web directory. Never expose `/api/uploads` without authentication, user/tenant quotas, auditing, isolation and content scanning. The previous v0.5.1 private ZIP containing a model credential must NOT be published; rotate credentials shared through chats or files.
