# Fast rendering, profiles and cross-platform startup — v0.9.2

## Two render paths

* **Quick reel** renders the first shot of at most 12 scenes — the fastest real image preview mode.
* **Scene overview** selects the first shot in every scene (or every selected scene/page). Existing rendered shots are skipped. This is **not** a render of the entire scene or film.
* **Complete coverage** renders all remaining draft shots. Both modes preserve the screenplay and can use **each shot's current style**, or use one chosen preset + custom art direction for this batch.

The queue can run 1, 2, or 4 image calls concurrently on a **single local instance**. It uses atomic SQLite job-item claims, tracks completed/failed shots, and stores results. Changing the worker setting to 4 may cause 429 responses if your Meta team account has lower limits. The ETA is an estimate based on observed throughput and includes no guarantee. A cancelled job stops claiming new shots, but running requests may complete and still incur charges.

Do **not** use more than one independently running API process against the local project database for actual rendering; multi-instance/cloud use requires shared Postgres, a durable distributed queue, object storage, tenant-level quotas, and a global provider RPM limiter. Do **not** automatically replay unknown/running requests after a restart: they might already have been billed.

## Running it

| OS | Command | Opens |
| --- | --- | --- |
| Windows 10/11 | `START_FRAMEPILOT.bat` | `http://127.0.0.1:8012/book` |
| Linux | `bash START_FRAMEPILOT.sh` | same |
| macOS | `bash START_FRAMEPILOT.sh` | same |
| Docker (development) | `docker build -t framepilot .` and `docker run --rm -p 8012:8012 -v framepilot-data:/app/private_uploads -v framepilot-frames:/app/static/generated --env-file .env framepilot` | same |

Prerequisite: Python 3.10 or later, pip, internet for model calls and package install. Optional OCR requires system Tesseract. Native BLEND/Unreal rendering is not included. Docker command starts API only; for imports start a separate worker using the same data volumes and `python -m app.ingest_worker`.

The Windows launcher and shell launcher create **OS-specific** virtual environments. Do not copy `.venv` between operating systems. Browser UI supports current desktop Chrome/Firefox/Safari/Edge but interactive WebGL needs a supported GPU/driver.

## Profiles

The app already has self-hosted accounts. Set `FRAMEPILOT_AUTH_MODE=accounts` in `.env` and restart; choose **Profile** to create/login. You can now edit your profile display name. To access the same films on different machines, deploy one reachable HTTPS server with persistent storage and backups. This application has *not* been deployed to cloud storage by the release.

## Speed and costs

The provider publishes rate limits per team; check Meta Model API Limits before selecting parallel=4. The local backend does not enforce a cross-instance RPM limit. If a provider request fails it is recorded as a failed shot instead of automatically submitting a duplicate billable request. Rendering hundreds of image frames in a couple minutes is not realistic at default provider limits.

## Test boundaries

The automated tests cover the queue, selection counts, uniqueness under concurrency, profiles, routes, and geometry. They are *not* proof of provider throughput or macOS/Windows native end-to-end operation. See `tests/test_fast_render_v92.py`.
