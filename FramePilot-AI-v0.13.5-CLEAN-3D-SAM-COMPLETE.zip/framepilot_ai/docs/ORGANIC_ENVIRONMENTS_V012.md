# FramePilot 0.12 — Original Scene Design / Tide UI

## Three clear environment modes

1. **Original editable stage:** start empty, add actor/blocking primitives, position the cinema camera, adjust lighting, capture a frame and save shot state.
2. **Muse Spark stage proposal:** supply your own brief, optionally open with an existing screenplay shot, request bounded camera and primitive object suggestions. Nothing is applied until the director reviews the result and clicks Apply. Only allowlisted geometry types and numeric values may be placed; there is **no arbitrary generated code execution**.
3. **Your assets:** load a self-contained GLB from Blender for actual editable 3D transforms, or attach a still/video backplate. Generated Muse Image backdrops can guide the shot but are flat. Users can create original art in Draw or revise finished frames through SAM masks and Muse Image.

A backplate cannot be assumed to contain true 3D depth. A GLB import provides selectable transforms but does not reproduce Blender's full mesh editing or Unreal's native rendering and animation systems.

## User journey

Open Film → select scene/shot → 3D Set → Environment Design → Empty Stage / Muse proposal / import GLB → set camera → capture → Art Studio → Production Book / Production Hub.

Do not enable automatic expensive inference without user confirmation. The Muse proposal call generates text tokens; the Muse Image background is a separate billable call. Every image render in the existing batch feature has a confirmable cost estimate and a tracked job.

## Safety and deployment

- Upload validation accepts only supported still, video, and GLB formats within configured limits. Keep uploads outside public static content and enforce project ownership in account mode.
- Server-side Pydantic validation bounds object count, type, and coordinate range; client-side validation is additional defense only.
- Scene plans are suggestions, not executable scripts. Stage object data is saved to the existing project store. Media blobs themselves must be migrated with the project for cross-device access.
- Deployment beyond one developer host requires managed database, durable queue, S3-compatible object storage with tenant permissions, distributed rate limits, monitoring, and load validation. This source release does **not** meet 2-million-concurrent-request SLAs.
- Browser/WebGL/GLB interoperability and live Meta requests require a real-device acceptance test before production release.
