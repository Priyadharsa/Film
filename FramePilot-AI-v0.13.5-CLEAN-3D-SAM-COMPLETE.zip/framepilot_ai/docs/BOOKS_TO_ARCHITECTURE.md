# 11 system-design books → FramePilot design decisions

**Source**: the DEV Community article *I Read 25+ System Design Books, Here Are the 11 That Actually Made Me a Better Engineer* by Soma, published February 7, 2026 (edited February 18). These descriptions are grounded in the **article and publicly known architectural practices**, not a claim to have acquired and read the entire text of each book.

| # | Book mentioned in the article | Framing in the article | Application to FramePilot | v0.7 state |
|---|---|---|---|---|
| 1 | *Head First Software Architecture* | Principles and tradeoffs in architecture | Separate upload control, media storage, screenplay import, generation and UI | Modularized locally |
| 2 | *Designing Data-Intensive Applications* — Martin Kleppmann | Storage/processing systems and tradeoffs | Durable upload records, parts, checksums, idempotent import and retry | Implemented on SQLite single host; migrate to Postgres/queue for scale |
| 3 | *System Design Interview: An Insider's Guide*, Vols. 1–2 — Alex Xu | Concrete diagrams and large systems | Direct object-storage multipart path; small control-plane APIs | S3 adapter implemented; needs cloud integration tests |
| 4 | *Software Engineering at Google* | Sustainable engineering over time, at scale | Regression tests, schema evolution, operational gate checklist | Tests and versioning; no production SLO validation |
| 5 | *Clean Architecture* — Robert C. Martin | Maintainable boundaries between responsibilities | UploadService and independent import worker; UI uses an API contract | Implemented locally |
| 6 | *Systems Analysis and Design* — Scott Tilley | Requirements and system lifecycle | Define measurable upload cap, failure/retry flows, safe parser limits | Documented and partially tested |
| 7 | *Head First Design Patterns* — Freeman/Robson | Reusable design patterns and OO principles | Local vs S3 storage strategies under a consistent upload API | Implemented |
| 8 | *Hacking the System Design Interview* — Stanley Chiang | Gateway, cache, queue, object store, fanout, CDN | Keep 1 GiB bytes off stateless API with S3; worker behind queue | S3 adapter; cloud queue/gateway pending |
| 9 | *Fundamentals of Software Architecture* — Richards/Ford | Architectural characteristics and evolutionary architecture | Reliability, operability, privacy and cost constraints defined before implementation | ADR and checklist |
| 10 | *Systems Analysis and Design* — Dennis/Wixom/Roth (article spells Wroth) | Requirements and case studies | Upload lifecycle and filmmaker-specific scene import outcomes | API lifecycle tested |
| 11 | *Modern Systems Analysis and Design* — Valacich/George | Agile lifecycle and design analysis | Delivery stages: functional local → durable upload → secure cloud → load tests | Local proof of concept |

## The non-negotiable production criteria

A consumer-scale rollout is **not finished** simply because these techniques appear in code. Multi-user identity, tenant authorization, isolation for untrusted PDFs, quota enforcement, managed object storage, centralized relational DB, durable queue, CDN, secrets management, observability, availability targets, cost controls, disaster recovery and full load tests must all be verified. See `SCALING.md`.
