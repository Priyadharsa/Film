# v0.9 - Director's workstation, generation feedback and project profiles

## Generate one frame or every shot on a page

Open `/book` and select a film. Choose a screenplay page or scene. Click **Generate page** or **Generate scene**. The confirmation shows the number of Muse Image calls before any billed calls are made. Each shot is saved separately and a progress dock shows completed/failed totals. You can browse the film while generation is running. **Stop after current frame** prevents later shots, but cannot undo the currently active API request.

At most 32 shots per batch by default (`FRAMEPILOT_MAX_BATCH_SHOTS`); this is a deliberate cost/safety guard. A batch can't be launched twice concurrently for the same film. On application restart, incomplete batches are labelled `interrupted` rather than retried automatically to avoid accidental duplicate billing. The status is persisted in SQLite, though this local executor does not yet provide production-grade distributed delivery guarantees.

## Clean exports

Open Export → **Production package · ZIP**. The ZIP includes two PDF volumes, an editable JSON project, and a README. It excludes `.env`, private uploads, caches, API keys and original screenplay binary files. For a single page, use **Current page · PDF**. For a large book, volumes are limited to 250 scenes per export; select a scene range through the export APIs.

## Profiles and cloud deployment

By default, `FRAMEPILOT_AUTH_MODE=local` preserves local-only behavior and existing projects. No cloud sync occurs.

To enable protected accounts:

1. **Back up** `.env`, `private_uploads` and `static/generated`.
2. Add `FRAMEPILOT_AUTH_MODE=accounts` to `.env` (replace any existing setting) and restart.
3. Open Profile, register with an email and a password of at least 12 characters, then sign in.
4. If migrating old local projects, stop the server, run `python -m app.claim_local --email YOUR_EMAIL`, then restart. The command creates a database backup and only moves projects labelled `local` to the chosen account.

Accounts, session hashes and project records are stored in the server's SQLite database. For actual cloud availability across devices, deploy FramePilot to an HTTPS host with persistent database and object storage, operational backups, a managed queue, user quotas and monitoring. **The package does not include a hosted cloud backend, domain, or live remote account.** Existing generated files must also be retained in the deployment. Do not publicly expose the local development server or use this auth implementation as an audited SaaS identity provider.

## Security boundaries and scale

- Profile sessions: high-entropy tokens, SHA-256 token hashes at rest, HttpOnly SameSite=Strict cookies; Secure on HTTPS, PBKDF2-HMAC password hashes, login rate limiting, project owner filters.
- Model calls: model credentials remain in local `.env` and are never returned to the browser. New generation jobs have explicit per-job caps and manual cost confirmation.
- Development: SQLite and in-process ThreadPoolExecutor are suitable for one machine, **not millions of users**. The upload worker is separate; long-running Muse jobs still share the web process.
- Before production: move jobs to Redis/Celery/RQ, Postgres for projects and accounts, private object storage for all assets, dedicated artifact authorization, tenant quotas, account verification/reset flows, CSRF threat analysis, observability, real 1 GiB/resume trials, concurrency tests, and an independent security review.
- Tests in this release use mocked Meta calls. Live Muse/SAM access, billable inference, browser WebGL, cloud sync and third-party deployment are not proven by this suite.
