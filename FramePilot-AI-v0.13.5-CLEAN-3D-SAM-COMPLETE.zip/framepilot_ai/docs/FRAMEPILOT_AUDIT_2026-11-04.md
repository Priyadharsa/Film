# FramePilot technical & product audit — 2026-11-04

## Test scope and evidence

- Analyzed current v0.12 development source, FastAPI routes, local SQLite stores, browser source, job logic, image/reference handling, Meta clients, and PDF/ZIP exports.
- Full local Python and JavaScript suites, with targeted regression tests for 251-scene production export and cross-account reference protection.
- A real HTTP import of the user-provided 157-page *Interstellar* screenplay generated 367 parser scenes and 939 editable draft shots in approximately 5.3 seconds in this environment. Counts are heuristic, not an artist-approved breakdown.
- No paid Meta Model API inference or real-device Windows/macOS/Unreal/Blender browser rendering was performed in this audit.

## Confirmed bugs fixed

1. **Truncated “full” production export (P0):** the old package called `export_volume` without an end scene, exporting at most 250 scenes silently. The full ZIP now creates numbered production and comic PDF volumes, a complete `project.json`, explicit `manifest.json`, and available generated images (including version history). The single-volume PDF endpoints intentionally remain capped at 250 scenes.
2. **Cross-account reference injection (P0):** `PATCH .../shots/{id}` checked only that a reference file existed, without verifying it belonged to the current account. Added server-side `check_asset('reference',...)`; cross-account test now confirms 404.
3. **Release/test inconsistency (P2):** stale version and tool tab expectations caused 3 failing checks. Aligned current app, HTML, and tests to 0.12.2.

## Current workflow assessment

| Subsystem | Status | Remaining acceptance criteria |
| --- | --- | --- |
| PDF import & draft breakdown | Local test pass | OCR for scanned PDFs, multilingual scripts, author review and page-to-scene accuracy |
| Book/page/shot editors | API/JS tests pass | Full browser E2E, browser crash/resume, large book UI pagination |
| Character/body/face references | Local API and isolation tests pass | Real Muse continuity tests, reference mapping QA across scenes |
| Drawing/3D/GLB/Video | Unit/source verification | Actual browser WebGL, native GLB interoperability, video decode and long sessions |
| SAM selection & local edit | Unit verification | Real SAM provider call and visually accurate masks |
| Muse image editing | Mocked backend tests | Live API permissions, image accuracy and costs; exact mask containment is NOT guaranteed |
| Voice to storyboard | Local code review | Test real provider ASR with audio variants, transcription quality and diarization |
| Whole-film render | Tracked local job / bounded concurrency | Crash recovery, durable cloud queues, per-user budgets, actual per-frame latency |
| Export package | Multi-volume and artwork regression pass | Large-volume resource stress, cloud object storage, queued exports |
| Accounts | Self-hosted signup/session tests | HTTPS, CSRF/privacy review, password reset, email verification, managed identity |
| Distributed scale | Not verified | PostgreSQL/Redis/S3 migration, multi-region plan, realistic load and failure testing |

## High-priority follow-ups before production

1. **Visual end-to-end acceptance:** real browser tests on supported Windows, macOS and Linux browsers for upload → 3D → drawing → SAM/Muse → PDF.
2. **Render integrity:** make jobs durable across host crashes, reconcile ambiguous provider 500s without duplicate billing, apply tenant quotas, use per-task idempotency keys where providers support them.
3. **Export large books:** queue PDF/ZIP creation, stream from object storage, show progress, reserve storage/CPU budgets and expire artifacts safely.
4. **Consistency features:** explicit scene character bible, dialogues as editable *deterministic overlays*, a continuity checker for costume/background and original-shot-vs-revision comparison.
5. **Security:** replace SQLite with managed PostgreSQL, move private images to tenant-bound object storage, enforce quotas, malware scanning and authorization in *all* asset routes.
6. **Performance:** measure real provider requests per second, p95/p99, upload completion, memory per rendered frame, and cost per successful frame. Never claim 2 million simultaneous requests based on a local health probe.

## Known limitations

- “Local accounts” are not cloud synchronization. Images/videos used as backgrounds are not automatically reconstructed into 3D models. Blender `.glb` import/export is not native Unreal or Blender editing.
- Generation uses probabilistic models and may change faces/costumes unexpectedly or place text incorrectly. Dialogue bubbles should be deterministic post-processing, not entrusted to image generation.
- The `MAX_BOOK_SHOTS` ceiling and Meta's API rate limit restrict full-book rendering. A fast draft is not equivalent to hundreds of completed AI images.
- A successful source test suite does not prove production readiness, especially for a single-host SQLite application.

## Reproducibility

Run `python -m pytest -q` and `node --test tests/*.test.mjs` in the project root. No paid inference is performed by the automated suite. Keep `.env`, databases, private_uploads and generated artworks out of source control.
