# FramePilot — staged scale-readiness plan (v0.10.1)

## Truth in engineering

**Current status: local-first / single-host staging.** The source contains real filmmaking
modules, a Production Hub, a safe local admission controller, 1-GiB chunked upload,
self-hosted account mode, conflict detection, and persisted job records. It does **not**
serve 2 million simultaneous requests, and it is not ready for multi-node public deployment.

**2 million concurrent users** != **2 million active HTTP requests** != **2 million
simultaneous image-inference calls**. Use `concurrency = throughput * average latency`.
The actual service-level objective must specify requests/s, active users, p95/p99,
read/write mix, model calls/min, error budget, region(s), and budget.

## What's implemented and testable

- `/health/live` proves the API process responds. `/health/ready` tests writable local
  storage, SQLite reachability, and minimum available disk space.
- Setting `FRAMEPILOT_DEPLOYMENT_PROFILE=distributed` makes readiness return HTTP **503**
  intentionally: a multi-node database/queue migration is not yet complete.
- `TrafficGate` provides a bounded in-flight per-process gate and optional per-session/IP
  API rate limit. On overload it returns **429/503 with Retry-After**; it does not let
  unbounded requests accumulate. The ledger is bounded at 10,000 identities.
- Per-project optimistic locking returns HTTP 409 if one writer attempts to overwrite a
  newer edit; this prevents silent data loss when separate workers share a database.
- Operator counters at `/api/ops/capacity` require `FRAMEPILOT_OPERATIONS_TOKEN` via
  `X-Ops-Token`. Never expose that token in the frontend or Git.
- Local Docker Compose contains one API and one import worker sharing mounted local data;
  this is a **single-host integration test**, not a multi-node release.
- `loadtest/bounded_probe.py` sends capped read-only localhost requests (no Muse/SAM charges).
- Existing scene/shot editors, Art Studio, Cinema 3D and Production Hub regression tests
  remain in the CI test workflow.

## Production architecture that must still be built

```text
Browser / desktop client
  -> CDN for CSS/JS and immutable frame assets
  -> WAF / bot filtering / per-account quota at edge
  -> regional load balancer
  -> stateless FastAPI request/command service (auto scale)
      -> managed OAuth/OIDC + RBAC per film / crew role
      -> PostgreSQL (tenant indexed scene/shot rows; partition or shard when measured)
      -> managed Redis (shared cache/rate limits) -- NOT local in-process counters
      -> object storage, versioned private originals, multipart upload and signed URLs
      -> SQS/Kafka or equivalent durable queue
          -> isolated import/OCR workers
          -> independent Muse/SAM gateway and token-budgeted inference workers
          -> PDF/animatic render workers
      -> outbox + worker leases + reconciliation jobs + DLQs
  -> metrics/traces/logs/alerts and disaster recovery
```

**Never autoscale the current SQLite single-host app to multiple pods.** Each pod would
have its own data, session DB and job pool. A shared-volume SQLite setup is not a
substitute for transactional distributed metadata. `FRAMEPILOT_DEPLOYMENT_PROFILE` is a
fail-safe signal, not an implementation of the missing data layer.

## Contracts required before scaling

1. **Tenant isolation:** org_id/project_id foreign keys in every table, RBAC, row-level
   security where appropriate, authorization on media URLs and S3 signed links.
2. **Database migration:** SQLite -> PostgreSQL; scene/page/shot/revisions are individual
   rows. Use optimistic revisions, ordered migrations, unique idempotency keys, read
   replica routing and database connection pooling (PgBouncer or equivalent).
3. **Blob lifecycle:** direct-to-S3 multipart 1 GiB uploads, per-tenant quotas, content
   checks, malware scanning, signed delivery, retention and garbage collection.
4. **Durable generation:** ingestion requests return `202 + job_id`; workers use leases,
   visibility timeouts, idempotency, bounded retries and DLQs. A *maybe-billed*
   provider call should be reconciled before retry to avoid duplicate charges.
5. **Independent rate limits:** enforce RPM, concurrent requests, model tokens, image
   generation and daily credit budget separately; support 429 Retry-After and a circuit
   breaker when Muse/SAM are down.
6. **Security:** HTTPS only, authenticated APIs, account lifecycle, MFA/SSO, CSRF review,
   encrypted secrets and assets, retention/deletion policies, automated SAST/DAST,
   dependency scanning and third-party penetration test.
7. **SLOs:** define availability and first-frame latency; alert on p95/p99, 5xx rate,
   queue age, dead-letter count, object store errors, inference cost, image retry rate.
8. **Recovery:** automated snapshots/backups, restore drills, RPO/RTO targets, one-region
   failure simulations and immutable audit logs.

## Test ladder (non-negotiable)

| Gate | Scope | Evidence required |
|---|---|---|
| 0 | unit / contract | all tests green, deterministic provider mocks |
| 1 | single-host 32–128 clients | latency distributions and clean 429/503 responses |
| 2 | staging 1k–10k users | PostgreSQL/S3/queue, budgeted traffic and failover |
| 3 | staged 100k connections | multiple load generators, HPA, regional capacity |
| 4 | 2M target | production-like fleet, monitored p95/p99 and outage drills |

Never run giant traffic tests against Meta endpoints. Provider models should be mocked
for throughput tests. Scale real inference only after explicit quota/cost agreement.

## Run the measured safe check

```bash
pip install httpx
python -m uvicorn app.main:app --host 127.0.0.1 --port 8013
# In another terminal:
python loadtest/bounded_probe.py --requests 1000 --concurrency 32 --port 8013
```

This is **not** 2 million simultaneous requests. Monitor CPU, RAM, disk, 429 and 503;
record tool version, OS, machine, API calls, duration, and p95/p99 for every test.
