# Director's Book workflow (v0.8)

1. Import a PDF/TXT screenplay (up to **1 GiB upload bytes**) or choose the original demo. The importer stores each text PDF page or logical screenplay leaf as an individually editable page, plus draft scenes associated with that page.
2. Turn the page using Previous / Next or the jump field. There is **no full-document endless scroll**. A single long PDF page scrolls inside its own page leaf if necessary.
3. Select the scene on that page and its shot. Add a blank shot or a director's sequence pattern (introduction, romance, fight, suspense, climax, interval, comedy, emotion, montage).
4. Use the integrated 3D set to add actor markers, boxes, spheres, cylinders and independently move, rotate and scale them. A **single imported Blender .glb asset** is independently movable/rotatable/scalable as a whole asset. Internal Blender meshes are **not** separately mesh-edited. Export from Blender as glTF 2.0 **.glb with embedded resources**; 30 MiB limit per asset.
5. Pan/tilt/lens camera, use 3D/orbit, top or camera POV. Capture a WebGL render as the final 16:9 frame, or save the set and use its geometry as a Muse Image prompt hint.
6. Use DRAW to create your own frame with mouse/stylus/touch. Save it as a final frame or as an AI composition reference. 68 style descriptions + any custom art direction, up to eight image references per shot, Muse Image render and non-destructive revision (existing API key and access required). These are prompt-guided **not guaranteed exact style or identity**.
7. Export production PDF with scene text, lens notes and shot frames, or comic-layout PDF with four large panels per page. PDF export is capped at 250 scenes **per volume**, so long films export chapter-sized books without overwhelming one process. The v0.7 animatic feature remains in Advanced tools.
8. The original uploaded PDF's source page text and the scene draft are separate editable views. **Save page** saves the page. **Re-detect scenes** explicitly regenerates scene text from all edited pages while matching existing shot IDs by heading. Review source-to-scene matches on scripts with repeated or nonstandard headings. Never silently overwrite a user's established shot plan.

## Limitations worth acknowledging in the demo

- v0.8 is a local-first prototype, not yet a 10M-user service.
- Very large scanned PDFs need Tesseract and remain bound by OCR/page/character limits.
- The app provides a small Three.js stage and Blender GLB support—not the Blender modeling engine, mesh editor, or Unreal Engine cinematic renderer.
- 3D object transforms are deterministic. AI generated artwork is not guaranteed pixel-faithful to the geometry or reference face.
- Source book PDF examples should be used as reference inspiration, never redistributed in the public Git repository.
