# FramePilot v0.8.2 – Reader / Workstation improvements

This is a **local-first** editing environment, not the complete Unreal Engine or Adobe product. Use Chrome/Edge at a browser zoom of 100% to start.

## View layouts

- **Book spread**: screenplay and storyboard side by side. Both panels scroll independently on larger displays.
- **Script page**: large reading/editing page, with scene and page navigation.
- **Studio workspace**: uses all available horizontal space for the shot, drawing, or 3D stage.
- **Focus editor**: hides the shot preview and fields to maximize the selected editor (especially the 3D stage). Click again to return.
- **View zoom**: 80–175% for script type and frame image. It does **not** change lens calculations or stage geometry. In 3D view, use the camera controls or the mouse wheel to orbit/zoom.
- **Enlarge frame**: a lightbox for reviewing the storyboard at near-full screen.
- Keyboard: `1` book, `2` script, `3` studio, Left/Right page, Escape to exit preview/focus. Keyboard shortcuts do not activate while typing in form fields.

At narrow widths the book becomes a vertical layout with larger, scrollable controls instead of squeezing both pages into unreadable columns.

## Handling an HTTP 500

1. Make sure the app is **v0.8.2 on port 8006** (`http://127.0.0.1:8006/health`). Old servers on port 8005 are separate processes.
2. Run `powershell -ExecutionPolicy Bypass -File .\CHECK_FRAMEPILOT.ps1` from the app folder, in a separate PowerShell window.
3. Repeat the action. The error notification shows the HTTP status and a **request ID**. Match it to `private_uploads/logs/framepilot.log` or your PowerShell window.
4. A **422** indicates invalid input (for example a 250+ scene PDF export volume). A **503** may mean the AI client is missing or the API key cannot be used. A **502** indicates an upstream Meta AI call failed. An unexpected **500** includes a request ID and should be investigated from its traceback. Do **not** paste API keys or project scripts when requesting help.
5. Original project data is in `private_uploads`; generated images are in `static/generated`. Back both up before upgrades.

**No live Meta API call was made in automated tests.** Browser automation was blocked from accessing the local server in the release environment, so check 3D, camera controls and drawing on your Windows PC. Automated tests validate API flows and UI file structure, not full WebGL interaction.

## Production caveat

The local SQLite project store still serializes complete project documents and the 3D viewer relies on a public CDN for Three.js. Neither is a scalable multi-tenant backend. Public production needs tenant authentication, Postgres or per-scene storage, object storage, distributed jobs, quotas, and load-tested deployment. Do not expose this server to the Internet without those controls.
