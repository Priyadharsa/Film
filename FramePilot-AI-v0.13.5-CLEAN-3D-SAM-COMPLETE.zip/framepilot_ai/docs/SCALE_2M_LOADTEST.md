# 2,000,000 concurrent requests — architecture and evidence

**Status: NOT validated.** The v0.9.1 release is a local-first prototype. An honest 2M-concurrency claim requires a cloud deployment, actual measured p95/p99 latency, production-sized DBs, and distributed load generators.

## Clarify the target
- 2 million concurrent **connected users** is not 2 million simultaneous image generations.
- At 2 million in-flight requests, required throughput is `2_000_000 / average_response_seconds`. For a 0.2-second average, that is **10 million requests/second**; at 2 seconds it is 1 million req/s.
- 2 million queued image jobs must be handled separately with per-user quotas and provider-side concurrency limits. It is not viable to call Muse 2 million times concurrently.

## Production design
1. CDN + edge DDoS/rate limiting for static assets and authenticated clients; multi-region traffic routing.
2. Stateless API containers + autoscaling, strict admission control (429 Retry-After under overload), request idempotency and cancellation.
3. Object storage for 1GiB resumable uploads and generated frames; direct-to-bucket multipart transfers.
4. Sharded PostgreSQL or similar horizontally scalable metadata layer (tenant IDs in every query); avoid a giant serialized project row and use separate page/scene/shot tables.
5. Durable queue (SQS/Kafka equivalents), worker leases, dead-letter queues, dedupe IDs, retries with exponential backoff and exactly-once *effects* via idempotency, not a claim of exactly-once deliveries.
6. Muse/SAM calls behind an independently throttled and metered inference gateway; budgets, quotas, per-user concurrency, cost estimates before jobs start, and outcome reconciliation.
7. Metrics: p50/p95/p99 latency, error rate, DB contention, queue depth/age, time-to-first-frame, cancelled-job count, cost per rendered frame, dependency outage drills.
8. Test with traffic replay, gradually staged distributed load, soak runs, tenant security and failover drills. Keep upstream Muse calls mocked in load tests unless provider explicitly authorizes capacity testing.

## Included local test
Run `python -m pytest -q` and `node --test tests/*.test.mjs` for correctness.
For a bounded **read-only** HTTP smoke test, install Locust and run:

```shell
pip install locust
locust -f loadtest/locustfile.py --headless -u 100 -r 10 -t 60s --host http://127.0.0.1:8011
```

This measures one local instance at a small scale; it does not verify 2 million concurrent requests.

## Current implementation limits
- The API server and background-generation pool are local, SQLite-based components, not distributed.
- Each image generation may be billable and slow; renders are queued with explicit user confirmation and a maximum of 2 workers by default.
- Jobs have persisted per-shot progress. An interrupted uncertain model call is not automatically retried to prevent duplicate charges.
- A 1GiB transport ceiling is independent of screenplay processing ceilings (`MAX_SCRIPT_CHARS` and scene limits).
