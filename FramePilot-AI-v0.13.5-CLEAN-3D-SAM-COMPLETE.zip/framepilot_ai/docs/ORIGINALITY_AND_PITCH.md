# FramePilot AI — product positioning and originality

## Pitch

**From one screenplay to one coherent, director-editable visual production.** Instead of generating isolated pretty images, FramePilot keeps the selected *project → scene → shot* attached to the screenplay, camera plan, 3D set, blocking, storyboard drawings, references, SAM masks, Muse revisions and production documents.

## Good industry conventions to build upon

FramePilot deliberately uses familiar *interaction patterns*, not copied source code or proprietary assets:

- **Production-planning tools:** script breakdowns, shooting schedules, call sheets, shot lists, sides and crew records refer to the same film project.
- **Non-linear editors:** large preview monitor, shot strip, separate inspector and production-safe export actions.
- **3D previsualization tools:** 3D camera, actor/prop positioning, lighting, object transforms and GLB interchange.
- **Illustration software:** editable drawing, composition overlays, selection brushes and version history.
- **Generative image products:** text/reference-guided image creation and iterative editing; the important FramePilot difference is the *script-linked editing context*.

All demo script and artwork shipped in this repository are original. User-supplied films, commercial textbooks, brand assets and API secrets are not bundled.

## Credible differentiation

1. A screenplay import produces editable scenes and shot drafts before any paid AI call.
2. A director can build and inspect the shot in the 3D stage, draw a guide or assign references.
3. SAM object selection makes individual actors/props targetable for removal, local effects or movable 2.5D staging.
4. Muse Image refinement saves version history for the *same* shot; a connected Director AI suggests bounded, reviewable camera and blocking changes.
5. The project exports a production package with screenplay-linked storyboards, shot plans and planning PDFs.

## Verified versus future work

The source has automated tests and local HTTP checks. **Do not claim** that this source includes full native Blender/Unreal Engine, deployed cloud synchronization, proven 2 million concurrent users, exact face-preservation guarantees or instantaneous 939-image generation. These remain engineering or provider-dependent targets, not demonstrated facts.

## A judge-friendly closing statement

"FramePilot is a director's control room. An imported scene is not merely turned into an image: it becomes an editable film plan, with 3D blocking, artist sketches, object-level SAM edits, iterative Muse imagery, and production documents following the same shot from idea to execution."
