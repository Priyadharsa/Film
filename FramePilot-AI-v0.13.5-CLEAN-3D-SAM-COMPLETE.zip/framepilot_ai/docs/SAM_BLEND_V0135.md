# FramePilot AI 0.13.5 — SAM layer actions and Blender conversion

## Import Blender assets into Cinema 3D

* `.glb` imports directly. Choose **3D scene → Upload your environment → 3D asset import** and select **Object / prop**, **Actor / character**, or **Complete 3D set**. The existing **Stage & Scene → Import Blender .blend / .GLB** shortcut imports props.
* `.blend` is a native Blender project, **not** a web model. Conversion requires a local Blender application, and is opt-in because opening untrusted Blender project files executes a complex native parser.
* Install Blender on the computer running FramePilot. Add `FRAMEPILOT_ENABLE_LOCAL_BLEND=1` in your **local** `.env`. Optionally set `FRAMEPILOT_BLENDER_BIN=C:\\Program Files\\Blender Foundation\\Blender 4.5\\blender.exe` to the actual Blender executable on Windows. Restart the application. The editor checks `/api/models/capabilities` and shows a clear status.
* Conversion happens locally, using `--background --factory-startup --disable-autoexec`, a 120-second timeout, a maximum 80 MiB source and a maximum 30 MiB converted GLB. This is **not a security sandbox**; keep it disabled on publicly reachable servers. Do not open untrusted Blender projects. Production conversion needs a separate isolated service.
* Materials, nodes, meshes and transforms that glTF can represent may be preserved. Blender-specific modifiers, procedural simulations and unsupported rigs are not necessarily preserved. Missing linked textures may need repacking in Blender first.

## Local SAM edits (no Meta image calls)

1. Open a shot with an image, choose **Art & Muse**, enter a target (e.g. a coat, face, car, wall), and click **Detect with SAM 3.1**. The *selection* step uses Meta and may incur cost. Local operations below do not call the model.
2. Select the correct instance; correct its mask with the **Add / Erase** brush.
3. Under **LOCAL LAYER TOOLS**, choose an action:
   * **Remove selected actor / prop:** approximate local Remove & Heal (OpenCV) or make the object region transparent.
   * **Remove background:** produce a PNG with transparency outside the selected subject.
   * **Alter selected character or object:** recolor, outline, blur or replace masked pixels with an uploaded image.
   * **Alter background:** blur, apply a color mood, or replace outside the selected actor mask with an uploaded image.
4. For either replacement action, upload a PNG, JPEG or WebP file (up to 5 MiB), then **Apply change**. The replacement is a **2D composite** resized to the subject box or frame, not a generative 3D reconstruction.
5. Each successful operation saves a **new shot history revision**. The original remains intact. You can use Muse Image afterward for convincing generative removal, lighting, perspective, and reconstruction; even Muse cannot guarantee perfect continuity.

### Limits / safety

* The SAM image needs a valid pixel mask and a current shot, so modifying a stale frame is rejected with HTTP 409.
* Replacement references are uploaded into private storage and checked for the current account's ownership.
* Edits work on images up to 16 megapixels; use smaller reference files for performance.
* A `.blend` file is **not** a rigged native Blender scene inside the browser. The browser loads a GLB-converted version as an editable imported object, whose transform can be changed in FramePilot. Real native rig editing still requires Blender.

## Other corrections bundled

The Import Film dialog has a dedicated stacking layer above the sticky tool selector. It is readable, scrollable on short screens, keyboard-focusable and uses the minimalist white/teal design.
