# FramePilot Art Studio v0.8.5 — Director-controlled SAM + Muse

## A practical single-frame workflow

1. Open the film, select a **scene** and **shot** and choose **Art Studio**.
2. If the shot is empty, click **Generate frame with Muse** (after setting `.env`) or save an original drawing / capture a frame from Cinema 3D. Create the frame **before** segmenting objects.
3. Enter **one short concrete object name** such as `cassette`, `woman`, `wooden chair`, then click **Detect with SAM 3.1**. This is one metered Meta API inference call.
4. Choose the exact matched instance from the dropdown. The cyan overlay represents SAM's decoded binary mask, not a guessed rectangle.
5. Optionally select **Add to mask** or **Erase mask** and brush within the selected item's original SAM bounding box to correct the mask. No additional inference calls are made.
6. Apply local, reversible layer effects: isolate (transparent PNG), defocus background, color accent, silhouette, outline or blur target. These are real pixel operations, not synthetic AI inpainting. The original file is never overwritten.
7. For generative **remove / replace / redesign / change costume / change pose / relight / restyle**, choose an edit intent and provide explicit art direction. Click **Edit with Muse Image**. FramePilot sends the clean original, the cyan object-selection guide, the director instruction, plus up to eight role-tagged references.
8. Compare before/after using the slider, open **Frame History** to restore an earlier image, then export your production or comic PDF using the existing export buttons.

The **Expand Art Studio** button fills the filmmaking workspace; clicking again restores the book spread. This does not replace or alter the 3D construction section.

## Integration and accuracy

- **SAM 3.1 (`sam-3.1`)** is a perception model, not a generator. It receives one noun-phrase concept and the existing image via Meta Responses API, then returns boxes and pixel-accurate masks. Official `meta_sam_parser` decodes the SAM grammar; empty results are valid.
- **Muse Image (`muse-image-1.0`)** generates and edits images through Meta's Responses API. FramePilot sends real `input_image` parts and image-editing instructions; SAM guides targeting but **does not guarantee hard-mask-limited edits**. You must review results for identity continuity, geometry and unrequested changes.
- **Muse Spark** remains the screenplay director's breakdown tool. The application does not automatically spend model credits on every page, brush stroke or shot change.
- Existing style library contains 68 presets plus a custom prompt. Up to eight role-labeled character, prop, costume, location, pose, palette, style and composition references per shot.
- **Local layer effects** use Pillow and the actual SAM mask. The selection binary bytes and source-pixel bounding box are validated again on the server before use. Edits to a stale frame are rejected with 409.
- Frame and layer versions are recorded in existing shot history. Files are stored in `static/generated`. Uploaded private references are saved separately in `private_uploads`. Do not commit these folders or `.env`.

## Testing boundaries

Automated test cases use simulated SAM and Muse responses: no Meta credit is charged during tests. The production request shapes follow the documented Meta APIs, but **live Muse authentication/credits and live SAM segmentation have not been validated here**. This is a local-first editing prototype, not a demonstrated multi-user SaaS; see `PRODUCTION_SCALE.md` for deployment requirements.

## Windows setup

Stop an older FramePilot service, back up your `private_uploads/`, `static/generated/` and `.env`, then apply the v0.8.5 in-place hotfix to your *existing* `framepilot_ai` folder. Run `START_FRAMEPILOT.bat`, and open `http://127.0.0.1:8009/book`. Force-refresh (`Ctrl+Shift+R`) to load updated assets. If using the full source ZIP instead, the launcher creates `.venv` on Windows on first run; restore your own local `.env` privately and rotate any previously exposed API key.

## Useful official documentation

- https://dev.meta.ai/docs/image-generation
- https://dev.meta.ai/docs/sam/overview
- https://dev.meta.ai/docs/cookbook/sam-api-basics
