/** FramePilot Virtual Director — real 3D blocking, camera optics and scene coverage. */
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { focalToVerticalFov, horizontalFov, aimDirection, cameraSide, crossed180Line, shotSizeHint, clamp } from './geometry.js';

const $ = id => document.getElementById(id);
const safeNumber = (value, fallback) => Number.isFinite(+value) && value !== '' ? +value : fallback;
const uid = () => (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()) + String(Math.random());
const clone = v => JSON.parse(JSON.stringify(v));
const actorPalette = ['#b6c5ab','#d4b087','#a8b8ca','#c7a0aa','#c8be8b'];
const key = 'framepilot-v04-shotlab';
const defaultCam = () => ({ x: 0, y: 1.65, z: 5.7, pan: 0, tilt: -3, focal: 35 });
const obj = (name,kind,x,z,rotation=0, color='#b6c5ab') => ({ id:uid(), name,kind,x,z,rotation,color });
function presetEntities(type) {
  if(type==='interrogation') return [obj('Inspector','actor',-1.4,0,0,actorPalette[0]),obj('Witness','actor',1.25,0,180,actorPalette[1]),obj('Interrogation desk','table',0,.5,0),obj('Evidence box','evidence',.1,.45,0)];
  if(type==='stage') return [obj('Actor A','actor',-1.4,0,0,actorPalette[0]),obj('Actor B','actor',1.35,-.3,0,actorPalette[1])];
  return [obj('Mira','actor',-1.45,.45,0,actorPalette[0]),obj('Arun','actor',1.4,-.15,-25,actorPalette[1]),obj('Tea shop table','table',0,.25,0),obj('Cassette','evidence',.2,-.05,0),obj('Empty chair','chair',-2,-1.6,20),obj('Hanging lamp','lamp',0,-1.8,0)];
}
function createDefault(){return {version:'0.4.0',name:'INT. CLOSED TEA SHOP — NIGHT',beat:'Mira waits. Arun arrives with evidence. Nobody trusts the other.',preset:'tea',light:'noir',camera:defaultCam(),entities:presetEntities('tea'),shots:[],sourceBreakdown:null,characterReferenceId:null};}
function loadSaved(){try{const s=JSON.parse(localStorage.getItem(key));if(s && s.version==='0.4.0' && Array.isArray(s.entities) && s.camera && Array.isArray(s.shots))return s;}catch{}return createDefault();}
let state=loadSaved();
try {
  const transfer=JSON.parse(localStorage.getItem('framepilot-shotlab-transfer')||'null');
  if(transfer && transfer.sceneTitle){
    state.name=String(transfer.sceneTitle).slice(0,120);
    state.beat=String(transfer.shot?.visual_description||transfer.shot?.beat||state.beat).slice(0,500);
    state.sourceBreakdown={characters:transfer.characters||[],props:transfer.props||[],scene_summary:transfer.scene_summary||'',location_time:transfer.location_time||'',original_shot:transfer.shot||null};
    state.characterReferenceId=transfer.characterReferenceId||null;
    const chars=(transfer.characters||[]).slice(0,5);
    if(chars.length){state.entities=state.entities.filter(e=>e.kind!=='actor');chars.forEach((c,i)=>state.entities.unshift(obj(c.name||`Actor ${i+1}`,'actor',-2+i*1.3,i%2*.4,0,actorPalette[i%actorPalette.length])));}
    localStorage.removeItem('framepilot-shotlab-transfer');
  }
} catch(e){console.warn('Invalid director handoff',e);}
function save(){try{localStorage.setItem(key,JSON.stringify(state));}catch(e){console.warn('Local storage full; use Export Shot Bible',e);}}
const toastEl=$('toast');let toastTimer;
function toast(message){toastEl.textContent=message;toastEl.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastEl.classList.remove('visible'),4500);}

// Physical scene, 1 Three.js unit == 1 metre.
const scene=new THREE.Scene();scene.background=new THREE.Color('#111a16');scene.fog=new THREE.Fog('#111a16',18,45);
const wrap=$('canvas-wrap');const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;wrap.prepend(renderer.domElement);$('canvas-status').remove();
const orbitCamera=new THREE.PerspectiveCamera(48,16/9,.05,120);orbitCamera.position.set(10,10,12);orbitCamera.lookAt(0,0,0);
const filmCamera=new THREE.PerspectiveCamera(35,16/9,.05,100);
const planCam=new THREE.OrthographicCamera(-8,8,5,-5,.01,100);planCam.position.set(0,20,0);planCam.up.set(0,0,-1);planCam.lookAt(0,0,0);
const frontCam=new THREE.OrthographicCamera(-8,8,5,-5,.01,100);frontCam.position.set(0,3,20);frontCam.lookAt(0,1,0);
const sideCam=new THREE.OrthographicCamera(-8,8,5,-5,.01,100);sideCam.position.set(20,3,0);sideCam.lookAt(0,1,0);
const orbit=new OrbitControls(orbitCamera,renderer.domElement);orbit.target.set(0,0.9,0);orbit.minDistance=4;orbit.maxDistance=30;orbit.maxPolarAngle=Math.PI/2.02;orbit.enableDamping=true;
const ambient=new THREE.AmbientLight('#e3f3e3',1.5);scene.add(ambient);
const keylight=new THREE.SpotLight('#f9bb68',50,20,Math.PI/4,.6,1);keylight.position.set(0,6,1.5);keylight.castShadow=true;keylight.shadow.mapSize.set(1024,1024);scene.add(keylight,keylight.target);
const fill=new THREE.DirectionalLight('#96bacc',1.1);fill.position.set(-4,6,-5);scene.add(fill);
const floor=new THREE.Mesh(new THREE.PlaneGeometry(12,9),new THREE.MeshStandardMaterial({color:'#222e27',roughness:.97}));floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;scene.add(floor);
const floorgrid=new THREE.GridHelper(12,12,0x62725d,0x3d4b40);floorgrid.position.y=.006;scene.add(floorgrid);
const setGroup=new THREE.Group();scene.add(setGroup);
const entityGroup=new THREE.Group();scene.add(entityGroup);
const lineMaterial=new THREE.LineBasicMaterial({color:'#e4bc67'});const axisLine=new THREE.Line(new THREE.BufferGeometry(),lineMaterial);scene.add(axisLine);
const filmRig=new THREE.Group();const rigBox=new THREE.Mesh(new THREE.BoxGeometry(.35,.21,.28),new THREE.MeshStandardMaterial({color:'#d4c299',metalness:.5,roughness:.4}));filmRig.add(rigBox);
const lensMesh=new THREE.Mesh(new THREE.CylinderGeometry(.09,.09,.27,16),new THREE.MeshStandardMaterial({color:'#101716',metalness:.5}));lensMesh.rotation.x=Math.PI/2;lensMesh.position.z=-.28;filmRig.add(lensMesh);
const tripod=new THREE.Mesh(new THREE.CylinderGeometry(.025,.055,.7,8),new THREE.MeshStandardMaterial({color:'#a89f84'}));tripod.position.y=-.44;filmRig.add(tripod);scene.add(filmRig);
scene.add(filmCamera);const frustum=new THREE.CameraHelper(filmCamera);frustum.material.transparent=true;frustum.material.opacity=.26;scene.add(frustum);
let mode='orbit',selectedId=null,dragging=null,editShotId=null;
const meshes=new Map();const raycaster=new THREE.Raycaster();const mouse=new THREE.Vector2();const groundPlane=new THREE.Plane(new THREE.Vector3(0,1,0),0);
const materials=new Map();
function material(color,roughness=.85){const k=color+':'+roughness;if(!materials.has(k))materials.set(k,new THREE.MeshStandardMaterial({color,roughness}));return materials.get(k);}
function box(w,h,d,x,y,z,color,parent){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material(color));mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;}
function labelSprite(text){const c=document.createElement('canvas');c.width=320;c.height=68;const ctx=c.getContext('2d');ctx.fillStyle='#122017e9';ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle='#f5d9ac';ctx.font='bold 30px Arial';ctx.textAlign='center';ctx.fillText(String(text).slice(0,19),160,44);const texture=new THREE.CanvasTexture(c);texture.colorSpace=THREE.SRGBColorSpace;const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,transparent:true,depthTest:false}));sprite.scale.set(1.28,.27,1);return sprite;}
function addWorld(){
 setGroup.clear();
 const grey='#42473e';
 box(12,3.6,.16,0,1.8,-4.55,grey,setGroup);box(.16,3.6,9.1,-6,1.8,0,grey,setGroup);
 for(let i=-5;i<=5;i+=2.5)box(.07,3.6,.12,i,1.8,-4.43,'#5b685a',setGroup);
 if(state.preset==='tea'){
   box(3,.18,.12,2,2,-4.37,'#7a6850',setGroup);box(1.2,.72,.05,2,2,-4.26,'#17221c',setGroup);
   box(1.7,1.3,.10,-3.2,1.75,-4.35,'#8a6640',setGroup);
 } else if(state.preset==='interrogation') {
   box(1.4,.45,.08,-2.5,2.2,-4.37,'#77837a',setGroup);
 } 
}
function makeEntity(e){
 const g=new THREE.Group();g.position.set(e.x,0,e.z);g.rotation.y=THREE.MathUtils.degToRad(e.rotation||0);g.userData.entityId=e.id;
 const tone=e.color||'#b9c3ac';
 if(e.kind==='actor'){
   const torso=new THREE.Mesh(new THREE.CylinderGeometry(.20,.27,.80,12),material(tone));torso.position.y=1.09;torso.castShadow=true;g.add(torso);
   const head=new THREE.Mesh(new THREE.SphereGeometry(.18,16,12),material('#c39f83'));head.position.y=1.68;head.castShadow=true;g.add(head);
   for(const sign of [-1,1]){
     const leg=new THREE.Mesh(new THREE.CylinderGeometry(.075,.08,.72,10),material('#43463e'));leg.position.set(sign*.13,.37,0);leg.castShadow=true;g.add(leg);
     const arm=new THREE.Mesh(new THREE.CylinderGeometry(.06,.07,.68,10),material(tone));arm.position.set(sign*.30,1.04,0);arm.rotation.z=sign*.12;arm.castShadow=true;g.add(arm);
   }
   const nose=box(.08,.10,.12,0,1.65,-.18,'#c39f83',g);nose.castShadow=false;
 } else if(e.kind==='table'){
   box(1.65,.12,.95,0,.78,0,'#70583c',g);
   for(const x of [-.68,.68])for(const z of [-.35,.35])box(.10,.74,.10,x,.37,z,'#544333',g);
 } else if(e.kind==='chair'){
   box(.55,.1,.50,0,.48,0,'#775a3d',g);box(.55,.7,.09,0,.87,.22,'#81684b',g);
   for(const x of [-.22,.22])for(const z of [-.18,.18])box(.06,.43,.06,x,.22,z,'#5b4839',g);
 } else if(e.kind==='lamp'){
   box(.08,2.0,.08,0,1.0,0,'#666a55',g);const shade=new THREE.Mesh(new THREE.ConeGeometry(.45,.44,18,1,true),material('#bb9b5d'));shade.position.y=2.13;shade.rotation.z=Math.PI;g.add(shade);
 } else if(e.kind==='evidence'){
   box(.37,.12,.24,0,.08,0,'#ba8960',g);
 } else {
   box(.6,.65,.6,0,.33,0,tone,g);
 }
 const sp=labelSprite(e.name);sp.position.set(0,e.kind==='actor'?2.2:e.kind==='lamp'?2.8:1.32,0);g.add(sp);
 entityGroup.add(g);meshes.set(e.id,g);
}
function rebuild(){entityGroup.clear();meshes.clear();addWorld();state.entities.forEach(makeEntity);refreshAxis();renderObjectList();syncSelected();updateMetrics();save();}
function selectedEntity(){return state.entities.find(e=>e.id===selectedId)||null;}
function choose(id){selectedId=id;syncSelected();renderObjectList();}
function renderObjectList(){
 const host=$('object-list');host.replaceChildren();
 state.entities.forEach(e=>{
  const btn=document.createElement('button');btn.className='object-row'+(e.id===selectedId?' active':'');
  const dot=document.createElement('span');dot.className='object-dot';dot.style.background=e.kind==='actor'?e.color:'#b8a06e';
  const label=document.createElement('span');label.className='object-info';const strong=document.createElement('strong');strong.textContent=e.name;const small=document.createElement('small');small.textContent=e.kind.toUpperCase();label.append(strong,small);
  const coords=document.createElement('span');coords.className='object-coord';coords.textContent=`${e.x.toFixed(1)}, ${e.z.toFixed(1)}`;
  btn.append(dot,label,coords);btn.addEventListener('click',()=>choose(e.id));host.append(btn);
 });$('object-count').textContent=String(state.entities.length).padStart(2,'0');
}
function syncSelected(){const e=selectedEntity();$('selected-empty').hidden=Boolean(e);$('selected-controls').hidden=!e;
 for(const [id,field] of [['obj-name','name'],['obj-x','x'],['obj-z','z'],['obj-rot','rotation']])if(e)$(id).value=e[field];
 $('obj-rot-out').textContent=e?`${e.rotation}°`:'0°';
 for(const [id,g] of meshes){
  for(const child of [...g.children]) if(child.userData.selectionRing){g.remove(child);child.geometry.dispose();child.material.dispose();}
  if(id===selectedId){
    const ring=new THREE.Mesh(new THREE.RingGeometry(.37,.49,40),new THREE.MeshBasicMaterial({color:'#f0c078',side:THREE.DoubleSide,transparent:true,opacity:.92}));
    ring.rotation.x=-Math.PI/2;ring.position.y=.024;ring.userData.selectionRing=true;g.add(ring);
  }
 }
}
function updateEntity(){const e=selectedEntity();if(!e)return;
 e.name=$('obj-name').value.trim().slice(0,50)||e.name;
 e.x=clamp(safeNumber($('obj-x').value,e.x),-5.5,5.5);e.z=clamp(safeNumber($('obj-z').value,e.z),-4,4);e.rotation=clamp(safeNumber($('obj-rot').value,e.rotation),-180,180);
 $('obj-rot-out').textContent=`${e.rotation}°`;rebuild();}
function setLighting(){const v=state.light;
 if(v==='daylight'){ambient.color.set('#dbe8f5');ambient.intensity=2.0;keylight.color.set('#fff0ce');keylight.intensity=32;fill.intensity=3;renderer.toneMappingExposure=1.5;scene.background.set('#26342e');scene.fog.color.set('#26342e');}
 else if(v==='moonlight'){ambient.color.set('#9ebbd0');ambient.intensity=1.2;keylight.color.set('#6ca2e0');keylight.intensity=27;fill.color.set('#f0ba6e');fill.intensity=.8;renderer.toneMappingExposure=1.0;scene.background.set('#121c25');scene.fog.color.set('#121c25');}
 else{ambient.color.set('#e6dfc3');ambient.intensity=1.15;keylight.color.set('#ffc071');keylight.intensity=48;fill.color.set('#88a4b4');fill.intensity=.65;renderer.toneMappingExposure=1.15;scene.background.set('#111a16');scene.fog.color.set('#111a16');}}
function refreshAxis(){
 const a=state.entities.filter(e=>e.kind==='actor');
 if(a.length<2){axisLine.visible=false;return;}
 axisLine.visible=mode!=='camera';axisLine.geometry.dispose();axisLine.geometry=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(a[0].x,.04,a[0].z),new THREE.Vector3(a[1].x,.04,a[1].z)]);
}
function currentSide(){const a=state.entities.filter(e=>e.kind==='actor');return a.length>=2?cameraSide(a[0],a[1],state.camera):0;}
function lastSide(){return state.shots.length?state.shots.at(-1).axisSide:0;}
function checkCrossing(){return crossed180Line(lastSide(),currentSide());}
function updateMetrics(){
 const c=state.camera;const aspect=Math.max(.8,renderer.domElement.clientWidth/Math.max(1,renderer.domElement.clientHeight));
 filmCamera.position.set(c.x,c.y,c.z);filmCamera.fov=focalToVerticalFov(c.focal,aspect);filmCamera.aspect=aspect;filmCamera.updateProjectionMatrix();
 const dir=aimDirection(c.pan,c.tilt);filmCamera.lookAt(c.x+dir.x*10,c.y+dir.y*10,c.z+dir.z*10);
 filmRig.position.set(c.x,c.y,c.z);filmRig.quaternion.copy(filmCamera.quaternion);frustum.update();
 $('shot-summary').textContent=`${c.focal} mm · ${c.y.toFixed(2)} m · ${c.pan}°`;
 $('focal-out').textContent=c.focal;$('pan-out').textContent=`${c.pan}°`;$('tilt-out').textContent=`${c.tilt}°`;
 $('h-fov').textContent=`${horizontalFov(c.focal).toFixed(1)}°`;$('v-fov').textContent=`${focalToVerticalFov(c.focal,16/9).toFixed(1)}°`;
 const a=state.entities.filter(e=>e.kind==='actor');let d='—';if(a.length){const p=a[0];d=`${Math.hypot(c.x-p.x,c.y-1.45,c.z-p.z).toFixed(2)} m`;}$('focus-distance').textContent=d;
 const crossed=checkCrossing();const valid=a.length>1;
 $('axis-status').textContent=!valid?'NEED TWO ACTORS':crossed?'AXIS CROSSED':'SAME SIDE / CLEAR';$('axis-status').className=crossed?'bad':'good';
 $('continuity-title').textContent=crossed?'180° line crossed':'Axis continuity in check';
 $('continuity-text').textContent=crossed?'Current camera position is on the opposite side of the line between the first two actors relative to your last saved shot. This may reverse screen direction. You can break the rule deliberately.':state.shots.length?'Current camera remains on the same side as the previous saved setup (or sits on the axis). Character movement can affect this diagnostic.':'Save a shot, then move your camera across the actor-to-actor axis to see a continuity warning.';
 $('continuity-icon').textContent=crossed?'⚠':'◎';$('continuity-icon').style.color=crossed?'var(--red)':'var(--green)';
 $('lens-hint').textContent=shotSizeHint(c.focal);
 $('cam-x').value=c.x;$('cam-y').value=c.y;$('cam-z').value=c.z;$('focal').value=c.focal;$('pan').value=c.pan;$('tilt').value=c.tilt;
}
function resize(){const w=wrap.clientWidth,h=wrap.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);orbitCamera.aspect=w/h;orbitCamera.updateProjectionMatrix();for(const o of [planCam,frontCam,sideCam]){const height=mode==='top'?10:8;const width=height*w/h;o.left=-width/2;o.right=width/2;o.top=height/2;o.bottom=-height/2;o.updateProjectionMatrix();}updateMetrics();}
const resizeObserver=new ResizeObserver(resize);resizeObserver.observe(wrap);
function cameraForView(){return ({orbit:orbitCamera,top:planCam,front:frontCam,side:sideCam,camera:filmCamera})[mode];}
function render(){requestAnimationFrame(render);orbit.enabled=mode==='orbit' && !dragging;if(orbit.enabled)orbit.update();filmRig.visible=mode!=='camera';frustum.visible=mode!=='camera' && mode!=='orbit';axisLine.visible=mode!=='camera' && state.entities.filter(e=>e.kind==='actor').length>=2;renderer.render(scene,cameraForView());}
function switchView(next){mode=next;document.querySelectorAll('[data-view]').forEach(btn=>btn.classList.toggle('active',btn.dataset.view===next));$('crosshair').classList.toggle('hidden',next!=='camera');$('safe-frame').classList.toggle('hidden',next!=='camera');$('projection-label').textContent=({orbit:'PERSPECTIVE · ORBIT',top:'ORTHOGRAPHIC · TOP PLAN',front:'ORTHOGRAPHIC · FRONT ELEVATION',side:'ORTHOGRAPHIC · SIDE ELEVATION',camera:'CINEMATIC CAMERA · LIVE'})[next];$('scene-pov-legend').textContent=next==='camera'?'SHOT COMPOSITION · 16:9 REFERENCE':'CLICK TO SELECT · DRAG TO BLOCK';resize();}
function screenPoint(evt){const r=renderer.domElement.getBoundingClientRect();mouse.x=2*(evt.clientX-r.left)/r.width-1;mouse.y=1-2*(evt.clientY-r.top)/r.height;}
function raycastGround(evt){screenPoint(evt);raycaster.setFromCamera(mouse,cameraForView());const p=new THREE.Vector3();return raycaster.ray.intersectPlane(groundPlane,p)?p:null;}
renderer.domElement.addEventListener('pointerdown',evt=>{
 if(evt.button!==0)return;
 screenPoint(evt);raycaster.setFromCamera(mouse,cameraForView());const hits=raycaster.intersectObjects([...meshes.values()],true);
 if(!hits.length){choose(null);return;}
 let node=hits[0].object;while(node && !node.userData.entityId)node=node.parent;
 if(!node?.userData.entityId)return;choose(node.userData.entityId);
 const p=raycastGround(evt);if(!p)return;const e=selectedEntity();dragging={id:e.id,startX:e.x,startZ:e.z,offsetX:e.x-p.x,offsetZ:e.z-p.z};renderer.domElement.setPointerCapture(evt.pointerId);evt.preventDefault();
});
renderer.domElement.addEventListener('pointermove',evt=>{
 if(!dragging)return;const p=raycastGround(evt);if(!p)return;const e=selectedEntity();if(!e || e.id!==dragging.id)return;
 e.x=clamp(Math.round((p.x+dragging.offsetX)*4)/4,-5.5,5.5);e.z=clamp(Math.round((p.z+dragging.offsetZ)*4)/4,-4,4);
 const g=meshes.get(e.id);if(g)g.position.set(e.x,0,e.z);
 $('obj-x').value=e.x;$('obj-z').value=e.z;refreshAxis();updateMetrics();renderObjectList();
});
renderer.domElement.addEventListener('pointerup',()=>{if(dragging){dragging=null;save();}});
renderer.domElement.addEventListener('pointercancel',()=>{dragging=null;});

function snapshotImage(){
 filmRig.visible=false;frustum.visible=false;axisLine.visible=false;
 renderer.render(scene,filmCamera);
 const canvas=document.createElement('canvas');canvas.width=480;canvas.height=270;const ctx=canvas.getContext('2d');
 const src=renderer.domElement;const scale=Math.min(src.width/480,src.height/270);const sw=480*scale,sh=270*scale;
 ctx.drawImage(src,(src.width-sw)/2,(src.height-sh)/2,sw,sh,0,0,480,270);
 filmRig.visible=true;refreshAxis();return canvas.toDataURL('image/jpeg',.72);
}
function captureShot(){
 if(state.shots.length>=20){toast('20 saved shots maximum. Export a Shot Bible to archive your work.');return null;}
 const shot={id:uid(),number:state.shots.length+1,createdAt:new Date().toISOString(),camera:clone(state.camera),entities:clone(state.entities),axisSide:currentSide(),beat:state.beat,sceneName:state.name,light:state.light,preset:state.preset,thumbnail:snapshotImage(),imageUrl:null,versions:[]};
 state.shots.push(shot);save();renderShots();updateMetrics();toast(`Camera setup ${shot.number.toString().padStart(2,'0')} saved. All geometry locked for this shot.`);return shot;
}
function shotPrompt(s){
 const c=s.camera;const actors=s.entities.filter(e=>e.kind==='actor'),props=s.entities.filter(e=>e.kind!=='actor');
 const format=e=>`${e.name} at (${e.x.toFixed(2)}m right, ${e.z.toFixed(2)}m depth)`;
 const dir=aimDirection(c.pan,c.tilt);
 return [
  `ONE widescreen live-action cinematic storyboard frame for ${s.sceneName}.`,
  `Exact virtual set layout in metres: ${actors.map(format).join('; ')||'no named actors'}. Props: ${props.map(format).join('; ')||'none'}.`,
  `Director's 3D camera is at x=${c.x.toFixed(2)}m, height=${c.y.toFixed(2)}m, z=${c.z.toFixed(2)}m; pan=${c.pan}° around Y axis, tilt=${c.tilt}° (positive aims up). Camera looks along unit direction (${dir.x.toFixed(3)},${dir.y.toFixed(3)},${dir.z.toFixed(3)}).`,
  `Full frame 36mm wide sensor, ${c.focal}mm lens with ${horizontalFov(c.focal).toFixed(1)}° horizontal field of view. Preserve resulting visual sense of camera angle, near/far relationships, actors' screen left/right order, size and depth.`,
  `Director's beat: ${s.beat}. Light design: ${s.light}. Set: ${s.preset}.`,
  `No engineering grid, boxes, coordinates, camera UI, measurement labels, lettering, borders or watermarks in final image. Render an expressive film still, not the 3D primitive previsualization. Spatial interpretation is approximate, not a pixel-perfect projection.`
 ].join('\n');
}
async function generateImage(shot){
 if(!shot)return;const btn=$('generate-current');btn.disabled=true;btn.textContent=`✦ RENDERING SHOT ${shot.number}…`;
 try{
 const characterList=state.sourceBreakdown?.characters?.length?state.sourceBreakdown.characters:shot.entities.filter(e=>e.kind==='actor').map(e=>({name:e.name,description:`consistent film character ${e.name}`,objective:'Support the dramatic beat',emotional_state:'As directed'}));
 const payload={scene_title:shot.sceneName,visual_style:'cinematic photoreal film storyboard, strong practical lighting, widescreen 16:9, intentional camera composition',style_preset:'photoreal',shot:{shot_number:shot.number,beat:shot.beat,shot_type:shotSizeHint(shot.camera.focal),camera_angle:`Camera at (${shot.camera.x},${shot.camera.y},${shot.camera.z})m; pan ${shot.camera.pan} degrees, tilt ${shot.camera.tilt} degrees, ${shot.camera.focal}mm lens`,camera_movement:'Static virtual camera setup',visual_description:shot.beat,director_purpose:'Preserve actor staging and test narrative coverage',image_prompt:shotPrompt(shot)},characters:characterList,props:state.sourceBreakdown?.props||[],scene_summary:state.sourceBreakdown?.scene_summary||shot.beat,location_time:state.sourceBreakdown?.location_time||shot.sceneName,character_reference_id:state.characterReferenceId,reference_character:characterList[0]?.name||'Main character'};
 const response=await fetch('/api/storyboard',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
 const data=await response.json();if(!response.ok)throw Error(data.detail||`API error ${response.status}`);
 shot.imageUrl=data.image_url;save();renderShots();toast(`Muse Image created shot ${shot.number}. Select EDIT to add, remove or alter an object.`);
 }catch(error){toast(`AI generation failed: ${error.message}`);console.error(error);}finally{btn.disabled=false;btn.textContent='✦ GENERATE AI STORYBOARD';}
}
function makeBtn(text,fn,className=''){const b=document.createElement('button');b.textContent=text;b.type='button';b.className=className;b.addEventListener('click',fn);return b;}
function renderShots(){
 const host=$('shots-list');host.replaceChildren();$('shot-count').textContent=String(state.shots.length).padStart(2,'0');
 if(!state.shots.length){host.innerHTML='<div class="empty-shots"><span>◇</span><strong>Your shot sequence begins here.</strong><p>Position your actors and camera, then save a setup to compare continuity across shots.</p></div>';return;}
 state.shots.forEach((s,index)=>{
 const card=document.createElement('article');card.className='shot-card';
 const visual=document.createElement('div');visual.className='shot-visual';const image=document.createElement('img');image.src=s.imageUrl||s.thumbnail;image.alt=`Shot ${s.number} ${s.imageUrl?'AI storyboard':'3D camera preview'}`;visual.append(image);
 const pill=document.createElement('span');pill.className='overlay-tag';pill.textContent=s.imageUrl?'✦ MUSE IMAGE':'◉ GEOMETRY PREVIS';visual.append(pill);
 const details=document.createElement('div');details.className='shot-details';const title=document.createElement('strong');title.textContent=`SHOT ${String(index+1).padStart(2,'0')} / ${s.camera.focal} MM`;const desc=document.createElement('p');desc.textContent=`X ${s.camera.x}m · H ${s.camera.y}m · Z ${s.camera.z}m · PAN ${s.camera.pan}°`;
 const acts=document.createElement('div');acts.className='shot-actions';
 acts.append(makeBtn('RESTORE RIG',()=>restoreShot(s)),makeBtn(s.imageUrl?'↻ RE-RENDER':'✦ AI RENDER',()=>generateImage(s),'gold-action'));
 if(s.imageUrl){acts.append(makeBtn('EDIT FRAME',()=>openEdit(s),'gold-action'));if(s.versions?.length)acts.append(makeBtn('UNDO EDIT',()=>{s.imageUrl=s.versions.pop();save();renderShots();toast('Restored previous edit version.');}));}
 acts.append(makeBtn('↗ REFERENCE STUDIO',()=>{
   localStorage.setItem('framepilot-reference-studio-transfer',JSON.stringify({scene_title:s.sceneName,sceneName:s.sceneName,shot:{shot_number:s.number,shot_type:shotSizeHint(s.camera.focal),camera_angle:'Eye level',visual_description:s.beat,image_prompt:shotPrompt(s)},location_time:s.sceneName}));
   window.location.href='/studio';
 }));
 acts.append(makeBtn('REMOVE',()=>{if(!confirm('Remove this saved shot? Generated images are not deleted.'))return;state.shots=state.shots.filter(x=>x.id!==s.id);state.shots.forEach((x,i)=>x.number=i+1);save();renderShots();updateMetrics();}));
 details.append(title,desc,acts);card.append(visual,details);host.append(card);
 });
}
function restoreShot(s){state.camera=clone(s.camera);state.entities=clone(s.entities);state.light=s.light;state.preset=s.preset;state.beat=s.beat;state.name=s.sceneName;
 $('scene-name').value=state.name;$('beat').value=state.beat;$('set-preset').value=state.preset;$('light').value=state.light;
 choose(null);setLighting();rebuild();switchView('camera');toast(`Restored camera and blocking from shot ${s.number}.`);
}
function openEdit(s){if(!s.imageUrl)return;editShotId=s.id;$('edit-image').src=s.imageUrl;$('edit-instruction').value='';$('edit-target').value='';$('edit-sam').checked=false;$('edit-status').textContent='';$('edit-dialog').classList.remove('hidden');}
function closeEdit(){editShotId=null;$('edit-dialog').classList.add('hidden');}
async function applyEdit(){const shot=state.shots.find(s=>s.id===editShotId),instruction=$('edit-instruction').value.trim();if(!shot || !shot.imageUrl)return;if(instruction.length<5){$('edit-status').textContent='Enter a more detailed instruction.';return;}
 const btn=$('apply-edit');btn.disabled=true;btn.textContent='EDITING…';$('edit-status').textContent='Requesting image edit; original is preserved.';
 try{const name=shot.imageUrl.split('/').pop().split('?')[0];const res=await fetch('/api/edit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({image_filename:name,instruction,target:$('edit-target').value.trim(),use_sam:$('edit-sam').checked})});const data=await res.json();if(!res.ok)throw Error(data.detail||`Edit error ${res.status}`);
 shot.versions=shot.versions||[];shot.versions.push(shot.imageUrl);shot.imageUrl=data.image_url;save();renderShots();closeEdit();toast(`Edited shot ${shot.number}. Previous version kept; undo is available.`);
 }catch(e){$('edit-status').textContent=e.message;}finally{btn.disabled=false;btn.textContent='✦ APPLY EDIT';}
}
function downloadFile(blob,filename){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
function exportProject(){const exportData={...state,exportedAt:new Date().toISOString(),modelNotes:'AI-generated stills are prompt-guided approximations, not deterministic renders of the 3D set.'};downloadFile(new Blob([JSON.stringify(exportData,null,2)],{type:'application/json'}),`framepilot-${new Date().toISOString().slice(0,10)}-shot-bible.json`);toast('Shot Bible downloaded. Project includes measured set, camera rigs and shot history.');}
function screenshot(){const blob=snapshotImage();const a=document.createElement('a');a.href=blob;a.download='framepilot-camera-previs.jpg';a.click();toast('Camera POV exported as an image.');}
function setPreset(type){if(state.preset===type)return;
 if(!confirm('Load a new set preset? This replaces the current unsaved object placements. Saved shots remain intact.')){$('set-preset').value=state.preset;return;}
 state.preset=type;state.entities=presetEntities(type);state.camera=defaultCam();selectedId=null;rebuild();switchView('orbit');toast('Set preset loaded. Save a shot to retain its layout.');}

// Controls: every change updates projection, continuity and saved project state.
$('scene-name').value=state.name;$('beat').value=state.beat;$('set-preset').value=state.preset;$('light').value=state.light;
$('scene-name').addEventListener('input',e=>{state.name=e.target.value;save();});$('beat').addEventListener('input',e=>{state.beat=e.target.value;save();});$('set-preset').addEventListener('change',e=>setPreset(e.target.value));$('light').addEventListener('change',e=>{state.light=e.target.value;setLighting();save();});
for(const id of ['obj-name','obj-x','obj-z','obj-rot'])$(id).addEventListener(id==='obj-name'?'change':'input',updateEntity);
$('delete-object').addEventListener('click',()=>{if(!selectedId)return;state.entities=state.entities.filter(x=>x.id!==selectedId);selectedId=null;rebuild();});
$('add-actor').addEventListener('click',()=>{if(state.entities.length>=25)return toast('Maximum 25 scene objects.');const i=state.entities.filter(e=>e.kind==='actor').length;const e=obj(`Actor ${i+1}`,'actor',-.5+i*.7,.3,0,actorPalette[i%5]);state.entities.push(e);rebuild();choose(e.id);toast('Actor added; move in plan or edit coordinates.');});
$('add-prop').addEventListener('click',()=>{if(state.entities.length>=25)return toast('Maximum 25 scene objects.');const e=obj(`Prop ${state.entities.length+1}`,'crate',0,0);state.entities.push(e);rebuild();choose(e.id);toast('Prop added; drag into position.');});
const limits={x:[-9,9],y:[.3,6],z:[-9,9],pan:[-180,180],tilt:[-70,70],focal:[18,120]};
for(const [id,field] of [['cam-x','x'],['cam-y','y'],['cam-z','z'],['pan','pan'],['tilt','tilt'],['focal','focal']]){$(id).value=state.camera[field];$(id).addEventListener('input',evt=>{const old=state.camera[field];state.camera[field]=clamp(safeNumber(evt.target.value,old),...limits[field]);updateMetrics();save();});}
$('reset-camera').addEventListener('click',()=>{state.camera=defaultCam();updateMetrics();save();toast('Camera rig reset to 35mm standard setup.');});
document.querySelectorAll('[data-view]').forEach(btn=>btn.addEventListener('click',()=>switchView(btn.dataset.view)));
$('capture-shot').addEventListener('click',captureShot);$('generate-current').addEventListener('click',()=>{const s=captureShot();if(s)generateImage(s);});
$('export-project').addEventListener('click',exportProject);$('screenshot').addEventListener('click',screenshot);
$('import-project-button').addEventListener('click',()=>$('import-project').click());
$('import-project').addEventListener('change',async e=>{
 const file=e.target.files?.[0];if(!file)return;
 try{
  if(file.size>5*1024*1024)throw new Error('Project file too large.');
  const parsed=JSON.parse(await file.text());
  if(parsed.version!=='0.4.0'||!Array.isArray(parsed.entities)||!parsed.camera||!Array.isArray(parsed.shots))throw new Error('Choose a FramePilot v0.4 Shot Bible.');
  if(parsed.entities.length>25||parsed.shots.length>20)throw new Error('This project exceeds scene limits.');
  state={...createDefault(),...parsed};
  state.entities=parsed.entities.map(x=>({...obj('Object','crate',0,0),...x,x:clamp(safeNumber(x.x,0),-5.5,5.5),z:clamp(safeNumber(x.z,0),-4,4),rotation:clamp(safeNumber(x.rotation,0),-180,180)}));
  for(const field of Object.keys(limits))state.camera[field]=clamp(safeNumber(state.camera[field],defaultCam()[field]),...limits[field]);
  state.name=String(state.name||'Untitled scene').slice(0,120);state.beat=String(state.beat||'').slice(0,500);
  $('scene-name').value=state.name;$('beat').value=state.beat;$('set-preset').value=state.preset;$('light').value=state.light;
  selectedId=null;setLighting();rebuild();renderShots();save();toast('Shot Bible imported. Your 3D set and saved shots are ready.');
 }catch(err){toast(`Import failed: ${err.message}`);}finally{e.target.value='';}
});
$('close-edit').addEventListener('click',closeEdit);$('cancel-edit').addEventListener('click',closeEdit);$('apply-edit').addEventListener('click',applyEdit);$('edit-dialog').addEventListener('click',e=>{if(e.target===$('edit-dialog'))closeEdit();});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeEdit();});

addWorld();setLighting();rebuild();renderShots();resize();switchView('orbit');render();
