/** Browser-side 1 GiB resumable multipart upload; stores only a session ID, never file bytes. */
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const storageKey = file => `framepilot-upload-v07:${file.name}:${file.size}:${file.lastModified}`;

async function req(url, options) {
  const response = await fetch(url,options);
  const json = await response.json().catch(() => ({}));
  if (!response.ok) throw Error(json.detail || `HTTP ${response.status}`);
  return json;
}

async function retry(fn, tries=4) {
  let last;
  for (let i=0;i<tries;i++) {
    try { return await fn(); }
    catch(e) { last=e; if (i+1<tries) await sleep(Math.min(700*(2**i),5000)); }
  }
  throw last;
}

export async function uploadLargeFile(file,{title='',ocr=true,onProgress=()=>{},onState=()=>{}}={}) {
  const cap=1024*1024*1024;
  if(file.size<1 || file.size>cap)throw Error('Choose a file no larger than 1 GiB.');
  const key=storageKey(file);
  let id=localStorage.getItem(key);
  let session;
  if(id) {
    try {session=await req(`/api/uploads/${id}`);}
    catch {localStorage.removeItem(key);id=null;}
  }
  if(!session) {
    session=await req('/api/uploads',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({filename:file.name,size:file.size,kind:'screenplay',title,ocr})});
    id=session.id;localStorage.setItem(key,id);
  }
  if(session.size !== file.size || session.filename !== file.name)throw Error('Upload session does not match this file.');
  const count=session.parts_total, size=session.part_size;
  let received=new Set(session.received);
  const remoteEtags={...(session.etags||{})};
  onProgress(received.size/count,received.size*size,file.size);
  if(session.status==='uploading') {
    const missing=Array.from({length:count},(_,i)=>i).filter(i=>!received.has(i));
    let cursor=0;
    let fatal=null;
    async function uploader() {
      while(cursor<missing.length && !fatal) {
        const i=missing[cursor++];
        const blob=file.slice(i*size,Math.min(file.size,(i+1)*size));
        try {
          const response=await retry(async()=>{
            if(session.backend==='s3'){
              const signed=await req(`/api/uploads/${id}/parts/${i}/sign`);
              const r=await fetch(signed.url,{method:'PUT',body:blob});
              if(!r.ok)throw Error(`Object storage returned ${r.status}`);
              const etag=r.headers.get('etag');
              if(!etag)throw Error('S3 CORS must expose the ETag header. Configure your bucket CORS.');
              return {etag};
            }
            const bytes=await blob.arrayBuffer();
            const sha=await crypto.subtle.digest('SHA-256',bytes);
            const hex=Array.from(new Uint8Array(sha)).map(x=>x.toString(16).padStart(2,'0')).join('');
            return req(`/api/uploads/${id}/parts/${i}`,{method:'PUT',headers:{'Content-Type':'application/octet-stream','X-Content-SHA256':hex},body:blob});
          });
          if(response.etag)remoteEtags[i]=response.etag;
          received.add(i);onProgress(received.size/count,Math.min(file.size,received.size*size),file.size);
        } catch(err){fatal=err;throw err;}
      }
    }
    // Three concurrent 8 MiB parts: bounded upload RAM and retry cost.
    await Promise.all(Array.from({length:Math.min(3,missing.length)},()=>uploader()));
    onState('Verifying uploaded parts…');
    const body=session.backend==='s3'?{parts:Array.from({length:count},(_,i)=>({part_index:i,etag:remoteEtags[i]}))}:{};
    session=await req(`/api/uploads/${id}/complete`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  }
  while(true){
    session=await req(`/api/uploads/${id}`);
    if(session.status==='completed') {
      localStorage.removeItem(key);return session;
    }
    if(session.status==='stored') {
      localStorage.removeItem(key);return session;
    }
    if(['failed','canceled'].includes(session.status)) {
      localStorage.removeItem(key);
      throw Error(session.error||`Import ${session.status}.`);
    }
    onState(session.status==='processing'?'Extracting scenes in background…':'Queued for screenplay import…');
    await sleep(1500);
  }
}
