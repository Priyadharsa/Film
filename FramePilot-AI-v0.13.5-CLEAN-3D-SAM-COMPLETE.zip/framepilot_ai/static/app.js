const screenplayEl = document.getElementById('screenplay');
const analyzeButton = document.getElementById('analyze-button');
const statusEl = document.getElementById('status');
const resultsEl = document.getElementById('results');
const charCountEl = document.getElementById('char-count');
const referenceInput = document.getElementById('character-reference');
const referenceCharacterInput = document.getElementById('reference-character');
const referencePreview = document.getElementById('reference-preview');
const referencePreviewImage = document.getElementById('reference-preview-image');
const referenceFilename = document.getElementById('reference-filename');
const referenceStatus = document.getElementById('reference-status');
let currentBreakdown = null;
let characterReferenceId = null;
let referenceUploadPromise = null;
let referencePreviewUrl = null;

const sampleScene = `INT. CLOSED TEA SHOP — NIGHT

Rain ticks against the corrugated shutter. A single tube light flickers above three empty tables.

MIRA (29), still wearing her office ID card, sits alone. She keeps checking the wall clock. A paper cup of tea has gone cold.

The shutter lifts six inches. ARUN (35) ducks under it, carrying a soaked canvas bag. He does not look at her.

                         MIRA
             You said you had proof.

Arun places a small audio cassette on the table. His hand trembles. Mira reaches for it, but he pulls it back.

                         ARUN
             Before you listen, tell me who sent you.

                         MIRA
             You called me.

A beat. Somewhere outside, a motorcycle engine starts, then cuts off.

Arun looks through the narrow gap beneath the shutter. He slides the cassette across the table.

                         ARUN
             Then we're both already late.

Mira closes her fingers around the cassette. The tube light goes dark.`;

function setStatus(message, kind = '') {
  statusEl.textContent = message;
  statusEl.className = `status ${kind}`.trim();
}
function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function safeText(value, fallback = '—') {
  return typeof value === 'string' && value.trim() ? value : fallback;
}

screenplayEl.addEventListener('input', () => {
  charCountEl.textContent = `${screenplayEl.value.length.toLocaleString()} / 14,000`;
});
document.getElementById('load-sample').addEventListener('click', () => {
  screenplayEl.value = sampleScene;
  screenplayEl.dispatchEvent(new Event('input'));
  setStatus('Sample scene loaded. Press Analyze Scene to create the breakdown.');
});
document.getElementById('new-scene').addEventListener('click', () => {
  resultsEl.classList.add('hidden');
  screenplayEl.focus();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

referenceInput.addEventListener('change', () => {
  const file = referenceInput.files?.[0];
  characterReferenceId = null;
  if (referencePreviewUrl) URL.revokeObjectURL(referencePreviewUrl);
  referencePreviewUrl = null;

  if (!file) {
    referencePreview.classList.add('hidden');
    referenceUploadPromise = null;
    return;
  }

  const acceptedTypes = ['image/png', 'image/jpeg', 'image/webp'];
  if (!acceptedTypes.includes(file.type)) {
    referenceInput.value = '';
    setStatus('Choose a PNG, JPEG or WebP reference image.', 'error');
    referencePreview.classList.add('hidden');
    return;
  }
  if (file.size > 5 * 1024 * 1024) {
    referenceInput.value = '';
    setStatus('Character reference images must be 5 MB or smaller.', 'error');
    referencePreview.classList.add('hidden');
    return;
  }

  referencePreviewUrl = URL.createObjectURL(file);
  referencePreviewImage.src = referencePreviewUrl;
  referenceFilename.textContent = file.name;
  referenceStatus.textContent = 'Uploading reference securely…';
  referencePreview.classList.remove('hidden');
  setStatus('Uploading character reference…');

  referenceUploadPromise = (async () => {
    const form = new FormData();
    form.append('file', file);
    const response = await fetch('/api/reference', { method: 'POST', body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'Character reference upload failed.');
    if (referenceInput.files?.[0] !== file) return null;
    characterReferenceId = data.reference_id;
    referenceStatus.textContent = 'Reference ready · applied to ' + (referenceCharacterInput.value.trim() || 'Main character');
    setStatus('Character reference ready. It will guide each generated storyboard shot.', 'success');
    return characterReferenceId;
  })().catch(error => {
    if (referenceInput.files?.[0] === file) {
      characterReferenceId = null;
      referenceInput.value = '';
      referenceStatus.textContent = error.message;
      setStatus(error.message, 'error');
    }
    throw error;
  });
  // Avoid an unhandled rejection if the user selects a file and does not generate a frame.
  referenceUploadPromise.catch(() => {});
});

analyzeButton.addEventListener('click', async () => {
  const screenplay = screenplayEl.value.trim();
  if (screenplay.length < 40) {
    setStatus('Paste a complete scene (at least 40 characters) before analyzing.', 'error');
    screenplayEl.focus();
    return;
  }
  analyzeButton.disabled = true;
  analyzeButton.querySelector('span:first-child').textContent = 'ANALYZING…';
  setStatus('Muse Spark is reading the scene and planning the coverage. This can take a little while.');
  resultsEl.classList.add('hidden');
  try {
    const response = await fetch('/api/analyze', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ screenplay })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || `Request failed (${response.status})`);
    currentBreakdown = data;
    renderBreakdown(data);
    resultsEl.classList.remove('hidden');
    setStatus('Scene breakdown complete. Generate storyboard frames for the shots you want to visualize.', 'success');
    resultsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    setStatus(error.message || 'Something went wrong. Please retry.', 'error');
  } finally {
    analyzeButton.disabled = false;
    analyzeButton.querySelector('span:first-child').textContent = 'ANALYZE SCENE';
  }
});

function renderBreakdown(data) {
  document.getElementById('scene-title').textContent = safeText(data.scene_title, 'Untitled scene');
  document.getElementById('scene-summary').textContent = safeText(data.scene_summary);
  document.getElementById('logline').textContent = safeText(data.logline);
  document.getElementById('genre-mood').textContent = safeText(data.genre_mood);
  document.getElementById('location-time').textContent = safeText(data.location_time);
  document.getElementById('props').textContent = (data.props || []).join(' · ') || 'None identified';

  const characters = document.getElementById('characters');
  characters.replaceChildren();
  (data.characters || []).forEach(character => {
    const card = el('article', 'character-card');
    card.append(el('div', 'character-name', safeText(character.name)));
    card.append(el('p', 'character-desc', safeText(character.description)));
    const meta = el('div', 'character-meta');
    const objective = el('div'); objective.append(el('span', '', 'OBJECTIVE')); objective.append(document.createTextNode(safeText(character.objective)));
    const emotion = el('div'); emotion.append(el('span', '', 'EMOTIONAL STATE')); emotion.append(document.createTextNode(safeText(character.emotional_state)));
    meta.append(objective, emotion); card.append(meta); characters.append(card);
  });
  if (!characters.children.length) characters.append(el('p', 'character-desc', 'No named characters identified.'));

  const beats = document.getElementById('beats');
  beats.replaceChildren();
  (data.story_beats || []).forEach((beat, index) => {
    const card = el('article', 'beat-card');
    card.append(el('div', 'beat-index', String(beat.beat_number || index + 1).padStart(2, '0')));
    const body = el('div'); body.append(el('div', 'beat-title', safeText(beat.label)));
    body.append(el('div', 'beat-copy', safeText(beat.description)));
    if (beat.emotional_shift) body.append(el('div', 'beat-shift', `SHIFT · ${beat.emotional_shift}`));
    card.append(body); beats.append(card);
  });
  if (!beats.children.length) beats.append(el('p', 'character-desc', 'No story beats returned.'));

  const shots = document.getElementById('shots');
  shots.replaceChildren();
  (data.shots || []).forEach((shot, index) => shots.append(makeShotCard(shot, index)));
}

function makeShotCard(shot, index) {
  const card = el('article', 'shot-card');
  const info = el('div', 'shot-info');
  const top = el('div', 'shot-top');
  top.append(el('span', 'shot-badge', `SHOT ${String(shot.shot_number || index + 1).padStart(2, '0')}`));
  top.append(el('span', 'shot-type', safeText(shot.shot_type, 'SHOT')));
  info.append(top);
  info.append(el('h4', '', safeText(shot.beat, 'Visual beat')));
  info.append(el('p', '', safeText(shot.visual_description)));
  const tags = el('div', 'shot-tags');
  tags.append(el('span', '', safeText(shot.camera_angle)), el('span', '', safeText(shot.camera_movement)));
  info.append(tags);
  info.append(el('div', 'shot-purpose', `DIRECTOR'S INTENTION · ${safeText(shot.director_purpose)}`));

  const visual = el('div', 'shot-visual');
  const button = el('button', 'generate-button', '✦ GENERATE STORYBOARD FRAME');
  button.type = 'button';
  button.addEventListener('click', async () => {
    button.disabled = true;
    button.textContent = 'GENERATING FRAME…';
    try {
      if (referenceInput.files?.[0] && !characterReferenceId && referenceUploadPromise) {
        await referenceUploadPromise;
      }
      const response = await fetch('/api/storyboard', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scene_title: currentBreakdown?.scene_title || 'Untitled scene',
          visual_style: 'cinematic graphite and ink storyboard illustration, subtle warm highlights, professional director storyboard',
          shot,
          characters: currentBreakdown?.characters || [],
          scene_summary: currentBreakdown?.scene_summary || '',
          location_time: currentBreakdown?.location_time || '',
          props: currentBreakdown?.props || [],
          character_reference_id: characterReferenceId,
          reference_character: referenceCharacterInput.value.trim() || 'Main character'
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Storyboard generation failed');
      const img = document.createElement('img');
      img.src = data.image_url;
      img.alt = `Storyboard frame for shot ${data.shot_number}`;
      img.onload = () => {
        button.remove();
        let activeImageUrl = data.image_url;
        const undoStack = [];
        const stage = el('div', 'segmentation-stage');
        const overlay = document.createElement('canvas');
        overlay.className = 'segmentation-overlay';
        overlay.width = img.naturalWidth;
        overlay.height = img.naturalHeight;
        stage.append(img, overlay);
        visual.prepend(stage);
        visual.append(el('span', 'image-label', `MUSE IMAGE · ${data.reference_used ? 'REFERENCE LOCKED' : 'SHOT ' + String(data.shot_number).padStart(2, '0')}`));
        const controls = el('div', 'segment-tools');
        const prompt = document.createElement('input');
        prompt.className = 'segment-prompt';
        prompt.type = 'text';
        prompt.maxLength = 100;
        prompt.placeholder = 'Object to segment · e.g. woman, cassette';
        prompt.setAttribute('aria-label', 'Object to segment');
        const segmentButton = el('button', 'segment-button', 'SEGMENT');
        segmentButton.type = 'button';
        const resultText = el('span', 'segment-result', 'SAM 3.1 · ONE OBJECT PER SEARCH');
        segmentButton.addEventListener('click', async () => {
          const objectPrompt = prompt.value.trim();
          if (!objectPrompt) {
            resultText.textContent = 'Enter one object name first.';
            prompt.focus();
            return;
          }
          segmentButton.disabled = true;
          segmentButton.textContent = 'SCANNING…';
          resultText.textContent = 'SAM 3.1 is finding the object and decoding its mask…';
          const ctx = overlay.getContext('2d');
          ctx.clearRect(0, 0, overlay.width, overlay.height);
          try {
            const imageFilename = activeImageUrl.split('/').pop().split('?')[0];
            const response = await fetch('/api/segment', {
              method: 'POST', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ image_filename: imageFilename, prompt: objectPrompt })
            });
            const segmented = await response.json();
            if (!response.ok) throw new Error(segmented.detail || 'SAM 3.1 segmentation failed.');
            (segmented.objects || []).forEach((object, objectIndex) => {
              const bytes = Uint8Array.from(atob(object.mask_base64), char => char.charCodeAt(0));
              const maskCanvas = document.createElement('canvas');
              maskCanvas.width = object.mask_width;
              maskCanvas.height = object.mask_height;
              const maskCtx = maskCanvas.getContext('2d');
              const maskImage = maskCtx.createImageData(maskCanvas.width, maskCanvas.height);
              for (let pixel = 0; pixel < bytes.length; pixel += 1) {
                if (bytes[pixel]) {
                  const offset = pixel * 4;
                  maskImage.data[offset] = 246;
                  maskImage.data[offset + 1] = 190;
                  maskImage.data[offset + 2] = 91;
                  maskImage.data[offset + 3] = 112;
                }
              }
              maskCtx.putImageData(maskImage, 0, 0);
              const left = Math.max(0, object.left);
              const top = Math.max(0, object.top);
              const right = Math.min(overlay.width, object.right);
              const bottom = Math.min(overlay.height, object.bottom);
              if (right > left && bottom > top) {
                ctx.drawImage(maskCanvas, left, top, right - left, bottom - top);
                ctx.strokeStyle = '#f6be5b';
                ctx.lineWidth = Math.max(2, overlay.width / 500);
                ctx.strokeRect(left, top, right - left, bottom - top);
                ctx.fillStyle = '#f6be5b';
                ctx.font = `bold ${Math.max(14, overlay.width / 45)}px sans-serif`;
                ctx.fillText(`${objectPrompt} ${objectIndex + 1}`, left + 5, Math.max(18, top - 7));
              }
            });
            resultText.textContent = segmented.message || `${segmented.objects.length} object(s) segmented.`;
            setStatus(segmented.message || 'SAM 3.1 segmentation complete.', segmented.objects.length ? 'success' : '');
          } catch (error) {
            resultText.textContent = error.message;
            setStatus(error.message, 'error');
          } finally {
            segmentButton.disabled = false;
            segmentButton.textContent = 'SEGMENT';
          }
        });
        controls.append(prompt, segmentButton, resultText);
        visual.append(controls);
        const editControls = el('div', 'edit-controls');
        const editPrompt = document.createElement('input');
        editPrompt.className='edit-prompt'; editPrompt.type='text'; editPrompt.maxLength=600;
        editPrompt.placeholder='Add, remove or alter a character / object…';
        editPrompt.setAttribute('aria-label','Storyboard image edit instruction');
        const editTarget = document.createElement('input');
        editTarget.type='text'; editTarget.maxLength=100; editTarget.placeholder='Target object (optional)';
        const samLabel = document.createElement('label');
        const samBox = document.createElement('input'); samBox.type='checkbox';
        samLabel.append(samBox,document.createTextNode(' SAM grounded'));
        const editButton=el('button','','✦ EDIT IMAGE'); editButton.type='button';
        const undoButton=el('button','','↶ UNDO'); undoButton.type='button'; undoButton.disabled=true;
        const editResult=el('span','edit-result','Original is kept. AI may change nearby pixels.');
        undoButton.addEventListener('click',()=>{
          if(!undoStack.length)return;
          activeImageUrl=undoStack.pop();img.src=activeImageUrl;
          undoButton.disabled=!undoStack.length;
          editResult.textContent='Previous version restored.';
        });
        editButton.addEventListener('click',async()=>{
          if(editPrompt.value.trim().length<5){editResult.textContent='Enter at least five characters.';return;}
          if(samBox.checked && !editTarget.value.trim()){
            editResult.textContent='Enter a SAM target object or untick SAM grounding.';return;
          }
          editButton.disabled=true;editButton.textContent='EDITING…';editResult.textContent='Muse Image is editing the selected frame…';
          try{
            const res=await fetch('/api/edit',{method:'POST',headers:{'Content-Type':'application/json'},
              body:JSON.stringify({image_filename:activeImageUrl.split('/').pop().split('?')[0],
                instruction:editPrompt.value.trim(),target:editTarget.value.trim(),use_sam:samBox.checked})});
            const changed=await res.json();if(!res.ok)throw new Error(changed.detail||'Image edit failed');
            undoStack.push(activeImageUrl);activeImageUrl=changed.image_url;img.src=activeImageUrl;
            undoButton.disabled=false;editResult.textContent='Edited image ready; original version retained.';
          }catch(error){editResult.textContent=error.message;setStatus(error.message,'error');}
          finally{editButton.disabled=false;editButton.textContent='✦ EDIT IMAGE';}
        });
        editControls.append(editPrompt,editTarget,samLabel,editButton,undoButton,editResult);
        visual.append(editControls);
      };
      img.onerror = () => { setStatus('The generated storyboard image could not be loaded.','error'); };
    } catch (error) {
      button.disabled = false;
      button.textContent = '↻ RETRY STORYBOARD';
      setStatus(error.message, 'error');
    }
  });
  const toLab = el('button', 'director-shot-link', '◈ BLOCK THIS SHOT IN 3D ↗');
  toLab.type = 'button';
  toLab.addEventListener('click', () => {
    localStorage.setItem('framepilot-shotlab-transfer', JSON.stringify({
      sceneTitle: currentBreakdown?.scene_title || 'Untitled scene',
      shot, characters: currentBreakdown?.characters || [],
      props: currentBreakdown?.props || [],
      scene_summary: currentBreakdown?.scene_summary || '',
      location_time: currentBreakdown?.location_time || '',
      characterReferenceId
    }));
    window.location.href = '/shotlab';
  });
  info.append(toLab);
  const toStudio = el('button', 'director-shot-link', '✦ COMBINE REFERENCES + STYLES ↗');
  toStudio.type = 'button';
  toStudio.addEventListener('click', () => {
    localStorage.setItem('framepilot-reference-studio-transfer', JSON.stringify({
      scene_title: currentBreakdown?.scene_title || 'Untitled scene', shot,
      location_time: currentBreakdown?.location_time || ''
    }));
    window.location.href = '/studio';
  });
  info.append(toStudio);

  visual.append(button);
  card.append(info, visual);
  return card;
}
