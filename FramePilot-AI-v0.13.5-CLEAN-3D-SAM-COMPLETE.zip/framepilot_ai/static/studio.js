/* FramePilot Reference Studio — private multi-reference storyboard composition. */
'use strict';
const $ = id => document.getElementById(id);
const roles = ['character','costume','location','prop','pose','composition','palette','style','other'];
const state = { references: [], frames: [], styles: [] };
const icons = {graphite:'✎',technical:'⌁',ink_bw:'◩',charcoal:'◼',watercolor:'◌',oil:'❖',photoreal:'◈',noir:'◑',anime:'✧',manga:'▤',animation_2d:'✿',cartoon:'★',animation_3d:'⬡',stop_motion:'◕',comic:'▥',concept:'◇',pixel:'▦'};
const popular = ['graphite','ink_bw','oil','photoreal','anime','manga','cartoon','animation_3d','watercolor'];
function status(message, kind='') { $('status').textContent=message; $('status').className=`status ${kind}`; }
function node(tag, className='', text) { const e=document.createElement(tag);if(className)e.className=className;if(text!==undefined)e.textContent=text;return e; }
async function api(path,body) { const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json().catch(()=>({detail:'Invalid server response'}));if(!r.ok)throw Error(typeof d.detail==='string'?d.detail:`Request failed (${r.status})`);return d; }
function updateCounts(){ $('ref-count').textContent=`${state.references.length} / 8`; $('selected-count').textContent=`${state.references.filter(x=>x.active).length} reference image(s) selected`; }
function currentReferences() { const selected=state.references.filter(ref=>ref.active); const pending=selected.filter(ref=>!ref.reference_id||ref.error);if(pending.length)throw Error('One or more selected references are still uploading or failed. Deselect or remove them.');return selected.map(({reference_id,role,label,instruction})=>({reference_id,role,label:label||'Reference',instruction})); }
async function loadStyles(){ try{
  const r=await fetch('/api/styles');if(!r.ok)throw Error(`Style list failed ${r.status}`);const d=await r.json();state.styles=d.styles;
  const select=$('style');select.replaceChildren();
  const families=[...new Set(d.styles.map(s=>s.family))];for(const family of families){const group=document.createElement('optgroup');group.label=family;for(const style of d.styles.filter(s=>s.family===family)){const option=node('option','',style.label);option.value=style.id;group.append(option);}select.append(group);}
  select.value='graphite';renderStyleChips();
 }catch(error){ status(error.message,'error'); }
}
function renderStyleChips(){const host=$('style-grid');host.replaceChildren();for(const id of popular){const style=state.styles.find(s=>s.id===id);if(!style)continue;const b=node('button',`style-chip${$('style').value===id?' selected':''}`);b.type='button';b.append(node('span','style-icon',icons[id]||'✧'),document.createTextNode(style.label));b.addEventListener('click',()=>{$('style').value=id;renderStyleChips();});host.append(b);}}
$('style').addEventListener('change',renderStyleChips);
function addFiles(files){const accepted=['image/png','image/jpeg','image/webp'];const available=8-state.references.length;for(const file of Array.from(files).slice(0,available)){
 if(!accepted.includes(file.type)){status(`${file.name}: only PNG, JPEG, or WebP are supported.`,'error');continue;}
 if(!file.size||file.size>5*1024*1024){status(`${file.name}: file must be between 1 byte and 5 MB.`,'error');continue;}
 const item={key:(globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random()}`),reference_id:null,filename:file.name,preview:URL.createObjectURL(file),role:state.references.length===0?'character':'location',label:file.name.replace(/\.[^.]+$/,'').slice(0,80)||'Reference',instruction:'',active:true,uploading:true,error:''};
 state.references.push(item);renderRefs();
 const form=new FormData();form.append('file',file);
 fetch('/api/reference',{method:'POST',body:form}).then(async r=>{const d=await r.json();if(!r.ok)throw Error(d.detail||`Upload failed ${r.status}`);item.reference_id=d.reference_id;item.uploading=false;renderRefs();status(`${item.filename} uploaded privately.`,'success');}).catch(e=>{item.error=e.message;item.uploading=false;renderRefs();status(`${item.filename}: ${e.message}`,'error');});
 }
 if(files.length>available)status(`Maximum 8 references per render. Only ${Math.max(available,0)} image(s) were added.`,'error');updateCounts();}
$('files').addEventListener('change',e=>{addFiles(e.target.files);e.target.value='';});
const drop=$('dropzone');for(const event of ['dragenter','dragover'])drop.addEventListener(event,e=>{e.preventDefault();drop.classList.add('dragover');});for(const event of ['dragleave','drop'])drop.addEventListener(event,e=>{e.preventDefault();drop.classList.remove('dragover');});drop.addEventListener('drop',e=>addFiles(e.dataTransfer.files));
function renderRefs(){const host=$('ref-list');host.replaceChildren();if(!state.references.length){host.append(node('div','empty-ref','No references yet. You can generate with text only, or upload images above.'));updateCounts();return;}
 for(const item of state.references){const card=node('article',`ref-card${item.active?'':' inactive'}`);const img=document.createElement('img');img.src=item.preview;img.alt=`Reference image: ${item.filename}`;card.append(img);const body=node('div','ref-content');const top=node('div','ref-top');const include=node('label');const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.checked=item.active;checkbox.addEventListener('change',()=>{item.active=checkbox.checked;card.classList.toggle('inactive',!item.active);updateCounts();});include.append(checkbox,document.createTextNode(' INCLUDE'));const remove=node('button','remove','×');remove.type='button';remove.title='Remove reference';remove.addEventListener('click',()=>{state.references=state.references.filter(r=>r.key!==item.key);URL.revokeObjectURL(item.preview);renderRefs();});top.append(include,remove);body.append(top,node('div','ref-name',item.filename));const select=document.createElement('select');select.setAttribute('aria-label',`Role for ${item.filename}`);for(const role of roles){const option=node('option','',role.toUpperCase());option.value=role;select.append(option);}select.value=item.role;select.addEventListener('change',()=>{item.role=select.value;});body.append(select);
 const label=document.createElement('input');label.type='text';label.maxLength=80;label.value=item.label;label.placeholder='Label (e.g. Mira)';label.setAttribute('aria-label','Reference label');label.addEventListener('input',()=>{item.label=label.value;});body.append(label);
 const instruction=document.createElement('input');instruction.type='text';instruction.maxLength=240;instruction.value=item.instruction;instruction.placeholder='Use only face / costume / set…';instruction.setAttribute('aria-label','Reference instruction');instruction.addEventListener('input',()=>{item.instruction=instruction.value;});body.append(instruction);
 body.append(node('div',`ref-status${item.error?' error':''}`,item.error|| (item.uploading?'UPLOADING…':'✓ PRIVATE REFERENCE READY')));card.append(body);host.append(card);
 }updateCounts();}
function payload(){const shotText=$('shot').value.trim();if(shotText.length<15)throw Error('Describe the shot in at least 15 characters.');return {
 scene_title:$('title').value.trim()||'Untitled scene',style_preset:$('style').value,style_custom:$('style-custom').value.trim(),visual_style:'film storyboard',reference_images:currentReferences(),
 location_time:$('location').value.trim(),scene_summary:shotText.slice(0,1200),shot:{shot_number:1,beat:shotText.slice(0,500),shot_type:$('shot-type').value,camera_angle:$('angle').value,camera_movement:'Static camera',visual_description:shotText.slice(0,1300),director_purpose:'Establish drama, geography and shot continuity',image_prompt:shotText},
 characters:[],props:[]
 };}
function appendFrame(imageUrl, style, refCount, type='Generated', note=''){
 const card=node('article','render-card');const top=node('div','render-top');top.append(node('span','',`FRAME ${String(state.frames.length+1).padStart(2,'0')} · ${type.toUpperCase()}`),node('span','',style.toUpperCase()));card.append(top);
 const img=document.createElement('img');img.src=imageUrl;img.alt=`Storyboard in ${style} style`;img.loading='lazy';card.append(img);
 const meta=node('div','render-meta');meta.append(node('p','',`${refCount} visual references · ${note||'MUSE IMAGE'}`));const controls=node('div','render-buttons');const download=node('a','','↓ DOWNLOAD');download.href=imageUrl;download.download=`framepilot-${style}-${Date.now()}.png`;download.target='_blank';const edit=node('button','','✦ EDIT / RESTYLE');edit.type='button';controls.append(download,edit);meta.append(controls);card.append(meta);
 const editor=node('div','edit-inline');editor.hidden=true;const label=node('label','','EDIT INSTRUCTION / RESTYLE');const prompt=document.createElement('textarea');prompt.maxLength=600;prompt.placeholder='e.g. Change her saree to white, but keep camera, face, framing and location unchanged.';const styleText=node('label','','Current chosen style will be applied to the edit.');const apply=node('button','','✦ CREATE REVISED FRAME');apply.type='button';editor.append(label,prompt,styleText,apply);card.append(editor);edit.addEventListener('click',()=>{editor.hidden=!editor.hidden;});apply.addEventListener('click',async()=>{
  const instruction=prompt.value.trim()||`Re-render this exact storyboard image in the selected ${$('style').selectedOptions[0]?.textContent||'art'} style while maintaining camera framing and all subject identities.`;
  if(instruction.length<5){status('Enter a clear edit instruction.','error');return;}
  apply.disabled=true;apply.textContent='EDITING…';status('Muse Image is refining the previous frame; this uses Meta API credits.');
  try{const d=await api('/api/edit',{image_filename:imageUrl.split('/').pop().split('?')[0],instruction,reference_images:currentReferences(),style_preset:$('style').value,style_custom:$('style-custom').value.trim()});appendFrame(d.image_url,$('style').selectedOptions[0]?.textContent||$('style').value,state.references.filter(x=>x.active).length,'Revised',`Original ${imageUrl.split('/').pop()}`);status('New revision created. Original image remains available.','success');}
  catch(e){status(e.message,'error');}finally{apply.disabled=false;apply.textContent='✦ CREATE REVISED FRAME';}
 });
 const host=$('result-list');if(!state.frames.length)host.replaceChildren();host.prepend(card);state.frames.push({url:imageUrl,style,refCount});$('render-count').textContent=`${state.frames.length} FRAMES`;
}
$('generate').addEventListener('click',async()=>{
 const button=$('generate');try{
  const request=payload();button.disabled=true;button.textContent='GENERATING WITH MUSE IMAGE…';status(`Rendering one shot using ${request.reference_images.length} selected references. This can take a while.`);
  const result=await api('/api/storyboard',request);
  appendFrame(result.image_url,$('style').selectedOptions[0]?.textContent||result.style_preset,result.reference_count,'Generated',result.model);
  status(`Frame generated using ${result.reference_count} references. You can edit or restyle without overwriting the original.`,'success');
 }catch(e){status(e.message,'error');}finally{button.disabled=false;button.innerHTML='✦ GENERATE ONE STORYBOARD FRAME <span>↗</span>';}
});
$('sample').addEventListener('click',()=>{$('title').value='INT. CLOSED TEA SHOP — NIGHT';$('shot').value='Mira sits at the left of an empty tea shop, tense, studying a cassette. Arun enters from the right under a half-closed rain-slick shutter, carrying a dark canvas bag. A tube light illuminates their faces. Single widescreen shot, strong blocking, no text, no contact sheet.';$('location').value='Rainy tea shop, night';status('Example loaded. Upload multiple references or generate directly.');});
try{const x=JSON.parse(localStorage.getItem('framepilot-reference-studio-transfer')||'null');if(x){$('title').value=String(x.scene_title||x.sceneName||'Untitled').slice(0,160);$('shot').value=String(x.shot?.image_prompt||x.shot?.visual_description||x.prompt||x.beat||'').slice(0,2400);$('angle').value=x.shot?.camera_angle && [...$('angle').options].some(o=>o.value===x.shot.camera_angle)?x.shot.camera_angle:'Eye level';$('shot-type').value=x.shot?.shot_type && [...$('shot-type').options].some(o=>o.value===x.shot.shot_type)?x.shot.shot_type:'Wide shot';$('location').value=String(x.location_time||x.sceneName||'').slice(0,240);localStorage.removeItem('framepilot-reference-studio-transfer');status('Shot imported. Add references and choose a style before generating.','success');}}catch(e){console.warn('Shot transfer was not readable',e);}
loadStyles();
