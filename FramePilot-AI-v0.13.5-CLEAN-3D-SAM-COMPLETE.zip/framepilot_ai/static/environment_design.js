/** Model plans are only data; don't construct arbitrary scene graph code. */
export const SUPPORTED_SET_KINDS=Object.freeze(['actor','box','sphere','cylinder','table','chair','wall','door','window','bed','tree','plant','rock','mountain','building','road','water','car','boat','lamp','sign','screen','column','streetlight','stage']);
const kinds=new Set(SUPPORTED_SET_KINDS);
const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
export function buildEditableSetFromPlan(plan,idFactory=()=>crypto.randomUUID()){
 if(!plan || !Array.isArray(plan.add_objects))return [];
 return plan.add_objects.slice(0,12).filter(o=>o&&kinds.has(o.kind)&&typeof o.name==='string').map(o=>({
  id:idFactory(),kind:o.kind,name:o.name.trim().slice(0,60)||o.kind,
  x:clamp(Number(o.x)||0,-40,40),y:clamp(Number(o.y)||0,0,20),z:clamp(Number(o.z)||0,-40,40),
  rot:clamp(Number(o.rot)||0,-180,180),scale:clamp(Number(o.scale)||1,.1,8),
  color:/^#[a-fA-F0-9]{6}$/.test(o.color||'')?o.color:'#86b9b7'
 }));
}
export function describeEditableSet(objects){
 const count=objects.length;
 return `${count} editable ${count===1?'object':'objects'}: ${objects.slice(0,6).map(o=>o.name).join(', ')}${count>6?'…':''}`;
}
