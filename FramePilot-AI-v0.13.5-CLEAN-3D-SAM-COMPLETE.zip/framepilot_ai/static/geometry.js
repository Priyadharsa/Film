// FramePilot geometry primitives. Set units are metres, yaw/pan is degrees,
// world X is screen right in the default stage and camera forward is -Z.
export const deg = radians => radians * 180 / Math.PI;
export const rad = degrees => degrees * Math.PI / 180;
export const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
export function focalToVerticalFov(focalLengthMm, aspect = 16 / 9, sensorWidthMm = 36) {
  if (!(focalLengthMm > 0 && aspect > 0 && sensorWidthMm > 0)) throw new Error('Invalid lens geometry');
  const sensorHeight = sensorWidthMm / aspect;
  return deg(2 * Math.atan(sensorHeight / (2 * focalLengthMm)));
}
export function horizontalFov(focalLengthMm, sensorWidthMm = 36) {
  if (!(focalLengthMm > 0)) throw new Error('Invalid focal length');
  return deg(2 * Math.atan(sensorWidthMm / (2 * focalLengthMm)));
}
export function aimDirection(panDeg, tiltDeg) {
  const pan = rad(panDeg), tilt = rad(tiltDeg);
  return { x: Math.sin(pan) * Math.cos(tilt), y: Math.sin(tilt), z: -Math.cos(pan) * Math.cos(tilt) };
}
export function cameraSide(actorA, actorB, camera) {
  if (!actorA || !actorB || !camera) return 0;
  const cross = (actorB.x - actorA.x) * (camera.z - actorA.z) -
                (actorB.z - actorA.z) * (camera.x - actorA.x);
  return Math.abs(cross) < 0.03 ? 0 : Math.sign(cross);
}
export function crossed180Line(previousSide, nextSide) {
  return previousSide !== 0 && nextSide !== 0 && previousSide !== nextSide;
}
export function shotSizeHint(focal) {
  return focal >= 70 ? 'Tight portrait / telephoto' : focal >= 45 ? 'Natural perspective' : focal >= 28 ? 'Medium-wide cinematic' : 'Wide environmental';
}
