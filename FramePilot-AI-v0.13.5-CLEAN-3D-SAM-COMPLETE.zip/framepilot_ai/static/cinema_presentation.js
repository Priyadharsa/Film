/** Manage maximized Cinema 3D without trapping document or inspector scrolling.
 * No dependence on the 3D renderer; safe to unit-test without WebGL.
 */
export function createCinemaPresentation({stage,button,body,root,view,refresh=()=>{}}){
  let position=null;
  const isMaximized=()=>stage.classList.contains('stage-maximized');
  function set(enabled){
    enabled=Boolean(enabled);
    if(enabled===isMaximized()){
      // Clean up stale scroll locks left by a hidden stage during navigation.
      if(!enabled){body.classList.remove('cinema-scroll-locked');root.classList.remove('cinema-scroll-locked');}
      return;
    }
    if(enabled){
      position={x:Number(view.scrollX)||0,y:Number(view.scrollY)||0};
      stage.classList.add('stage-maximized');
      body.classList.add('cinema-scroll-locked');
      root.classList.add('cinema-scroll-locked');
      button.textContent='↙ Restore 3D';
    }else{
      stage.classList.remove('stage-maximized');
      body.classList.remove('cinema-scroll-locked');
      root.classList.remove('cinema-scroll-locked');
      button.textContent='⛶ Maximize 3D';
      const previous=position;
      position=null;
      if(previous && typeof view.scrollTo==='function')view.requestAnimationFrame?.(()=>view.scrollTo(previous.x,previous.y));
    }
    button.setAttribute('aria-pressed',String(enabled));
    button.setAttribute('aria-expanded',String(enabled));
    refresh();
  }
  return {set,isMaximized};
}
