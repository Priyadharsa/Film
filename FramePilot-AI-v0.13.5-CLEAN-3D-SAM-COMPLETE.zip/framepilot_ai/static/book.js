import {uploadLargeFile} from './upload.js';
import {createCinemaPresentation} from './cinema_presentation.js';
import {CAMERA_PRESETS,LIGHT_PRESETS,makeStageObjects,validateCamera,aspectRatio,cameraFov,clamp,makeShotManifest} from './cinema_utils.js';
import {buildEditableSetFromPlan, describeEditableSet} from './environment_design.js';
const $=id=>document.getElementById(id);
const st={project:null,page:1,sid:null,shid:null,tab:'set',styles:[],patterns:[],busy:false,selected:null,eraser:false,draw:false,drawDirty:false,drafts:new Map(),sam:{source:null,objects:[],index:-1},compare:null,directorPlan:null,directorApplied:false};
const clone=x=>JSON.parse(JSON.stringify(x));
const currentScene=()=>st.project?.scenes.find(s=>s.id===st.sid);
const currentShot=()=>currentScene()?.shots.find(s=>s.id===st.shid);
const page=()=>st.project?.pages?.[st.page-1];
const pages=()=>st.project?.pages?.length||0;
const path=()=>`/api/projects/${st.project.id}/scenes/${st.sid}/shots/${st.shid}`;
const j=(method,body)=>({method,headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
async function api(path,opts){
 let r;try{r=await fetch(path,opts)}catch(e){throw Error(`Network unavailable: ${e.message}`)}
 const type=r.headers.get('content-type')||'';
 const data=type.includes('json')?await r.json().catch(()=>({})):null;
 if(!r.ok){const raw=data?.detail;const message=typeof raw==='string'?raw:
  Array.isArray(raw)?raw.map(x=>`${(x.loc||[]).join('.')}: ${x.msg}`).join('; '):
  raw&&typeof raw==='object'?JSON.stringify(raw):`Request failed`;
  const rid=r.headers.get('x-request-id');throw Error(`${r.status} — ${message}${rid?` (request ${rid})`:''}`)}
 return data;
}
function notify(message,bad=false){const t=$('toast');t.textContent=message;t.className='toast visible'+(bad?' error':'');clearTimeout(notify.timer);notify.timer=setTimeout(()=>t.className='toast',6000);$('status').textContent=message;}
function busy(v,label='Working…'){
 st.busy=v;$('status').textContent=v?label:(st.project?'Ready · project saved':'No film loaded');
 const ai=/Muse|SAM|generat|segment|render|edit.*image|rendering/i.test(label);
 const node=$('task-loader');if(!node)return;
 if(v&&ai){node.hidden=false;$('task-title').textContent=label;$('task-hint').textContent='The AI model is processing this shot. Avoid double-clicking Generate.';}
 if(!v)node.hidden=true;
}
async function loadIndex(selectId){try{const r=await api('/api/projects');const select=$('project-select');select.replaceChildren(new Option('Choose a film',''));for(const item of r.projects)select.add(new Option(`${item.title} · ${item.scenes} scenes`,item.id));if(st.project){select.value=st.project.id;}else if(selectId)await openProject(selectId);else if(r.projects?.length)await openProject(r.projects[0].id);}catch(e){if(e.message.startsWith('401')){$('account-modal').hidden=false;loadAccount();}else notify(e.message,true)}}
async function openProject(pid){const r=await api('/api/projects/'+encodeURIComponent(pid));st.project=r.project;st.page=1;st.sid=null;st.shid=null;render();$('project-select').value=pid;warnIncompleteImport(st.project);}
function update(result){st.project=result.project||result;render();}
function warnIncompleteImport(project){
 const expected=Number(project?.source?.pages||0),actual=project?.pages?.length||0;
 if(expected>8&&actual<expected*.85){notify(`This saved film has only ${actual} of ${expected} source pages. Re-import the original PDF with automatic OCR; the existing partial film will not generate missing pages.`,true)}
}

function usablePages(){if(st.project?.pages?.length)return;st.project.pages=st.project.scenes.map((s,i)=>({number:i+1,text:s.slugline+'\n\n'+s.text,notes:'',scene_ids:[s.id]}));}
function render(){const p=st.project;if(!p)return;usablePages();st.page=Math.max(1,Math.min(pages(),st.page));$('film-title').textContent=p.title;$('page-number').textContent=String(st.page).padStart(2,'0');$('page-jump').value=st.page;$('page-total').textContent='/ '+pages();$('page-prev').disabled=st.page<=1;$('page-next').disabled=st.page>=pages();$('page-source').textContent=(p.source?.filename||'SCREENPLAY').slice(0,26);
const pg=page(),draft=st.drafts.get(`${p.id}:${st.page}`);$('script-text').value=draft?.text??pg?.text??'';$('page-notes').value=draft?.notes??pg?.notes??'';const sceneIds=pg?.scene_ids||[];const found=p.scenes.filter(s=>sceneIds.includes(s.id));const chooser=$('scene-select');chooser.replaceChildren();for(const s of found)chooser.add(new Option(`${String(s.number).padStart(3,'0')} · ${s.slugline}`,s.id));if(!found.length&&p.scenes.length){const near=p.scenes.find(x=>(x.source_pages||[]).some(n=>n>=st.page))||p.scenes.at(-1);chooser.add(new Option(`${near.number} · ${near.slugline} (nearest)`,near.id));}
if(!Array.from(chooser.options).some(o=>o.value===st.sid))st.sid=chooser.value||p.scenes[0]?.id||null;chooser.value=st.sid||'';
const sc=currentScene();$('scene-title').textContent=sc?.slugline||'New scene';const shotChooser=$('shot-select');shotChooser.replaceChildren();for(const sh of sc?.shots||[])shotChooser.add(new Option(`SH ${String(sh.number).padStart(3,'0')} · ${sh.name}`,sh.id));if(!sc?.shots.some(s=>s.id===st.shid))st.shid=sc?.shots[0]?.id||null;shotChooser.value=st.shid||'';
renderShot();}
function renderShot(){const sc=currentScene(),sh=currentShot();if(st.directorPlan&&st.directorPlan.key!==`${st.sid}:${st.shid}`)directorClear();$('shot-count').textContent=`${sc?.shots.length||0} SHOTS`;$('new-shot').disabled=!sc;$('shot-prev').disabled=!sh||sc.shots.indexOf(sh)===0;$('shot-next').disabled=!sh||sc.shots.indexOf(sh)===sc.shots.length-1;
if(!sh){$('shot-timeline').replaceChildren();$('shot-preview').hidden=true;$('empty-frame').hidden=false;$('frame-open').disabled=true;$('shot-name').value='';$('shot-desc').value='';return;}
const context=$('shared-shot-context');if(context)context.textContent=`SC ${sc.number} · SH ${sh.number} · ${sh.name||'Draft'} — shared by 3D, Draw, Art and Director AI`;
const turns=$('muse-turn-count');if(turns)turns.textContent=`${(sh.muse_turns||[]).length} recent Muse revisions`;
$('shot-name').value=sh.name||'';$('shot-desc').value=sh.description||'';$('duration').value=sh.duration_s||5;selectValue($('shot-type'),sh.shot_type||'Wide shot');$('frame-meta').textContent=`SC${sc.number} · SH${sh.number} · ${(sh.style_preset||'graphite').toUpperCase()}`;
showFrame(sh,st.project.revision);
selectValue($('styles'),sh.style_preset||'graphite');$('style-custom').value=sh.style_custom||'';renderRefs();renderVersions();renderTimeline();loadDrawing();updateSAMFrame();renderArtCompare();if(engine.ready)engine.load(sh.camera||{});}
function showFrame(shot,revision){
 const image=$('shot-preview'),placeholder=$('empty-frame');
 const source=shot?.image_url||shot?.sketch_url||'';
 $('frame-open').disabled=!source;
 if(!source){image.removeAttribute('src');image.hidden=true;placeholder.hidden=false;
  placeholder.querySelector('strong').textContent='Frame awaits its director.';
  placeholder.querySelector('small').textContent='Draw, capture 3D, or generate with Muse.';return;}
 // An image was generated; never display the 'awaits its director' message.
 const url=source+'?v='+encodeURIComponent(revision||0);
 placeholder.hidden=true;image.hidden=false;
 image.onload=()=>{if(image.getAttribute('src')===url){image.hidden=false;placeholder.hidden=true;}};
 image.onerror=()=>{if(image.getAttribute('src')!==url)return;
  image.hidden=true;placeholder.hidden=false;$('frame-open').disabled=true;
  placeholder.querySelector('strong').textContent='Generated image cannot be loaded';
  placeholder.querySelector('small').textContent='The frame was saved, but its image file is unavailable. Inspect the server log or retry the frame.';};
 if(image.getAttribute('src')!==url)image.src=url;
}
function mergeRenderProgress(remote){
 if(!st.project||!remote?.project||remote.project.id!==st.project.id)return;
 const revisions=new Map();for(const scene of remote.project.scenes||[])for(const shot of scene.shots||[])revisions.set(shot.id,shot);
 let activeChanged=false,otherChanged=false;
 for(const scene of st.project.scenes||[])for(const shot of scene.shots||[]){
  const next=revisions.get(shot.id);if(!next)continue;
  if(next.image_url!==shot.image_url||next.sketch_url!==shot.sketch_url){
   for(const key of ['image_url','sketch_url','history','status','muse_turns','muse_last_response_id','muse_last_image_url'])if(key in next)shot[key]=next[key];
   if(shot.id===st.shid)activeChanged=true;else otherChanged=true;
  }
 }
 st.project.revision=remote.project.revision;
 if(activeChanged){showFrame(currentShot(),st.project.revision);renderVersions();renderArtCompare();}
 if(activeChanged||otherChanged)renderTimeline();
 // Crucially do not call render() here: that resets unsaved screenplay fields and drawings.
}
function selectValue(el,value){if(value&&!Array.from(el.options).some(o=>o.value===value))el.add(new Option(value,value));el.value=value;}
function renderTimeline(){
 const host=$('shot-timeline');host.replaceChildren();const scene=currentScene();if(!scene)return;
 const all=scene.shots||[],active=all.findIndex(sh=>sh.id===st.shid);
 // Render a bounded filmstrip even for exceptionally long scenes.
 const lo=Math.max(0,active-10),hi=Math.min(all.length,Math.max(active+11,lo+21));
 if(lo>0){const before=document.createElement('span');before.className='timeline-ellipsis';before.textContent=`+${lo} earlier`;host.append(before);}
 for(let i=lo;i<hi;i++){
  const sh=all[i],btn=document.createElement('button');btn.type='button';btn.className='timeline-shot'+(sh.id===st.shid?' selected':'');
  btn.setAttribute('aria-label',`Select shot ${sh.number}: ${sh.name}`);btn.setAttribute('aria-current',String(sh.id===st.shid));
  const thumb=document.createElement('div');thumb.className='timeline-thumb';const uri=sh.image_url||sh.sketch_url;
  if(uri){const img=document.createElement('img');img.src=uri;img.alt='';img.loading='lazy';thumb.append(img);}else thumb.textContent='◈';
  const title=document.createElement('span');title.textContent=`${String(sh.number).padStart(2,'0')}  ${sh.name||'New shot'}`;
  const duration=document.createElement('small');duration.textContent=`${Number(sh.duration_s||5).toFixed(1)}s · ${sh.status||'Draft'}`;
  btn.append(thumb,title,duration);btn.onclick=()=>{st.shid=sh.id;renderShot();};host.append(btn);
 }
 if(hi<all.length){const later=document.createElement('span');later.className='timeline-ellipsis';later.textContent=`+${all.length-hi} later`;host.append(later);}
 host.querySelector('.selected')?.scrollIntoView({block:'nearest',inline:'nearest'});
}
function renderRefs(){const host=$('refs');host.replaceChildren();for(const ref of currentShot()?.references||[]){const row=document.createElement('div');row.className='ref-item';const img=document.createElement('img');img.src=`/api/reference/${ref.reference_id}/preview`;const role=document.createElement('select');for(const x of ['character','face','body','costume','location','prop','pose','composition','palette','style','other'])role.add(new Option(x,x));role.value=ref.role;role.onchange=()=>editRef(ref.reference_id,{role:role.value});const remove=document.createElement('button');remove.textContent='✕';remove.onclick=()=>removeRef(ref.reference_id);const identity=document.createElement('input');identity.value=ref.label||'';identity.maxLength=80;identity.setAttribute('aria-label','Character or reference name');identity.title='Use the same name for matching face/body/costume';identity.onchange=()=>editRef(ref.reference_id,{label:identity.value.trim()||'Reference'});
 const instruction=document.createElement('input');instruction.value=ref.instruction||'';instruction.maxLength=240;instruction.placeholder='Visual direction (optional)';instruction.setAttribute('aria-label','Reference instruction');instruction.onchange=()=>editRef(ref.reference_id,{instruction:instruction.value});
 row.append(img,role,identity,instruction,remove);host.append(row);}}
function renderVersions(){const host=$('versions');host.replaceChildren();for(const item of (currentShot()?.history||[]).slice().reverse()){if(!item.url)continue;const b=document.createElement('button');b.title=item.kind||'Version';const im=document.createElement('img');im.src=item.url;b.append(im);b.onclick=()=>saveShot({image_url:item.url});host.append(b);}}
async function saveShot(changes){if(!currentShot())return;try{busy(true,'Saving shot');const r=await api(path(),j('PATCH',changes));update(r);notify('Shot saved.');return true;}catch(e){notify(e.message,true);return false;}finally{busy(false)}}
async function changePage(to){
 if(st.drawDirty&&!confirm('There is an unsaved drawing. Continue without saving?'))return;
 if(st.project&&st.drafts.has(`${st.project.id}:${st.page}`)){
  const saved=await savePage();if(!saved)return;
 }
 st.drawDirty=false;st.page=Math.max(1,Math.min(pages(),to));st.sid=null;st.shid=null;render();
}
$('page-prev').onclick=()=>changePage(st.page-1);$('page-next').onclick=()=>changePage(st.page+1);$('page-jump').onchange=()=>changePage(Number($('page-jump').value)||1);
$('scene-select').onchange=e=>{st.sid=e.target.value;st.shid=null;render()};$('shot-select').onchange=e=>{st.shid=e.target.value;renderShot()};
function stepShot(n){const s=currentScene(),index=s?.shots.findIndex(x=>x.id===st.shid)??-1;if(index<0)return;st.shid=s.shots[Math.max(0,Math.min(s.shots.length-1,index+n))].id;renderShot();}
$('shot-prev').onclick=()=>stepShot(-1);$('shot-next').onclick=()=>stepShot(1);
// Save text without losing pending edits when a shot or 3D object is saved.
function rememberPageDraft(){
 if(!st.project)return;
 st.drafts.set(`${st.project.id}:${st.page}`,{text:$('script-text').value,notes:$('page-notes').value});
 $('status').textContent='Unsaved screenplay page changes';
}
$('script-text').addEventListener('input',rememberPageDraft);
$('page-notes').addEventListener('input',rememberPageDraft);
async function savePage(){
 if(!st.project)return false;
 try{busy(true,'Saving page');const r=await api(`/api/projects/${st.project.id}/pages/${st.page}`,j('PATCH',{text:$('script-text').value,notes:$('page-notes').value}));
  st.project.pages[st.page-1]=r.page;st.project.revision=r.revision;st.drafts.delete(`${st.project.id}:${st.page}`);
  notify('Page saved. Use “Re-detect scenes” to update scene drafts.');return true;
 }catch(e){notify(e.message,true);return false;}finally{busy(false)}
}
$('save-page').onclick=savePage;
$('save-scene').onclick=async()=>{if(await savePage())await rebuild()};
async function rebuild(){if(!confirm('Re-detect scene boundaries from the edited book pages? Matching existing shots will be kept, but scene text will be rebuilt.'))return;try{busy(true,'Reading screenplay');const r=await api(`/api/projects/${st.project.id}/rebuild-scenes`,{method:'POST'});st.sid=null;st.shid=null;update(r);notify(`Book updated: ${st.project.scenes.length} editable scenes.`);}catch(e){notify(e.message,true)}finally{busy(false)}}
$('rebuild').onclick=rebuild;
$('new-shot').onclick=async()=>{if(!currentScene())return;try{const r=await api(`/api/projects/${st.project.id}/scenes/${st.sid}/shots`,{method:'POST'});update(r);st.shid=currentScene().shots.at(-1).id;render();notify('Draft shot created.');}catch(e){notify(e.message,true)}};
$('new-scene').onclick=async()=>{if(!st.project)return;const slugline=prompt('New scene heading','INT. NEW LOCATION - NIGHT');if(!slugline)return;try{const r=await api(`/api/projects/${st.project.id}/scenes`,j('POST',{slugline,text:'',source_page:st.page}));update(r);st.sid=st.project.scenes.at(-1).id;st.shid=currentScene().shots[0]?.id;render();notify('Scene created on this book page.');}catch(e){notify(e.message,true)}};
$('save-shot-top').onclick=()=>$('save-shot').click();
$('save-shot').onclick=()=>saveShot({name:$('shot-name').value.trim()||'Untitled shot',description:$('shot-desc').value,shot_type:$('shot-type').value,duration_s:Number($('duration').value)||5});
// Import dialog: proper focus management and a single reliable close path.
let importReturnFocus=null;
function openImportDialog(){
  importReturnFocus=document.activeElement;
  $('import-modal').hidden=false;
  $('import-title').focus();
}
function closeImportDialog(){
  $('import-modal').hidden=true;
  if(importReturnFocus?.isConnected)importReturnFocus.focus();
  importReturnFocus=null;
}
$('project-select').onchange=e=>e.target.value&&openProject(e.target.value);
$('new-film').onclick=openImportDialog;
$('cancel-import').onclick=closeImportDialog;
$('import-modal').addEventListener('keydown',e=>{
  if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closeImportDialog();return}
  if(e.key!=='Tab')return;
  const all=[...$('import-modal').querySelectorAll('button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),a[href]')].filter(el=>!el.hidden&&el.getClientRects().length);
  if(!all.length)return;
  if(e.shiftKey&&document.activeElement===all[0]){e.preventDefault();all.at(-1).focus()}
  else if(!e.shiftKey&&document.activeElement===all.at(-1)){e.preventDefault();all[0].focus()}
});
$('demo').onclick=async()=>{try{busy(true,'Creating demo');const r=await api('/api/projects/demo',{method:'POST'});st.project=r.project;st.sid=null;st.shid=null;st.page=1;render();await loadIndex();notify('Original film demo opened.');}catch(e){notify(e.message,true)}finally{busy(false)}};
$('submit-import').onclick=async()=>{const file=$('import-file').files?.[0],text=$('import-text').value;if(!file&&!text.trim())return notify('Choose a file or paste screenplay text.',true);try{busy(true,'Importing screenplay');let r;if(file){$('progress').hidden=false;const upload=await uploadLargeFile(file,{title:$('import-title').value,ocr:$('ocr').checked,onProgress:n=>{$('progress').value=Math.round(n*100);$('import-info').textContent=`Upload ${Math.round(n*100)}% — safe to resume`},onState:t=>{$('import-info').textContent=t}});if(!upload.project_id)throw Error('Import did not return a project ID.');r=await api(`/api/projects/${upload.project_id}`);}else{const fd=new FormData();fd.append('title',$('import-title').value);fd.append('screenplay_text',text);r=await api('/api/projects/import',{method:'POST',body:fd});}st.project=r.project;st.page=1;st.sid=null;st.shid=null;render();await loadIndex();closeImportDialog();notify(`Imported ${st.project.pages?.length||0} screenplay pages, ${st.project.scenes.length} scenes, ${st.project.scenes.reduce((n,s)=>n+s.shots.length,0)} editable shots. Muse artwork has not started.`);}catch(e){notify(e.message,true);$('import-info').textContent=e.message;}finally{busy(false)}};
async function pdf(kind){if(!st.project)return notify('Open or import a film first.',true);if(st.drafts.has(`${st.project.id}:${st.page}`)&&!(await savePage()))return;let start=1;if(st.project.scenes.length>250){const entered=prompt('Large book: choose first scene for this 250-scene PDF volume (1, 251, 501...)','1');if(!entered)return;start=Math.floor(Number(entered));if(!start||start<1)return notify('Choose a valid scene number.',true);}const url=`/api/projects/${st.project.id}/${kind}?from_scene=${start}&to_scene=${Math.min(start+249,st.project.scenes.length)}`;
 try{busy(true,'Building PDF…');const r=await fetch(url);
   if(!r.ok){const details=await r.json().catch(()=>({}));const req=r.headers.get('x-request-id');throw Error(`${r.status} — ${details.detail||'PDF export failed'}${req?` (request ${req})`:''}`)}
   const file=await r.blob();if(!file.size||file.type!=='application/pdf')throw Error('Server did not return a valid PDF file.');
   const link=document.createElement('a'),tmp=URL.createObjectURL(file);link.href=tmp;
   link.download=`framepilot-${kind==='comic.pdf'?'comic':'production'}-${start}.pdf`;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(tmp),60000);
   notify('PDF exported successfully.');
 }catch(e){notify(`PDF export: ${e.message}`,true)}finally{busy(false)}
}
$('pdf').onclick=()=>pdf('export.pdf');$('comic').onclick=()=>pdf('comic.pdf');
async function downloadFile(url,filename,caption){
 if(!st.project)return notify('Open a film before exporting.',true);
 try{busy(true,caption||'Preparing export');const r=await fetch(url);
  if(!r.ok){const details=await r.json().catch(()=>({}));throw Error(`${r.status} — ${details.detail||'Export failed'} (request ${r.headers.get('x-request-id')||'unknown'})`)}
  const blob=await r.blob();if(!blob.size)throw Error('The downloaded file is empty.');
  const link=document.createElement('a');const target=URL.createObjectURL(blob);link.href=target;link.download=filename;
  document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(target),30000);
  const direct=$('export-direct');if(direct){direct.href=url;direct.download=filename;direct.hidden=false;direct.textContent='Download again (direct browser link)';} notify('Download requested. If blocked, use the direct link under Export.');
 }catch(e){const direct=$('export-direct');if(direct){direct.href=url;direct.download=filename;direct.hidden=false;direct.textContent='Try direct browser download';}notify(e.message,true)}finally{busy(false);$('export-menu').open=false}
}
$('download-pack').onclick=()=>{if(!st.project)return notify('Choose a film first.',true);
 const url=`/api/projects/${encodeURIComponent(st.project.id)}/production-pack.zip`;
 const a=document.createElement('a');a.href=url;a.download='framepilot-full-production-pack.zip';document.body.append(a);a.click();a.remove();
 const direct=$('export-direct');direct.href=url;direct.download='framepilot-full-production-pack.zip';direct.hidden=false;direct.textContent='Retry full production download';
 $('export-menu').open=false;notify('Your full production ZIP is being prepared. Check browser Downloads, or use Retry under Export.');
};
$('download-json').onclick=()=>downloadFile(`/api/projects/${st.project.id}/export.json`,'framepilot-project.json','Preparing project JSON');
$('download-page').onclick=()=>{
 const ids=new Set(page()?.scene_ids||[]),indexes=st.project.scenes.map((x,i)=>ids.has(x.id)?i+1:null).filter(Boolean);
 if(!indexes.length)return notify('No scenes are linked to this page.',true);
 const from=Math.min(...indexes),to=Math.max(...indexes);
 downloadFile(`/api/projects/${st.project.id}/export.pdf?from_scene=${from}&to_scene=${to}`,`page-${st.page}-storyboard.pdf`,'Exporting page');
};

async function loadSelections(){try{const [sty,patterns]=await Promise.all([api('/api/styles'),api('/api/projects/shot-patterns/list')]);st.styles=sty.styles;st.patterns=patterns.patterns;const sel=$('styles');sel.replaceChildren();const batch=$('batch-style');batch.replaceChildren(new Option('Respect each shot’s own style',''));for(const g of Array.from(new Set(st.styles.map(s=>s.family)))){const grp=document.createElement('optgroup');grp.label=g;for(const s of st.styles.filter(x=>x.family===g))grp.append(new Option(s.label,s.id));sel.append(grp);batch.append(grp.cloneNode(true));}const vs=$('voice-style');vs.replaceChildren();for(const sty of st.styles)vs.add(new Option(sty.label,sty.id));vs.value='graphite';const ps=$('grammar');for(const p of st.patterns)ps.add(new Option(`${p.label} · ${p.shots} shots`,p.id));}catch(e){notify(e.message,true)}}
// Audio direction is transcribed with Muse Voice, then stored as an ordinary
// editable screenplay scene. Model image generation remains an explicit second step.
let voiceSceneLink=null;
$('voice-file').addEventListener('change',()=>{voiceSceneLink=null;$('voice-status').textContent='Ready for Muse Voice transcription.';});
let activeVoiceJob=null;
let completedVoiceJob=null;
function uploadWithProgress(url,form,onProgress){return new Promise((resolve,reject)=>{
 const xhr=new XMLHttpRequest();xhr.open('POST',url);xhr.withCredentials=true;
 xhr.upload.onprogress=(ev)=>{if(ev.lengthComputable)onProgress(ev.loaded,ev.total)};
 xhr.onload=()=>{let data={};try{data=JSON.parse(xhr.responseText||'{}')}catch{}
  if(xhr.status>=200&&xhr.status<300)resolve(data);
  else reject(Error(`${xhr.status} — ${data.detail||'Upload failed'}`))};
 xhr.onerror=()=>reject(Error('Upload interrupted. Check the network and try again.'));
 xhr.send(form);
})}
$('voice-cancel').onclick=async()=>{if(!activeVoiceJob)return;
 try{await api(`/api/voice-storyboard/jobs/${activeVoiceJob}/cancel`,{method:'POST'});
 $('voice-status').textContent='Cancellation requested. It will stop after the current audio segment.';
 }catch(e){notify(e.message,true)}
};
$('voice-transcribe').onclick=async()=>{
 const file=$('voice-file').files?.[0];
 if(!file)return notify('Choose an audio or video recording first.',true);
 if(file.size>500*1024*1024)return notify('Maximum recording size is 500 MiB.',true);
 const btn=$('voice-transcribe'),form=new FormData();form.append('file',file);
 btn.disabled=true;completedVoiceJob=null;$('voice-download').hidden=true;$('voice-import-all').hidden=true;$('voice-progress').value=0;
 $('voice-status').textContent='Uploading recording securely…';
 try{
  const initial=await uploadWithProgress('/api/voice-storyboard/jobs',form,(done,total)=>{
   const pct=Math.round(100*done/total);
   $('voice-progress').value=pct;
   $('voice-status').textContent=`Uploading recording… ${pct}%`;
  });
  activeVoiceJob=initial.job_id;$('voice-cancel').hidden=false;
  let current=initial;
  while(!['completed','failed','cancelled'].includes(current.state)){
   await new Promise(r=>setTimeout(r,1500));
   current=await api(`/api/voice-storyboard/jobs/${activeVoiceJob}`);
   const pct=current.parts_total?Math.round(100*current.parts_done/current.parts_total):0;
   $('voice-progress').value=pct;
   $('voice-status').textContent=current.state==='converting'?'Converting audio into safe transcription clips…':
    current.state==='queued'?'Waiting for transcription capacity…':
    `Transcribing ${current.parts_done} of ${current.parts_total} clips (${pct}%)…`;
  }
  if(current.state==='failed')throw Error(current.error||'Transcription failed');
  if(current.state==='cancelled')throw Error('Transcription was cancelled.');
  $('voice-transcript').value=current.transcript_preview||'';
  voiceSceneLink=null;
  const url=`/api/voice-storyboard/jobs/${activeVoiceJob}/transcript`;
  completedVoiceJob=activeVoiceJob;
  $('voice-download').href=url;$('voice-download').hidden=false;
  $('voice-import-all').hidden=false;
  $('voice-status').textContent=`Transcription ready · ${current.parts_total} clips. The editor shows up to 24,000 characters; download TXT for the complete transcript.`;
  $('voice-progress').value=100;
  notify('Muse Voice transcription ready. Review the text or download the full transcript.');
 }catch(e){$('voice-status').textContent=`Audio processing stopped: ${e.message}`;notify(e.message,true)}
 finally{btn.disabled=false;$('voice-cancel').hidden=true;activeVoiceJob=null}
};

$('voice-import-all').onclick=async()=>{
 if(!completedVoiceJob)return notify('Transcribe a recording first.',true);
 if(!confirm('Import the full transcript as a new editable film? Your current film will remain saved.'))return;
 const btn=$('voice-import-all');btn.disabled=true;
 try{
  busy(true,'Importing the complete transcript as a screenplay');
  const response=await fetch(`/api/voice-storyboard/jobs/${completedVoiceJob}/transcript`,{credentials:'same-origin'});
  if(!response.ok)throw Error('The full transcript is no longer available. Download it or transcribe again.');
  const transcript=await response.text();
  const fd=new FormData();fd.append('screenplay_text',transcript);
  fd.append('title',($('voice-heading').value.trim()||'Voice Storyboard Film').replace(/^INT\.|^EXT\./,'').trim());
  const imported=await api('/api/projects/import',{method:'POST',body:fd});
  st.project=imported.project;st.page=1;st.sid=null;st.shid=null;
  render();await loadIndex();
  notify(`Entire transcript imported as ${st.project.scenes.length} editable scenes. Review shot divisions before generating images.`);
 }catch(e){notify(e.message,true)}finally{busy(false);btn.disabled=false}
};
async function createSceneFromVoice(){
 if(!st.project)throw Error('Open or create a film before making an audio scene.');
 const transcript=$('voice-transcript').value.trim();
 if(transcript.length<10)throw Error('Record or enter at least ten characters of spoken direction.');
 const heading=$('voice-heading').value.trim()||'INT. VOICE CONCEPT - DAY';
 const direction=$('voice-direction').value.trim();
 const style=$('voice-style').value||'graphite';
 const fingerprint=JSON.stringify([st.project.id,transcript,heading,direction,style]);
 if(voiceSceneLink?.fingerprint===fingerprint){st.sid=voiceSceneLink.sceneId;st.shid=voiceSceneLink.shotId;render();return voiceSceneLink;}
 const body={slugline:heading,text:transcript+(direction?'\n\nVISUAL DIRECTION: '+direction:''),source_page:st.page};
 const added=await api(`/api/projects/${st.project.id}/scenes`,j('POST',body));
 st.project=added.project;
 const scene=st.project.scenes.at(-1),shot=scene?.shots?.[0];
 if(!shot)throw Error('Scene was created but has no shot. Use + Shot.');
 st.sid=scene.id;st.shid=shot.id;render();
 const edit=await api(path(),j('PATCH',{name:'Voice-directed establishing frame',
    description:(direction||transcript).slice(0,1600),style_preset:style}));
 update(edit);st.sid=scene.id;st.shid=shot.id;render();
 voiceSceneLink={fingerprint,sceneId:scene.id,shotId:shot.id};
 return voiceSceneLink;
}
$('voice-create').onclick=async()=>{const btn=$('voice-create');btn.disabled=true;
 try{busy(true,'Creating editable voice scene');await createSceneFromVoice();notify('Voice scene added to your book with three editable shots.');}
 catch(e){notify(e.message,true)}finally{busy(false);btn.disabled=false}
};
$('voice-render').onclick=async()=>{
 if(!$('voice-transcript').value.trim())return notify('Transcribe or enter an audio scene first.',true);
 if(!confirm('Generate one storyboard image with Meta Muse Image? This may use paid model credits.'))return;
 const btn=$('voice-render');btn.disabled=true;
 try{busy(true,'Creating voice scene and rendering Muse image');await createSceneFromVoice();
  const result=await api(path()+'/render',j('POST',{use_sketch:false}));
  update(result);tool('art');notify('Voice storyboard frame created. You can now edit it with SAM/Muse.');
 }catch(e){notify(e.message,true)}finally{busy(false);btn.disabled=false}
};

$('apply-grammar').onclick=async()=>{if(!currentScene())return;const g=$('grammar').value;if(!g)return notify('Choose a scene sequence.',true);try{busy(true,'Adding director pattern');const r=await api(`/api/projects/${st.project.id}/scenes/${st.sid}/shot-patterns/${g}`,{method:'POST'});update(r);notify('Draft sequence added. Adapt each shot to your screenplay.');}catch(e){notify(e.message,true)}finally{busy(false)}};
$('save-style').onclick=()=>saveShot({style_preset:$('styles').value,style_custom:$('style-custom').value});
$('muse').onclick=async()=>{if(!currentShot())return notify('Select a shot.',true);try{busy(true,'Muse Image generation');const r=await api(path(),j('PATCH',{style_preset:$('styles').value,style_custom:$('style-custom').value}));update(r);const result=await api(path()+'/render',j('POST',{use_sketch:true}));update(result);notify('Muse frame generated; review framing and continuity.');}catch(e){notify(e.message,true)}finally{busy(false)}};
$('revise').onclick=async()=>{if(st.busy)return;const sh=currentShot();if(!sh?.image_url)return notify('Generate or capture a frame first.',true);
 const choice=$('art-intent').value,raw=$('revision').value.trim(),obj=selectedSAM();
 const target=$('art-target').value.trim();
 if(choice!=='restyle'&&choice!=='custom'&&!obj)return notify('Detect and select the object using SAM first.',true);
 const verbs={remove:`Remove only the selected ${target||'object'}. Reconstruct its original background naturally.`,replace:`Replace only the selected ${target||'object'} with the following: ${raw}`,appearance:`Change the selected ${target||'character'} appearance: ${raw}`,pose:`Change the selected ${target||'character'} pose or emotion: ${raw}`,lighting:`Adjust the lighting on the selected ${target||'object'}: ${raw}`,restyle:`Restyle this entire frame: ${raw}`,custom:raw};
 const instruction=verbs[choice]||raw;
 if(instruction.length<8||(choice!=='remove'&&!raw))return notify('Describe the desired change in the instruction box.',true);
 try{busy(true,'Muse Image is editing this version');const before=sh.image_url;
 const r=await api(path()+'/muse-refine',j('POST',{instruction,target:obj?target:'',selected_box:obj?[obj.left,obj.top,obj.right,obj.bottom]:null,selection:obj||null,style_preset:$('styles').value,style_custom:$('style-custom').value}));
 update(r);st.compare={before,after:r.image_url};renderArtCompare();notify(`Muse edit saved. ${r.chained?'Continuing existing image conversation.':'New image-edit conversation started.'} You can ask again.`);
 }catch(e){notify(e.message,true)}finally{busy(false)}};
// SAM + Muse: one explicit source frame, visible mask, chosen instance and undoable versions.
function samReset(url){st.sam={source:url||null,objects:[],index:-1};$('sam-instances').replaceChildren(new Option('No selection',''));$('sam-status').textContent='Detect an object to see its mask.';}
function selectedSAM(){return st.sam?.objects?.[st.sam.index]||null;}
function updateSAMFrame(){
 const url=currentShot()?.image_url||null;
 if(st.sam.source!==url)samReset(url);
 const im=$('sam-view');im.hidden=!url;$('sam-empty').hidden=!!url;
 if(!url){$('sam-mask').getContext('2d').clearRect(0,0,$('sam-mask').width,$('sam-mask').height);return;}
 im.onload=()=>{const canvas=$('sam-mask');canvas.width=im.naturalWidth;canvas.height=im.naturalHeight;$('sam-stage').style.aspectRatio=`${im.naturalWidth}/${im.naturalHeight}`;drawSAMMask();};
 im.src=url+'?v='+(st.project?.revision||1);
}
function drawSAMMask(){
 const im=$('sam-view'),cv=$('sam-mask'),context=cv.getContext('2d');if(!im.naturalWidth)return;
 if(cv.width!==im.naturalWidth||cv.height!==im.naturalHeight){cv.width=im.naturalWidth;cv.height=im.naturalHeight;}
 context.clearRect(0,0,cv.width,cv.height);const obj=selectedSAM();if(!obj)return;
 const w=obj.mask_width,h=obj.mask_height;if(w*h>16_000_000){$('sam-status').textContent='Mask exceeds overlay limit.';return;}
 try{
  const raw=atob(obj.mask_base64);if(raw.length!==w*h)throw Error('Invalid mask');
  const tile=document.createElement('canvas');tile.width=w;tile.height=h;
  const c=tile.getContext('2d');const rgba=c.createImageData(w,h);
  for(let i=0;i<raw.length;i++){if(raw.charCodeAt(i)){const j=i*4;rgba.data[j]=54;rgba.data[j+1]=234;rgba.data[j+2]=221;rgba.data[j+3]=105}}
  c.putImageData(rgba,0,0);context.drawImage(tile,obj.left,obj.top,obj.right-obj.left,obj.bottom-obj.top);
  context.strokeStyle='#36eadd';context.lineWidth=Math.max(2,cv.width/550);context.setLineDash([12,8]);context.strokeRect(obj.left,obj.top,obj.right-obj.left,obj.bottom-obj.top);context.setLineDash([]);
 }catch(error){$('sam-status').textContent='Could not display selection mask: '+error.message;}
}
function renderArtCompare(){
 const image=currentShot()?.image_url,history=currentShot()?.history||[];
 const before=(st.compare?.after===image?st.compare.before:history.length>1?history[history.length-2].url:null)||image;
 const after=image;const stage=$('art-compare-stage');stage.hidden=!before||!after;
 if(!after)return;
 $('art-before').src=before;$('art-after').src=after;
 $('art-after').style.opacity=String(Number($('art-compare').value)/100);
}
// User refinement is deliberately bounded to the SAM ROI. Save only when the
// pointer stroke ends; no huge spread/apply argument lists (stack-safe).
let samBrush='inspect',samPaint=null;
function setSAMBrush(mode){samBrush=mode;$('sam-stage').dataset.brush=mode;
 for(const v of ['inspect','add','erase']){const b=$('sam-brush-'+v);b.classList.toggle('active',v===mode);b.setAttribute('aria-pressed',String(v===mode))}
}
for(const mode of ['inspect','add','erase'])$('sam-brush-'+mode).onclick=()=>setSAMBrush(mode);
function samStrokePoint(event){const obj=selectedSAM(),cv=$('sam-mask');if(!samPaint||!obj)return;
 const r=cv.getBoundingClientRect();if(r.width<1||r.height<1)return;
 const x=(event.clientX-r.left)*cv.width/r.width,y=(event.clientY-r.top)*cv.height/r.height;
 const mw=obj.mask_width,mh=obj.mask_height,scaleX=mw/(obj.right-obj.left),scaleY=mh/(obj.bottom-obj.top);
 const cx=(x-obj.left)*scaleX,cy=(y-obj.top)*scaleY;
 const radius=Math.max(1,Number($('sam-brush-size').value)*Math.max(scaleX,scaleY));
 const xmin=Math.max(0,Math.floor(cx-radius)),xmax=Math.min(mw-1,Math.ceil(cx+radius));
 const ymin=Math.max(0,Math.floor(cy-radius)),ymax=Math.min(mh-1,Math.ceil(cy+radius));
 for(let py=ymin;py<=ymax;py++)for(let px=xmin;px<=xmax;px++){
  if((px-cx)**2+(py-cy)**2<=radius*radius)samPaint[py*mw+px]=samBrush==='add'?1:0;
 }
}
function encodeBinaryMask(bytes){let text='';for(let i=0;i<bytes.length;i+=8192){let part='';for(let j=i;j<Math.min(i+8192,bytes.length);j++)part+=String.fromCharCode(bytes[j]);text+=part}return btoa(text)}
$('sam-mask').addEventListener('pointerdown',e=>{const obj=selectedSAM();if(!obj||samBrush==='inspect')return;
 samPaint=Uint8Array.from(atob(obj.mask_base64),c=>c.charCodeAt(0));e.currentTarget.setPointerCapture(e.pointerId);samStrokePoint(e)});
$('sam-mask').addEventListener('pointermove',e=>{if(samPaint)samStrokePoint(e)});
function endSAMStroke(){if(!samPaint)return;const obj=selectedSAM();if(obj){obj.mask_base64=encodeBinaryMask(samPaint);drawSAMMask();$('sam-status').textContent='Selection refined. Apply a local layer or Muse edit.'}samPaint=null}
$('sam-mask').addEventListener('pointerup',endSAMStroke);$('sam-mask').addEventListener('pointercancel',endSAMStroke);
$('art-compare').oninput=e=>{$('art-after').style.opacity=String(Number(e.target.value)/100)};
$('sam-detect').onclick=async()=>{const sh=currentShot(),url=sh?.image_url,target=$('art-target').value.trim();
 if(!url)return notify('Select a shot with an image. Create/capture one first.',true);
 if(target.length<2)return notify('Name one concrete visible object: woman, chair, cassette, etc.',true);
 try{busy(true,'SAM 3.1 identifying objects');const source=url;
 const result=await api('/api/segment',j('POST',{image_filename:url.split('/').at(-1),prompt:target}));
 if(currentShot()?.image_url!==source){notify('Frame changed during detection. Detect again.',true);return;}
 st.sam={source,objects:result.objects||[],index:(result.objects||[]).length?0:-1};
 const list=$('sam-instances');list.replaceChildren();if(!st.sam.objects.length){list.add(new Option('No matches',''));$('sam-status').textContent=result.message||'No match';return;}
 st.sam.objects.forEach((o,i)=>list.add(new Option(`${target} #${i+1}${o.confidence!=null?' · '+Math.round(o.confidence*100)+'%':''}`,String(i))));
 list.value='0';drawSAMMask();$('sam-status').textContent=`${st.sam.objects.length} instance(s) found · choose which to edit.`;
 }catch(e){notify(e.message,true);$('sam-status').textContent=e.message}finally{busy(false)}
};
$('sam-instances').onchange=e=>{st.sam.index=Number(e.target.value);drawSAMMask()};
$('sam-clear').onclick=()=>{samReset(currentShot()?.image_url);drawSAMMask()};
$('sam-stage-to-3d').onclick=async()=>{
 const shot=currentShot(),selection=selectedSAM();
 if(!shot?.image_url||!selection)return notify('Detect and select a character or prop with SAM first.',true);
 try{
  busy(true,'Creating movable character/object cutout');
  const response=await api(path()+'/sam-stage-cutout',j('POST',{source_filename:shot.image_url.split('/').at(-1),selection,operation:'isolate'}));
  if(currentShot()?.image_url!==response.source_frame)return notify('Shot changed during extraction. Select it again.',true);
  tool('set');await engine.show();
  engine.add('cutout',{url:response.cutout_url,filename:$('art-target').value.trim()||'SAM selected cutout'});
  notify('Cutout added to Cinema 3D. Move, rotate or scale it, then Save scene. It is 2.5D, not a rigged actor.');
 }catch(e){notify(e.message,true)}finally{busy(false)}
};
const samReplaceModes=new Set(['replace_subject','replace_background']);
const samTintModes=new Set(['target_tint','background_tint']);
const samHelp={erase_heal:'Removes a selected actor or prop by approximating nearby pixels. Complex backgrounds may need Muse.',erase_transparent:'Makes the selected region transparent; it does not reconstruct what was behind it.',isolate:'Keeps the selected actor or prop and removes the entire background.',replace_subject:'Upload a replacement subject image. This is a flat, mask-clipped composite; use Muse for realistic pose/lighting.',replace_background:'Upload a new environment image; the selected actor or object stays in place.',target_tint:'Change only the selected subject colour with the color picker.',background_tint:'Change the environment colour without recolouring the selected subject.'};
function updateSamEffectControls(){
 const operation=$('sam-operation').value;
 $('sam-tint-control').hidden=!samTintModes.has(operation);
 $('sam-replacement-control').hidden=!samReplaceModes.has(operation);
 $('sam-effect-help').textContent=samHelp[operation]||'Edits only the selected mask or its background. Successful changes remain in shot history.';
}
$('sam-operation').addEventListener('change',updateSamEffectControls);
updateSamEffectControls();
$('sam-apply').onclick=async()=>{const shot=currentShot(),obj=selectedSAM();if(!shot?.image_url||!obj)return notify('Detect and select an object with SAM first.',true);
 const before=shot.image_url,operation=$('sam-operation').value;
 try{
  let replacement_reference_id=null;
  if(samReplaceModes.has(operation)){
   const file=$('sam-replacement-file').files?.[0];
   if(!file)throw Error('Choose a replacement image first (PNG/JPG/WebP).');
   if(file.size>5*1024*1024)throw Error('Replacement pictures must be 5 MB or smaller.');
   const fd=new FormData();fd.append('file',file);
   busy(true,'Uploading replacement image');
   const uploaded=await api('/api/reference',{method:'POST',body:fd});
   replacement_reference_id=uploaded.reference_id;
  }
  busy(true,'Applying local pixel-mask operation');
  const result=await api(path()+'/sam-layer',j('POST',{source_filename:before.split('/').at(-1),selection:obj,operation,replacement_reference_id,tint:$('sam-tint').value}));
 update(result);st.compare={before,after:result.image_url};renderArtCompare();notify('Local SAM layer saved. No Muse Image credit used.');
 }catch(e){notify(e.message,true)}finally{busy(false)}
};
$('art-max').onclick=()=>{if($('book-wrap').dataset.layout==='studio'&&$('book-wrap').dataset.focus==='true')setLayout('book',false);else setLayout('studio',true);$('art-max').setAttribute('aria-pressed',String($('book-wrap').dataset.focus==='true'));};
$('art-intent').onchange=()=>{const choice=$('art-intent').value;
 const examples={remove:'Remove the selected item and reconstruct the background.',replace:'A brass key instead of the selected cassette.',appearance:'Change the coat to a dark green cotton jacket.',pose:'Have the actor turn toward the camera with a worried expression.',lighting:'Give the selected subject a warm rim light.',restyle:'Hand-painted watercolor with controlled brush grain and a soft palette.',custom:'Describe exactly what should change and what should remain untouched.'};
 $('revision').placeholder=examples[choice];
};
async function editRef(id,changes){const refs=clone(currentShot()?.references||[]),ref=refs.find(r=>r.reference_id===id);if(!ref)return;Object.assign(ref,changes);await saveShot({references:refs});}
async function removeRef(id){const refs=(currentShot()?.references||[]).filter(r=>r.reference_id!==id);await saveShot({references:refs});}
$('refs-scene').onclick=async()=>{if(!currentScene()||!currentShot())return notify('Select a scene and shot first.',true);
 const refs=currentShot().references||[];if(!refs.length)return notify('Upload references to this shot first.',true);
 try{busy(true,'Sharing character and environment references');const r=await api(`/api/projects/${st.project.id}/scenes/${st.sid}/references`,j('POST',{references:refs}));update(r);notify(`References applied to ${r.updated} shots in this scene.`)}catch(e){notify(e.message,true)}finally{busy(false)}
};
$('dialogue-apply').onclick=async()=>{const sh=currentShot();if(!sh?.image_url)return notify('Generate or save a frame before adding dialogue.',true);
 const text=$('dialogue-text').value.trim();if(!text)return notify('Enter the dialogue or caption first.',true);
 try{busy(true,'Typesetting dialogue');const r=await api(path()+'/dialogue',j('POST',{text,speaker:$('dialogue-speaker').value.trim(),style:$('dialogue-style').value,position:$('dialogue-position').value}));update(r);notify('Dialogue added as a new frame version.')}catch(e){notify(e.message,true)}finally{busy(false)}
};
$('refs-upload').onchange=async e=>{const fs=Array.from(e.target.files||[]),sh=currentShot();if(!sh)return notify('Select a shot first.',true);let refs=clone(sh.references||[]);if(fs.length+refs.length>8)return notify('Maximum 8 reference images per shot.',true);try{busy(true,'Uploading reference images');for(const f of fs){const fd=new FormData();fd.append('file',f);const r=await api('/api/reference',{method:'POST',body:fd});refs.push({reference_id:r.reference_id,role:refs.length?'location':'character',label:f.name.replace(/\.[^.]+$/,'').slice(0,80)||'Reference',instruction:''});
 const saved=await saveShot({references:refs});if(!saved)throw Error('Image uploaded but could not attach to shot. Check the request ID.');}
 notify(`${fs.length} reference image(s) added.`);}catch(e){notify(e.message,true)}finally{busy(false);e.target.value='';}};
function tool(mode){if(mode!=='set'&&$('tool-set')?.classList.contains('stage-maximized'))switchCinemaMax(false);st.tab=mode;const title={set:'3D Set / Camera',draw:'Drawing Canvas',art:'AI Art & References',director:'Muse Director / Story & Shot',voice:'Voice to Storyboard',frame:'Frame History'};if($('editor-mode-label'))$('editor-mode-label').textContent=title[mode]||'Editor';document.querySelector('.visual-leaf')?.setAttribute('data-editor',mode);for(const btn of document.querySelectorAll('[data-tab]')){const selected=btn.dataset.tab===mode;btn.classList.toggle('active',selected);btn.setAttribute('aria-selected',String(selected));}for(const name of ['set','draw','art','voice','director','frame'])$('tool-'+name).hidden=name!==mode;if(mode==='set')engine.show();if(mode==='draw')loadDrawing();if(mode==='art'){updateSAMFrame();renderArtCompare()}if(mode==='director'&&!st.directorPlan)directorShowSaved()}
document.querySelectorAll('[data-tab]').forEach(btn=>btn.onclick=()=>tool(btn.dataset.tab));
// First-run actions: navigate to existing tools, never trigger an accidental paid Meta call.
$('jump-import').onclick=()=>$('new-film').click();
$('jump-art').onclick=()=>{tool('art');$('tool-art').scrollIntoView({behavior:'smooth',block:'start'});};
$('jump-batch').onclick=()=>{$('full-film-tools').scrollIntoView({behavior:'smooth',block:'start'});};
$('download-film-top').onclick=()=>$('download-pack').click();
for(const btn of document.querySelectorAll('[data-inspect]'))btn.onclick=()=>{
 const section=$(btn.dataset.inspect);if(section){section.scrollIntoView({behavior:'smooth',block:'start'});}
};

// Original drawing canvas. Frame and composition are separate, versioned assets.
const dc=$('drawing'),ctx=dc.getContext('2d');let drawingId=null;
function whiteCanvas(){ctx.fillStyle='#fffdf5';ctx.fillRect(0,0,dc.width,dc.height);ctx.strokeStyle='#d4d0c6';ctx.strokeRect(30,30,dc.width-60,dc.height-60);}
function loadDrawing(){const sh=currentShot();if(!sh||drawingId===st.shid)return;resetSketchHistory();drawingId=st.shid;st.drawDirty=false;whiteCanvas();if(sh.sketch_url){const loadedId=st.shid,img=new Image();img.onload=()=>{if(st.shid!==loadedId)return;ctx.drawImage(img,0,0,dc.width,dc.height)};img.src=sh.sketch_url;}}
function dcPoint(e){const r=dc.getBoundingClientRect();return{x:(e.clientX-r.left)*dc.width/r.width,y:(e.clientY-r.top)*dc.height/r.height}}
// Director sketch tools: strokes and simple construction shapes with undo/redo.
let strokeStart=null,strokeBase=null,sketchUndo=[],sketchRedo=[];
const MAX_SKETCH_STATES=12;
function rememberSketch(){sketchUndo.push(dc.toDataURL('image/png'));if(sketchUndo.length>MAX_SKETCH_STATES)sketchUndo.shift();sketchRedo=[];}
function restoreSketch(snapshot){const image=new Image();image.onload=()=>{ctx.clearRect(0,0,dc.width,dc.height);ctx.drawImage(image,0,0);st.drawDirty=true};image.src=snapshot;}
function resetSketchHistory(){sketchUndo=[];sketchRedo=[];strokeStart=null;strokeBase=null;}
$('draw-undo').onclick=()=>{if(!sketchUndo.length)return;sketchRedo.push(dc.toDataURL('image/png'));restoreSketch(sketchUndo.pop())};
$('draw-redo').onclick=()=>{if(!sketchRedo.length)return;sketchUndo.push(dc.toDataURL('image/png'));restoreSketch(sketchRedo.pop())};
function shapeStroke(x,y){if(!strokeStart||!strokeBase)return;
 ctx.putImageData(strokeBase,0,0);ctx.beginPath();const dx=x-strokeStart.x,dy=y-strokeStart.y;
 const mode=$('draw-tool').value;
 if(mode==='line'){ctx.moveTo(strokeStart.x,strokeStart.y);ctx.lineTo(x,y)}
 else if(mode==='rectangle')ctx.rect(strokeStart.x,strokeStart.y,dx,dy);
 else if(mode==='ellipse')ctx.ellipse(strokeStart.x+dx/2,strokeStart.y+dy/2,Math.max(.1,Math.abs(dx)/2),Math.max(.1,Math.abs(dy)/2),0,0,Math.PI*2);
 ctx.stroke();
}
dc.addEventListener('pointerdown',e=>{if(!currentShot())return;rememberSketch();st.draw=true;st.drawDirty=true;dc.setPointerCapture(e.pointerId);const p=dcPoint(e);
 ctx.lineWidth=Number($('pen-width').value);ctx.strokeStyle=st.eraser?'#fffdf5':$('pen-color').value;
 ctx.lineCap='round';ctx.lineJoin='round';strokeStart=p;
 strokeBase=($('draw-tool').value==='pen'||st.eraser)?null:ctx.getImageData(0,0,dc.width,dc.height);
 ctx.beginPath();ctx.moveTo(p.x,p.y);if(!strokeBase){ctx.lineTo(p.x+.1,p.y+.1);ctx.stroke();}});
dc.addEventListener('pointermove',e=>{if(!st.draw)return;const p=dcPoint(e);if(strokeBase)shapeStroke(p.x,p.y);else{ctx.lineTo(p.x,p.y);ctx.stroke();}});
function finishStroke(){st.draw=false;strokeBase=null;strokeStart=null;ctx.closePath();}
dc.addEventListener('pointerup',finishStroke);dc.addEventListener('pointercancel',finishStroke);
$('erase').onclick=()=>{st.eraser=!st.eraser;$('erase').classList.toggle('active',st.eraser)};
$('clear-draw').onclick=()=>{if(confirm('Clear unsaved drawing?')){rememberSketch();whiteCanvas();st.drawDirty=true}};
$('draw-thirds').onchange=e=>$('drawing-stage').classList.toggle('show-thirds',e.target.checked);
$('draw-import').onchange=e=>{const f=e.target.files?.[0];if(!f)return;const url=URL.createObjectURL(f),img=new Image();img.onload=()=>{rememberSketch();whiteCanvas();const ratio=Math.min(dc.width/img.width,dc.height/img.height);const w=img.width*ratio,h=img.height*ratio;ctx.drawImage(img,(dc.width-w)/2,(dc.height-h)/2,w,h);URL.revokeObjectURL(url);st.drawDirty=true;};img.src=url;};
async function saveArtwork(blob,kind){if(!currentShot()||!blob)return;const fd=new FormData();fd.append('file',blob,'director-frame.png');fd.append('kind',kind);try{busy(true,'Saving original artwork');const r=await api(path()+'/artwork',{method:'POST',body:fd});st.drawDirty=false;drawingId=null;update(r);notify(kind==='frame'?'Frame saved.':'Sketch saved as an AI composition reference.');}catch(e){notify(e.message,true)}finally{busy(false)}}
const drawSave=kind=>dc.toBlob(blob=>saveArtwork(blob,kind),'image/png');$('sketch-save').onclick=()=>drawSave('sketch');$('drawing-frame').onclick=()=>drawSave('frame');
$('drawing-to-muse').onclick=()=>{dc.toBlob(async blob=>{await saveArtwork(blob,'sketch');tool('art');notify('Sketch saved as a composition guide. Choose a style and click Generate with Muse.');},'image/png')};
$('drawing-to-set').onclick=()=>{dc.toBlob(async blob=>{
  await saveArtwork(blob,'sketch');tool('set');await engine.show();
  await uploadEnvironmentMedia(new File([blob],'director-sketch.png',{type:'image/png'}));
 },'image/png')};

// Integrated cinematic previsualization: editable stage + Blender / Unreal glTF interchange.
// This is a portable Three.js stage, not native Blender or Unreal Engine rendering.
const engine={
 ready:false,objects:[],world:null,THREE:null,renderer:null,orbit:null,transform:null,camera:null,cameraPOV:null,mode:'orbit',
 meshes:new Map(),selected:null,dragging:null,undo:[],snapshotLimit:30,
 async init(){if(this.ready)return;const v=$('viewport');try{
  const T=await import('three');
  const [{OrbitControls},{GLTFLoader},{TransformControls},{GLTFExporter}]=await Promise.all([
   import('three/addons/controls/OrbitControls.js'),import('three/addons/loaders/GLTFLoader.js'),
   import('three/addons/controls/TransformControls.js'),import('three/addons/exporters/GLTFExporter.js')]);
  this.THREE=T;this.GLTFLoader=GLTFLoader;this.GLTFExporter=GLTFExporter;
  const scene=new T.Scene();this.world=scene;scene.background=new T.Color('#31414c');
  this.ambient=new T.HemisphereLight('#ffffff','#526e5d',1.5);scene.add(this.ambient);
  this.keyLight=new T.DirectionalLight('#fff3dc',3);this.keyLight.position.set(-4,8,5);scene.add(this.keyLight);
  this.fillLight=new T.DirectionalLight('#e4eafa',1.5);this.fillLight.position.set(4,3,2);scene.add(this.fillLight);
  this.rimLight=new T.DirectionalLight('#fff3dc',2);this.rimLight.position.set(1,5,-5);scene.add(this.rimLight);
  const floor=new T.Mesh(new T.PlaneGeometry(30,30),new T.MeshStandardMaterial({color:0x344b3d,roughness:1}));floor.rotation.x=-Math.PI/2;floor.name='Stage floor';scene.add(floor);this.floor=floor;
  this.grid=new T.GridHelper(30,30,0x718b6e,0x4c6252);this.grid.position.y=.013;scene.add(this.grid);
  const renderer=new T.WebGLRenderer({antialias:true,preserveDrawingBuffer:true,alpha:false});renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.5));renderer.outputColorSpace=T.SRGBColorSpace;
  this.renderer=renderer;v.replaceChildren(renderer.domElement);
  this.camera=new T.PerspectiveCamera(48,16/9,.1,200);this.camera.position.set(8,7,11);
  const orbit=new OrbitControls(this.camera,renderer.domElement);orbit.target.set(0,1,0);orbit.enableDamping=false;
  orbit.addEventListener('change',()=>this.draw());this.orbit=orbit;
  this.cameraPOV=new T.PerspectiveCamera(36,16/9,.1,200);
  this.topCamera=new T.OrthographicCamera(-6,6,6,-6,.1,150);this.topCamera.position.set(0,30,0);this.topCamera.up.set(0,0,-1);this.topCamera.lookAt(0,0,0);
  this.ray=new T.Raycaster();this.pointer=new T.Vector2();this.ground=new T.Plane(new T.Vector3(0,1,0),0);
  const transform=new TransformControls(this.camera,renderer.domElement);scene.add(transform.getHelper());this.transform=transform;
  transform.addEventListener('change',()=>this.draw());
  transform.addEventListener('dragging-changed',e=>{
   orbit.enabled=!e.value&&this.mode==='orbit';
   if(!e.value){this.commitTransform();}
  });
  renderer.domElement.addEventListener('pointerdown',e=>this.pointerDown(e));
  this.ready=true;
  new ResizeObserver(()=>this.resize()).observe(v);
  this.load(currentShot()?.camera||{});this.resize();
 }catch(e){console.error('Cinema editor failed',e);v.textContent='3D stage requires WebGL and access to the Three.js module CDN. Script, drawing and PDFs still work.';throw e;}},
 show(){if(!this._initPromise)this._initPromise=this.init().finally(()=>{this._initPromise=null});return this._initPromise.then(()=>{if(this.ready){requestAnimationFrame(()=>this.resize())}}).catch(e=>{console.warn('Cinema stage unavailable',e);});},
 load(saved){
  this.state={...validateCamera(saved),fps:clamp(saved.fps??24,1,240),aperture:clamp(saved.aperture??2.8,1,32)};
  this.lighting={...LIGHT_PRESETS.daylight,...(saved.lighting||{})};
  this.environment=saved.environment?{...saved.environment}:null;this._backdropVersion=(this._backdropVersion||0)+1;
  this.objects=(Array.isArray(saved.objects)?saved.objects:(saved.actors||[{name:'Actor A',x:-1,z:0},{name:'Actor B',x:1,z:0}]).map((a,i)=>({id:`actor-${i}`,kind:'actor',name:a.name||`Actor ${i+1}`,x:a.x||0,y:0,z:a.z||0,rot:0,scale:1}))).map(x=>({...x,color:x.color||'#a3aaac'}));
  this.selected=this.objects[0]?.id||null;
  $('camera-movement').value=currentShot()?.camera_movement||'Static';
  if(this.floor)this.floor.material.color.set(this.environment?.floor_color||'#344b3d');
  this.rebuild();this.sync();this.applyLighting();this.applyBackdrop();this.draw();
 },
 rebuild(){if(!this.ready)return;this.transform?.detach();
  for(const m of this.meshes.values()){this.world.remove(m);m.traverse(n=>{if(n.geometry)n.geometry.dispose?.();if(n.material){if(n.material.map)n.material.map.dispose?.();if(n.material.dispose)n.material.dispose();}})}
  this.meshes.clear();for(const obj of this.objects)this.addMesh(obj);this.syncList();
 },
 async addMesh(obj){if(!this.ready)return;const T=this.THREE;const holder=new T.Group();holder.userData.key=obj.id;holder.name=obj.name;
  const material=new T.MeshStandardMaterial({color:obj.color||'#a3aaac',roughness:.73});
  const part=(geometry,x,y,z,m=material)=>{const mesh=new T.Mesh(geometry,m);mesh.position.set(x,y,z);holder.add(mesh);return mesh};
  const box=(w,h,d,x,y,z)=>part(new T.BoxGeometry(w,h,d),x,y,z);
  if(obj.kind==='cutout'&&/^\/static\/generated\/shot-[0-9]+-[a-f0-9]{10}\.png$/.test(obj.image_url||'')){
   const tex=await new T.TextureLoader().loadAsync(obj.image_url);
   if(!this.objects.some(x=>x.id===obj.id)){tex.dispose();return;}
   tex.colorSpace=T.SRGBColorSpace;
   const ratio=tex.image?.width&&tex.image?.height?tex.image.width/tex.image.height:1;
   const height=2.2,width=Math.min(6,ratio*height);
   part(new T.PlaneGeometry(width,height),0,height/2,0,
      new T.MeshBasicMaterial({map:tex,transparent:true,side:T.DoubleSide,depthWrite:false}));
  }
  else if(obj.kind==='glb'&&obj.asset_id){try{const loader=new this.GLTFLoader();const item=await loader.loadAsync('/api/models/'+obj.asset_id);if(!this.objects.some(x=>x.id===obj.id))return;holder.add(item.scene);}catch(e){console.warn('GLB failed',e);box(1,1,1,0,.5,0);}}
  else if(obj.kind==='actor'){
   part(new T.CylinderGeometry(.23,.31,1.15,14),0,.85,0);
   part(new T.SphereGeometry(.22,16,12),0,1.64,0,new T.MeshStandardMaterial({color:'#e7ba91'}));
   box(.25,.13,.25,0,.08,-.25);
  }else if(obj.kind==='table'){
   box(1.6,.12,1.0,0,.78,0);for(const x of [-.7,.7])for(const z of [-.4,.4])box(.09,.75,.09,x,.37,z);
  }else if(obj.kind==='chair'){
   box(.6,.11,.6,0,.48,0);box(.6,.72,.1,0,.83,.28);for(const x of [-.25,.25])for(const z of [-.22,.22])box(.08,.43,.08,x,.23,z);
  }else if(obj.kind==='door'){
   box(1.1,2.2,.12,0,1.1,0);part(new T.SphereGeometry(.045),.4,1,.1,new T.MeshStandardMaterial({color:'#cfb46f'}));
  }else if(obj.kind==='window'){
   const frame=new T.MeshStandardMaterial({color:'#719db0',metalness:.2,roughness:.2,transparent:true,opacity:.65});
   part(new T.BoxGeometry(2,1.5,.08),0,1.5,0,frame);box(.08,1.7,.12,0,1.5,.02);box(2.2,.08,.12,0,1.5,.02);
  }else if(obj.kind==='bed'){
   box(2,.32,2.5,0,.38,0);box(2,.75,.12,0,.72,-1.2);
  }else if(['road','water','rail','stage','pier','bridge'].includes(obj.kind)){
   const dims={road:[2.5,.05,9],water:[12,.04,12],rail:[.4,.12,10],stage:[5,.45,3],pier:[2,.22,7],bridge:[4,.35,9]};const [w,h,d]=dims[obj.kind];
   part(new T.BoxGeometry(w,h,d),0,h/2-.03,0,new T.MeshStandardMaterial({color:obj.kind==='water'?'#297caa':obj.kind==='road'?'#44474c':obj.color,roughness:obj.kind==='water'?.25:.85,metalness:obj.kind==='water'?.2:0}));
  }else if(['tree','palm','plant'].includes(obj.kind)){
   const ht=obj.kind==='plant'?.75:obj.kind==='palm'?3.6:3;
   part(new T.CylinderGeometry(.10,.19,ht*.68,8),0,ht*.34,0,new T.MeshStandardMaterial({color:'#6b4c35'}));
   const foliage=new T.MeshStandardMaterial({color:obj.kind==='palm'?'#3f8e59':'#427850'});
   part(new T.ConeGeometry(obj.kind==='plant'?.45:1.15,ht*.65,9),0,ht*.8,0,foliage);
  }else if(obj.kind==='mountain'||obj.kind==='rock'){
   part(new T.ConeGeometry(obj.kind==='rock'?.8:2.5,obj.kind==='rock'?.85:5,6),0,obj.kind==='rock'?.45:2.5,0);
  }else if(['building','column'].includes(obj.kind)){
   const h=obj.kind==='building'?5.0:3.5;
   part(new T.BoxGeometry(obj.kind==='building'?3.0:.52,h,obj.kind==='building'?2.5:.52),0,h/2,0);
  }else if(['car','vehicle','boat','plane'].includes(obj.kind)){
   box(obj.kind==='boat'?2.7:1.8,.48,obj.kind==='boat'?1.0:3.0,0,.42,0);
   box(1.15,.6,1.2,0,.95,0);
  }else if(['streetlight','lamp'].includes(obj.kind)){
   const h=obj.kind==='streetlight'?4:1.6;
   part(new T.CylinderGeometry(.05,.08,h,10),0,h/2,0);
   part(new T.SphereGeometry(.23),0,h,0,new T.MeshStandardMaterial({color:'#fff4d1',emissive:'#ffc966',emissiveIntensity:.6}));
  }else if(['desk','counter','bench','sofa','seat'].includes(obj.kind)){
   const w=obj.kind==='counter'?2.5:obj.kind==='bench'?2:1.5;
   box(w,.18,.9,0,.75,0);box(.10,.7,.1,-w*.4,.34,0);box(.10,.7,.1,w*.4,.34,0);
   if(['sofa','seat'].includes(obj.kind))box(w,.95,.14,0,.95,-.45);
  }else if(['machine','crate','screen','sign','fence','curtain','umbrella','cloud'].includes(obj.kind)){
   const dims={machine:[1.6,1.8,1.2],crate:[.8,.8,.8],screen:[1.8,1,.08],sign:[1.5,.7,.12],fence:[3,1.1,.12],curtain:[2,2,.09],umbrella:[2,.14,2],cloud:[2,.8,.8]};
   const [w,h,d]=dims[obj.kind];box(w,h,d,0,obj.kind==='cloud'?4:h/2,0);
  }else{
   const geo=obj.kind==='sphere'?new T.SphereGeometry(.5,24,18):obj.kind==='cylinder'?new T.CylinderGeometry(.42,.42,1,20):
    obj.kind==='wall'?new T.BoxGeometry(4,2.8,.14):new T.BoxGeometry(1,1,1);
   part(geo,0,obj.kind==='wall'?1.4:.5,0);
  }
  holder.position.set(Number(obj.x)||0,Number(obj.y)||0,Number(obj.z)||0);holder.rotation.y=(Number(obj.rot)||0)*Math.PI/180;holder.scale.setScalar(Number(obj.scale)||1);
  this.world.add(holder);this.meshes.set(obj.id,holder);
  if(this.selected===obj.id)this.attachSelected();this.draw();
 },
 syncList(){const list=$('object-list');list.replaceChildren();for(const o of this.objects)list.add(new Option(`${o.kind.toUpperCase()} · ${o.name}`,o.id));
  if(!this.objects.some(x=>x.id===this.selected))this.selected=this.objects[0]?.id||null;
  list.value=this.selected||'';this.syncSelection();this.attachSelected();
 },
 syncSelection(){const o=this.objects.find(x=>x.id===this.selected);for(const [id,key] of [['obj-name','name'],['obj-x','x'],['obj-y','y'],['obj-z','z'],['obj-rot','rot'],['obj-scale','scale'],['obj-color','color']])$(id).value=o?.[key]??'';},
 attachSelected(){if(!this.transform)return;const obj=this.meshes.get(this.selected);if(obj&&this.mode==='orbit')this.transform.attach(obj);else this.transform.detach();this.draw();},
 sync(){for(const [id,key] of [['cam-x','x'],['cam-y','y'],['cam-z','z'],['cam-pan','pan'],['cam-tilt','tilt'],['cam-roll','roll'],['cam-lens','lens'],['cam-fps','fps'],['cam-aperture','aperture'],['cam-aspect','aspect']])$(id).value=this.state?.[key]??'';
  for(const [id,key] of [['light-key','key'],['light-fill','fill'],['light-rim','rim'],['light-color','color']])$(id).value=this.lighting[key];
  this.projection();
 },
 projection(){if(!this.ready)return;const s=this.state;
  this.cameraPOV.position.set(s.x,s.y,s.z);
  const pan=s.pan*Math.PI/180,tilt=s.tilt*Math.PI/180;
  this.cameraPOV.lookAt(s.x+Math.sin(pan)*Math.cos(tilt),s.y+Math.sin(tilt),s.z-Math.cos(pan)*Math.cos(tilt));
  this.cameraPOV.rotateZ(s.roll*Math.PI/180);
  this.cameraPOV.fov=cameraFov(s.lens);this.cameraPOV.aspect=aspectRatio(s.aspect);this.cameraPOV.updateProjectionMatrix();
  $('fov').textContent=`${s.lens} mm · H-FOV ${(2*Math.atan(36/(2*s.lens))*180/Math.PI).toFixed(1)}°`;
  $('stage-aspect-label').textContent=`${s.aspect} · ${s.lens} mm`;
  this.draw();
 },
 applyLighting(){if(!this.ready)return;
  const l=this.lighting;this.keyLight.intensity=clamp(l.key,0,10);this.fillLight.intensity=clamp(l.fill,0,10);
  this.rimLight.intensity=clamp(l.rim,0,10);this.ambient.intensity=clamp(l.ambient,0,10);
  this.keyLight.color.set(l.color||'#ffffff');this.rimLight.color.set(l.color||'#ffffff');if(!this.environment?.backdrop_reference_id&&!this.environment?.media_url)this.world.background=new this.THREE.Color(l.background||'#243a49');this.draw();
 },
 resize(){if(!this.ready)return;const r=$('viewport').getBoundingClientRect();const w=Math.max(250,Math.round(r.width)||250),h=Math.max(180,Math.round(r.height)||180);
  this.renderer.setSize(w,h,false);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.cameraPOV.aspect=aspectRatio(this.state.aspect);this.cameraPOV.updateProjectionMatrix();
  const a=w/h;this.topCamera.left=-9*a;this.topCamera.right=9*a;this.topCamera.top=9;this.topCamera.bottom=-9;this.topCamera.updateProjectionMatrix();this.draw();
 },
 draw(){if(!this.ready||this._drawing)return;this._drawing=true;try{
  const renderer=this.renderer,c=renderer.domElement;
  const W=Math.max(1,Math.round(c.getBoundingClientRect().width)),H=Math.max(1,Math.round(c.getBoundingClientRect().height));
  if(this.mode==='camera'){
   const ratio=aspectRatio(this.state.aspect);
   const rw=W/H;let vw=W,vh=H;if(rw>ratio)vw=Math.max(1,Math.floor(H*ratio));else vh=Math.max(1,Math.floor(W/ratio));
   const left=Math.floor((W-vw)/2),bottom=Math.floor((H-vh)/2);
   renderer.setViewport(0,0,W,H);renderer.setScissorTest(false);renderer.setClearColor('#05090b');renderer.clear(true,true,true);
   renderer.setViewport(left,bottom,vw,vh);renderer.setScissor(left,bottom,vw,vh);renderer.setScissorTest(true);
   renderer.render(this.world,this.cameraPOV);renderer.setScissorTest(false);renderer.setViewport(0,0,W,H);
  }else{
   renderer.setScissorTest(false);renderer.setViewport(0,0,W,H);
   renderer.render(this.world,this.mode==='plan'?this.topCamera:this.camera);
  }
 }finally{this._drawing=false;}},
 switchMode(mode){if(!this.ready)return;this.mode=mode;this.orbit.enabled=mode==='orbit';this.attachSelected();
  $('stage-view-label').textContent=mode==='camera'?'CAMERA VIEW':mode==='plan'?'ORTHOGRAPHIC TOP':'PERSPECTIVE';
  this.draw();
 },
 setTransform(mode){this.transform?.setMode(mode);if(this.transform){this.transform.setTranslationSnap($('stage-snap').checked?.5:null);this.transform.setRotationSnap($('stage-snap').checked?Math.PI/12:null);this.transform.setScaleSnap($('stage-snap').checked?.25:null)}},
 pointerRay(e){const r=this.renderer.domElement.getBoundingClientRect();this.pointer.set((e.clientX-r.left)*2/r.width-1,-(e.clientY-r.top)*2/r.height+1);this.ray.setFromCamera(this.pointer,this.mode==='plan'?this.topCamera:this.mode==='camera'?this.cameraPOV:this.camera);},
 pointerDown(e){if(this.mode==='camera'||this.transform?.dragging)return;this.pointerRay(e);const hits=this.ray.intersectObjects([...this.meshes.values()],true);
  if(!hits.length)return;let root=hits[0].object;while(root.parent&&root.userData.key===undefined)root=root.parent;
  if(!root.userData.key)return;this.selected=root.userData.key;this.syncList();this.draw();
 },
 commitTransform(){const mesh=this.meshes.get(this.selected),o=this.objects.find(x=>x.id===this.selected);if(!mesh||!o)return;
  o.x=+mesh.position.x.toFixed(3);o.y=+mesh.position.y.toFixed(3);o.z=+mesh.position.z.toFixed(3);o.rot=+(mesh.rotation.y*180/Math.PI).toFixed(2);o.scale=+mesh.scale.x.toFixed(3);
  this.syncSelection();this.draw();
 },
 moveSelected(){const o=this.objects.find(x=>x.id===this.selected);if(!o)return;
  for(const [k,id] of [['name','obj-name'],['x','obj-x'],['y','obj-y'],['z','obj-z'],['rot','obj-rot'],['scale','obj-scale'],['color','obj-color']])
   o[k]=['name','color'].includes(k)?$(id).value:(Number($(id).value)||0);
  o.scale=clamp(o.scale,.1,20);const mesh=this.meshes.get(o.id);
  if(mesh){mesh.name=o.name;mesh.position.set(o.x,o.y,o.z);mesh.rotation.y=o.rot*Math.PI/180;mesh.scale.setScalar(o.scale);
   if(o.kind!=='glb'&&o.kind!=='cutout')mesh.traverse(n=>{if(n.isMesh&&n.material?.color&&n.material.color.getHexString()!=='e7ba91')n.material.color.set(o.color||'#a3aaac')});}
  this.syncList();this.draw();
 },
 add(kind,model){if(!this.ready)return;const o={id:crypto.randomUUID(),kind,name:kind==='glb'?model.filename:kind==='cutout'?(model?.filename||'SAM staging cutout'):`${kind} ${this.objects.length+1}`,x:0,y:0,z:0,rot:0,scale:1,color:'#a3aaac',asset_id:model?.asset_id,asset_role:model?.role||'prop',...(kind==='cutout'?{image_url:model?.url}: {})};
  this.objects.push(o);this.selected=o.id;this.addMesh(o);this.syncList();
 },
 cameraToSelected(){const o=this.objects.find(x=>x.id===this.selected);if(!o)return;const dx=o.x-this.state.x,dy=o.y+1.1-this.state.y,dz=o.z-this.state.z;
  this.state.pan=Math.atan2(dx,-dz)*180/Math.PI;this.state.tilt=Math.atan2(dy,Math.hypot(dx,dz))*180/Math.PI;
  this.state={...this.state,...validateCamera(this.state)};this.sync();
 },
 populate(preset){for(const o of makeStageObjects(preset))this.objects.push(o);this.selected=this.objects.at(-1)?.id||this.selected;this.rebuild();},
 capture(){if(!this.ready)return Promise.resolve(null);const before=this.mode,gridWas=this.grid.visible;this.grid.visible=false;this.switchMode('camera');this.resize();return new Promise(resolve=>this.renderer.domElement.toBlob(blob=>{this.grid.visible=gridWas;this.switchMode(before);resolve(blob)},'image/png'));},
 async applyBackdrop(){
  if(!this.ready)return;
  const environment=this.environment||{};
  const legacyId=environment.backdrop_reference_id;
  const mediaUrl=environment.media_url || (legacyId?`/api/reference/${encodeURIComponent(legacyId)}/preview`:null);
  const type=environment.media_kind||'image';
  const sequence=++this._backdropVersion;
  if(this._backgroundVideo){this._backgroundVideo.pause();this._backgroundVideo.removeAttribute('src');this._backgroundVideo.load();this._backgroundVideo=null;}
  this._backdropTexture?.dispose();this._backdropTexture=null;
  if(!mediaUrl){this.world.background=new this.THREE.Color(this.lighting.background||'#31414c');this.draw();return}
  if(!/^\/api\/(environment-media\/[a-f0-9]{32}|reference\/[a-f0-9]{32}\/preview)$/.test(mediaUrl)&&
     !/^\/static\/generated\/shot-[0-9]+-[a-f0-9]{10}\.(png|jpg|webp)$/.test(mediaUrl)){
   console.warn('Rejected unsafe environment URL');return;
  }
  try{
    let texture;
    if(type==='video'){
      const video=document.createElement('video');video.src=mediaUrl;video.crossOrigin='same-origin';video.muted=true;
      video.loop=true;video.playsInline=true;video.autoplay=true;video.preload='metadata';
      await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error('Video load timeout')),15000);
        video.addEventListener('loadeddata',()=>{clearTimeout(timeout);resolve()}, {once:true});
        video.addEventListener('error',()=>{clearTimeout(timeout);reject(Error('Video cannot be decoded'))},{once:true});
        video.load();});
      if(sequence!==this._backdropVersion){video.pause();return;}
      texture=new this.THREE.VideoTexture(video);this._backgroundVideo=video;
      // Videos are user-provided backplates. Silent looping playback is browser-safe.
      video.play().catch(()=>console.info('Video playback requires a user gesture'));
      const videoTick=()=>{if(this._backgroundVideo!==video||!this.ready)return;
        if(!document.hidden&&!video.paused)this.draw();requestAnimationFrame(videoTick)};
      requestAnimationFrame(videoTick);
    }else texture=await new this.THREE.TextureLoader().loadAsync(mediaUrl);
    if(sequence!==this._backdropVersion){texture.dispose();return;}
    texture.colorSpace=this.THREE.SRGBColorSpace;this._backdropTexture=texture;
    this.world.background=texture;this.draw();
    $('environment-media-status').textContent=type==='video'?'Moving background ready. Save scene to preserve it.':'Environment reference ready. Save scene to preserve it.';
  }catch(e){console.warn('Environment image/video unavailable',e);
    if(sequence===this._backdropVersion){this.world.background=new this.THREE.Color(this.lighting.background||'#31414c');this.draw();$('environment-media-status').textContent=e.message;}
  }
 },
 setEnvironment(env,preserveActors=true){
  if(!this.ready)throw new Error('Start the 3D viewport first');
  const actors=preserveActors?this.objects.filter(o=>o.kind==='actor'||o.asset_role==='character'):[];
  this.objects=[...actors,...env.objects];this.selected=this.objects[0]?.id||null;
  const backdrop={media_id:this.environment?.media_id,media_url:this.environment?.media_url,
    media_kind:this.environment?.media_kind,media_name:this.environment?.media_name,
    backdrop_reference_id:this.environment?.backdrop_reference_id};
  this.environment={id:env.id,label:env.label,category:env.category,floor_color:env.background||'#cfebe6',...backdrop};
  this.lighting={...(LIGHT_PRESETS[env.mood]||LIGHT_PRESETS.daylight)};this.floor.material.color.set(env.background||'#cfebe6');
  this.rebuild();this.applyLighting();this.applyBackdrop();this.sync();
 },
 clearEnvironment(preserveActors=true){this.objects=preserveActors?this.objects.filter(o=>o.kind==='actor'||o.asset_role==='character'):[];
  this.environment=null;this.floor?.material.color.set('#344b3d');this.rebuild();this.applyBackdrop();},
 serialize(){return {...this.state,lighting:{...this.lighting},environment:this.environment?{...this.environment}:null,objects:this.objects.map(o=>({...o})),actors:this.objects.filter(o=>o.kind==='actor').map(({name,x,z})=>({name,x,z}))};},
 async exportGLB(){if(!this.ready)return;const T=this.THREE,out=new T.Scene();out.name='FramePilot Cinema Stage';
  for(const item of this.meshes.values())out.add(item.clone(true));
  out.add(this.cameraPOV.clone());const light=this.keyLight.clone();light.name='Camera key light';out.add(light);
  const exporter=new this.GLTFExporter();const file=await new Promise((resolve,reject)=>exporter.parse(out,resolve,reject,{binary:true,onlyVisible:true}));
  downloadBlob(new Blob([file],{type:'model/gltf-binary'}),'framepilot-set.glb');
 }
};
function downloadBlob(blob,filename){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200)}
const cinemaPresentation=createCinemaPresentation({
  stage:$('tool-set'),button:$('stage-max'),root:document.documentElement,
  body:document.body,view:window,
  refresh:()=>requestAnimationFrame(()=>engine.resize())
});
function switchCinemaMax(force){
  const shouldEnable=force??!cinemaPresentation.isMaximized();
  if(shouldEnable && st.tab!=='set')tool('set');
  cinemaPresentation.set(shouldEnable);
  if(shouldEnable)requestAnimationFrame(()=>engine.show());
}
$('stage-max').onclick=()=>switchCinemaMax();
$('stage-blocking-map').onclick=async()=>{
 if(!engine.ready)return notify('Open the Cinema 3D stage first.',true);
 const before=engine.mode;
 try{engine.grid.visible=true;engine.switchMode('plan');engine.draw();
  const blob=await new Promise(resolve=>engine.renderer.domElement.toBlob(resolve,'image/png'));
  if(blob)downloadBlob(blob,`framepilot-blocking-scene-${currentScene()?.number||1}.png`);
  notify('Director blocking map downloaded.');
 }finally{engine.switchMode(before);engine.grid.visible=$('stage-grid').checked;engine.draw()}
};

$('stage-toggle-inspector').onclick=()=>{const hide=$('tool-set').classList.toggle('inspector-collapsed');$('stage-toggle-inspector').textContent=hide?'Show inspector':'Hide inspector';requestAnimationFrame(()=>engine.resize())};
for(const b of document.querySelectorAll('[data-add]'))b.onclick=()=>engine.add(b.dataset.add);
// Organic authoring replaces the legacy procedural catalogue. The scene remains
// editable: Muse proposes bounded *data*, never Blender code or executable tools.
let environmentProposal=null;
$('environment-clear').onclick=()=>{
 if(!engine.ready)return notify('Open Cinema 3D first.',true);
 if(!confirm('Start an empty set? The current unsaved stage geometry will be replaced.'))return;
 engine.clearEnvironment($('environment-preserve-actors').checked);
 environmentProposal=null;$('environment-approve').disabled=true;
 $('environment-plan-preview').textContent='Empty stage ready. Add primitives, import GLB, or describe a new scene.';
 notify('Empty stage created. Save scene to keep it.');
};
$('environment-reset-camera').onclick=()=>{
 if(!engine.ready)return notify('Open Cinema 3D first.',true);
 engine.state={...engine.state,x:0,y:1.7,z:8,pan:0,tilt:0,roll:0,lens:35};engine.sync();engine.draw();
 notify('Camera reset to eye level. Save the scene to keep it.');
};
$('environment-plan').onclick=async()=>{
 const brief=$('environment-scene-brief').value.trim();
 if(brief.length<12)return notify('Describe the location and visual intent in a little more detail.',true);
 if(!st.project||!currentShot())return notify('Select a film and shot before designing the set.',true);
 const button=$('environment-plan');button.disabled=true;button.textContent='Planning…';
 environmentProposal=null;$('environment-approve').disabled=true;
 $('environment-plan-preview').textContent='Muse Spark is drafting a set and camera plan…';
 try{
  busy(true,'Muse designing editable 3D blocking');
  const result=await api('/api/director/plan',j('POST',{
   project_id:st.project.id,scene_id:st.sid,shot_id:st.shid,
   mode:'muse',focus:'blocking',direction:'Design an original editable 3D film set with motivated blocking. '+brief
  }));
  environmentProposal={...result,key:`${st.sid}:${st.shid}`};
  const objects=buildEditableSetFromPlan(result.proposal,()=>crypto.randomUUID());
  const summary=describeEditableSet(objects);
  $('environment-plan-preview').textContent=`${result.proposal.concept} · ${summary}. ${result.proposal.rationale||''}`;
  $('environment-approve').disabled=objects.length===0;
  if(!objects.length)notify('Muse suggested no objects. Clarify your set description or add GLB assets.',true);
 }catch(e){
  $('environment-plan-preview').textContent='Set proposal unavailable. You can still create a blank set or import your own 3D assets.';
  notify(e.message,true);
 }finally{busy(false);button.disabled=false;button.textContent='✦ Propose 3D blocking';}
};
$('environment-approve').onclick=()=>{
 const currentKey=`${st.sid}:${st.shid}`;
 if(!environmentProposal||environmentProposal.key!==currentKey)return notify('Request a proposal for the selected shot.',true);
 if(!engine.ready)return notify('Open Cinema 3D first.',true);
 const plan=environmentProposal.proposal;
 const objects=buildEditableSetFromPlan(plan,()=>crypto.randomUUID());
 if(!objects.length)return notify('No objects were proposed.',true);
 if(!confirm(`Place ${objects.length} editable 3D proxies on the stage? Existing set objects will be replaced. Save the shot afterward.`))return;
 engine.setEnvironment({id:'original-muse-set',category:'custom',label:plan.concept,mood:'daylight',background:'#cfebe6',objects},$('environment-preserve-actors').checked);
 for(const [key,value] of Object.entries(plan.camera||{})){if(value!=null&&key in engine.state)engine.state[key]=value;}
 engine.state=validateCamera(engine.state);engine.sync();engine.draw();
 $('environment-approve').disabled=true;notify('Original 3D blocking placed. Inspect, adjust and Save scene.');
};
async function uploadEnvironmentMedia(file){
 if(!file)return;
 if(!engine.ready)return notify('Open Cinema 3D before importing a background.',true);
 const fd=new FormData();fd.append('file',file);
 try{busy(true,'Importing environment media');const media=await api('/api/environment-media',{method:'POST',body:fd});
   engine.environment={...(engine.environment||{}),media_id:media.media_id,media_url:media.url,
                       media_kind:media.kind,backdrop_reference_id:null,media_name:media.filename};
   await engine.applyBackdrop();notify(`Imported ${media.kind} background. Click Save scene to keep it.`);
 }catch(error){notify(error.message,true)}finally{busy(false)}
}
$('environment-image').onchange=async e=>{await uploadEnvironmentMedia(e.target.files?.[0]);e.target.value=''};
$('environment-video').onchange=async e=>{await uploadEnvironmentMedia(e.target.files?.[0]);e.target.value=''};
$('environment-remove-media').onclick=async()=>{if(!engine.ready)return;
 engine.environment={...(engine.environment||{}),media_url:null,media_kind:null,media_id:null,backdrop_reference_id:null};
 await engine.applyBackdrop();notify('Environment background removed. Save scene to keep this change.');
};
$('environment-generate').onclick=async()=>{if(!engine.ready)return notify('Open Cinema 3D first.',true);
 const description=$('environment-prompt').value.trim();if(description.length<12)return notify('Describe the setting, lighting and art treatment.',true);
 if(!confirm('Generate one environment image with Muse? This may consume a paid model call.'))return;
 try{busy(true,'Muse creating environment');const r=await api('/api/storyboard',j('POST',{
  scene_title:'Director environment concept',style_preset:'photoreal',
  visual_style:'cinematic environment concept art',
  shot:{shot_number:1,shot_type:'Wide establishing shot',camera_angle:'Eye level',camera_movement:'Static',
   visual_description:description,beat:'Environment design',director_purpose:'3D stage background',
   image_prompt:'ONE EMPTY FILM SET BACKGROUND, no people or words. '+description},
  scene_summary:'Environment reference image for a filmmaker.'}));
  engine.environment={...(engine.environment||{}),media_url:r.image_url,media_kind:'image',backdrop_reference_id:null};
  await engine.applyBackdrop();notify('Muse environment attached as a visual background. Save scene to keep it.');
 }catch(e){notify(e.message,true)}finally{busy(false)}
};
async function showBlenderCapabilities(){
 try{const info=await api('/api/models/capabilities');
  const message=info.blend?'Blender conversion ready · .blend and .glb supported':
   !info.blend_enabled?'GLB supported · to import .blend, enable FRAMEPILOT_ENABLE_LOCAL_BLEND=1 in local .env and restart':
   'GLB supported · install Blender and restart FramePilot to import .blend';
  $('blend-status').textContent=message;
  return info;
 }catch(e){$('blend-status').textContent='GLB supported · Blender conversion status unavailable';return null;}
}
async function importEnvironmentGLB(file,role){if(!file)return;
 if(file.name.toLowerCase().endsWith('.blend')){
  const capabilities=await showBlenderCapabilities();
  if(!capabilities?.blend)return notify($('blend-status').textContent,true);
 }
 const fd=new FormData();fd.append('file',file);
 try{busy(true,'Importing 3D '+role+(file.name.toLowerCase().endsWith('.blend')?' · converting with local Blender':' '));const r=await api('/api/models',{method:'POST',body:fd});
  if(!engine.ready)throw Error('Open 3D Set before importing GLB.');
  engine.add('glb',{...r,role});notify('Blender '+role+' imported. Move or scale it, then Save scene.');
 }catch(e){notify(e.message,true)}finally{busy(false)}
}
$('environment-model').onchange=async e=>{await importEnvironmentGLB(e.target.files?.[0],$('model-role').value);e.target.value=''};
$('stage-create').onclick=()=>{if(!engine.ready)return notify('Load 3D first',true);engine.populate($('stage-preset').value);notify('Stage objects added. Save shot blocking to keep them.')};
$('object-list').onchange=e=>{engine.selected=e.target.value;engine.syncSelection();engine.attachSelected()};
for(const id of ['obj-name','obj-x','obj-y','obj-z','obj-rot','obj-scale','obj-color'])$(id).addEventListener('change',()=>engine.moveSelected());
$('duplicate-object').onclick=()=>{const o=engine.objects.find(x=>x.id===engine.selected);if(!o)return;const c={...o,id:crypto.randomUUID(),name:o.name+' copy',x:o.x+1};engine.objects.push(c);engine.selected=c.id;engine.addMesh(c);engine.syncList()};
$('remove-object').onclick=()=>{engine.objects=engine.objects.filter(o=>o.id!==engine.selected);engine.rebuild()};
$('camera-target').onclick=()=>engine.cameraToSelected();
for(const [id,k] of [['cam-x','x'],['cam-y','y'],['cam-z','z'],['cam-pan','pan'],['cam-tilt','tilt'],['cam-roll','roll'],['cam-lens','lens'],['cam-fps','fps'],['cam-aperture','aperture'],['cam-aspect','aspect']])
 $(id).addEventListener('change',()=>{if(!engine.ready)return;engine.state={...engine.state,[k]:k==='aspect'?$(id).value:Number($(id).value)};
 engine.state={...engine.state,...validateCamera(engine.state)};engine.sync();});
$('cam-preset').onchange=()=>{const preset=CAMERA_PRESETS[$('cam-preset').value];if(!preset||!engine.ready)return;
 engine.state={...engine.state,...validateCamera({...engine.state,...preset})};engine.sync();engine.switchMode('camera');document.querySelector('[data-view="camera"]').click()};
$('stage-monitor-lock').onchange=()=>{$('tool-set').classList.toggle('monitor-unlocked',!$('stage-monitor-lock').checked);requestAnimationFrame(()=>engine.resize());};
$('stage-grid').onchange=()=>{if(engine.grid){engine.grid.visible=$('stage-grid').checked;engine.draw()}};
$('stage-snap').onchange=()=>engine.setTransform(document.querySelector('[data-transform].active')?.dataset.transform||'translate');
$('stage-safe').onchange=()=>{$('safe-guide').hidden=!$('stage-safe').checked};
for(const [id,k] of [['light-key','key'],['light-fill','fill'],['light-rim','rim'],['light-color','color']])$(id).addEventListener('change',()=>{if(!engine.ready)return;engine.lighting[k]=k==='color'?$(id).value:clamp($(id).value,0,10);engine.applyLighting()});
$('light-preset').onchange=()=>{if(!engine.ready)return;engine.lighting={...LIGHT_PRESETS[$('light-preset').value]};engine.applyLighting();engine.sync()};
for(const b of document.querySelectorAll('[data-transform]'))b.onclick=()=>{for(const v of document.querySelectorAll('[data-transform]'))v.classList.toggle('active',v===b);engine.setTransform(b.dataset.transform)};
for(const b of document.querySelectorAll('[data-view]'))b.onclick=()=>{for(const v of document.querySelectorAll('[data-view]'))v.classList.toggle('active',v===b);engine.switchMode(b.dataset.view)};
const saveCinema=()=>{if(!engine.ready)return notify('3D stage unavailable',true);return saveShot({camera:engine.serialize(),lens_mm:Math.round(engine.state.lens),camera_movement:$('camera-movement').value})};
$('save-set').onclick=saveCinema;$('stage-save').onclick=saveCinema;
$('capture-frame').onclick=async()=>{const blob=await engine.capture();if(!blob)return notify('3D stage unavailable',true);await saveArtwork(blob,'frame')};
$('stage-export-json').onclick=()=>{if(!engine.ready)return notify('3D stage unavailable',true);downloadBlob(new Blob([JSON.stringify(makeShotManifest(engine.state,engine.objects,engine.lighting),null,2)],{type:'application/json'}),'framepilot-cinema-scene.json')};
$('stage-export-glb').onclick=async()=>{try{await engine.exportGLB();notify('Portable GLB exported for Blender / Unreal import.')}catch(e){notify('GLB export failed: '+e.message,true)}};
$('model-upload').onchange=async e=>{await importEnvironmentGLB(e.target.files?.[0],'prop');e.target.value=''};
await loadSelections();await loadIndex();tool('set');showBlenderCapabilities();

// Workstation modes: readable book, full script, or maximized director's studio.
const viewportRoot=$('book-wrap');
let lastMode='book';
function setLayout(mode,focus=false){
 if(!['book','script','studio'].includes(mode))mode='book';
 if(mode!=='studio' && cinemaPresentation.isMaximized())switchCinemaMax(false);
 viewportRoot.dataset.layout=mode;viewportRoot.dataset.focus=String(Boolean(focus));
 for(const b of document.querySelectorAll('[data-layout]')){
  const selected=b.dataset.layout===mode;b.classList.toggle('active',selected);b.setAttribute('aria-pressed',String(selected));
 }
 $('focus-stage').textContent=focus?'↙ Leave focus':'⛶ Focus editor';
 $('focus-stage').setAttribute('aria-pressed',String(Boolean(focus)));
 if(mode==='studio'&&st.tab==='set')requestAnimationFrame(()=>engine.show());
 if(mode==='studio'&&st.tab==='draw')requestAnimationFrame(()=>loadDrawing());
}
document.querySelectorAll('.view-choice').forEach(b=>b.addEventListener('click',()=>setLayout(b.dataset.layout)));
// On phones, show the six creative tools first; the script remains one tap away.
if(window.matchMedia?.('(max-width: 680px)').matches)setLayout('studio',false);
$('focus-stage').onclick=()=>{
 if(viewportRoot.dataset.focus==='true')setLayout(lastMode,false);
 else{lastMode=viewportRoot.dataset.layout;setLayout('studio',true)}
};
$('view-zoom').addEventListener('change',e=>{
 const factor=Math.min(1.75,Math.max(.8,Number(e.target.value)/100));
 viewportRoot.style.setProperty('--page-zoom',String(factor));
 viewportRoot.style.setProperty('--preview-zoom',String(factor));
});
const previewBox=$('frame-lightbox');
function closePreview(){previewBox.hidden=true;}
$('frame-open').onclick=()=>{
 const url=currentShot()?.image_url||currentShot()?.sketch_url;
 if(!url)return notify('There is no frame yet. Use Draw or Capture Frame.',true);
 $('frame-lightbox-img').src=url;
 $('frame-lightbox-title').textContent=`${currentScene()?.slugline||'Scene'} · ${currentShot()?.name||'Shot'}`;
 previewBox.hidden=false;
};
$('frame-close').onclick=closePreview;
previewBox.addEventListener('click',e=>{if(e.target===previewBox)closePreview()});
document.addEventListener('keydown',e=>{
 const inEditor=['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName);
 if(e.key==='Escape'){if($('tool-set').classList.contains('stage-maximized'))switchCinemaMax(false);closePreview();if(viewportRoot.dataset.focus==='true')setLayout(lastMode,false);return}
 if(inEditor||e.ctrlKey||e.metaKey||e.altKey)return;
 if(st.tab==='set'&&engine.ready){
  if(e.key.toLowerCase()==='f'){switchCinemaMax();return}
  if(['g','r','s'].includes(e.key.toLowerCase())){const t={g:'translate',r:'rotate',s:'scale'}[e.key.toLowerCase()];document.querySelector(`[data-transform="${t}"]`)?.click();return}
  if(e.key.toLowerCase()==='c'){$('tool-set').querySelector('[data-view="camera"]')?.click();return}
  if(e.key==='Delete'&&engine.selected){$('remove-object').click();return}
 }
 if(e.key==='1')setLayout('book');if(e.key==='2')setLayout('script');if(e.key==='3')setLayout('studio');
 if(e.key==='ArrowLeft')changePage(st.page-1);if(e.key==='ArrowRight')changePage(st.page+1);
});

// v0.9 — durable batch generation. A frame is generated and saved individually;
// the page remains usable while the server processes the remaining shots.
let batchTimer=null,activeBatch=null,lastBatchSync=0;
function dock(job){const ui=$('generation-dock');ui.hidden=false;
 $('job-title').textContent=job.state==='running'?'Generating selected shots':job.state==='queued'?'Waiting for a generation worker':'Generation '+job.state.replaceAll('_',' ');
 $('job-progress').max=job.total||1;$('job-progress').value=job.completed||0;
 $('job-counter').textContent=`${job.completed} / ${job.total} frames · ${job.failures} failed`;
 const eta=job.estimated_remaining_seconds;
 if(eta!=null&&['running','queued'].includes(job.state))$('job-title').textContent=`Rendering · ${job.done} frames ready · ~${Math.ceil(eta/60)} min remaining (rough estimate)`;
 else if(['running','queued'].includes(job.state))$('job-title').textContent=`Rendering · ${job.done} frames ready — starting with scene previews`;
 const latest=job.results?.at(-1);$('job-status').textContent=latest?`${latest.ok?'✓':'⚠'} ${latest.message}`:'The first frame is being prepared…';
 const active=['queued','running','cancel_requested'].includes(job.state);
 $('job-cancel').hidden=!active;$('job-cancel').disabled=job.state==='cancel_requested';
 $('job-retry-failed').hidden=active||!(job.failures>0);$('job-retry-failed').disabled=active;
 $('job-dismiss').hidden=active;
 $('generate-page').disabled=active;$('generate-scene').disabled=active;
}
async function watchBatch(id){clearTimeout(batchTimer);try{
 const job=await api(`/api/jobs/${id}`);activeBatch=job;dock(job);
 if(job.done>0 && st.project?.id===job.project_id && job.done!==lastBatchSync){
   lastBatchSync=job.done;
   try{const fresh=await api(`/api/projects/${job.project_id}`);mergeRenderProgress(fresh);}catch(e){console.warn('Could not refresh completed frames',e)}
 }
 if(['queued','running','cancel_requested'].includes(job.state)){
  batchTimer=setTimeout(()=>watchBatch(id),1300);
 }else{
  try{if(st.project?.id===job.project_id){const r=await api(`/api/projects/${job.project_id}`);mergeRenderProgress(r);}}catch(e){console.warn(e)}
  localStorage.removeItem('framepilot-current-job');
  notify(job.state==='completed'?`All ${job.done} frames saved.`:`Batch finished: ${job.done} saved; ${job.failures} failed. Check the dock.`,job.failures>0);
 }
 }catch(e){$('job-status').textContent=e.message;if(/^40[14] —/.test(e.message)){localStorage.removeItem('framepilot-current-job');$('job-cancel').hidden=true;$('job-dismiss').hidden=false;activeBatch=null;}else batchTimer=setTimeout(()=>watchBatch(id),4000);}
}
async function planEntireBook(){
 if(!st.project)return notify('Import or open a screenplay first.',true);
 if(st.drafts.has(`${st.project.id}:${st.page}`)&&!(await savePage()))return null;
 try{busy(true,'Creating editable shots for every screenplay beat');
  const r=await api(`/api/projects/${st.project.id}/plan-entire-book`,{method:'POST'});
  update(r);const c=r.coverage;
  $('book-coverage').textContent=`${c.total_shots.toLocaleString()} editable shot drafts across ${c.scenes} scenes. No Meta calls were made.`;
  notify(`${c.total_shots} drafts are ready (${c.added} new). No Meta credits used.`);
  return c;
 }catch(e){notify(e.message,true);return null}finally{busy(false)}
}
$('plan-book').onclick=()=>planEntireBook();
async function queueBatch(scope){
 if(!st.project)return notify('Open a film first.',true);
 if(activeBatch&&['queued','running','cancel_requested'].includes(activeBatch.state))return notify('A generation job is already running for this film.',true);
 if(scope==='book'){if(!(await planEntireBook()))return;}
 const coverage=(scope==='scene'||scope==='page')?'all':$('batch-coverage').value,style_preset=$('batch-style').value||null;
 const style_custom=style_preset?$('batch-custom').value.trim():'';
 const workers=Number($('batch-workers').value);
 const req={project_id:st.project.id,scope,page:st.page,scene_id:st.sid,skip_rendered:true,
           coverage,style_preset,style_custom,workers};
 try{
  const params=new URLSearchParams({project_id:req.project_id,scope:req.scope,skip_rendered:'true',coverage,workers:String(workers)});
  if(style_preset){params.set('style_preset',style_preset);params.set('style_custom',style_custom);}
  if(scope==='page')params.set('page',String(st.page));
  if(scope==='scene')params.set('scene_id',st.sid);
  const estimate=await api(`/api/jobs/estimate?${params}`);
  const count=estimate.model_calls;
  if(!count)return notify('All shots in this selection already have images. Nothing to render.');
  const selection=coverage==='first_12'?'first draft frame of up to 12 scenes':coverage==='scene_first'?'one draft frame per scene':'every unfinished shot';
  const styleName=style_preset?$('batch-style').selectedOptions[0]?.textContent:'the style saved on each shot';
  const message=`Generate ${count} ${selection} images from this ${scope}?\nStyle: ${styleName}\n\nMuse Image may bill for each returned image. Rendering is not instantaneous and may be throttled by provider limits. Stop affects shots not yet started. Continue?`;
  if(!confirm(message))return;
  if(scope==='book')req.confirmed_count=count;
  const job=await api('/api/jobs/generate',j('POST',req));
  localStorage.setItem('framepilot-current-job',job.id);
  activeBatch=job;dock(job);watchBatch(job.id);
  notify(`Queued ${count} images. Draft frames remain editable while the job runs.`);
 }catch(e){notify(e.message,true)}
}
$('generate-page').onclick=()=>queueBatch('page');
$('generate-scene').onclick=()=>queueBatch('scene');
$('generate-book').onclick=()=>queueBatch('book');
$('job-cancel').onclick=async()=>{if(!activeBatch)return;
 try{const job=await api(`/api/jobs/${activeBatch.id}/cancel`,{method:'POST'});dock(job);notify('Stop requested. An image already being generated may still finish.');}catch(e){notify(e.message,true)}
};
$('job-retry-failed').onclick=async()=>{
 if(!activeBatch?.failures)return notify('No failed frames to retry.');
 if(!confirm(`Retry ${activeBatch.failures} failed frame requests? Meta may bill for retried calls. Successful frames will not be regenerated.`))return;
 try{const job=await api(`/api/jobs/${activeBatch.id}/retry-failed`,{method:'POST'});
  localStorage.setItem('framepilot-current-job',job.id);activeBatch=job;dock(job);watchBatch(job.id);
  notify('Failed frames queued for an explicit retry. Original results are preserved.');
 }catch(e){notify(e.message,true)}
};
$('job-dismiss').onclick=()=>{$('generation-dock').hidden=true;activeBatch=null};
const recoverId=localStorage.getItem('framepilot-current-job');if(recoverId)watchBatch(recoverId);

// v0.12 — Director's Room. Muse Spark proposes typed film changes, never commands.
const directorExamples={
 character:'Introduce this character through silhouette and framing before showing their face. Establish a memorable visual trait and a clear eyeline.',
 dialogue:'Stage the two speakers with a readable 180-degree axis. Begin with a master, then motivate a tighter emotional reverse angle.',
 romance:'Create an intimate, consent-aware romance beat with expressive blocking, soft motivated lighting and a slow push-in.',
 fight:'Make the choreography spatially readable. Use a wide master, motivated camera movement, clear stunt safety distances and sound cues.',
 suspense:'Build suspense through negative space and a delayed reveal. Maintain continuity of light, props and screen direction.',
 interval:'Design a bold interval reveal with a clear silhouette, visual setup and payoff, and an impactful sound bridge.',
 climax:'Convey the protagonist\'s final emotional choice through clear composition, a motivated lens shift and decisive blocking.',
 montage:'Plan a concise visual montage with distinct action beats, matching eyelines and coherent transitions.'
};
for(const btn of document.querySelectorAll('[data-director-prompt]'))btn.addEventListener('click',()=>{
 $('director-direction').value=directorExamples[btn.dataset.directorPrompt]||'';
 $('director-direction').focus();
});
function directorClear(){
 st.directorPlan=null;st.directorApplied=false;
 if(!$('director-preview'))return;
 $('director-preview').hidden=true;$('director-empty').hidden=false;
 $('director-source').textContent='NO PLAN YET';
}
function directorShowSaved(){
 const sh=currentShot(),notes=sh?.director_notes;
 if(!notes?.concept){directorClear();return}
 $('director-empty').hidden=true;$('director-preview').hidden=false;
 $('director-source').textContent='SAVED DIRECTOR PASS';
 $('director-concept').textContent=notes.concept;
 $('director-rationale').textContent=notes.rationale||'';
 $('director-shot').textContent=`${sh.shot_type||'Shot'} · ${sh.duration_s||5}s`;
 $('director-camera').textContent=`${sh.camera?.lens||sh.lens_mm||35}mm · ${sh.camera_movement||'Static'}`;
 $('director-assets').textContent=`${(sh.camera?.objects||[]).length} stage objects · ${(sh.director_guides||[]).length} sketch guides`;
 $('director-lighting').textContent=notes.lighting||'';
 $('director-sound').textContent=notes.sound||'';
 const ul=$('director-checks');ul.replaceChildren();for(const note of notes.continuity||[]){const li=document.createElement('li');li.textContent=note;ul.append(li)}
 $('director-safety').textContent=notes.safety||'';
 $('director-apply').disabled=true;
}
function directorDisplay(result){
 const p=result.proposal;
 $('director-empty').hidden=true;$('director-preview').hidden=false;
 $('director-source').textContent=result.source;
 $('director-concept').textContent=p.concept;
 $('director-rationale').textContent=p.rationale||'';
 $('director-shot').textContent=`${p.shot.shot_type||currentShot()?.shot_type||'Shot'} · ${p.shot.duration_s||currentShot()?.duration_s||5}s`;
 $('director-camera').textContent=`${p.camera.lens||currentShot()?.lens_mm||35}mm · ${p.shot.camera_movement||'Static'}`;
 $('director-assets').textContent=`${p.add_objects.length} set objects · ${p.drawing_guides.length} sketch guides`;
 $('director-lighting').textContent=p.lighting||'Use motivated set lighting.';
 $('director-sound').textContent=p.sound||'Record clean dialogue and room tone.';
 const ul=$('director-checks');ul.replaceChildren();for(const note of p.continuity||[]){const li=document.createElement('li');li.textContent=note;ul.append(li)}
 $('director-safety').textContent=p.safety||'';
 $('director-apply').disabled=false;
}
$('director-generate').onclick=async()=>{
 const sh=currentShot();if(!st.project||!sh)return notify('Choose a film and a shot before asking the director.',true);
 const direction=$('director-direction').value.trim();if(direction.length<8)return notify('Describe the shot intention in at least eight characters.',true);
 const btn=$('director-generate');btn.disabled=true;btn.textContent='◌ Developing shot plan…';
 const begun=Date.now();const ticker=setInterval(()=>{if(st.busy){const sec=Math.round((Date.now()-begun)/1000);$('task-hint').textContent=`Planning ${sec}s elapsed · waiting for Muse. The result will be reviewable before applying.`;}},4000);
 try{busy(true,'Muse Director planning this shot');
  const result=await api('/api/director/plan',j('POST',{
   project_id:st.project.id,scene_id:st.sid,shot_id:st.shid,direction,
   mode:$('director-mode').value,focus:$('director-focus').value}));
  st.directorPlan={...result,key:`${st.sid}:${st.shid}`};st.directorApplied=false;
  directorDisplay(result);notify(result.source?.startsWith('Offline recovery')?'Muse returned an unusable plan. A safe offline draft is ready for review; no edits were applied.':'Shot treatment ready to review. No edits have been applied.',Boolean(result.source?.startsWith('Offline recovery')));
 }catch(e){notify(e.message,true)}finally{clearInterval(ticker);busy(false);btn.disabled=false;btn.textContent='✦ Propose shot improvements'}
};
$('director-apply').onclick=async()=>{
 const proposal=st.directorPlan;if(!proposal||proposal.key!==`${st.sid}:${st.shid}`)return notify('Request a proposal for this shot.',true);
 if(!confirm('Apply the recommended shot details, camera settings and new stage objects? The last AI application can be undone.'))return;
 const btn=$('director-apply');btn.disabled=true;
 try{busy(true,'Applying approved director shot plan');
  const result=await api('/api/director/apply',j('POST',{project_id:st.project.id,scene_id:st.sid,
   shot_id:st.shid,expected_revision:st.project.revision,proposal:proposal.proposal}));
  st.directorApplied=true;update(result);
  notify('Director changes saved. Open 3D Set to inspect the camera and objects.');
 }catch(e){notify(e.message,true)}finally{busy(false);btn.disabled=false}
};
$('director-undo').onclick=async()=>{
 if(!currentShot())return;
 try{busy(true,'Restoring previous director revision');
  const r=await api('/api/director/undo',j('POST',{project_id:st.project.id,scene_id:st.sid,
   shot_id:st.shid,expected_revision:st.project.revision}));
  update(r);st.directorApplied=false;notify('Previous director setup restored.');
 }catch(e){notify(e.message,true)}finally{busy(false)}
};
$('director-draw').onclick=async()=>{
 const proposal=st.directorPlan;
 const guides=(proposal?.key===`${st.sid}:${st.shid}`?proposal.proposal.drawing_guides:currentShot()?.director_guides)||[];if(!guides.length)return notify('This proposal has no drawing guides.',true);
 tool('draw');loadDrawing();
 // Wait for the existing sketch to finish loading before adding vector guides.
 const existing=currentShot()?.sketch_url;
 if(existing)await new Promise(resolve=>{const im=new Image();im.onload=resolve;im.onerror=resolve;im.src=existing;});
 rememberSketch();ctx.save();ctx.lineWidth=5;ctx.setLineDash([14,9]);ctx.font='bold 21px Segoe UI, sans-serif';
 for(const g of guides){const x=g.x1*dc.width,y=g.y1*dc.height,w=(g.x2-g.x1)*dc.width,h=(g.y2-g.y1)*dc.height;
  ctx.beginPath();ctx.strokeStyle=g.color;ctx.fillStyle=g.color;
  if(g.kind==='line'){ctx.moveTo(x,y);ctx.lineTo(x+w,y+h)}
  else if(g.kind==='rectangle')ctx.rect(x,y,w,h);
  else if(g.kind==='ellipse')ctx.ellipse(x+w/2,y+h/2,Math.max(.2,Math.abs(w/2)),Math.max(.2,Math.abs(h/2)),0,0,Math.PI*2);
  ctx.stroke();if(g.label)ctx.fillText(g.label,x+8,Math.max(24,y-10),240);
 }
 ctx.restore();st.drawDirty=true;
 notify('Composition guides added to the sketch. Save sketch to preserve them.');
};
$('director-copy-brief').onclick=async()=>{
 const scene=currentScene(),shot=currentShot();
 if(!scene||!shot)return notify('Choose a shot first.',true);
 const brief=`FramePilot Muse Code development brief (review before running):\nFilm: ${st.project.title}\nScene: ${scene.slugline}\nShot: ${shot.name}\nGoal: ${$('director-direction').value.trim()||'Improve film pre-production tools'}\nDo not access private screenplay assets or API credentials. Propose code changes and tests before editing.`;
 try{await navigator.clipboard.writeText(brief);notify('Muse Code development brief copied. Use only inside your trusted local project terminal.');}
 catch(e){notify('Clipboard unavailable in this browser. Copy the direction text manually.',true)}
};
$('director-direction').addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key==='Enter'){$('director-generate').click();e.preventDefault()}});

// v0.9 — account experience. This is a self-hosted profile, not SaaS cloud sync.
let accountMode='local',accountUser=null;
async function loadAccount(){try{
 const r=await api('/api/auth/me');accountMode=r.mode;accountUser=r.user;
 $('sync-indicator').textContent=accountMode==='accounts'?(accountUser?`● ${accountUser.name} · server saved`:'○ Sign in to save'):'● Local projects';
 $('account-message').textContent=accountMode==='accounts'?(accountUser?`Signed in as ${accountUser.name} (${accountUser.email}). Your films are private to this account on this server.`:'Sign in or create an account. Projects are saved on this server.'):'Local-only mode. To enable profiles set FRAMEPILOT_AUTH_MODE=accounts in .env and restart FramePilot.';
 $('auth-form').hidden=accountMode!=='accounts'||!!accountUser;$('account-logout').hidden=!accountUser||accountMode!=='accounts';
 $('profile-form').hidden=accountMode!=='accounts'||!accountUser;
 if(accountUser)$('profile-name').value=accountUser.name;
 }catch(e){$('account-message').textContent=e.message;}
}
$('account-open').onclick=async()=>{$('account-modal').hidden=false;await loadAccount()};
$('account-close').onclick=()=>{$('account-modal').hidden=true};
$('auth-form').onsubmit=async e=>{e.preventDefault();try{
 const r=await api('/api/auth/login',j('POST',{email:$('account-email').value,password:$('account-password').value}));
 accountUser=r.user;window.location.reload();
 }catch(err){notify(err.message,true)}};
$('account-register').onclick=async()=>{try{
 const result=await api('/api/auth/register',j('POST',{email:$('account-email').value,password:$('account-password').value,name:$('account-name').value}));
 if(result.user){notify('Account created and signed in. Opening private workspace…');window.location.reload();}
 else notify('Account created. Sign in to continue.');
 }catch(err){notify(err.message,true)}};
$('account-logout').onclick=async()=>{try{await api('/api/auth/logout',{method:'POST'});window.location.reload();}catch(err){notify(err.message,true)}};

$('profile-form').onsubmit=async e=>{e.preventDefault();try{
 const newName=$('profile-name').value.trim();
 if(!newName)throw Error('Enter your display name.');
 const result=await api('/api/auth/profile',j('PATCH',{name:newName}));
 accountUser=result.user;await loadAccount();notify('Profile updated on this server.');
 }catch(err){notify(err.message,true)}};

loadAccount();

window.addEventListener('pagehide',()=>{if(cinemaPresentation.isMaximized())cinemaPresentation.set(false)});
