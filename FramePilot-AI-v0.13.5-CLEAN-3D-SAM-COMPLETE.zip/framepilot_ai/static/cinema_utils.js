/** Pure cinematography math / presets. Unit: metres, degrees, full-frame 36x24 mm. */
export const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,Number.isFinite(Number(v))?Number(v):lo));
export const aspectRatio=(name='16:9')=>({ '16:9':16/9,'2.39:1':2.39,'4:3':4/3,'1:1':1,'9:16':9/16 })[name] || 16/9;
export const cameraFov=(lens=35)=>2*Math.atan(24/(2*clamp(lens,12,350)))*180/Math.PI;
export const CAMERA_PRESETS={
 'establishing':{x:0,y:2.8,z:10,pan:0,tilt:-8,lens:24,roll:0},
 'wide':{x:0,y:1.65,z:7.5,pan:0,tilt:-2,lens:28,roll:0},
 'medium':{x:0,y:1.6,z:4.2,pan:0,tilt:0,lens:50,roll:0},
 'close':{x:0,y:1.6,z:2.5,pan:0,tilt:0,lens:85,roll:0},
 'low':{x:0,y:0.5,z:5,pan:0,tilt:12,lens:35,roll:0},
 'high':{x:0,y:3.5,z:6,pan:0,tilt:-20,lens:35,roll:0},
 'dutch':{x:0,y:1.7,z:5,pan:0,tilt:-2,lens:35,roll:16},
 'over-shoulder':{x:-1.1,y:1.65,z:2.5,pan:13,tilt:-2,lens:65,roll:0},
 'top-down':{x:0,y:8,z:0.2,pan:0,tilt:-88,lens:28,roll:0},
};
export const LIGHT_PRESETS={
 'daylight':{key:3,fill:1.5,rim:2,ambient:1.5,color:'#fff3dc',background:'#31414c'},
 'noir':{key:3.2,fill:0.15,rim:1.1,ambient:.18,color:'#dfeaff',background:'#10151a'},
 'golden-hour':{key:3.7,fill:.8,rim:2.2,ambient:.75,color:'#ffb36b',background:'#483424'},
 'moonlight':{key:1.5,fill:.3,rim:1.1,ambient:.45,color:'#93b7ff',background:'#0f1c32'},
 'interrogation':{key:4.8,fill:.2,rim:.4,ambient:.18,color:'#e9e4ce',background:'#111719'},
 'romance':{key:1.7,fill:1.3,rim:2.1,ambient:1.1,color:'#ffd9b5',background:'#4c3143'},
 'stage':{key:3.0,fill:2,rim:1.4,ambient:1.1,color:'#ffffff',background:'#1b252b'},
};
export const STAGE_PRESETS={
 'blank':[],
 'interrogation':[
  ['table','Interview table',0,0,0,0],['chair','Suspect chair',0,0,1.3,180],['chair','Detective chair',0,0,-1.3,0],
  ['wall','Back wall',0,0,-4,0],['door','Exit door',-3.6,0,-3.9,0],['actor','Detective',-0.6,0,-1.4,0],['actor','Suspect',.6,0,1.4,180]],
 'cafe':[
  ['table','Cafe table',0,0,0,0],['chair','Chair A',-1.1,0,0,90],['chair','Chair B',1.1,0,0,-90],
  ['window','Street window',0,0,-4,0],['actor','Lead',-1.1,0,0,90],['actor','Partner',1.1,0,0,-90]],
 'street':[
  ['wall','Storefront',0,0,-5,0],['door','Entrance',2,0,-4.8,0],['box','Vehicle marker',-2,0,-1.2,0],
  ['actor','Character A',-1,0,1.5,0],['actor','Character B',1.5,0,-.7,0]],
 'bedroom':[
  ['bed','Bed',-1.4,0,-1.7,0],['table','Side table',.8,0,-2.5,0],['window','Window',2.2,0,-4,0],
  ['door','Door',-3.5,0,-3.8,0],['actor','Character',1,0,0,0]],
 'fight':[
  ['box','Obstacle',-2,0,0,0],['table','Breakaway table',2,0,-1,0],
  ['actor','Fighter A',-1.3,0,1.2,45],['actor','Fighter B',1.3,0,-.6,-45]],
};
export const makeStageObjects=(preset,idFactory=()=>crypto.randomUUID())=>(STAGE_PRESETS[preset]||[]).map(([kind,name,x,y,z,rot])=>({id:idFactory(),kind,name,x,y,z,rot,scale:1,color:'#a3aaac'}));
export const validateCamera=(input={})=>({
 x:clamp(input.x??0,-100,100),y:clamp(input.y??1.65,.05,60),z:clamp(input.z??5.7,-100,100),
 pan:clamp(input.pan??0,-360,360),tilt:clamp(input.tilt??-3,-89,89),roll:clamp(input.roll??0,-60,60),
 lens:clamp(input.lens??35,12,350),aspect:['16:9','2.39:1','4:3','1:1','9:16'].includes(input.aspect)?input.aspect:'16:9'
});
export function makeShotManifest(camera,objects,lighting){return {format:'FramePilot.Scene.v1',units:'metres',upAxis:'Y',camera:validateCamera(camera),objects:structuredClone(objects),lighting:{...lighting}}}
