/** Integrated 3D ShotLab. Metres, full-frame lens, camera viewpoint, floor plan. */
import * as THREE from 'three';
import {focalToVerticalFov,aimDirection,cameraSide,crossed180Line} from './geometry.js';
const $=id=>document.getElementById(id);
const container=$('set-viewport');
let renderer,scene,setCamera,topCamera,viewCamera,mode='set',rig,actorsGroup,actorMeshes=[],world;
const def={x:0,y:1.65,z:5.7,pan:0,tilt:-3,lens:35,actors:[{name:'Actor A',x:-1,z:0},{name:'Actor B',x:1,z:0}]};
const state={...structuredClone(def)};
const clone=v=>JSON.parse(JSON.stringify(v));
const deg=v=>v*Math.PI/180;
function makeBox(x,y,z,w,h,d,color){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshStandardMaterial({color,roughness:.85}));mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;scene.add(mesh);return mesh;}
function init(){
 renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));renderer.setClearColor('#18231d');renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.shadowMap.enabled=true;container.replaceChildren(renderer.domElement);
 scene=new THREE.Scene();scene.background=new THREE.Color('#1b2922');scene.fog=new THREE.Fog('#1b2922',18,50);
 scene.add(new THREE.AmbientLight(0xf8ecdb,1.7));const light=new THREE.DirectionalLight(0xffcc99,2.2);light.position.set(2,7,4);light.castShadow=true;scene.add(light);
 const ground=new THREE.Mesh(new THREE.PlaneGeometry(12,9),new THREE.MeshStandardMaterial({color:'#344439',roughness:1}));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
 const grid=new THREE.GridHelper(12,12,'#94a48d','#50685c');grid.position.y=.008;scene.add(grid);
 makeBox(0,1.8,-4.5,12,3.6,.12,'#4f5f51');makeBox(-6,1.8,0,.12,3.6,9,'#47574a');
 makeBox(0,.65,.2,2,.1,1.3,'#836b51');for(const x of [-.85,.85])for(const z of [-.35,.75])makeBox(x,.32,z,.08,.63,.08,'#7e684f');
 for(let n=-4;n<5;n+=2)makeBox(n,1.9,-4.3,.05,2.2,.06,'#829186');
 rig=new THREE.Group();const body=new THREE.Mesh(new THREE.BoxGeometry(.45,.26,.3),new THREE.MeshStandardMaterial({color:'#cbad7c',metalness:.55,roughness:.4}));rig.add(body);
 const lens=new THREE.Mesh(new THREE.CylinderGeometry(.1,.1,.26,16),new THREE.MeshStandardMaterial({color:'#161b1b'}));lens.rotation.x=Math.PI/2;lens.position.z=-.28;rig.add(lens);scene.add(rig);
 actorsGroup=new THREE.Group();scene.add(actorsGroup);
 setCamera=new THREE.PerspectiveCamera(45,16/9,.1,90);setCamera.position.set(8,8,10);setCamera.lookAt(0,1,0);
 topCamera=new THREE.OrthographicCamera(-8,8,4.5,-4.5,.1,100);topCamera.position.set(0,22,0);topCamera.up.set(0,0,-1);topCamera.lookAt(0,0,0);
 viewCamera=new THREE.PerspectiveCamera(35,16/9,.1,120);
 window.addEventListener('resize',resize);new ResizeObserver(resize).observe(container);
 renderer.domElement.addEventListener('pointerdown',onPointerDown);renderer.domElement.addEventListener('pointermove',onPointerMove);window.addEventListener('pointerup',()=>dragging=null);
 rebuildActors();recalc();resize();}
function rebuildActors(){if(!actorsGroup)return;actorsGroup.clear();actorMeshes=[];state.actors.forEach((actor,i)=>{const g=new THREE.Group();g.position.set(actor.x,0,actor.z);const colors=['#bba77f','#92b9b5','#c89183','#b8b0c5','#aeb18d'];const color=colors[i%colors.length];const torso=new THREE.Mesh(new THREE.CylinderGeometry(.24,.29,1.1,12),new THREE.MeshStandardMaterial({color}));torso.position.y=.9;torso.userData.index=i;g.add(torso);const head=new THREE.Mesh(new THREE.SphereGeometry(.22,16,12),new THREE.MeshStandardMaterial({color:'#e5cba7'}));head.position.y=1.64;head.userData.index=i;g.add(head);const marker=new THREE.Mesh(new THREE.ConeGeometry(.18,.34,4),new THREE.MeshStandardMaterial({color:'#d5b77e'}));marker.position.set(0,.1,-.38);marker.rotation.x=Math.PI/2;marker.userData.index=i;g.add(marker);actorsGroup.add(g);actorMeshes.push({g,meshes:[torso,head,marker]});});}
function recalc(){if(!renderer)return;rig.position.set(state.x,state.y,state.z);const dir=aimDirection(state.pan,state.tilt);rig.lookAt(state.x+dir.x,state.y+dir.y,state.z+dir.z);viewCamera.position.set(state.x,state.y,state.z);viewCamera.lookAt(state.x+dir.x,state.y+dir.y,state.z+dir.z);viewCamera.fov=focalToVerticalFov(state.lens);viewCamera.updateProjectionMatrix();
const s=window.__fpShotIndex;const prior=window.__fpPriorCam;let notice='';if(prior&&state.actors.length>=2){const p=cameraSide(state.actors[0],state.actors[1],prior);const q=cameraSide(state.actors[0],state.actors[1],state);notice=crossed180Line(p,q)?' · 180° LINE CROSSING':' · AXIS HELD';}
$('fov-info').textContent=`FULL FRAME H-FOV ${(2*Math.atan(36/(2*state.lens))*180/Math.PI).toFixed(1)}°${notice}`;render();}
function resize(){if(!renderer)return;const w=Math.max(container.clientWidth,280),h=Math.max(container.clientHeight,220);renderer.setSize(w,h,false);setCamera.aspect=w/h;setCamera.updateProjectionMatrix();viewCamera.aspect=w/h;viewCamera.updateProjectionMatrix();const a=w/h;topCamera.left=-7*a;topCamera.right=7*a;topCamera.top=7;topCamera.bottom=-7;topCamera.updateProjectionMatrix();render();}
function render(){if(!renderer)return;renderer.render(scene,mode==='plan'?topCamera:mode==='camera'?viewCamera:setCamera);}
function emit(){window.dispatchEvent(new CustomEvent('fp-camera-ready',{detail:clone(state)}));}
function switchMode(next){mode=next==='camera'?'camera':next==='plan'?'plan':'set';rig.visible=mode!=='camera';render();}
let dragging=null;const ray=new THREE.Raycaster();const plane=new THREE.Plane(new THREE.Vector3(0,1,0),0);const pointer=new THREE.Vector2();
function setRay(e){const r=renderer.domElement.getBoundingClientRect();pointer.x=((e.clientX-r.left)/r.width)*2-1;pointer.y=-((e.clientY-r.top)/r.height)*2+1;ray.setFromCamera(pointer,mode==='plan'?topCamera:setCamera);}
function onPointerDown(e){if(mode==='camera')return;setRay(e);const hits=ray.intersectObjects(actorMeshes.flatMap(x=>x.meshes),false);if(hits.length){dragging=hits[0].object.userData.index;renderer.domElement.setPointerCapture(e.pointerId);}}
function onPointerMove(e){if(dragging===null)return;setRay(e);const where=new THREE.Vector3();if(ray.ray.intersectPlane(plane,where)){state.actors[dragging].x=Math.max(-5.7,Math.min(5.7,+where.x.toFixed(2)));state.actors[dragging].z=Math.max(-4.2,Math.min(4.2,+where.z.toFixed(2)));actorMeshes[dragging].g.position.set(state.actors[dragging].x,0,state.actors[dragging].z);render();emit();}}
function load(payload){const c=payload.camera||{};for(const k of ['x','y','z','pan','tilt','lens'])state[k]=Number.isFinite(Number(c[k]))?Number(c[k]):def[k];state.actors=Array.isArray(c.actors)&&c.actors.length?c.actors.map((a,i)=>({name:String(a.name||`Actor ${i+1}`).slice(0,50),x:Number(a.x)||0,z:Number(a.z)||0})):clone(def.actors);window.__fpShotIndex=payload.shotId;window.__fpPriorCam=payload.priorCamera||null;rebuildActors();recalc();emit();}
window.FramePilot3D={captureState:()=>clone(state),captureImage:()=>new Promise(resolve=>{if(!renderer)return resolve(null);render();renderer.domElement.toBlob(blob=>resolve(blob),'image/png');})};
window.addEventListener('fp-shot-changed',e=>{const c=e.detail;load(c);});
window.addEventListener('fp-show-geometry',()=>{resize();});
window.addEventListener('fp-geometry-update',e=>{for(const k of ['x','y','z','pan','tilt','lens'])if(Number.isFinite(e.detail[k]))state[k]=e.detail[k];recalc();});
window.addEventListener('fp-view',e=>switchMode(e.detail));
window.addEventListener('fp-actor-add',()=>{if(state.actors.length>=8)return;state.actors.push({name:`Actor ${state.actors.length+1}`,x:0,z:0});rebuildActors();recalc();emit();});
window.addEventListener('fp-actor-remove',e=>{state.actors.splice(e.detail.index,1);rebuildActors();recalc();emit();});
window.addEventListener('fp-actor-move',e=>{const {index,axis,value}=e.detail;if(!state.actors[index]||!Number.isFinite(value))return;state.actors[index][axis]=Math.max(-6,Math.min(6,value));rebuildActors();recalc();});
try{init();}catch(e){console.error('ShotLab renderer unavailable',e);container.innerHTML='<div class="load-hint">3D preview could not start. WebGL support and an internet connection to load Three.js are required. The script, drawing, AI and PDF features remain available.</div>';}
