"""Environment image/video security, tenant isolation, and workstation UI contract."""
import io
import base64
from pathlib import Path
from PIL import Image
from fastapi.testclient import TestClient
from app.main import app
from app import auth, environment_media as media


def png():
    out=io.BytesIO()
    Image.new('RGB',(40,28),'#6789ab').save(out,format='PNG')
    return out.getvalue()


def test_images_are_private_and_validated(tmp_path,monkeypatch):
    monkeypatch.setattr(auth,'DB',tmp_path/'accounts.sqlite3')
    monkeypatch.setattr(media,'MEDIA_DIR',tmp_path/'private_media')
    media.MEDIA_DIR.mkdir()
    monkeypatch.setattr(auth,'AUTH_MODE','local')
    c=TestClient(app)
    r=c.post('/api/environment-media',files={'file':('forest.png',png(),'image/png')})
    assert r.status_code==201,r.text
    data=r.json();assert data['kind']=='image' and data['url'].startswith('/api/environment-media/')
    result=c.get(data['url']);assert result.status_code==200 and result.content==png()
    assert result.headers['cache-control'].startswith('private')
    assert c.post('/api/environment-media',files={'file':('fake.png',b'not a png','image/png')}).status_code==422
    assert c.post('/api/environment-media',files={'file':('model.glb',b'glTFxxxx','model/gltf-binary')}).status_code==415
    assert c.get('/api/environment-media/../etc/passwd').status_code in (404,405)


def test_video_magic_and_range(tmp_path,monkeypatch):
    monkeypatch.setattr(auth,'AUTH_MODE','local')
    monkeypatch.setattr(media,'MEDIA_DIR',tmp_path/'private_media');media.MEDIA_DIR.mkdir()
    c=TestClient(app)
    # A header is accepted for background transport testing, NOT proof of decodable media.
    sample=b'\0\0\0\x18ftypisom'+b'\0'*600
    r=c.post('/api/environment-media',files={'file':('clip.mp4',sample,'video/mp4')})
    assert r.status_code==201,r.text
    u=r.json()['url'];res=c.get(u,headers={'Range':'bytes=0-15'})
    assert res.status_code==206 and res.content==sample[:16]
    assert c.post('/api/environment-media',files={'file':('fake.mp4',b'abcd'*30,'video/mp4')}).status_code==422
    assert c.post('/api/environment-media',files={'file':('fake.webm',b'abc'*50,'video/webm')}).status_code==422


def test_private_asset_cannot_cross_users(tmp_path,monkeypatch):
    monkeypatch.setattr(auth,'AUTH_MODE','accounts')
    monkeypatch.setattr(auth,'DB',tmp_path/'users.sqlite3')
    monkeypatch.setattr(media,'MEDIA_DIR',tmp_path/'private_media');media.MEDIA_DIR.mkdir()
    alice=TestClient(app);bob=TestClient(app)
    for c,who in [(alice,'alice'),(bob,'bob')]:
        assert c.post('/api/auth/register',json={'email':f'{who}@example.com','name':who,'password':'strong-password-1234'}).status_code==201
        assert c.post('/api/auth/login',json={'email':f'{who}@example.com','password':'strong-password-1234'}).status_code==200
    r=alice.post('/api/environment-media',files={'file':('actor.png',png(),'image/png')})
    assert r.status_code==201
    url=r.json()['url']
    assert alice.get(url).status_code==200
    assert bob.get(url).status_code in (403,404)
    assert TestClient(app).get(url).status_code==401


def test_workstation_imports_and_fixed_canvas_controls():
    from app import generation_jobs
    assert generation_jobs.MAX_PARALLEL==8
    assert generation_jobs.BatchRequest(project_id='film',scope='book').workers==8
    c=TestClient(app)
    h=c.get('/book').text
    for id in ('environment-video','environment-image','environment-generate','drawing-to-set',
               'drawing-to-muse','draw-undo','draw-redo','draw-tool','stage-blocking-map','stage-monitor-lock'):
        assert f'id="{id}"' in h,id
    assert 'value="8"' in h and 'Parallel images' not in h
