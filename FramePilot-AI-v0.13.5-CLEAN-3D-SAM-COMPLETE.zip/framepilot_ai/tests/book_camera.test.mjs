import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../static/book.js',import.meta.url),'utf8');

test('camera redraw does not recursively invoke OrbitControls.update',()=>{
  const body=source.match(/draw\(\)\{(.*?)\},\s*switchMode\(/s)?.[1];
  assert.ok(body,'Camera draw() function should be present');
  const draw=new Function(body);
  let count=0,updates=0;
  const stage={ready:true,_drawing:false,mode:'orbit',world:{},camera:{},
     cameraPOV:{},topCamera:{},
     renderer:{domElement:{getBoundingClientRect(){return {width:800,height:450}}},setScissorTest(){},setViewport(){},render(){count++;}},
     orbit:{update(){updates++;draw.call(stage);}}
  };
  draw.call(stage);
  assert.equal(count,1,'draw() should render the scene exactly once');
  assert.equal(updates,0,'draw() should not call OrbitControls.update()');
  stage.orbit.update();
  assert.equal(count,2,'OrbitControls change can trigger a redraw without recursion');
  assert.equal(updates,1);
});

test('browser fetches fresh book javascript after hotfix',()=>{
  const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
  assert.match(html,/book\.js\?v=0\.13\.5/);
});
