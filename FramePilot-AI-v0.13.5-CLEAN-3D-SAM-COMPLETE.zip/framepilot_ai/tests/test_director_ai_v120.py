import copy
import json
import types
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app import auth, workspace_api as wa
from app.project_store import ProjectStore
from app import director_assistant as director
from app.meta_resilience import call_responses


@pytest.fixture
def web(tmp_path,monkeypatch):
    monkeypatch.setattr(wa,'STORE',ProjectStore(tmp_path/'private'))
    monkeypatch.setattr(auth,'DB',tmp_path/'users.sqlite3')
    monkeypatch.setattr(auth,'AUTH_MODE','local')
    return TestClient(app),monkeypatch


def _ids(client):
    r=client.post('/api/projects/demo')
    assert r.status_code==200,r.text
    project=r.json()['project']
    scene=project['scenes'][0]
    shot=scene['shots'][0]
    return project,scene,shot


def _input(p,s,h,mode='offline',text='Make the tension visible through a careful camera setup.'):
    return {'project_id':p['id'],'scene_id':s['id'],'shot_id':h['id'],
            'direction':text,'mode':mode,'focus':'balanced'}


def test_plan_is_preview_until_confirmed_and_undo_restores_geometry(web):
    client,_=web
    project,scene,shot=_ids(client)
    before=copy.deepcopy(shot)
    req=_input(project,scene,shot,text='Develop an intimate romantic scene with clear eyelines')
    plan=client.post('/api/director/plan',json=req)
    assert plan.status_code==200,plan.text
    proposed=plan.json()
    assert proposed['source'].startswith('Offline')
    assert proposed['proposal']['camera']['lens']==65
    assert client.get('/api/projects/'+project['id']).json()['project']['revision']==project['revision']
    # Add one real 3D object to prove the accepted proposal persists.
    proposed['proposal']['add_objects']=[{'kind':'table','name':'Tea-shop table','x':0,'y':0,'z':1,
                                         'rot':0,'scale':1,'color':'#b7a68c'}]
    applied=client.post('/api/director/apply',json={
        'project_id':project['id'],'scene_id':scene['id'],'shot_id':shot['id'],
        'expected_revision':project['revision'],'proposal':proposed['proposal']})
    assert applied.status_code==200,applied.text
    changed=applied.json()['project'];saved=changed['scenes'][0]['shots'][0]
    assert saved['camera']['lens']==65
    assert any(o['name']=='Tea-shop table' for o in saved['camera']['objects'])
    assert saved['director_guides'] and saved['director_revisions']
    assert saved['status']=='Review'
    # A stale UI is never allowed to overwrite a newer camera.
    stale=client.post('/api/director/apply',json={
        'project_id':project['id'],'scene_id':scene['id'],'shot_id':shot['id'],
        'expected_revision':project['revision'],'proposal':proposed['proposal']})
    assert stale.status_code==409
    undo=client.post('/api/director/undo',json={
        'project_id':project['id'],'scene_id':scene['id'],'shot_id':shot['id'],
        'expected_revision':changed['revision']})
    assert undo.status_code==200,undo.text
    restored=undo.json()['project']['scenes'][0]['shots'][0]
    assert restored.get('camera')==before.get('camera')
    assert restored.get('name')==before.get('name')
    assert restored.get('director_guides',[])==[]


def test_proposals_are_validated_and_no_dynamic_code_or_external_assets(web):
    client,_=web
    project,scene,shot=_ids(client)
    p=client.post('/api/director/plan',json=_input(project,scene,shot)).json()['proposal']
    p['add_objects']=[{'kind':'glb','name':'https://unsafe.example/a.glb','x':0,'y':0,'z':0}]
    r=client.post('/api/director/apply',json={'project_id':project['id'],'scene_id':scene['id'],
      'shot_id':shot['id'],'expected_revision':project['revision'],'proposal':p})
    assert r.status_code==422,r.text
    assert client.get('/api/projects/'+project['id']).json()['project']['revision']==project['revision']


def test_failed_provider_call_is_retried_then_gives_clear_service_error(web):
    client,patch=web
    p,s,h=_ids(client)
    def fake_muse(*args,**kwargs):
        raise types.SimpleNamespace  # raises TypeError on purpose
    patch.setattr(director,'muse_plan',fake_muse)
    r=client.post('/api/director/plan',json=_input(p,s,h,mode='muse'))
    assert r.status_code==503,r.text
    assert client.get('/api/projects/'+p['id']).json()['project']['revision']==p['revision']


def test_retry_500_then_200_and_never_retry_401():
    class FakeResponse:
        def __init__(self,status):self.status_code=status;self.headers={}
    class Err(Exception):
        def __init__(self,code):self.status_code=code;self.response=FakeResponse(code)
    class FakeClient:
        def __init__(self,codes):self.codes=iter(codes);self.calls=0;self.responses=self
        def create(self,**kw):
            self.calls+=1
            code=next(self.codes)
            if code!=200:raise Err(code)
            return {'ok':True}
    c=FakeClient([500,502,200]);waits=[]
    response=call_responses(c,sleep=waits.append,jitter=lambda:0)
    assert response=={'ok':True} and c.calls==3 and len(waits)==2
    authfail=FakeClient([401,200])
    with pytest.raises(Err):call_responses(authfail,sleep=lambda _:None)
    assert authfail.calls==1
    quota=FakeClient([429,200]);waits=[]
    assert call_responses(quota,sleep=waits.append,jitter=lambda:0)['ok']
    assert len(waits)==1


def test_registration_starts_valid_session_and_profiles_are_private(web):
    client,patch=web
    patch.setattr(auth,'AUTH_MODE','accounts')
    a=TestClient(app);b=TestClient(app)
    assert a.get('/api/projects').status_code==401
    result=a.post('/api/auth/register',json={
      'email':'director-2026@example.com','name':'Director','password':'a-strong-long-passphrase-123'})
    assert result.status_code==201,result.text
    assert result.json()['user']['email']=='director-2026@example.com'
    assert result.cookies.get('fp_session')
    assert a.get('/api/auth/diagnostics').json()['session_valid']
    assert a.get('/api/projects').status_code==200
    assert b.get('/api/projects').status_code==401
    # Inapplicable credentials remain 401 and should NOT be silently retried.
    wrong=b.post('/api/auth/login',json={'email':'director-2026@example.com','password':'wrong-pass'})
    assert wrong.status_code==401
    project,scene,shot=_ids(a)
    r=b.post('/api/director/plan',json=_input(project,scene,shot))
    assert r.status_code==401
    b.post('/api/auth/register',json={
      'email':'director-two@example.com','name':'Director Two','password':'another-strong-passphrase'})
    # Even logged in to a different profile, this film is not visible.
    assert b.post('/api/director/plan',json=_input(project,scene,shot)).status_code==404
    assert a.post('/api/director/plan',json=_input(project,scene,shot)).status_code==200
