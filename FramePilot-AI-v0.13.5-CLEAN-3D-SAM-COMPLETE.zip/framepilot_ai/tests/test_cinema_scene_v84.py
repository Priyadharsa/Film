"""Regression: cinema rig and editable objects persist through a real shot API."""
from fastapi.testclient import TestClient
from app.main import app
from app import workspace_api
from app.project_store import ProjectStore


def test_camera_and_lighting_and_prop_persist(tmp_path,monkeypatch):
    monkeypatch.setattr(workspace_api,'STORE',ProjectStore(tmp_path/'projects'))
    client=TestClient(app)
    r=client.post('/api/projects/import',data={'title':'Camera test','screenplay_text':'INT. ROOM - NIGHT\nTwo actors meet at a table.'})
    assert r.status_code==200,r.text
    p=r.json()['project'];pid=p['id'];s=p['scenes'][0];shot=s['shots'][0]
    camera={'x':1.3,'y':1.65,'z':4.8,'lens':50,'pan':3,'tilt':-4,'roll':11,'aspect':'2.39:1','fps':24,'aperture':2.8,
            'objects':[{'id':'chair-1','kind':'chair','name':'A chair','x':2,'y':0,'z':-3,'rot':90,'scale':1,'color':'#9aaabc'}],
            'lighting':{'key':3.2,'fill':0.3,'rim':1.4,'ambient':0.6,'color':'#ffcc99','background':'#10151a'}}
    resp=client.patch(f'/api/projects/{pid}/scenes/{s["id"]}/shots/{shot["id"]}',json={'camera':camera,'lens_mm':50,'camera_movement':'Dolly in'})
    assert resp.status_code==200,resp.text
    refreshed=client.get(f'/api/projects/{pid}').json()['project']['scenes'][0]['shots'][0]
    assert refreshed['camera']['objects'][0]['kind']=='chair'
    assert refreshed['camera']['lighting']['key']==3.2
    assert refreshed['camera']['aspect']=='2.39:1'
    assert refreshed['camera']['roll']==11
    assert refreshed['camera_movement']=='Dolly in'


def test_book_has_cinema_toolbar_and_version():
    client=TestClient(app)
    h=client.get('/book');assert h.status_code==200
    assert 'Maximize 3D' in h.text and 'Export .GLB' in h.text
    assert client.get('/health').json()['version']=='0.13.5'
