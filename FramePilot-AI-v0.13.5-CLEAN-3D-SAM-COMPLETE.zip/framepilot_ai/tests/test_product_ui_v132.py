"""Release regression: local-only Blender conversion and minimalist workstation assets."""
from pathlib import Path
import json
import struct
from fastapi.testclient import TestClient
from app.main import app
from app import model_assets


def sample_glb():
    data=json.dumps({'asset': {'version': '2.0'},'scenes':[{'nodes':[]}], 'nodes':[]},separators=(',',':')).encode()
    data+=b' ' * (-len(data)%4)
    return b'glTF'+struct.pack('<II',2,20+len(data))+struct.pack('<I4s',len(data),b'JSON')+data


def test_blend_disabled_by_default(monkeypatch):
    monkeypatch.delenv('FRAMEPILOT_ENABLE_LOCAL_BLEND',raising=False)
    with TestClient(app) as client:
        response=client.post('/api/models',files={'file':('movie.blend',b'BLENDERxxx','application/octet-stream')})
    assert response.status_code==403
    assert 'disabled' in response.text.lower()


def test_blend_conversion_local_only_and_validated(monkeypatch,tmp_path):
    monkeypatch.setenv('FRAMEPILOT_ENABLE_LOCAL_BLEND','1')
    monkeypatch.setattr(model_assets,'FOLDER',tmp_path)
    calls=[]
    def conversion(raw):
        calls.append(raw)
        return sample_glb()
    monkeypatch.setattr(model_assets,'convert_blend',conversion)
    with TestClient(app) as client:
        r=client.post('/api/models',files={'file':('actor.blend',b'BLENDERsource bytes','application/octet-stream')})
        assert r.status_code==200,r.text
        assert r.json()['url'].startswith('/api/models/')
        result=client.get(r.json()['url'])
    assert result.status_code==200 and result.content.startswith(b'glTF')
    assert calls==[b'BLENDERsource bytes']


def test_minimalist_assets_and_all_shot_tools_preserved():
    root=Path(__file__).resolve().parents[1]/'static'
    html=(root/'book.html').read_text()
    css=(root/'film_product.css').read_text()
    for identity in ('script-text','scene-select','shot-select','tool-set','tool-draw','tool-art','tool-director','tool-voice','generate-book','download-pack','stage-max','environment-model'):
        assert f'id="{identity}"' in html
    assert '/static/film_product.css?v=0.13.5' in html
    assert '--fp-teal' in css and '.cinema-stage.stage-maximized' in css
    assert 'color-scheme: light' in css
