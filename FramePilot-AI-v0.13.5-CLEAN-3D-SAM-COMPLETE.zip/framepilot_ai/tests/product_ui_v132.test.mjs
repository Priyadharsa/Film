import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createCinemaPresentation} from '../static/cinema_presentation.js';

function classes(){const s=new Set();return {contains:x=>s.has(x),add:x=>s.add(x),remove:x=>s.delete(x),toString:()=>[...s].join(' ')}}

test('maximize/restore releases scroll on both root and body, including repeated restore',()=>{
 const stage={classList:classes()},body={classList:classes()},root={classList:classes()};
 const button={textContent:'',attrs:{},setAttribute(k,v){this.attrs[k]=v}};
 let resizes=0,scrolled=null;
 const view={scrollX:17,scrollY:201,scrollTo(x,y){scrolled=[x,y]},requestAnimationFrame(cb){cb()}};
 const p=createCinemaPresentation({stage,body,root,button,view,refresh:()=>resizes++});
 p.set(true);
 assert.equal(stage.classList.contains('stage-maximized'),true);
 assert.equal(body.classList.contains('cinema-scroll-locked'),true);
 p.set(false);
 assert.equal(stage.classList.contains('stage-maximized'),false);
 assert.equal(body.classList.contains('cinema-scroll-locked'),false);
 assert.equal(root.classList.contains('cinema-scroll-locked'),false);
 assert.deepEqual(scrolled,[17,201]);
 body.classList.add('cinema-scroll-locked'); p.set(false);
 assert.equal(body.classList.contains('cinema-scroll-locked'),false);
 assert.equal(resizes,2);
});

test('product UI has no duplicate IDs and retains connected actions',()=>{
 const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
 const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
 assert.equal(new Set(ids).size,ids.length);
 assert.match(html,/film_product\.css\?v=0\.13\.5/);
 for(const name of ['3D scene','Drawing','Art &amp; Muse','AI director','Voice','Generate complete screenplay'])assert.ok(html.includes(name),name);
});
