"""v0.8 regression tests: page source, long films, 3D GLB and comic PDF."""
from __future__ import annotations
import json
import struct
from pathlib import Path
import fitz
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app import workspace_api, model_assets
from app.project_store import ProjectStore
from app.screenplay_parser import parse_scenes, page_records, connect_pages
from app.styles import STYLE_PRESETS

@pytest.fixture
def client(monkeypatch, tmp_path):
    monkeypatch.setattr(workspace_api,'STORE',ProjectStore(tmp_path/'project'))
    monkeypatch.setattr(workspace_api,'GENERATED',tmp_path/'generated')
    monkeypatch.setattr(workspace_api,'REFERENCES',tmp_path/'refs')
    monkeypatch.setattr(model_assets,'FOLDER',tmp_path/'models')
    for p in ('generated','refs','models'):(tmp_path/p).mkdir()
    return TestClient(app)

def test_300_scene_full_film_can_be_parsed_without_240_limit():
    text='\n'.join(f'INT. LOCATION {i} - NIGHT\nCharacter speaks in scene {i}.\n' for i in range(300))
    pages=page_records(text)
    result=parse_scenes(text,[p['text'] for p in pages])
    assert len(result)==300
    assert all(len(s['shots'])==1 for s in result)
    connected=connect_pages(pages,result)
    assert len(connected)>1
    assert any(connected[-1]['scene_ids'])

def test_editable_page_and_scene_rebuild_preserves_shot_ids(client):
    project=client.post('/api/projects/import',data={'title':'Book','screenplay_text':
      'INT. ROOM - NIGHT\nFirst scene.\nEXT. PARK - MORNING\nSecond scene.'}).json()['project']
    assert len(project['pages'])==1
    pid=project['id']; first=project['scenes'][0];shot=first['shots'][0]
    page=client.get(f'/api/projects/{pid}/pages/1');assert page.status_code==200
    patch=client.patch(f'/api/projects/{pid}/pages/1',json={'text':
      'INT. ROOM - NIGHT\nChanged scene.\nEXT. PARK - MORNING\nSecond scene.','notes':'Director changed the opening'})
    assert patch.status_code==200
    rebuild=client.post(f'/api/projects/{pid}/rebuild-scenes')
    assert rebuild.status_code==200,rebuild.text
    changed=rebuild.json()['project']
    assert changed['scenes'][0]['id']==first['id']
    assert changed['scenes'][0]['shots'][0]['id']==shot['id']
    assert 'Changed scene' in changed['scenes'][0]['text']

def test_original_pdf_page_spans_multiple_scenes(client):
    doc=fitz.open();pg=doc.new_page()
    pg.insert_text((50,50),'INT. CAB - NIGHT\nMira waits.\nEXT. RIVER - DAWN\nSun rises.',fontsize=12)
    pdf=doc.tobytes();doc.close()
    r=client.post('/api/projects/import',files={'file':('pages.pdf',pdf,'application/pdf')})
    assert r.status_code==200,r.text
    data=r.json()['project']
    assert data['source']['pages']==1
    assert len(data['scenes'])==2
    assert len(data['pages'][0]['scene_ids'])==2

def test_68_styles_and_draft_shot_grammar(client):
    assert len(STYLE_PRESETS)>=50
    p=client.post('/api/projects/demo').json()['project'];s=p['scenes'][0]
    r=client.post(f"/api/projects/{p['id']}/scenes/{s['id']}/shot-patterns/fight")
    assert r.status_code==200,r.text
    assert len(r.json()['project']['scenes'][0]['shots'])==len(s['shots'])+4
    assert client.get('/api/projects/shot-patterns/list').status_code==200

def test_book_routes_and_export_volumes(client):
    assert 'Director Workstation' in client.get('/book').text
    assert '/static/book.js' in client.get('/').text
    p=client.post('/api/projects/demo').json()['project'];pid=p['id']
    for suffix in ('export.pdf','comic.pdf'):
        r=client.get(f'/api/projects/{pid}/{suffix}')
        assert r.status_code==200,r.text if r.status_code!=200 else ''
        assert r.content.startswith(b'%PDF')
        with fitz.open(stream=r.content,filetype='pdf') as doc:
            txt=''.join(page.get_text() for page in doc)
            assert 'FRAMEPILOT' in txt
    assert client.get(f'/api/projects/{pid}/comic.pdf?from_scene=2&to_scene=1').status_code==422

def glb_fixture():
    data=json.dumps({'asset':{'version':'2.0'},'scenes':[{'nodes':[]}],'scene':0}).encode('utf-8')
    data+=b' ' * ((4-len(data)%4)%4)
    return struct.pack('<4sII',b'glTF',2,20+len(data))+struct.pack('<I4s',len(data),b'JSON')+data

def test_blender_glb_upload_validation(client):
    r=client.post('/api/models',files={'file':('prop.glb',glb_fixture(),'model/gltf-binary')})
    assert r.status_code==200,r.text
    model=client.get(r.json()['url'])
    assert model.status_code==200 and model.content.startswith(b'glTF')
    assert client.post('/api/models',files={'file':('bad.glb',b'INVALID','application/octet-stream')}).status_code==422
    evil=json.dumps({'asset':{'version':'2.0'},'images':[{'uri':'https://unsafe.example/file.png'}]}).encode('utf-8')
    evil+=b' '*((4-len(evil)%4)%4)
    invalid=struct.pack('<4sII',b'glTF',2,20+len(evil))+struct.pack('<I4s',len(evil),b'JSON')+evil
    assert client.post('/api/models',files={'file':('remote.glb',invalid,'application/octet-stream')}).status_code==422
