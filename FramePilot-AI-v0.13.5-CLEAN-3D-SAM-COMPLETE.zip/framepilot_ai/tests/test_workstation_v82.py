"""Workstation smoke tests: core flows and stable error responses."""
from __future__ import annotations
import io
import json
from pathlib import Path
from PIL import Image
from fastapi.testclient import TestClient
import pytest
from app.main import app
from app import workspace_api
from app.project_store import ProjectStore

@pytest.fixture
def client(tmp_path,monkeypatch):
    for d in ('generated','references'):(tmp_path/d).mkdir()
    monkeypatch.setattr(workspace_api,'STORE',ProjectStore(tmp_path/'projects'))
    monkeypatch.setattr(workspace_api,'GENERATED',tmp_path/'generated')
    monkeypatch.setattr(workspace_api,'REFERENCES',tmp_path/'references')
    return TestClient(app,raise_server_exceptions=False)

def test_workstation_page_and_diagnostics(client):
    r=client.get('/book')
    assert r.status_code==200
    assert 'Focus editor' in r.text
    assert 'view-zoom' in r.text
    assert 'Studio workspace' in r.text
    assert r.headers.get('x-request-id')
    assert client.get('/health').json()['version']=='0.13.5'

def test_long_film_edit_and_exports_never_500(client):
    script='\n'.join(f'INT. ROOM {n} - NIGHT\nActor enters {n}.\n' for n in range(360))
    r=client.post('/api/projects/import',data={'title':'360-scene smoke','screenplay_text':script})
    assert r.status_code==200,r.text
    project=r.json()['project'];pid=project['id']
    assert len(project['scenes'])==360
    scene=project['scenes'][0];sid=scene['id'];shid=scene['shots'][0]['id']
    for req in [
        client.get(f'/api/projects/{pid}/pages?limit=20'),
        client.patch(f'/api/projects/{pid}/pages/1',json={'text':'INT. ROOM 0 - NIGHT\nChanged','notes':'Needs lighting'}),
        client.patch(f'/api/projects/{pid}/scenes/{sid}/shots/{shid}',json={'camera':{'x':1,'y':1.8,'z':4},'lens_mm':50}),
        client.post(f'/api/projects/{pid}/scenes/{sid}/shots'),
        client.post(f'/api/projects/{pid}/scenes/{sid}/shot-patterns/fight'),
    ]:
        assert req.status_code==200,req.text[:400]
        assert 'x-request-id' in req.headers
    im=Image.new('RGB',(640,360),'#bb8866');buf=io.BytesIO();im.save(buf,'PNG')
    art=client.post(f'/api/projects/{pid}/scenes/{sid}/shots/{shid}/artwork',files={'file':('drawing.png',buf.getvalue(),'image/png')},data={'kind':'frame'})
    assert art.status_code==200,art.text[:200]
    for ext in ('export.pdf','comic.pdf'):
        pdf=client.get(f'/api/projects/{pid}/{ext}?from_scene=1&to_scene=40')
        assert pdf.status_code==200,pdf.text[:200] if pdf.status_code!=200 else ''
        assert pdf.content[:4]==b'%PDF'
    assert client.get(f'/api/projects/{pid}/export.pdf?from_scene=100&to_scene=10').status_code==422
    assert client.post(f'/api/projects/{pid}/rebuild-scenes').status_code==200

def test_invalid_artwork_and_missing_project_are_client_errors(client):
    p=client.post('/api/projects/demo').json()['project'];sc=p['scenes'][0];sh=sc['shots'][0]
    prefix=f"/api/projects/{p['id']}/scenes/{sc['id']}/shots/{sh['id']}"
    bad=client.post(prefix+'/artwork',files={'file':('bad.png',b'not an image','image/png')},data={'kind':'frame'})
    assert bad.status_code==415
    assert bad.headers.get('x-request-id')
    assert client.get('/api/projects/nonexistent').status_code==404

def test_unexpected_error_reports_safe_request_id(client,monkeypatch):
    def boom():raise RuntimeError('SERVER_ONLY_SECRET_MUST_NOT_LEAK')
    monkeypatch.setattr(workspace_api.STORE,'list',boom)
    response=client.get('/api/projects')
    assert response.status_code==500
    payload=response.json()
    assert payload['request_id']==response.headers['x-request-id']
    assert 'SERVER_ONLY_SECRET' not in response.text

def test_missing_ai_client_returns_service_unavailable(client,monkeypatch):
    p=client.post('/api/projects/demo').json()['project']
    scene=p['scenes'][0];shot=scene['shots'][0]
    def missing(**kwargs):
        raise ModuleNotFoundError('openai')
    monkeypatch.setattr(workspace_api,'generate_storyboard_image',missing)
    r=client.post(f"/api/projects/{p['id']}/scenes/{scene['id']}/shots/{shot['id']}/render",json={'use_sketch':False})
    assert r.status_code==503
    assert 'START_FRAMEPILOT' in r.json()['detail']
    assert r.headers['x-request-id']
