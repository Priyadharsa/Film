import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../static/book.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../static/import_dialog_fix.css',import.meta.url),'utf8');

test('Art Studio clearly separates remove, alter subject and environment edits',()=>{
 for(const operation of ['erase_heal','erase_transparent','isolate','target_tint','background_tint','replace_subject','replace_background']){
  assert.ok(html.includes(`value="${operation}"`),operation);
 }
 for(const id of ['sam-replacement-control','sam-replacement-file','sam-tint-control','sam-tint','sam-effect-help']){
  assert.ok(html.includes(`id="${id}"`),id);
 }
 assert.match(css,/#sam-tint-control\[hidden\],#sam-replacement-control\[hidden\]\{display:none!important\}/);
 assert.match(js,/const samReplaceModes=new Set/);
 assert.match(js,/replacement_reference_id=uploaded\.reference_id/);
 assert.match(js,/source_filename:before\.split/);
});

test('.blend uploads are routed through the same Blender conversion with an honest capability check',()=>{
 assert.match(html,/id="environment-model"[^>]+accept="\.glb,\.blend/);
 assert.match(html,/id="model-upload"[^>]+accept="\.glb,\.blend/);
 assert.match(js,/\/api\/models\/capabilities/);
 assert.match(js,/capabilities\?\.blend/);
 assert.match(js,/importEnvironmentGLB\(e\.target\.files\?\.\[0\],'prop'\)/);
});
