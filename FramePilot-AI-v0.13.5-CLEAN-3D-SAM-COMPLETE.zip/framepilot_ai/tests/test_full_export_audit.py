"""Regression: a successful full download must contain *every* scene and media asset."""
import io
import json
import copy
import zipfile
from pathlib import Path

from fastapi.testclient import TestClient
from PIL import Image

from app import workspace_api as wa
from app.main import app
from app.project_store import ProjectStore


def test_full_pack_multiple_volumes_keeps_all_scenes_and_artwork(tmp_path,monkeypatch):
    monkeypatch.setattr(wa,'STORE',ProjectStore(tmp_path/'private'))
    monkeypatch.setattr(wa,'GENERATED',tmp_path/'generated')
    wa.GENERATED.mkdir()
    client=TestClient(app,raise_server_exceptions=False)
    project=client.post('/api/projects/demo').json()['project']
    pid=project['id']
    first=copy.deepcopy(project['scenes'][0]);first['shots']=first['shots'][:1]
    filename='shot-1-0123456789.png'
    Image.new('RGB',(64,36),'#568b9c').save(wa.GENERATED/filename)
    first['shots'][0]['image_url']='/static/generated/'+filename
    def enlarge(p):
        p['scenes']=[]
        for n in range(251):
            item=copy.deepcopy(first)
            item['id']=f'testscene-{n}'
            item['number']=n+1
            item['slugline']=f'INT. SCENE {n+1} - DAY'
            item['shots'][0]['id']=f'testshot-{n}'
            p['scenes'].append(item)
    wa.STORE.mutate(pid,enlarge)
    result=client.get(f'/api/projects/{pid}/production-pack.zip')
    assert result.status_code==200,result.text[:300]
    with zipfile.ZipFile(io.BytesIO(result.content)) as z:
        names=z.namelist()
        pdfs=[x for x in names if x.endswith('.pdf') and '/planning/' not in x]
        assert len(pdfs)==4,pdfs
        assert sum('production-book-volume-' in x for x in pdfs)==2
        manifest=json.loads(z.read(next(x for x in names if x.endswith('/manifest.json'))))
        assert manifest['total_scenes']==251
        assert manifest['exported_scenes']==251
        assert manifest['volumes']==[{'first_scene':1,'last_scene':250},{'first_scene':251,'last_scene':251}]
        data=json.loads(z.read(next(x for x in names if x.endswith('/project.json'))))
        assert len(data['scenes'])==251
        assert len([x for x in names if x.endswith(filename)])==1
        assert not any(x.endswith('.env') for x in names)


def test_full_pack_range_validation(tmp_path,monkeypatch):
    monkeypatch.setattr(wa,'STORE',ProjectStore(tmp_path/'private'))
    monkeypatch.setattr(wa,'GENERATED',tmp_path/'generated')
    wa.GENERATED.mkdir()
    client=TestClient(app)
    pid=client.post('/api/projects/demo').json()['project']['id']
    for range_query in ['from_scene=0','from_scene=999','from_scene=2&to_scene=1','to_scene=999']:
        assert client.get(f'/api/projects/{pid}/production-pack.zip?{range_query}').status_code==422
