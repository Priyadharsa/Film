"""Cross-account references must not be attachable to another user's shot."""
import io
from PIL import Image
from fastapi.testclient import TestClient
from app import auth, main, workspace_api as wa
from app.main import app
from app.project_store import ProjectStore


def test_cross_account_reference_isolation(tmp_path, monkeypatch):
    private=tmp_path/'private';private.mkdir()
    monkeypatch.setattr(main,'PRIVATE_REFERENCE_DIR',private)
    monkeypatch.setattr(wa,'REFERENCES',private)
    monkeypatch.setattr(wa,'STORE',ProjectStore(tmp_path/'projects'))
    monkeypatch.setattr(auth,'DB',tmp_path/'accounts.sqlite3')
    monkeypatch.setattr(auth,'AUTH_MODE','accounts')
    a=TestClient(app);b=TestClient(app)
    for client,email in [(a,'director-a@example.org'),(b,'director-b@example.org')]:
        r=client.post('/api/auth/register',json={'email':email,'name':'Director','password':'strong-passphrase-123'})
        assert r.status_code==201,r.text
    payload=io.BytesIO();Image.new('RGB',(40,40),'#abcabc').save(payload,'PNG')
    uploaded=a.post('/api/reference',files={'file':('person.png',payload.getvalue(),'image/png')})
    assert uploaded.status_code==200,uploaded.text
    reference_id=uploaded.json()['reference_id']
    own=b.post('/api/projects/demo');assert own.status_code==200,own.text
    p=own.json()['project'];sc=p['scenes'][0];sh=sc['shots'][0]
    path=f"/api/projects/{p['id']}/scenes/{sc['id']}/shots/{sh['id']}"
    assert b.patch(path,json={'references':[{'reference_id':reference_id,'role':'face','label':'Stolen'}]}).status_code==404
    assert b.get(f'/api/reference/{reference_id}/preview').status_code==404
    assert a.get(f'/api/reference/{reference_id}/preview').status_code==200
