"""Submission-critical workflows; Meta calls are mocked to avoid billing."""
import base64
import time
from pathlib import Path
from PIL import Image
from fastapi.testclient import TestClient
from app import main, workspace_api as wa, generation_jobs as jobs, auth
from app.project_store import ProjectStore

MASK={'object_id':'0','left':1,'top':1,'right':3,'bottom':3,'mask_width':2,'mask_height':2,
      'mask_base64':base64.b64encode(b'\x01\x01\x01\x01').decode(),'confidence':0.98}

def test_sam_staging_cutout_is_transparent_and_does_not_replace_frame(tmp_path,monkeypatch):
    store=ProjectStore(tmp_path/'projects')
    gen=tmp_path/'generated';gen.mkdir()
    monkeypatch.setattr(wa,'STORE',store)
    monkeypatch.setattr(wa,'GENERATED',gen)
    monkeypatch.setattr(main,'GENERATED_DIR',gen)
    monkeypatch.setattr(auth,'AUTH_MODE','local')
    c=TestClient(main.app,raise_server_exceptions=False)
    project=c.post('/api/projects/demo').json()['project'];scene=project['scenes'][0];shot=scene['shots'][0]
    before=shot['image_url'];src=before.split('/')[-1]
    base=f"/api/projects/{project['id']}/scenes/{scene['id']}/shots/{shot['id']}"
    r=c.post(base+'/sam-stage-cutout',json={'source_filename':src,'selection':MASK,'operation':'isolate'})
    assert r.status_code==200,r.text
    result=r.json();assert result['kind']=='cutout'
    with Image.open(gen/result['cutout_url'].split('/')[-1]) as im:
        assert im.mode=='RGBA';assert im.getpixel((0,0))[3]==0
        assert im.getpixel((1,1))[3]==255
    updated=c.get(f"/api/projects/{project['id']}").json()['project']
    assert updated['scenes'][0]['shots'][0]['image_url']==before
    assert c.post(base+'/sam-stage-cutout',json={'source_filename':'shot-1-aaaaaaaaaa.png','selection':MASK,'operation':'isolate'}).status_code==409
    assert c.post(base+'/sam-stage-cutout',json={'source_filename':src,'selection':dict(MASK,mask_base64='???'),'operation':'isolate'}).status_code==422


def test_failed_job_can_be_retried_without_repeating_successful_frames(tmp_path,monkeypatch):
    monkeypatch.setattr(wa,'STORE',ProjectStore(tmp_path/'store'))
    monkeypatch.setattr(jobs,'DB',tmp_path/'jobs.sqlite3')
    monkeypatch.setattr(jobs,'pace_inference',lambda:None)
    monkeypatch.setattr(auth,'AUTH_MODE','local')
    c=TestClient(main.app,raise_server_exceptions=False)
    script='\n\n'.join(f'INT. ROOM {i} - DAY\n\nActor crosses doorway.' for i in range(4))
    project=c.post('/api/projects/import',data={'screenplay_text':script}).json()['project']
    pid=project['id'];count=c.get('/api/jobs/estimate',params={'project_id':pid,'scope':'book'}).json()['model_calls']
    first=project['scenes'][0]['shots'][0]['id'];calls=[]
    def fake_render(pid,sid,shid,request):
        calls.append(shid)
        if shid==first and calls.count(first)==1:raise RuntimeError('temporary failure')
    monkeypatch.setattr(wa,'render_shot',fake_render)
    r=c.post('/api/jobs/generate',json={'project_id':pid,'scope':'book','workers':2,'confirmed_count':count})
    assert r.status_code==202,r.text
    jid=r.json()['id']
    def poll(id):
        for _ in range(300):
            data=c.get(f'/api/jobs/{id}').json()
            if data['state'] not in ('queued','running','cancel_requested'):return data
            time.sleep(.02)
        raise AssertionError('timed out')
    first_result=poll(jid)
    assert first_result['state']=='completed_with_errors'
    assert first_result['failures']==1 and first_result['done']==count-1
    done_shots=set(calls)-{first}
    retry=c.post(f'/api/jobs/{jid}/retry-failed')
    assert retry.status_code==202,retry.text
    finished=poll(retry.json()['id'])
    assert finished['total']==1 and finished['done']==1 and finished['failures']==0
    assert calls.count(first)==2 and all(calls.count(s)==1 for s in done_shots)


def test_submission_critical_controls_present():
    page=Path(__file__).resolve().parent.parent/'static'/'book.html'
    html=page.read_text()
    for marker in ('sam-stage-to-3d','job-retry-failed','sam-operation','revise','muse-turn-count','shared-shot-context'):
        assert f'id="{marker}"' in html
    js=(page.parent/'book.js').read_text()
    assert "'/retry-failed'" in js or '/retry-failed`' in js
    assert 'sam-stage-cutout' in js


def test_muse_revisions_chain_and_save_same_shot(tmp_path,monkeypatch):
    from app import image_edit
    store=ProjectStore(tmp_path/'projects')
    gen=tmp_path/'generated';gen.mkdir()
    monkeypatch.setattr(wa,'STORE',store)
    monkeypatch.setattr(wa,'GENERATED',gen)
    monkeypatch.setattr(main,'GENERATED_DIR',gen)
    monkeypatch.setattr(auth,'AUTH_MODE','local')
    c=TestClient(main.app,raise_server_exceptions=False)
    film=c.post('/api/projects/demo').json()['project'];scene=film['scenes'][0];shot=scene['shots'][0]
    route=f"/api/projects/{film['id']}/scenes/{scene['id']}/shots/{shot['id']}/muse-refine"
    chains=[]
    def mock_editor(src,instruction,target,bbox,**opts):
        chains.append(opts['previous_response_id'])
        output=f'shot-{shot["number"]}-{len(chains):010x}.png'
        Image.new('RGB',(12,12),(100+len(chains),50,30)).save(gen/output)
        return output,'mock-muse',f'response-id-{len(chains)}'
    monkeypatch.setattr(image_edit,'edit_storyboard_frame',mock_editor)
    for n in range(2):
        res=c.post(route,json={'instruction':'Change expression gently'})
        assert res.status_code==200,res.text
        data=res.json()
        assert data['chained']==(n>0)
        sh=data['project']['scenes'][0]['shots'][0]
        assert len(sh['muse_turns'])==n+1
        assert len(sh['history'])>=n+1
    assert chains==[None,'response-id-1']
    # No new image, no history change on invalid instructions.
    bad=c.post(route,json={'instruction':'x'})
    assert bad.status_code==422
