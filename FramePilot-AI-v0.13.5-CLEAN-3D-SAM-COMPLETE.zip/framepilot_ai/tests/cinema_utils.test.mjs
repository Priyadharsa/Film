import test from 'node:test';import assert from 'node:assert/strict';
import {CAMERA_PRESETS,LIGHT_PRESETS,makeStageObjects,STAGE_PRESETS,aspectRatio,cameraFov,validateCamera,makeShotManifest} from '../static/cinema_utils.js';
test('camera presets span framing and every camera angle has valid limits',()=>{for(const c of Object.values(CAMERA_PRESETS)){const v=validateCamera(c);assert.ok(v.lens>=12);assert.ok(v.tilt<=89);assert.ok(v.y>0)}});
test('FOV is narrower at longer focal lengths',()=>assert.ok(cameraFov(24)>cameraFov(85)));
test('stage templates generate unique IDs and editable objects',()=>{for(const key of Object.keys(STAGE_PRESETS)){let n=0;const objs=makeStageObjects(key,()=>`unit-${++n}`);assert.equal(new Set(objs.map(x=>x.id)).size,objs.length);for(const o of objs) assert.equal(typeof o.x,'number')}});
test('aspect names map to numeric output ratio',()=>{assert.equal(aspectRatio('1:1'),1);assert.ok(aspectRatio('2.39:1')>aspectRatio('16:9'))});
test('light choices have physically reasonable nonnegative intensities',()=>{for(const l of Object.values(LIGHT_PRESETS))assert.ok([l.key,l.fill,l.rim,l.ambient].every(x=>x>=0))});
test('input values are clamped and manifests are independent',()=>{const v=validateCamera({lens:-2,tilt:101,y:-33,aspect:'bad'});assert.equal(v.lens,12);assert.equal(v.aspect,'16:9');const x=[{id:'a'}],m=makeShotManifest(v,x,{key:1});x[0].id='b';assert.equal(m.objects[0].id,'a')});
