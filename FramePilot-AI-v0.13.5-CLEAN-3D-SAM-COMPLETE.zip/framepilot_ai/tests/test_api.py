# The route tests do not contact Meta. In minimal CI environments where the
# optional network client is not installed, replace just its import surface.
import sys
import types
try:
    from openai import OpenAI  # noqa: F401
except (ImportError, ModuleNotFoundError):
    module = types.ModuleType("openai")
    class UnavailableOpenAI:
        def __init__(self, *args, **kwargs):
            raise RuntimeError("No API client in route test environment")
    module.OpenAI = UnavailableOpenAI
    sys.modules["openai"] = module

from fastapi.testclient import TestClient
from app.main import app

client=TestClient(app)

def test_health():
    response=client.get('/health')
    assert response.status_code==200
    assert response.json()['status']=='ok'

def test_studio_routes():
    assert 'VIRTUAL DIRECTOR' in client.get('/shotlab').text
    assert 'FILM PRE-PRODUCTION WORKSPACE' in client.get('/').text
    assert 'FramePilot' in client.get('/static/shotlab.js').text

def test_image_unauthorized_path_rejected():
    r=client.post('/api/edit',json={
      'image_filename':'../../.env','instruction':'Remove the object'
    })
    assert r.status_code==422

def test_missing_generated_image_returns_404():
    r=client.post('/api/edit',json={
      'image_filename':'shot-1-abcdef1234.png','instruction':'Remove the object'
    })
    assert r.status_code==404
