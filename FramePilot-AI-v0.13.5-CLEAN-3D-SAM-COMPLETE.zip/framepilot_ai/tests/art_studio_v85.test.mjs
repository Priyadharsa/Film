import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
const js=fs.readFileSync(new URL('../static/book.js',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../static/book.css',import.meta.url),'utf8');
test('SAM and Muse editing is visible inside unified book',()=>{
 for(const id of ['sam-detect','sam-instances','sam-mask','sam-stage','sam-apply','art-intent','revision','revise','refs-upload','art-compare']){
  assert.match(html,new RegExp(`id="${id}"`));
 }
 assert.match(html,/SAM 3\.1 selects/);
 assert.match(html,/Muse Image redesigns/);
 assert.match(js,/selected_box:obj/);
 assert.match(js,/sam-layer/);
});
test('art monitor and focus viewport have separate explicit styles',()=>{
 assert.match(css,/\.art-workspace/);
 assert.match(css,/\.sam-stage/);
 assert.match(css,/\.art-inspector/);
 assert.match(css,/\.book-wrap\[data-focus="true"\] \.sam-stage/);
});
