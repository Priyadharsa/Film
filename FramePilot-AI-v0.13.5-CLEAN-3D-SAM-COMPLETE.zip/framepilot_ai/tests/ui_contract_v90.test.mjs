import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../static/book.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../static/book.css',import.meta.url),'utf8');
test('all directly referenced button and form IDs are in the book HTML',()=>{
 const ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]));
 const refs=new Set([...js.matchAll(/\$\('([^']+)'\)/g)].map(x=>x[1]));
 assert.deepEqual([...refs].filter(id=>!ids.has(id)),[]);
});
test('generation queue has visible progress and cancel controls',()=>{
 for(const id of ['generate-page','generate-scene','generation-dock','job-progress','job-cancel','task-loader'])
  assert.match(html,new RegExp(`id="${id}"`));
 assert.match(js,/watchBatch\(/);assert.match(js,/Stop requested/);
});
test('exports are grouped rather than scattered in the main header',()=>{
 assert.match(html,/id="export-menu"/);assert.match(html,/id="download-pack"/);
 assert.match(html,/id="download-json"/);assert.match(html,/id="download-page"/);
});
test('profiles support registration, login, logout and an explicit cloud limitation',()=>{
 for(const id of ['account-open','account-modal','account-register','account-login','account-logout'])assert.match(html,new RegExp(`id="${id}"`));
 assert.match(html,/not connected to a cloud provider/);
});
test('studio retains large viewport and accessible focus styles',()=>{
 assert.match(css,/\.cinema-stage\.stage-maximized/);
 assert.match(css,/\.generation-dock/);
 assert.match(css,/focus-visible/);
});
