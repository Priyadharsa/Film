import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../static/book.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../static/book.css',import.meta.url),'utf8');
test('every new cinema control is present in one unified book workspace',()=>{
 for(const id of ['tool-set','stage-max','stage-toggle-inspector','cinema-inspector','stage-grid','stage-snap','stage-create','cam-preset','cam-aspect','cam-roll','cam-lens','light-preset','light-key','light-fill','light-rim','light-color','camera-movement','stage-export-glb','stage-export-json','capture-frame','object-list','obj-color','duplicate-object','camera-target']){
  assert.match(html,new RegExp(`id="${id}"`),`Missing ${id}`)
 }
});
test('Maximize is a true fixed viewport overlay with restore and inspector hide',()=>{
 assert.match(css,/\.cinema-stage\.stage-maximized\{position:fixed!important/);
 assert.match(css,/\.cinema-stage\.inspector-collapsed/);
 assert.match(js,/createCinemaPresentation/);
 assert.match(readFileSync(new URL('../static/cinema_presentation.js',import.meta.url),'utf8'),/classList\.add\('stage-maximized'\)/);
 assert.match(js,/requestAnimationFrame\(\(\)=>engine\.resize\(\)\)/);
});
test('camera capture switches to cinematic camera, hides stage grid, and restores edit view',()=>{
 assert.match(js,/capture\(\)\{.*?this\.grid\.visible=false;this\.switchMode\('camera'\)/s);
 assert.match(js,/this\.grid\.visible=gridWas;this\.switchMode\(before\)/s);
});
test('GLB import, transforms, and camera save persist through existing project API',()=>{
 assert.match(js,/TransformControls/);assert.match(js,/GLTFExporter/);
 assert.match(js,/saveShot\(\{camera:engine\.serialize\(\)/);
 assert.match(js,/camera_movement:/);
 assert.match(js,/downloadBlob\(new Blob\(\[file\]/);
});
