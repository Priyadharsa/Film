"""v0.9.2 safe render selection and bounded parallelism tests.

All image requests are mocked; tests don't claim real Meta throughput or billing.
"""
from __future__ import annotations
import threading
import time
from concurrent.futures import ThreadPoolExecutor
import pytest
from fastapi.testclient import TestClient
from app import workspace_api as wa, generation_jobs as jobs, auth
from app.project_store import ProjectStore
from app.main import app

@pytest.fixture
def run_server(tmp_path,monkeypatch):
    monkeypatch.setattr(wa,'STORE',ProjectStore(tmp_path/'private'))
    monkeypatch.setattr(jobs,'DB',tmp_path/'jobs.sqlite3')
    monkeypatch.setattr(jobs,'pace_inference',lambda:None)
    monkeypatch.setattr(auth,'DB',tmp_path/'auth.sqlite3')
    monkeypatch.setattr(auth,'AUTH_MODE','local')
    monkeypatch.setattr(jobs,'MAX_PARALLEL',4)
    return TestClient(app),monkeypatch

def wait_job(c,jid):
    for _ in range(350):
        row=c.get(f'/api/jobs/{jid}').json()
        if row['state'] not in ('queued','running','cancel_requested'):return row
        time.sleep(.025)
    raise AssertionError(f'Job never finished {row}')

def test_fast_preview_vs_full_and_style_validation(run_server):
    c,patch=run_server
    script='\n\n'.join(f'INT. PLACE {i} - DAY\n\nActor crosses the room.\n\nHe looks at the lamp.' for i in range(10))
    r=c.post('/api/projects/import',data={'screenplay_text':script})
    assert r.status_code==200,r.text
    pid=r.json()['project']['id']
    preview=c.get('/api/jobs/estimate',params={'project_id':pid,'scope':'book','coverage':'scene_first','workers':4})
    full=c.get('/api/jobs/estimate',params={'project_id':pid,'scope':'book','coverage':'all'})
    assert preview.status_code==200
    assert preview.json()['model_calls']==10
    assert full.json()['model_calls']>=10
    assert c.get('/api/jobs/estimate',params={'project_id':pid,'scope':'book','style_preset':'fake-style'}).status_code==422
    assert c.post('/api/jobs/generate',json={'project_id':pid,'scope':'book','coverage':'scene_first'}).status_code==422


def test_parallel_workers_claim_unique_shots_and_style(run_server):
    c,patch=run_server
    r=c.post('/api/projects/import',data={'screenplay_text':'\n\n'.join(f'INT. SET {i} - DAY\n\nPerson opens a door.' for i in range(18))})
    assert r.status_code==200,r.text
    pid=r.json()['project']['id']
    lock=threading.Lock();seen=[];active=0;max_active=0
    def fake_render(project,scene,shot,body):
        nonlocal active,max_active
        with lock:
            active+=1;max_active=max(max_active,active)
            seen.append((shot,body.style_preset,body.style_custom))
        time.sleep(.028)
        with lock:active-=1
    patch.setattr(wa,'render_shot',fake_render)
    count=c.get('/api/jobs/estimate',params={'project_id':pid,'scope':'book','coverage':'scene_first'}).json()['model_calls']
    req={'scope':'book','project_id':pid,'coverage':'scene_first','confirmed_count':count,
         'workers':4,'style_preset':'graphite','style_custom':'high contrast pencil'}
    response=c.post('/api/jobs/generate',json=req)
    assert response.status_code==202,response.text
    result=wait_job(c,response.json()['id'])
    assert result['state']=='completed' and result['failures']==0
    assert result['done']==count and len(seen)==count
    assert len(set(x[0] for x in seen))==count
    assert all(s=='graphite' and x=='high contrast pencil' for _,s,x in seen)
    assert 2<=max_active<=4
    assert result['coverage']=='scene_first' and result['workers']==4


def test_profile_edit_for_logged_in_user(run_server):
    c,patch=run_server
    patch.setattr(auth,'AUTH_MODE','accounts')
    assert c.patch('/api/auth/profile',json={'name':'New Name'}).status_code==401
    r=c.post('/api/auth/register',json={'email':'director@example.com','name':'Director','password':'An-extremely-safe-password-99'})
    assert r.status_code==201,r.text
    assert c.post('/api/auth/login',json={'email':'director@example.com','password':'An-extremely-safe-password-99'}).status_code==200
    r=c.patch('/api/auth/profile',json={'name':'New Director'})
    assert r.status_code==200,r.text
    assert r.json()['user']['name']=='New Director'
    assert c.get('/api/auth/me').json()['user']['name']=='New Director'
    assert c.patch('/api/auth/profile',json={'name':'  '}).status_code==422
