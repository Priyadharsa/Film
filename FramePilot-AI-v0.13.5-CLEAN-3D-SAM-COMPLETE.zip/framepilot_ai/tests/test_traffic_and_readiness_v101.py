"""Controlled overload and operational contract. No external provider calls."""
from concurrent.futures import ThreadPoolExecutor
from fastapi.testclient import TestClient
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route

from app.traffic_controls import TrafficGate, TrafficControlMiddleware, identity
from app.main import app


def test_bounded_inflight_and_release():
    gate = TrafficGate(max_inflight=2)
    assert gate.enter('A').accepted
    assert gate.enter('B').accepted
    no = gate.enter('C')
    assert not no.accepted and no.reason == 'capacity' and no.retry_after == 1
    gate.leave()
    assert gate.enter('C').accepted
    gate.leave()
    gate.leave()
    assert gate.snapshot()['active_requests'] == 0
    assert gate.snapshot()['rejected_capacity_total'] == 1


def test_rate_window_ledger_bounded_and_resets():
    gate = TrafficGate(max_inflight=2, max_per_minute=2, max_tracked=2)
    for _ in range(2):
        assert gate.enter('A', now=10).accepted
        gate.leave()
    assert gate.enter('A', now=11).reason == 'rate'
    assert gate.enter('A', now=70).accepted
    gate.leave()
    for key in ['B','C']:
        assert gate.enter(key, now=70).accepted
        gate.leave()
    assert gate.snapshot()['tracked_identities'] == 2


def test_gate_thread_safe_under_burst():
    gate = TrafficGate(max_inflight=5)
    from threading import Barrier
    from time import sleep
    barrier = Barrier(32)
    def attempt(_):
        barrier.wait()
        allowed = gate.enter('visitor')
        if allowed.accepted:
            sleep(0.025)
            gate.leave()
        return allowed.accepted
    with ThreadPoolExecutor(max_workers=32) as pool:
        outcomes=list(pool.map(attempt, range(32)))
    assert sum(outcomes) == 5
    assert gate.snapshot()['active_requests'] == 0


def test_trusted_socket_identity_not_forwarded_headers():
    scope={'client':('203.0.113.21',32411), 'headers':[(b'x-forwarded-for',b'1.1.1.1')]}
    assert identity(scope) == 'ip:203.0.113.21'
    scope['headers'].append((b'cookie',b'fp_session=superprivate'))
    assert identity(scope).startswith('session:') and 'superprivate' not in identity(scope)


def test_http_rejection_and_retry_header():
    async def pong(_):
        return JSONResponse({'ok':True})
    test_app=Starlette(routes=[Route('/api/ping',pong),Route('/health',pong)])
    test_app.add_middleware(TrafficControlMiddleware,gate=TrafficGate(max_inflight=2,max_per_minute=1))
    with TestClient(test_app) as client:
        assert client.get('/api/ping').status_code==200
        response=client.get('/api/ping')
        assert response.status_code==429 and response.headers['retry-after']
        assert client.get('/health').status_code==200


def test_readiness_and_operators_protected(monkeypatch):
    monkeypatch.setenv('FRAMEPILOT_MIN_FREE_MB','0')
    monkeypatch.delenv('FRAMEPILOT_DEPLOYMENT_PROFILE',raising=False)
    monkeypatch.setenv('FRAMEPILOT_OPERATIONS_TOKEN','test-secret')
    with TestClient(app) as client:
        assert client.get('/health/live').json()['status']=='alive'
        ready=client.get('/health/ready')
        assert ready.status_code==200,ready.text
        assert ready.json()['deployment_profile']=='local'
        assert client.get('/api/ops/capacity').status_code==404
        assert client.get('/api/ops/capacity', headers={'x-ops-token':'wrong'}).status_code==404
        assert client.get('/api/ops/capacity', headers={'x-ops-token':'test-secret'}).status_code==200
        assert client.get('/api/styles').headers['x-content-type-options']=='nosniff'
        monkeypatch.setenv('FRAMEPILOT_DEPLOYMENT_PROFILE','distributed')
        response=client.get('/health/ready')
        assert response.status_code==503
        assert 'distributed_metadata_and_workers_not_configured' in response.json()['checks']


def test_cross_worker_optimistic_lock_prevents_lost_edits(tmp_path):
    from app.project_store import ProjectStore
    from threading import Barrier
    gate=Barrier(2)
    left=ProjectStore(tmp_path)
    right=ProjectStore(tmp_path)
    project=left.create('Concurrent movie',[],{})
    def edit(store,suffix):
        def change(p):
            p['title']=suffix
            gate.wait(timeout=5)
        try:
            store.mutate(project['id'],change)
            return 200
        except Exception as error:
            return getattr(error,'status_code',500)
    with ThreadPoolExecutor(max_workers=2) as pool:
        outcomes=list(pool.map(lambda a:edit(*a), [(left,'Left'),(right,'Right')]))
    assert sorted(outcomes)==[200,409]
    assert left.get(project['id'])['title'] in ('Left','Right')
