import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../static/book.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../static/book.css',import.meta.url),'utf8');
test('reader, studio and focus modes all have live controls',()=>{
 for(const id of ['view-zoom','focus-stage','frame-open','frame-close'])assert.match(html,new RegExp(`id="${id}"`));
 for(const mode of ['book','script','studio'])assert.match(html,new RegExp(`data-layout="${mode}"`));
 assert.match(js,/function setLayout\(/);assert.match(js,/viewportRoot\.dataset\.layout=mode/);
});
test('workspace is not constrained to old 28 percent frame preview',()=>{
 assert.match(css,/\.frame\{height:auto;min-height:260px;max-height:none/);
 assert.match(css,/\.viewport\{min-height:410px/);
 assert.match(css,/\.book-wrap\[data-focus="true"\]/);
});
test('project JS has one 3D initialization in flight',()=>{
 assert.match(js,/if\(!this\._initPromise\)this\._initPromise=this\.init\(\)/);
});

test('v0.8.3 workstation has active shot timeline and large side-by-side art monitor',()=>{
 assert.match(html,/id="shot-timeline"/);
 assert.match(html,/id="save-shot-top"/);
 assert.match(css,/visual-leaf\[data-editor="art"\]/);
 assert.match(js,/function renderTimeline\(/);
 assert.match(js,/function tool\(mode\)/);
});
