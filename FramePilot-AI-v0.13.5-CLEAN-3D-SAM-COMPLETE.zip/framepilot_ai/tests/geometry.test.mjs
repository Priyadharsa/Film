import test from 'node:test';
import assert from 'node:assert/strict';
import {focalToVerticalFov,horizontalFov,aimDirection,cameraSide,crossed180Line,shotSizeHint} from '../static/geometry.js';

test('physical full-frame FOV decreases as focal length increases',()=>{
 assert.ok(horizontalFov(18)>horizontalFov(35));
 assert.ok(horizontalFov(35)>horizontalFov(85));
 assert.ok(Math.abs(horizontalFov(35)-54.43)<.1);
 assert.ok(Math.abs(focalToVerticalFov(35,16/9)-32.26)<.2);
});
test('pan zero aims down -Z; positive tilt points upward',()=>{
 const d=aimDirection(0,0);assert.ok(Math.abs(d.x)<1e-10);assert.equal(d.y,0);assert.equal(d.z,-1);
 const r=aimDirection(90,0);assert.ok(Math.abs(r.x-1)<1e-10);assert.ok(Math.abs(r.z)<1e-10);
 assert.ok(aimDirection(0,20).y>0);
});
test('180-degree rule crossing uses the signed axis relative to two actors',()=>{
 const a={x:-1,z:0},b={x:1,z:0};const left=cameraSide(a,b,{x:0,z:3});const right=cameraSide(a,b,{x:0,z:-3});
 assert.equal(left,1);assert.equal(right,-1);assert.ok(crossed180Line(left,right));assert.equal(crossed180Line(1,1),false);
 assert.equal(crossed180Line(0,-1),false);
 assert.equal(cameraSide(a,b,{x:0,z:0}),0);
});
test('long focal lengths provide a tight framing hint',()=>{
 assert.match(shotSizeHint(85),/telephoto/);assert.match(shotSizeHint(18),/Wide/);
});
