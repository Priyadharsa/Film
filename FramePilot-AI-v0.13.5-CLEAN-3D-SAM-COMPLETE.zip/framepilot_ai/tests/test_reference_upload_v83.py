"""Regression matrix for reference uploads, shot attachments, and artwork persistence.
No external calls or paid Meta API requests are used.
"""
import io
import hashlib
from concurrent.futures import ThreadPoolExecutor

import pytest
from fastapi.testclient import TestClient
from PIL import Image
from app.main import app
from app import main, workspace_api
from app.project_store import ProjectStore

@pytest.fixture
def env(tmp_path, monkeypatch):
    root=tmp_path/'private';gen=tmp_path/'generated'
    root.mkdir();gen.mkdir()
    monkeypatch.setattr(main,'PRIVATE_REFERENCE_DIR',root)
    monkeypatch.setattr(workspace_api,'REFERENCES',root)
    monkeypatch.setattr(workspace_api,'GENERATED',gen)
    monkeypatch.setattr(workspace_api,'STORE',ProjectStore(root/'projects'))
    client=TestClient(app,raise_server_exceptions=False)
    response=client.post('/api/projects/demo')
    assert response.status_code==200
    project=response.json()['project']
    sc=project['scenes'][0];sh=sc['shots'][0]
    return client,project,f"/api/projects/{project['id']}/scenes/{sc['id']}/shots/{sh['id']}",root,gen

def img(fmt='PNG',size=(256,144)):
    out=io.BytesIO()
    Image.new('RGB',size,'#65b3cd').save(out,format=fmt)
    return out.getvalue()

@pytest.mark.parametrize('fmt',['PNG','JPEG','WEBP'])
def test_upload_attach_and_preview_no_500(env,fmt):
    client,p,endpoint,root,_=env
    r=client.post('/api/reference',files={'file':(f'actor.{fmt.lower()}',img(fmt),f'image/{fmt.lower()}')})
    assert r.status_code==200,r.text
    ref=r.json()['reference_id']
    assert client.get(f'/api/reference/{ref}/preview').status_code==200
    row={'reference_id':ref,'role':'character','label':'Mira','instruction':'Preserve face'}
    attached=client.patch(endpoint,json={'references':[row]})
    assert attached.status_code==200,attached.text
    saved=attached.json()['project']['scenes'][0]['shots'][0]['references']
    assert saved==[row]
    assert client.patch(endpoint,json={'references':[]}).status_code==200


def test_eight_references_and_reassign_roles(env):
    client,p,path,_,_=env
    references=[]
    for i in range(8):
        r=client.post('/api/reference',files={'file':(f'ref-{i}.png',img(),'image/png')})
        assert r.status_code==200
        references.append({'reference_id':r.json()['reference_id'],'role':'location' if i else 'character','label':f'Ref {i}','instruction':''})
    r=client.patch(path,json={'references':references})
    assert r.status_code==200,r.text
    references[0]['role']='costume'
    assert client.patch(path,json={'references':references}).status_code==200
    assert client.patch(path,json={'references':references+[references[0]]}).status_code==422
    assert client.patch(path,json={'references':[references[0],references[0]]}).status_code==422
    assert client.patch(path,json={'references':[{'reference_id':'a'*32,'role':'character','label':'Gone'}]}).status_code==404


def test_corrupt_empty_wrong_type_and_size_errors(env):
    client,_,path,_,_=env
    for data,code in [(b'',400),(b'not an image',415),(b'\x89PNG\r\n\x1a\ntruncated',415)]:
        r=client.post('/api/reference',files={'file':('bad.png',data,'image/png')})
        assert r.status_code==code,r.text
    huge=client.post('/api/reference',files={'file':('large.png',b'\x89PNG\r\n\x1a\n'+b'0'*(5*1024*1024),'image/png')})
    assert huge.status_code==413
    assert client.patch(path,json={'references':[{'reference_id':'BAD','label':'bad'}]}).status_code==422


def test_artwork_frame_sketch_history_and_export(env):
    client,p,path,_,gen=env
    for kind in ['sketch','frame']:
        r=client.post(path+'/artwork',files={'file':('director.png',img(),'image/png')},data={'kind':kind})
        assert r.status_code==200,r.text
        saved=r.json()['project']['scenes'][0]['shots'][0]
        assert saved['sketch_url' if kind=='sketch' else 'image_url'].startswith('/static/generated/shot-')
    assert len(saved['history'])>=2
    pdf=client.get(f"/api/projects/{p['id']}/export.pdf")
    assert pdf.status_code==200 and pdf.content.startswith(b'%PDF')
    comic=client.get(f"/api/projects/{p['id']}/comic.pdf")
    assert comic.status_code==200 and comic.content.startswith(b'%PDF')
    for bad in [b'invalid image',b'\xff\xd8\xffbad']:
        assert client.post(path+'/artwork',files={'file':('bad.jpg',bad,'image/jpeg')},data={'kind':'frame'}).status_code==415
    assert client.post(path+'/artwork',files={'file':('large.png',b'x'*(8*1024*1024+1),'image/png')},data={'kind':'frame'}).status_code==413
    assert client.post(path+'/artwork',files={'file':('p.png',img(),'image/png')},data={'kind':'unexpected'}).status_code==422


def test_ui_routes_scene_create_style_library_and_missing_ai(env):
    client,p,path,root,gen=env
    for endpoint in ['/', '/book','/workspace','/advanced','/studio','/shotlab','/health','/api/projects']:
        assert client.get(endpoint).status_code==200,endpoint
    html=client.get('/book').text
    assert 'shot-timeline' in html and 'ONE SCRIPT' in html and 'v0.13.5' in html
    styles=client.get('/api/styles').json()['styles']
    assert len(styles)>=50
    r=client.post(f"/api/projects/{p['id']}/scenes",json={'slugline':'EXT. STREET - NIGHT','text':'Walking','source_page':1})
    assert r.status_code==200
    added=client.post(f"/api/projects/{p['id']}/scenes/{p['scenes'][0]['id']}/shots")
    assert added.status_code==200
