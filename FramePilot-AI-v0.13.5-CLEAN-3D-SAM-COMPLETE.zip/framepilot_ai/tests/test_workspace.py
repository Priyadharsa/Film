"""Tests for local-first full-film workflow — all Meta requests mocked."""
import io
from pathlib import Path

import fitz
import pytest
from PIL import Image
from fastapi.testclient import TestClient

from app.main import app
from app import workspace_api
from app.project_store import ProjectStore
from app.screenplay_parser import parse_scenes, extract_pdf_text

TEST_SCRIPT='''INT. TEA SHOP - NIGHT

Mira holds a cassette while Arun waits by the doorway.

MIRA
This ends tonight.

EXT. MARKET STREET - DAWN

The market awakes. Arun slips through a narrow crowd as Mira watches.'''  # original text

@pytest.fixture
def env(monkeypatch,tmp_path):
    monkeypatch.setattr(workspace_api,'STORE',ProjectStore(tmp_path/'db'))
    monkeypatch.setattr(workspace_api,'GENERATED',tmp_path/'generated')
    monkeypatch.setattr(workspace_api,'REFERENCES',tmp_path/'references')
    (tmp_path/'generated').mkdir();(tmp_path/'references').mkdir()
    return TestClient(app),tmp_path


def test_parser_scene_boundaries_and_draft_shots():
    sc=parse_scenes(TEST_SCRIPT)
    assert len(sc)==2
    assert sc[0]['slugline']=='INT. TEA SHOP - NIGHT'
    assert len(sc[0]['shots'])==3
    assert sc[0]['shots'][0]['status']=='Draft'
    assert 'Mira' in sc[0]['text']


def test_pdf_text_extraction_and_scanned_rejection():
    d=fitz.open();p=d.new_page();p.insert_text((72,92),TEST_SCRIPT,fontsize=9)
    raw=d.tobytes();d.close()
    text,meta=extract_pdf_text(raw)
    assert 'Mira holds a cassette' in text
    assert meta['pages']==1
    d=fitz.open();d.new_page();scan=d.tobytes();d.close()
    with pytest.raises(ValueError,match='scanned'):
        extract_pdf_text(scan)


def test_import_and_project_persistence(env):
    client,tmp=env
    r=client.post('/api/projects/import',data={'title':'Director Test','screenplay_text':TEST_SCRIPT})
    assert r.status_code==200,r.text
    pid=r.json()['project']['id']
    assert len(r.json()['project']['scenes'])==2
    assert client.get('/api/projects').json()['projects'][0]['title']=='Director Test'
    assert ProjectStore(tmp/'db').get(pid)['title']=='Director Test'


def test_edit_shot_artwork_pdf_and_json_export(env):
    client,tmp=env
    proj=client.post('/api/projects/import',data={'title':'The Last Signal','screenplay_text':TEST_SCRIPT}).json()['project']
    pid=proj['id'];s=proj['scenes'][0];sh=s['shots'][0]
    route=f'/api/projects/{pid}/scenes/{s["id"]}/shots/{sh["id"]}'
    r=client.patch(route,json={'name':'Tight push-in','camera':{'x':1,'z':5,'pan':-10,'lens':55,'actors':[]},'lens_mm':55,'style_preset':'manga'})
    assert r.status_code==200,r.text
    image=Image.new('RGB',(512,288),'#f2eddf');bio=io.BytesIO();image.save(bio,format='PNG')
    a=client.post(route+'/artwork',data={'kind':'frame'},files={'file':('board.png',bio.getvalue(),'image/png')})
    assert a.status_code==200,a.text
    assert a.json()['project']['scenes'][0]['shots'][0]['history']
    response=client.get(f'/api/projects/{pid}/export.pdf')
    assert response.status_code==200,response.text[:120] if response.status_code!=200 else ''
    assert response.content.startswith(b'%PDF-')
    doc=fitz.open(stream=response.content,filetype='pdf');combined=''.join(pg.get_text() for pg in doc)
    assert len(doc)>=3
    assert 'THE LAST SIGNAL' in combined
    assert 'INT. TEA SHOP' in combined
    assert 'Tight push-in' in combined
    doc.close()
    js=client.get(f'/api/projects/{pid}/export.json')
    assert js.status_code==200 and js.json()['title']=='The Last Signal'


def test_import_pdf_endpoint_and_invalid_upload(env):
    client,_=env
    doc=fitz.open();pg=doc.new_page();pg.insert_text((50,55),TEST_SCRIPT);pdf=doc.tobytes();doc.close()
    r=client.post('/api/projects/import',data={'title':'Script'},files={'file':('script.pdf',pdf,'application/pdf')})
    assert r.status_code==200,r.text
    r=client.post('/api/projects/import',files={'file':('malware.pdf',b'not-a-pdf','application/pdf')})
    assert r.status_code==422


def test_scene_ai_breakdown_requires_explicit_request(env,monkeypatch):
    client,_=env
    p=client.post('/api/projects/import',data={'title':'Test','screenplay_text':TEST_SCRIPT}).json()['project']
    s=p['scenes'][0]
    calls=[]
    def fake(text):
        calls.append(text)
        from app.schemas import SceneBreakdown,Shot
        return SceneBreakdown(shots=[Shot(shot_number=1,beat='One cinematic beat',visual_description='Arun entering')])
    monkeypatch.setattr(workspace_api,'analyze_screenplay',fake)
    assert calls==[]
    r=client.post(f'/api/projects/{p["id"]}/scenes/{s["id"]}/ai-breakdown')
    assert r.status_code==200,r.text
    assert len(calls)==1
    assert len(r.json()['project']['scenes'][0]['shots'])==1


def test_reject_arbitrary_image_url_and_invalid_artwork(env):
    client,_=env
    p=client.post('/api/projects/demo',data={}).json()['project'];s=p['scenes'][0];sh=s['shots'][0]
    base=f'/api/projects/{p["id"]}/scenes/{s["id"]}/shots/{sh["id"]}'
    assert client.patch(base,json={'image_url':'https://attacker.example/img'}).status_code==422
    r=client.post(base+'/artwork',data={'kind':'sketch'},files={'file':('x.png',b'not image','image/png')})
    assert r.status_code==415


def test_render_includes_sketch_and_camera_in_prompt(env,monkeypatch):
    client,tmp=env
    p=client.post('/api/projects/demo').json()['project'];s=p['scenes'][0];sh=s['shots'][0]
    base=f'/api/projects/{p["id"]}/scenes/{s["id"]}/shots/{sh["id"]}'
    im=Image.new('RGB',(100,60),'white');f=io.BytesIO();im.save(f,format='PNG')
    client.post(base+'/artwork',data={'kind':'sketch'},files={'file':('sketch.png',f.getvalue(),'image/png')})
    seen={}
    def fake(**kw):
        seen.update(kw)
        filename='shot-1-1234567890.png'
        (tmp/'generated'/filename).write_bytes(f.getvalue())
        return filename,'muse-image-1.0'
    monkeypatch.setattr(workspace_api,'generate_storyboard_image',fake)
    r=client.post(base+'/render',json={'use_sketch':True})
    assert r.status_code==200,r.text
    assert 'Geometry guide' in seen['shot'].visual_description
    assert seen['reference_images'][0]['role']=='composition'
    assert r.json()['project']['scenes'][0]['shots'][0]['image_url'].endswith('1234567890.png')


def test_title_page_is_not_false_scene():
    sc=parse_scenes("THE LAST SIGNAL\nby A. Director\n\n" + TEST_SCRIPT)
    assert len(sc)==2
    assert sc[0]['slugline'].startswith('INT. TEA SHOP')

def test_add_scene_supports_own_new_scene(env):
    client,_=env
    p=client.post('/api/projects/demo').json()['project']
    r=client.post(f"/api/projects/{p['id']}/scenes",json={'slugline':'EXT. BEACH - SUNSET','text':'A lone walker pauses beside a boat.'})
    assert r.status_code==200,r.text
    new=r.json()['project']['scenes'][-1]
    assert new['slugline']=='EXT. BEACH - SUNSET'
    assert len(new['shots'])==3
