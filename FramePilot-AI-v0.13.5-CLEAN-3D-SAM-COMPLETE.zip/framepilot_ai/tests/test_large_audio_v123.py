"""Large audio tests use a fake provider and locally decoded media; no Meta charges."""
import io
import os
import sys
import wave
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from app.main import app
from app import large_audio_jobs as v

client = TestClient(app)


def make_wav(seconds=1):
    mem=io.BytesIO()
    with wave.open(mem, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
        w.writeframes(b'\x00\x00' * (16000*seconds))
    return mem.getvalue()


def test_media_allowlist():
    assert {'.mp3','.m4a','.wav','.flac','.ogg','.opus','.webm','.mp4','.mov','.mkv'}.issubset(v.EXTENSIONS)
    response=client.post('/api/voice-storyboard/jobs',files={'file':('bad.exe',b'XXX','application/octet-stream')})
    assert response.status_code==415


def test_500_mib_boundary_and_no_file_leak(monkeypatch):
    assert v.MAX_AUDIO_BYTES==524_288_000
    monkeypatch.setattr(v, 'MAX_AUDIO_BYTES', 2)
    response=client.post('/api/voice-storyboard/jobs',files={'file':('a.wav',b'123','audio/wav')})
    assert response.status_code==413


def test_bundled_ffmpeg_fallback(monkeypatch):
    monkeypatch.setattr(v.shutil, 'which',lambda name:None)
    assert v.ffmpeg_binary()


def test_actual_wav_segmentation(tmp_path):
    src=tmp_path/'input.wav'; src.write_bytes(make_wav())
    clips=v.segment_audio(src,tmp_path)
    assert len(clips)==1
    with wave.open(str(clips[0]),'rb') as f:
        assert f.getnchannels()==1
        assert f.getsampwidth()==2
        assert f.getframerate()==16000


def test_full_upload_transcribe_and_private_text(monkeypatch, tmp_path):
    monkeypatch.setenv('MODEL_API_KEY','test-key-do-not-use')
    monkeypatch.setattr(v, 'WORK_ROOT', tmp_path)
    monkeypatch.setattr(v, 'transcribe_wav', lambda wav,key: {'transcript':'Scene one: a director enters.','duration_seconds':1.0})
    class InlinePool:
        def submit(self, fn, *args):return fn(*args)
    monkeypatch.setattr(v,'_pool',InlinePool())
    r=client.post('/api/voice-storyboard/jobs',files={'file':('audio.wav',make_wav(),'audio/wav')})
    assert r.status_code==202, r.text
    job_id=r.json()['job_id']
    job=client.get(f'/api/voice-storyboard/jobs/{job_id}').json()
    assert job['state']=='completed',job
    assert job['parts_done']==1
    assert 'director' in job['transcript_preview']
    transcript=client.get(f'/api/voice-storyboard/jobs/{job_id}/transcript')
    assert transcript.status_code==200
    assert 'Scene one:' in transcript.text
    assert not list((tmp_path/job_id).glob('source.*'))
    assert client.get('/api/voice-storyboard/jobs/unknown').status_code==404


def test_job_cancel_request(monkeypatch):
    job_id='cancel-check-id'
    v._jobs[job_id]={'job_id':job_id,'owner':'local','state':'transcribing','cancel_requested':False,'parts_done':0}
    r=client.post(f'/api/voice-storyboard/jobs/{job_id}/cancel')
    assert r.status_code==200
    assert v._jobs[job_id]['cancel_requested'] is True
    v._jobs.pop(job_id,None)
