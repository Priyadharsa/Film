import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('static/book.html','utf8');
const js=fs.readFileSync('static/book.js','utf8');
const css=fs.readFileSync('static/book.css','utf8');

test('Cinema environment accepts private still/video media and a Muse background prompt',()=>{
 for(const id of ['environment-image','environment-video','environment-generate','environment-remove-media','environment-media-status'])
  assert.ok(html.includes(`id="${id}"`),id);
 assert.match(js,/\/api\/environment-media/);
 assert.match(js,/new this\.THREE\.VideoTexture\(video\)/);
 assert.match(js,/\.media_kind/);
 assert.match(js,/await engine\.applyBackdrop\(\)/);
});

test('fixed 16 by 9 stage monitor can be unlocked and maximized',()=>{
 assert.match(html,/id="stage-monitor-lock" type="checkbox" checked/);
 assert.match(css,/aspect-ratio:16 \/ 9/);
 assert.match(css,/monitor-unlocked/);
 assert.match(js,/stage-monitor-lock/);
 assert.match(js,/stage-max/);
});

test('draw has undo redo primitives, composition grid, and routes to 3D and Muse',()=>{
 for(const id of ['draw-undo','draw-redo','draw-tool','draw-thirds','drawing-to-set','drawing-to-muse'])
  assert.ok(html.includes(`id="${id}"`),id);
 assert.match(js,/function rememberSketch/);
 assert.match(js,/function shapeStroke/);
 assert.match(js,/new File\(\[blob\],'director-sketch.png'/);
 assert.match(js,/tool\('art'\)/);
 assert.match(html,/Blocking map · PNG/);
});

test('parallel workers are configured internally, not displayed as settings',()=>{
 assert.match(html,/<input type="hidden" id="batch-workers" value="8">/);
 assert.doesNotMatch(html,/Parallel images/);
 assert.doesNotMatch(js,/Concurrent requests:/);
});
