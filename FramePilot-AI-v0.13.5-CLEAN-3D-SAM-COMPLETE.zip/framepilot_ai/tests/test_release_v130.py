"""Regression gates for scanned books, salvageable Muse plans and camera-aware drafts."""
import io
from pathlib import Path

import fitz
from fastapi.testclient import TestClient
from PIL import Image, ImageDraw

from app.main import app
from app import director_assistant as da, workspace_api as wa
from app.project_store import ProjectStore
from app.cinematic_grammar import recommend
from app.screenplay_parser import extract_pdf_text
from app.storyboard_planner import expand_scenes
from app.upload_api import UploadStart


def sample_text():
    return ('INT. CAFE - NIGHT\n\nA quiet cafe. Two friends exchange a letter as footsteps approach.\n\n'
            'MIRA\nI saw who opened the door.\n\nARUN\nSay nothing until we leave.\n\n'
            'EXT. RAINY STREET - NIGHT\n\nThe driver sprints toward the dark highway.\n')


def test_ocr_is_default_on_direct_and_resumable_uploads(monkeypatch,tmp_path):
    assert UploadStart(filename='screenplay.pdf',size=100).ocr is True
    monkeypatch.setattr(wa,'STORE',ProjectStore(tmp_path/'db'))
    calls=[]
    def fake_extract(raw,ocr,include_pages):
        calls.append((ocr,include_pages))
        return sample_text(),{'pages':3,'page_texts':[sample_text(),'',''],'ocr_used':True,'pages_with_text':1,'extraction_complete':True}
    monkeypatch.setattr(wa,'extract_pdf_text',fake_extract)
    with TestClient(app) as client:
        r=client.post('/api/projects/import',files={'file':('film.pdf',b'%PDF-fake','application/pdf')},data={'title':'OCR checked'})
    assert r.status_code==200,r.text
    assert calls==[(True,True)]
    assert len(r.json()['project']['pages'])==3


def test_scan_metadata_requires_text_and_never_silently_discards_pages():
    # A scanned 2-page film has image-bearing pages but no selectable text.
    im=Image.new('RGB',(320,400),'white');ImageDraw.Draw(im).text((15,40),'INT. LIVING ROOM - DAY',fill='black')
    raw_img=io.BytesIO();im.save(raw_img,'PNG')
    pdf=fitz.open()
    for _ in range(2):
        page=pdf.new_page();page.insert_image(page.rect,stream=raw_img.getvalue())
    try:
        extract_pdf_text(pdf.tobytes(),ocr=False)
    except ValueError as exc:
        assert '2 of 2' in str(exc) and 'OCR' in str(exc)
    else:raise AssertionError('Scanner content imported without OCR')


def test_camera_plans_follow_story_beats_and_lighting():
    scene={'id':'scene1','slugline':'INT. CAFE - NIGHT','text':'One actor waits.\n\nA sealed letter lies on the table.\n\nShe runs out into the street.','source_pages':[1,2], 'shots':[]}
    cover=expand_scenes([scene],fresh=True)
    assert cover['total_shots']>=1
    assert all('lighting_plan' in s and 'composition_plan' in s for s in scene['shots'])
    assert all('night' in s['lighting_plan'].lower() for s in scene['shots'])
    detail=recommend(scene['slugline'],'She notices the key on the table.',1,3)
    action=recommend(scene['slugline'],'She runs quickly across the street.',1,3)
    assert detail['shot_type']=='Insert' and detail['lens_mm']==85
    assert action['shot_type']=='Tracking shot'


def test_muse_plan_wrapper_partial_fields_and_malformed_fallback(monkeypatch,tmp_path):
    monkeypatch.setattr(wa,'STORE',ProjectStore(tmp_path/'db'))
    with TestClient(app) as client:
        project=client.post('/api/projects/import',data={'screenplay_text':sample_text(),'title':'Original small film'}).json()['project']
        scene=project['scenes'][0];shot=scene['shots'][0]
        req={'project_id':project['id'],'scene_id':scene['id'],'shot_id':shot['id'],
             'direction':'Create a precise tense close-up with negative space.','mode':'muse','focus':'camera'}
        proposal=da.recover_muse_plan({'proposal':{'shot':{'description':'A considered reveal.'},'camera':{'lens':65,'pan':20000},
              'add_objects':[{'kind':'glb','name':'unsafe','x':0,'y':0,'z':1}], 'lighting':'Motivated key'}},shot,req['direction'],'camera')
        assert proposal.camera.lens==65 and proposal.camera.pan is None
        assert proposal.add_objects==[] and proposal.lighting=='Motivated key'
        monkeypatch.setattr(da,'muse_plan',lambda *args,**kwargs: (_ for _ in ()).throw(ValueError('Invalid JSON')))
        response=client.post('/api/director/plan',json=req)
        assert response.status_code==200,response.text
        assert response.json()['source'].startswith('Offline recovery')
        assert client.get('/api/projects/'+project['id']).json()['project']['revision']==project['revision']


def test_pdf_sketches_differ_and_all_scene_exports_survive(tmp_path):
    from app.production_pdf import export_production_book
    from app.comic_pdf import export_comic_pdf
    project={'title':'An original microfilm','scenes':[
        {'id':'a','number':1,'slugline':'INT. CAFE - NIGHT','text':'She notices a key.','shots':[{'number':1,'name':'Establish','description':'The doorway','shot_type':'Wide shot','lens_mm':24,'duration_s':5,'lighting_plan':'night'},{'number':2,'name':'Clue','description':'The key','shot_type':'Insert','lens_mm':85,'duration_s':2,'lighting_plan':'night'}]},
        {'id':'b','number':2,'slugline':'EXT. ROAD - DAY','text':'The chase continues.','shots':[{'number':1,'name':'Chase','description':'She runs','shot_type':'Tracking shot','lens_mm':35,'duration_s':4}]}]}
    for fn in [export_production_book,export_comic_pdf]:
        data=fn(project,tmp_path)
        assert data.startswith(b'%PDF-')
        doc=fitz.open(stream=data,filetype='pdf')
        assert len(doc)>=3
        if fn==export_production_book:
            assert any('DRAFT COMPOSITION' in page.get_text() for page in doc)
        assert any('SCENE 002' in page.get_text() or 'SCENE 02' in page.get_text() for page in doc)
