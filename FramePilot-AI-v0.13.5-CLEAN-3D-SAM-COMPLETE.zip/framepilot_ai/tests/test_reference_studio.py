"""The new v0.5 workflow is tested without placing paid Meta API calls."""
from pathlib import Path
from PIL import Image
import io
from types import SimpleNamespace
from unittest.mock import Mock

from fastapi.testclient import TestClient
from app.main import app
from app import main, meta_client
from app.styles import STYLE_PRESETS, resolve_style

client = TestClient(app)


def test_studio_page_and_style_library():
    assert client.get('/studio').status_code == 200
    page = client.get('/studio').text
    assert 'Reference library' in page
    assert 'ART STYLE' in page
    assert '/static/studio.js' in page
    result = client.get('/api/styles')
    assert result.status_code == 200
    styles = result.json()['styles']
    assert len(styles) >= 16
    for key in ['graphite', 'oil', 'anime', 'manga', 'cartoon', 'photoreal', 'animation_3d']:
        assert any(style['id'] == key for style in styles)
        assert key in STYLE_PRESETS
    assert 'watercolor' in resolve_style('watercolor')


def valid_image_bytes(color='orange'):
    buf=io.BytesIO()
    Image.new('RGB',(180,110),color).save(buf,'PNG')
    return buf.getvalue()

def _upload(name, content):
    r = client.post('/api/reference', files={'file': (name, content, 'image/png')})
    assert r.status_code == 200, r.text
    return r.json()['reference_id']


def _request(images, style='manga'):
    return {'scene_title': 'The tea shop', 'style_preset': style,
            'shot': {'shot_number': 3, 'shot_type': 'Medium shot',
                     'visual_description': 'Mira waits in the rain; Arun opens the door.',
                     'image_prompt': 'Single wide cinematic frame'},
            'reference_images': images}


def test_multiple_references_role_tagged_and_counted(monkeypatch):
    a = _upload('mira.png', valid_image_bytes('orange'))
    b = _upload('tea-shop.png', valid_image_bytes('blue'))
    seen = {}

    def fake_generate(**kwargs):
        seen.update(kwargs)
        return 'shot-3-abcdef1234.png', 'muse-image-1.0'

    monkeypatch.setattr(main, 'generate_storyboard_image', fake_generate)
    res = client.post('/api/storyboard', json=_request([
        {'reference_id': a, 'role': 'character', 'label': 'Mira', 'instruction': 'Keep facial structure'},
        {'reference_id': b, 'role': 'location', 'label': 'Tea shop', 'instruction': 'Preserve the shutter'},
    ]))
    assert res.status_code == 200, res.text
    assert res.json()['reference_count'] == 2
    assert res.json()['reference_used'] is True
    assert res.json()['style_preset'] == 'manga'
    assert 'manga' in seen['visual_style']
    assert [x['role'] for x in seen['reference_images']] == ['character', 'location']
    assert [x['label'] for x in seen['reference_images']] == ['Mira', 'Tea shop']
    assert all(isinstance(x['path'], Path) and x['path'].exists() for x in seen['reference_images'])
    # Avoid leaving user-level images behind from tests
    for x in seen['reference_images']:
        x['path'].unlink()


def test_missing_reference_rejected_before_api_call(monkeypatch):
    fake = Mock()
    monkeypatch.setattr(main, 'generate_storyboard_image', fake)
    res = client.post('/api/storyboard', json=_request([{'reference_id': 'a'*32, 'role': 'prop', 'label': 'Cassette'}]))
    assert res.status_code == 404
    fake.assert_not_called()


def test_invalid_style_rejected_before_api_call(monkeypatch):
    fake = Mock()
    monkeypatch.setattr(main, 'generate_storyboard_image', fake)
    res = client.post('/api/storyboard', json=_request([], 'unregistered-model-style'))
    assert res.status_code == 422
    fake.assert_not_called()


def test_too_many_and_duplicate_references():
    row = {'reference_id': 'b'*32, 'role': 'character', 'label': 'Mira'}
    r = client.post('/api/storyboard', json=_request([row]*9))
    assert r.status_code == 422
    r = client.post('/api/storyboard', json=_request([row,row]))
    assert r.status_code == 422


def test_muse_image_api_includes_all_reference_image_parts(monkeypatch, tmp_path):
    a, b = tmp_path/'mira.png', tmp_path/'set.png'
    a.write_bytes(b'\x89PNG\r\n\x1a\n123')
    b.write_bytes(b'\x89PNG\r\n\x1a\n456')
    create = Mock(return_value=SimpleNamespace(output=[SimpleNamespace(type='image_generation_call', result='iVBORw0KGgoAAAA=')]))
    monkeypatch.setattr(meta_client, '_client', lambda: SimpleNamespace(responses=SimpleNamespace(create=create)))
    meta_client.generate_storyboard_image(
        shot=main.StoryboardRequest.model_validate(_request([])).shot,
        scene_title='Tea Shop', visual_style=resolve_style('oil'), output_dir=tmp_path,
        reference_images=[{'path': a, 'role':'character', 'label':'Mira', 'instruction':'Face'},
                          {'path': b, 'role':'location', 'label':'Tea shop', 'instruction':'Layout'}]
    )
    input_body = create.call_args.kwargs['input']
    content = input_body[0]['content']
    assert len([x for x in content if x['type']=='input_image']) == 2
    instructions = ' '.join(x['text'] for x in content if x['type']=='input_text')
    assert 'ROLE: character' in instructions
    assert 'ROLE: location' in instructions
    assert 'oil painting' in instructions


def test_edit_uses_extra_references_and_style_without_overwriting(monkeypatch, tmp_path):
    initial = tmp_path/'shot-1-aabbcc1122.png'
    initial.write_bytes(b'\x89PNG\r\n\x1a\nframe')
    monkeypatch.setattr(main, 'GENERATED_DIR', tmp_path)
    ref = _upload('outfit.png', valid_image_bytes('purple'))
    seen = {}
    def fake_edit(*args, **kwargs):
        seen['args'] = args
        seen.update(kwargs)
        return 'shot-1-eeeeeeeeee.png', 'muse-image-1.0'
    monkeypatch.setattr(main, 'edit_storyboard_frame', fake_edit)
    response = client.post('/api/edit', json={
        'image_filename': initial.name, 'instruction': 'Change Mira costume only',
        'reference_images': [{'reference_id': ref, 'role': 'costume', 'label': 'Office outfit'}],
        'style_preset': 'anime',
    })
    assert response.status_code == 200, response.text
    assert 'anime' in seen['style_instruction']
    assert seen['reference_images'][0]['role'] == 'costume'
    assert initial.exists()  # the source still is present
    seen['reference_images'][0]['path'].unlink()


def test_health_reports_v06():
    data = client.get('/health').json()
    assert data['version'] == '0.13.5'
    assert data['studio'] == '/book'
