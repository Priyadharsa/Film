import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../static/book.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../static/clarity_workspace.css',import.meta.url),'utf8');
test('all six shot tools are visible, labelled, and in a shared editor',()=>{
 const matches=[...html.matchAll(/<button[^>]*data-tab="(set|draw|art|director|voice|frame)"/g)].map(x=>x[1]);
 assert.deepEqual(matches,['set','draw','art','director','voice','frame']);
 for(const label of ['3D scene','Drawing','Art &amp; Muse','AI director','Voice','Versions'])assert.ok(html.includes(label),label);
 assert.match(css,/grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/);
});
test('bulk rendering comes after shot editor, while download is always visible',()=>{
 assert.ok(html.indexOf('id="full-film-tools"')>html.indexOf('id="tool-set"'));
 assert.ok(html.indexOf('id="full-film-tools"')>html.indexOf('class="tabbar"'));
 assert.match(html,/id="download-film-top"/);
 assert.match(js,/download-film-top.*download-pack/);
});
test('3D inspector controls are expanded and have direct section links',()=>{
 const region=html.split('id="cinema-inspector"')[1]?.split('</aside>')[0];
 assert.ok(region);
 assert.ok(!region.includes('<details'),'No hidden inspector accordion panels');
 for(const section of ['inspector-environment','inspector-stage','inspector-objects','inspector-camera','inspector-light'])assert.ok(region.includes('id="'+section+'"'),section);
 assert.match(css,/inspector-jumps/);
});
