import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../static/book.js',import.meta.url),'utf8');
test('render configuration has explicit quick reel, scene overview and complete coverage',()=>{
 for(const id of ['batch-coverage','batch-style','batch-workers','batch-custom'])assert.match(html,new RegExp(`id="${id}"`));
 for(const option of ['first_12','scene_first','all'])assert.match(html,new RegExp(`value="${option}"`));
 assert.match(js,/confirmed_count=count/);
});
test('account profile-name editing and background job ETA exist',()=>{
 assert.match(html,/id="profile-form"/);
 assert.match(js,/\/api\/auth\/profile/);
 assert.match(js,/estimated_remaining_seconds/);
});
