"""Ensure cinema library assets aren't exposed or silently accepted as unsupported formats."""
from fastapi.testclient import TestClient
from app.main import app
from app.model_assets import validate_glb
import json, struct
import pytest

def glb(graph):
    payload=json.dumps(graph).encode()
    payload+=b' ' * ((-len(payload))%4)
    total=20+len(payload)
    return b'glTF'+struct.pack('<II',2,total)+struct.pack('<I4s',len(payload),b'JSON')+payload

def test_3d_model_upload_accepts_blender_glb_and_rejects_arbitrary_files():
    client=TestClient(app)
    valid=glb({'asset':{'version':'2.0'},'scenes':[{'nodes':[]}],'scene':0})
    r=client.post('/api/models',files={'file':('director-set.glb',valid,'model/gltf-binary')})
    assert r.status_code==200,r.text
    response=client.get('/api/models/'+r.json()['asset_id'])
    assert response.status_code==200 and response.content==valid
    r=client.post('/api/models',files={'file':('malware.glb',b'not a glb','model/gltf-binary')})
    assert r.status_code==422
    assert client.get('/api/models/../.env').status_code in (404,307)

def test_disallow_external_texture_fetches():
    with pytest.raises(ValueError,match='External files'):
        validate_glb(glb({'asset':{'version':'2.0'},'images':[{'uri':'https://example.com/image.png'}]}))

def test_book_has_full_environment_controls():
    client=TestClient(app)
    r=client.get('/book')
    assert r.status_code==200 and 'ENVIRONMENT DESIGN · ORIGINAL SETS' in r.text and '1,000 PROCEDURAL LAYOUTS' not in r.text
    assert client.get('/health').json()['version']=='0.13.5'
