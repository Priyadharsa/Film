"""Durable 1 GiB upload control-plane tests. Uses tiny test fixtures, not a 1 GiB allocation."""
from __future__ import annotations

import hashlib
import io
from pathlib import Path

import fitz
import pytest
from fastapi.testclient import TestClient

from app.main import app
from app import upload_api
from app.upload_core import MAX_UPLOAD_BYTES, CHUNK_SIZE, UploadService
from app.ingest_worker import process_one
from app.project_store import ProjectStore


@pytest.fixture
def local(monkeypatch,tmp_path):
    service=UploadService(tmp_path/'ingest',backend='local')
    monkeypatch.setattr(upload_api,'SERVICE',service)
    return TestClient(app),service,ProjectStore(tmp_path/'project_store')


def pdf_bytes():
    doc=fitz.open();page=doc.new_page()
    page.insert_text((50,80),'INT. MUSIC ROOM - NIGHT\n\nMIRA picks up a cassette.\n\nEXT. STREET - DAWN\n\nARUN walks into the light.',fontsize=10)
    data=doc.tobytes();doc.close();return data


def test_upload_resume_sha256_and_background_import(local):
    client,service,store=local
    content=pdf_bytes()
    r=client.post('/api/uploads',json={'filename':'test.pdf','size':len(content),'title':'The Director Film'})
    assert r.status_code==200,r.text
    up=r.json();ident=up['id']
    assert up['parts_total']==1 and up['part_size']==CHUNK_SIZE
    assert service.status(ident)['received']==[]
    bad=client.put(f'/api/uploads/{ident}/parts/0',content=content,headers={'X-Content-SHA256':'0'*64})
    assert bad.status_code==422
    assert service.status(ident)['received']==[]
    r=client.put(f'/api/uploads/{ident}/parts/0',content=content,
                 headers={'X-Content-SHA256':hashlib.sha256(content).hexdigest()})
    assert r.status_code==200,r.text
    reloaded=UploadService(service.folder,backend='local')
    assert reloaded.status(ident)['received']==[0]
    assert client.post(f'/api/uploads/{ident}/complete').json()['status']=='queued'
    assert process_one(reloaded,store)
    done=client.get(f'/api/uploads/{ident}').json()
    assert done['status']=='completed' and done['project_id']
    project=store.get(done['project_id'])
    assert project['source']['sha256']==hashlib.sha256(content).hexdigest()
    assert project['scenes'][0]['slugline']=='INT. MUSIC ROOM - NIGHT'
    assert process_one(reloaded,store) is False


def test_missing_parts_and_order_independent_resume(local):
    client,service,_=local
    file_size=CHUNK_SIZE+16
    init=client.post('/api/uploads',json={'filename':'camera.mp4','size':file_size,'kind':'asset'}).json()
    ident=init['id']
    small=b'last-sixteen-byte'  # 17? ensure exact part size below.
    small=b'z'*16
    assert client.put(f'/api/uploads/{ident}/parts/1',content=small).status_code==200
    assert client.post(f'/api/uploads/{ident}/complete').status_code==409
    resumed=UploadService(service.folder,backend='local').status(ident)
    assert resumed['received']==[1]
    first=b'\x00\x00\x00\x18ftypisom'+b'A'*(CHUNK_SIZE-12)
    assert len(first)==CHUNK_SIZE
    assert client.put(f'/api/uploads/{ident}/parts/0',content=first).status_code==200
    assert client.post(f'/api/uploads/{ident}/complete').json()['status']=='stored'
    assert (service.objects_dir/f'{ident}.mp4').stat().st_size==file_size
    assert client.post(f'/api/uploads/{ident}/complete').json()['status']=='stored'


def test_limits_and_invalid_signature(local):
    client,service,_=local
    too_big=client.post('/api/uploads',json={'filename':'a.pdf','size':MAX_UPLOAD_BYTES+1})
    assert too_big.status_code==413
    bad_type=client.post('/api/uploads',json={'filename':'danger.exe','size':100})
    assert bad_type.status_code==415
    data=b'evil-payload'
    ident=client.post('/api/uploads',json={'filename':'sample.pdf','size':len(data)}).json()['id']
    assert client.put(f'/api/uploads/{ident}/parts/0',content=data).status_code==200
    assert client.post(f'/api/uploads/{ident}/complete').status_code==415
    assert service.status(ident)['status']=='uploading'


def test_retry_upload_conflict_and_cancel(local):
    client,service,_=local
    init=client.post('/api/uploads',json={'filename':'shot.txt','size':8}).json();ident=init['id']
    assert client.put(f'/api/uploads/{ident}/parts/0',content=b'12345678').status_code==200
    assert client.put(f'/api/uploads/{ident}/parts/0',content=b'abcdefgh').status_code==409
    assert client.delete(f'/api/uploads/{ident}').json()['status']=='canceled'
    assert client.put(f'/api/uploads/{ident}/parts/0',content=b'12345678').status_code==409


def test_exact_one_gib_reservation_without_memory_allocation(local):
    client,service,_=local
    response=client.post('/api/uploads',json={'filename':'feature.pdf','size':MAX_UPLOAD_BYTES})
    assert response.status_code==200,response.text
    data=response.json()
    assert data['parts_total']==128
    assert data['part_size']==CHUNK_SIZE
    assert client.delete(f"/api/uploads/{data['id']}").status_code==200


def test_s3_control_plane_sign_complete_worker(monkeypatch,tmp_path):
    from app import upload_api
    class FakeS3:
        def __init__(self):
            self.data=pdf_bytes();self.done=False
        def create_multipart_upload(self,**kw):return {'UploadId':'a1'}
        def generate_presigned_url(self,*args,**kw):return 'https://object-storage.example/test-signed-upload'
        def list_parts(self,**kw):return {'Parts': [],'IsTruncated':False}
        def complete_multipart_upload(self,**kw):self.done=True
        def head_object(self,**kw):return {'ContentLength':len(self.data)}
        def get_object(self,**kw):return {'Body':io.BytesIO(self.data)}
    fake=FakeS3()
    service=UploadService(tmp_path/'cloud-ingest',backend='s3');service.bucket='test-bucket'
    monkeypatch.setattr(service,'s3',lambda:fake)
    monkeypatch.setattr(upload_api,'SERVICE',service)
    client=TestClient(app)
    r=client.post('/api/uploads',json={'filename':'test.pdf','size':len(fake.data),'kind':'screenplay','title':'Cloud Film'})
    assert r.status_code==200,r.text
    up=r.json()
    assert up['backend']=='s3'
    signed=client.get(f"/api/uploads/{up['id']}/parts/0/sign")
    assert signed.status_code==200 and signed.json()['url'].startswith('https://object-storage.example')
    r=client.post(f"/api/uploads/{up['id']}/complete",json={'parts':[{'part_index':0,'etag':'"'+'a'*32+'"'}]})
    assert r.status_code==200,r.text
    assert r.json()['status']=='queued' and fake.done
    project_store=ProjectStore(tmp_path/'cloud-projects')
    assert process_one(service,project_store) is True
    assert service.status(up['id'])['status']=='completed'


def test_expiration_cleanup_removes_staging_files(local):
    client,service,_=local
    r=client.post('/api/uploads',json={'filename':'film.txt','size':12})
    ident=r.json()['id']
    assert client.put(f'/api/uploads/{ident}/parts/0',content=b'Hello world!').status_code==200
    with service.connect() as db:
        db.execute('UPDATE uploads SET updated=1 WHERE id=?',(ident,))
    assert service.cleanup(max_age_seconds=100) == 1
    assert service.status(ident)['status']=='expired'
    assert not (service.chunks_dir/ident).exists()
