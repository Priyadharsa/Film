import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {buildEditableSetFromPlan,describeEditableSet,SUPPORTED_SET_KINDS} from '../static/environment_design.js';
const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../static/book.js',import.meta.url),'utf8');
test('deprecated 1000 layout catalogue removed from 3D UI',()=>{
 assert.doesNotMatch(html,/1,000 PROCEDURAL LAYOUTS|environment-layout|environment-category/);
 assert.doesNotMatch(js,/ENVIRONMENT_TOTAL|buildEnvironment\(/);
 for(const id of ['environment-plan','environment-approve','environment-clear','environment-scene-brief','environment-image','environment-video','environment-model'])
  assert.match(html,new RegExp(`id="${id}"`));
});
test('Muse stage object data is bounded and independently editable',()=>{
 const source={add_objects:Array.from({length:30},(_,i)=>({kind:i%2?'tree':'actor',name:`Object ${i}`,x:500,y:-6,z:-100,scale:50,color:'malformed'}))};
 let count=0;const objects=buildEditableSetFromPlan(source,()=>`i${++count}`);
 assert.equal(objects.length,12);assert.equal(objects[0].x,40);assert.equal(objects[0].y,0);assert.equal(objects[0].scale,8);
 assert.equal(objects[0].color,'#86b9b7');assert.match(describeEditableSet(objects),/12 editable objects/);
 assert.ok(SUPPORTED_SET_KINDS.includes('building'));
});
test('untrusted model object types are ignored',()=>{
 const objects=buildEditableSetFromPlan({add_objects:[{kind:'run_shell',name:'evil'},{kind:'table',name:' Counter ',x:2,z:-1}]},()=> 'safe');
 assert.equal(objects.length,1);assert.equal(objects[0].name,'Counter');
 assert.equal(objects[0].id,'safe');
});
