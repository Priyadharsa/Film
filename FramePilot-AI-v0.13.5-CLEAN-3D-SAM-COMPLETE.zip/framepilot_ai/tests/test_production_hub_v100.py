"""Production Hub integrated contract, including PDF, CSV, ownership and filtering."""
from fastapi.testclient import TestClient
import pytest
from app.main import app
from app.project_store import ProjectStore
from app import production_hub, workspace_api

@pytest.fixture
def api(tmp_path,monkeypatch):
    store=ProjectStore(tmp_path)
    monkeypatch.setattr(production_hub,'STORE',store)
    monkeypatch.setattr(workspace_api,'STORE',store)
    with TestClient(app) as c:
        sample='''INT. TEA SHOP - MORNING\nMira places a brass key on the table. Silence.\nMIRA\nWe must leave now.\n\nEXT. RAILWAY PLATFORM - NIGHT\nThe train approaches through fog. Arun looks back.\nARUN\nThis is our last chance.'''
        response=c.post('/api/projects/import',data={'title':'Original Film','screenplay_text':sample})
        assert response.status_code==200,response.text
        project=response.json()['project']
        yield c,project['id'],project['scenes']

def test_production_hub_screen_and_ownership_route(api):
    c,pid,scenes=api
    assert c.get('/production').status_code==200
    assert b'Production Hub' in c.get('/production').content
    r=c.get(f'/api/production/{pid}')
    assert r.status_code==200,r.text
    assert r.json()['scenes'] and r.json()['production']['contacts']==[]
    assert c.get('/api/production/nosuch').status_code==404

def test_integrated_breakdown_schedule_callsheet(api):
    c,pid,scenes=api
    sid=scenes[0]['id']
    def post(kind,data):
        r=c.post(f'/api/production/{pid}/{kind}',json={'data':data})
        assert r.status_code==201,r.text
        return r.json()['record']
    crew=post('contacts',{'name':'Mira','role':'Lead actor','phone':'+91-1000000000','call_time':'06:00'})
    prop=post('breakdown',{'scene_id':sid,'category':'Props','name':'Brass key','quantity':'1'})
    day=post('shoot_days',{'date':'2026-11-09','scene_ids':[sid],'location':'Tea shop set','call_time':'06:00'})
    sheet=post('call_sheets',{'shoot_day_id':day['id'],'title':'DAY 1','general_call':'06:00','emergency':'Production manager'})
    data=c.get(f'/api/production/{pid}').json()['production']
    assert data['contacts'][0]['name']=='Mira'
    assert data['shoot_days'][0]['scene_ids']==[sid]
    assert data['breakdown'][0]['name']=='Brass key'
    for kind in ('call-sheet','script-sides','shot-list','script-breakdown','shooting-schedule','av-script','contacts','tasks','calendar','moodboard'):
        q={'shoot_day_id':day['id']} if kind=='call-sheet' else {}
        r=c.get(f'/api/production/{pid}/export/{kind}.pdf',params=q)
        assert r.status_code==200,(kind,r.status_code,r.text[:300])
        assert r.content[:5]==b'%PDF-',kind
        assert len(r.content)>1500,kind
    r=c.get(f'/api/production/{pid}/export/contacts.csv')
    assert r.status_code==200 and b'Mira' in r.content
    r=c.patch(f'/api/production/{pid}/contacts/{crew["id"]}',json={'data':{'role':'Assistant director'}})
    assert r.status_code==200
    assert r.json()['record']['role']=='Assistant director'
    assert c.delete(f'/api/production/{pid}/breakdown/{prop["id"]}').status_code==200
    assert c.get(f'/api/production/{pid}').json()['production']['breakdown']==[]

def test_validation_rejects_invalid_refs_and_still_returns_4xx(api):
    c,pid,scenes=api
    cases=[('shoot_days',{'scene_ids':['NOT_A_SCENE']},422),
           ('shoot_days',{'date':'tomorrow'},422),
           ('moodboard',{'image_url':'https://example.com/private.jpg'},422),
           ('contacts',{'password':'unexpected'},422),
           ('tasks',{'title':'X'*12000},413)]
    for kind,data,code in cases:
        r=c.post(f'/api/production/{pid}/{kind}',json={'data':data})
        assert r.status_code==code,(kind,r.status_code,r.text)

def test_prod_hub_navigation_and_safe_js():
    from pathlib import Path
    root=Path(__file__).parents[1]
    s=(root/'static/production.js').read_text()
    assert s.count("['")>=14
    assert 'textContent' in s
    assert 'innerHTML' not in s
    assert (root/'static/book.html').read_text().count('Production Hub')>=1
