"""SAM subject/environment pixel actions and Blender import capabilities."""
import base64
import io
import json
from pathlib import Path

import pytest
from PIL import Image
from fastapi.testclient import TestClient
from app.art_layers import process_layer
from app.project_store import ProjectStore
from app import main, workspace_api, model_assets


def mask():
    # 2x2 protected subject, within 6x4 canvas
    return {'left':2,'top':1,'right':4,'bottom':3,'mask_width':2,'mask_height':2,
            'mask_base64':base64.b64encode(bytes([1]*4)).decode('ascii')}


def test_remove_and_recolor_target_or_environment(tmp_path):
    original=tmp_path/'source.png';Image.new('RGBA',(6,4),(190,40,50,255)).save(original)
    cases=[('erase_transparent',(2,1),3,0),('isolate',(0,0),3,0)]
    for op,pos,channel,expected in cases:
        output=tmp_path/f'{op}.png'
        process_layer(original,mask(),op,output,tint='#008d82')
        with Image.open(output) as image:
            assert image.size==(6,4)
            assert image.getpixel(pos)[channel]==expected
        assert Image.open(original).getpixel((2,1))==(190,40,50,255)
    for op,changed,unchanged in [('target_tint',(2,1),(0,0)),('background_tint',(0,0),(2,1))]:
        dest=tmp_path/f'{op}.png';process_layer(original,mask(),op,dest,tint='#008d82')
        with Image.open(dest) as im:
            assert im.getpixel(changed)[:3] != (190,40,50)
            assert im.getpixel(unchanged)[:3] == (190,40,50)
    for invalid in ('#GGGGGG','red',''):
        with pytest.raises(ValueError,match='hexadecimal'):
            process_layer(original,mask(),'target_tint',tmp_path/'no.png',tint=invalid)


def test_replace_subject_background_with_image_preserving_other_region(tmp_path):
    original=tmp_path/'source.png';Image.new('RGBA',(6,4),(200,20,20,255)).save(original)
    incoming=tmp_path/'replacement.png';Image.new('RGB',(8,8),(0,50,240)).save(incoming)
    for op,target,unchanged in [
        ('replace_subject',(2,1),(0,0)),('replace_background',(0,0),(2,1))]:
        dest=tmp_path/f'{op}.png'
        process_layer(original,mask(),op,dest,replacement_path=incoming)
        with Image.open(dest) as im:
            assert im.getpixel(target)[:3]==(0,50,240)
            assert im.getpixel(unchanged)[:3]==(200,20,20)
    with pytest.raises(ValueError,match='replacement picture'):
        process_layer(original,mask(),'replace_subject',tmp_path/'no.png')


def test_replacement_api_saves_version_and_needs_uploaded_reference(monkeypatch,tmp_path):
    root=tmp_path/'private_uploads';root.mkdir()
    gen=tmp_path/'generated';gen.mkdir()
    monkeypatch.setattr(workspace_api,'STORE',ProjectStore(root))
    monkeypatch.setattr(workspace_api,'GENERATED',gen)
    monkeypatch.setattr(workspace_api,'REFERENCES',root)
    monkeypatch.setattr(main,'PRIVATE_REFERENCE_DIR',root)
    monkeypatch.setattr(main,'GENERATED_DIR',gen)
    with TestClient(main.app) as client:
        project=client.post('/api/projects/demo').json()['project']
        scene=project['scenes'][0];shot=scene['shots'][0]
        url=shot['image_url'];filename=url.rsplit('/',1)[-1]
        with Image.open(gen/filename) as im:
            imsize=im.size
        select={'left':0,'top':0,'right':2,'bottom':2,'mask_width':2,'mask_height':2,
                'mask_base64':base64.b64encode(b'\x01'*4).decode('ascii')}
        path=f'/api/projects/{project["id"]}/scenes/{scene["id"]}/shots/{shot["id"]}/sam-layer'
        req={'source_filename':filename,'operation':'replace_background','selection':select}
        assert client.post(path,json=req).status_code==422
        media=io.BytesIO();Image.new('RGB',(8,8),(30,150,255)).save(media,format='PNG')
        uploaded=client.post('/api/reference',files={'file':('set.png',media.getvalue(),'image/png')})
        assert uploaded.status_code==200,uploaded.text
        req['replacement_reference_id']=uploaded.json()['reference_id']
        applied=client.post(path,json=req)
        assert applied.status_code==200,applied.text
        data=applied.json()
        new=gen/data['image_url'].rsplit('/',1)[-1]
        assert new.exists() and data['project']['scenes'][0]['shots'][0]['image_url']==data['image_url']
        assert data['project']['scenes'][0]['shots'][0]['history'][-1]['kind']=='SAM layer · replace_background'
        assert client.post(path,json=req).status_code==409


def test_blender_import_capability_is_explicit_and_safe(monkeypatch):
    monkeypatch.delenv('FRAMEPILOT_ENABLE_LOCAL_BLEND',raising=False)
    with TestClient(main.app) as client:
        off=client.get('/api/models/capabilities')
        assert off.status_code==200
        assert off.json()['glb'] is True and off.json()['blend'] is False
    monkeypatch.setenv('FRAMEPILOT_ENABLE_LOCAL_BLEND','1')
    monkeypatch.setattr(model_assets.shutil,'which',lambda binary:'/usr/bin/blender' if binary=='blender' else None)
    with TestClient(main.app) as client:
        ready=client.get('/api/models/capabilities')
        assert ready.status_code==200
        assert ready.json()['blend'] is True
        assert ready.json()['blend_max_mib']==80
