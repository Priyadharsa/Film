import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
const css=readFileSync(new URL('../static/import_dialog_fix.css',import.meta.url),'utf8');
const js=readFileSync(new URL('../static/book.js',import.meta.url),'utf8');
test('import dialog has the proper hierarchy and accessible dialog semantics',()=>{
 assert.match(html,/id="import-modal"[^>]*role="dialog"[^>]*aria-modal="true"/);
 assert.match(html,/aria-labelledby="import-dialog-title"/);
 assert.match(html,/id="import-dialog-title"/);
 assert.match(html,/id="import-file"/);
 assert.match(html,/id="ocr"/);
 assert.match(html,/id="submit-import"/);
 assert.match(html,/import_dialog_fix\.css\?v=0\.13\.5/);
 assert.equal([...html.matchAll(/id="import-modal"/g)].length,1);
});
test('modal overlays outrank sticky tools and fullscreen stage',()=>{
 const z=Number(css.match(/body > \.overlay:not\(\[hidden\]\)\{[^}]*z-index:(\d+)/s)?.[1]);
 assert.ok(z>2000,`overlay must be above job HUD and cinema stage, got ${z}`);
 assert.match(css,/#import-modal \.import-dialog\{[^}]*max-height:calc\(100dvh - 32px\)/);
 assert.match(css,/body > \.overlay\[hidden\]\{display:none!important\}/);
});
test('import dialog closes and restores keyboard focus, never resets the form on error',()=>{
 assert.match(js,/function openImportDialog\(\)/);
 assert.match(js,/function closeImportDialog\(\)/);
 assert.match(js,/if\(e\.key==='Escape'\)/);
 assert.match(js,/if\(e\.key!=='Tab'\)return/);
 assert.match(js,/await loadIndex\(\);closeImportDialog\(\)/);
});
