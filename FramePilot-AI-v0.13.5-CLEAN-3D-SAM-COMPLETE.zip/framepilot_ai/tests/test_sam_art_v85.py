"""Art Studio v0.8.5: SAM masks and Muse edits without real/paid API calls."""
import base64
import io
from pathlib import Path
import pytest
from PIL import Image
from fastapi.testclient import TestClient
from app.art_layers import decode_mask,process_layer
from app.project_store import ProjectStore
from app import main, workspace_api


def sample_box():
    # 2 x 2 foreground target at (1,1) to (3,3) in a 4x4 image
    return {'object_id':'0','left':1,'top':1,'right':3,'bottom':3,
            'mask_width':2,'mask_height':2,
            'mask_base64':base64.b64encode(b'\x01\x00\x00\x01').decode(),
            'confidence':0.95}


def test_sam_mask_correct_pixel_location_and_validation():
    mask=decode_mask(sample_box(),(4,4))
    assert list(mask.getdata())==[0,0,0,0,0,255,0,0,0,0,255,0,0,0,0,0]
    for changed in [dict(sample_box(),right=8),dict(sample_box(),mask_base64='%%%'),
                    dict(sample_box(),mask_base64=base64.b64encode(b'\x01').decode())]:
        with pytest.raises(ValueError):decode_mask(changed,(4,4))


def test_local_layer_effects_are_non_destructive(tmp_path):
    src=tmp_path/'shot-1-1234567890.png';Image.new('RGB',(4,4),(230,90,70)).save(src)
    for operation in ['isolate','focus','accent','silhouette','outline','soften']:
        dest=tmp_path/f'{operation}.png'
        process_layer(src,sample_box(),operation,dest)
        with Image.open(dest) as im:
            assert im.size==(4,4)
            if operation=='isolate':
                assert im.getpixel((0,0))[3]==0
                assert im.getpixel((1,1))[3]==255
            if operation=='silhouette':
                assert im.getpixel((1,1))[:3]==(23,31,42)
    assert Image.open(src).getpixel((1,1))==(230,90,70)


@pytest.fixture
def art_api(tmp_path,monkeypatch):
    store=ProjectStore(tmp_path/'projects')
    generated=tmp_path/'generated';generated.mkdir()
    monkeypatch.setattr(workspace_api,'STORE',store)
    monkeypatch.setattr(workspace_api,'GENERATED',generated)
    monkeypatch.setattr(main,'GENERATED_DIR',generated)
    client=TestClient(main.app,raise_server_exceptions=False)
    project=client.post('/api/projects/demo').json()['project']
    scene=project['scenes'][0];shot=scene['shots'][0]
    base=f'/api/projects/{project["id"]}/scenes/{scene["id"]}/shots/{shot["id"]}'
    return client,generated,project,base


def test_mask_layer_api_history_stale_and_invalid_mask(art_api):
    client,generated,project,base=art_api
    url=project['scenes'][0]['shots'][0]['image_url']
    fname=url.split('/')[-1]
    with Image.open(generated/fname) as im:
        size=im.size
    full_mask=sample_box()
    full_mask.update({'left':1,'top':1,'right':3,'bottom':3})
    request={'source_filename':fname,'selection':full_mask,'operation':'isolate'}
    resp=client.post(base+'/sam-layer',json=request)
    assert resp.status_code==200,resp.text
    result=resp.json()
    assert result['image_url']!=url
    assert (generated/result['image_url'].split('/')[-1]).is_file()
    shot=result['project']['scenes'][0]['shots'][0]
    assert shot['history'][-1]['kind']=='SAM layer · isolate'
    assert shot['image_url']==result['image_url']
    assert client.post(base+'/sam-layer',json=request).status_code==409
    invalid={'source_filename':shot['image_url'].split('/')[-1],'selection':dict(sample_box(),mask_base64='notbase64'),'operation':'outline'}
    assert client.post(base+'/sam-layer',json=invalid).status_code==422
    invalid['selection']=sample_box();invalid['operation']='inpaint'
    assert client.post(base+'/sam-layer',json=invalid).status_code==422


def test_sam_selection_passes_to_muse_without_second_sam_call(art_api,monkeypatch):
    client,generated,project,base=art_api
    src=project['scenes'][0]['shots'][0]['image_url'].split('/')[-1]
    seen={}
    def fake_edit(image_path,instruction,target,bbox,reference_images,style_instruction,selection=None):
        seen.update({'instruction':instruction,'bbox':bbox,'target':target})
        return src,'mock-muse'
    monkeypatch.setattr(main,'edit_storyboard_frame',fake_edit)
    def forbid_sam(*args,**kw):raise AssertionError('Duplicate SAM call')
    monkeypatch.setattr(main,'segment_image_objects',forbid_sam)
    response=client.post('/api/edit',json={'image_filename':src,'instruction':'Replace the cassette with a key',
        'selected_box':[1,1,3,3],'selection':sample_box(),'target':'cassette','use_sam':True})
    assert response.status_code==200,response.text
    assert seen['bbox']==(1,1,3,3)
    assert response.json()['sam_grounded'] is True
    response=client.post('/api/edit',json={'image_filename':src,'instruction':'Replace the cassette with a key',
        'selected_box':[1,1,999999,999999],'target':'cassette'})
    assert response.status_code==422


def test_sam_api_mock_and_editor_ids(art_api,monkeypatch):
    client,generated,project,_=art_api
    filename=project['scenes'][0]['shots'][0]['image_url'].split('/')[-1]
    monkeypatch.setattr(main,'segment_image_objects',lambda path,prompt:{'model':'sam-3.1','prompt':prompt,
           'objects':[sample_box()],'message':'One selected object'})
    response=client.post('/api/segment',json={'image_filename':filename,'prompt':'cassette'})
    assert response.status_code==200,response.text
    assert response.json()['objects'][0]['mask_width']==2
    html=client.get('/book').text
    for ID in ['sam-detect','sam-instances','sam-stage','sam-mask','art-max','sam-apply','art-compare','revise']:
        assert f'id="{ID}"' in html
    assert client.get('/health').json()['version']=='0.13.5'


def test_muse_receives_clean_image_and_sam_visual_selection_guide(tmp_path,monkeypatch):
    """Mock Meta Responses API and check the *real* request payload construction."""
    from types import SimpleNamespace
    from app import image_edit
    picture=tmp_path/'shot-1-1234567890.png'
    Image.new('RGB',(4,4),(220,120,80)).save(picture)
    encoded=base64.b64encode(picture.read_bytes()).decode('ascii')
    seen={}
    class FakeResponses:
        def create(self,**kwargs):
            seen.update(kwargs)
            return SimpleNamespace(output=[SimpleNamespace(type='image_generation_call',result=encoded)])
    monkeypatch.setattr(image_edit,'_client',lambda:SimpleNamespace(responses=FakeResponses()))
    output,model=image_edit.edit_storyboard_frame(
        picture,'Replace the selected subject with a brass key',target='cassette',
        bbox=(1,1,3,3),selection=sample_box())
    assert model=='muse-image-1.0'
    assert (tmp_path/output).is_file()
    assert seen['model']=='muse-image-1.0'
    parts=seen['input'][0]['content']
    images=[part for part in parts if part['type']=='input_image']
    assert len(images)==2, 'one clean frame plus one SAM-highlighted guide'
    assert 'selection GUIDE' in ''.join(part.get('text','') for part in parts)


def test_invalid_muse_mask_does_not_send_api_call(art_api,monkeypatch):
    client,generated,project,_=art_api
    source=project['scenes'][0]['shots'][0]['image_url'].split('/')[-1]
    def forbid(*args,**kwargs):raise AssertionError('No model API calls with invalid selection')
    monkeypatch.setattr(main,'edit_storyboard_frame',forbid)
    bad=client.post('/api/edit',json={'image_filename':source,'instruction':'Remove the item',
        'selection':dict(sample_box(),mask_base64='bad')})
    assert bad.status_code==422,bad.text
