import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../static/book.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../static/book.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../static/book.css',import.meta.url),'utf8');

test('director assistant has proposal, apply, undo, sketch guide and CLI brief controls',()=>{
 for(const id of ['tool-director','director-direction','director-mode','director-focus','director-generate',
 'director-apply','director-undo','director-draw','director-copy-brief','director-preview','director-concept'])
   assert.ok(html.includes(`id="${id}"`),`${id} missing`);
 for(const snippet of ["'/api/director/plan'","'/api/director/apply'","'/api/director/undo'",
   "tool('draw')","rememberSketch()"])
   assert.ok(js.includes(snippet),`action missing ${snippet}`);
});
test('editor tool system routes the new assistant and keeps independent panels',()=>{
 assert.match(js,/director:'Muse Director/);
 assert.match(js,/\['set','draw','art','voice','director','frame'\]/);
 assert.match(css,/\.director-grid\{display:grid/);
 assert.match(css,/#director-preview\[hidden\]/);
});
test('account register flow consumes immediately signed-in session',()=>{
 assert.match(js,/if\(result\.user\)\{notify\('Account created and signed in/);
});
