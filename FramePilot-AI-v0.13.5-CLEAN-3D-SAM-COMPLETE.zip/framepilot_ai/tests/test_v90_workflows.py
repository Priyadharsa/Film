import io
import json
import time
import zipfile
import pytest
from pathlib import Path
from fastapi.testclient import TestClient
from app import auth, generation_jobs as jobs, workspace_api as wa
from app.main import app
from app.project_store import ProjectStore
from app.screenplay_parser import parse_scenes, page_records, connect_pages

@pytest.fixture
def test_server(tmp_path,monkeypatch):
    monkeypatch.setattr(wa,'STORE',ProjectStore(tmp_path/'private'))
    monkeypatch.setattr(wa,'GENERATED',tmp_path/'generated')
    wa.GENERATED.mkdir(parents=True,exist_ok=True)
    monkeypatch.setattr(jobs,'DB',tmp_path/'jobs.sqlite3')
    monkeypatch.setattr(jobs,'pace_inference',lambda:None)
    monkeypatch.setattr(auth,'DB',tmp_path/'accounts.sqlite3')
    monkeypatch.setattr(auth,'AUTH_MODE','local')
    client=TestClient(app)
    yield client,tmp_path,monkeypatch


def demo(client):
    r=client.post('/api/projects/demo')
    assert r.status_code==200,r.text
    return r.json()['project']


def test_clean_bundle_and_page_download(test_server):
    client,tmp,monkeypatch=test_server
    project=demo(client)
    r=client.get(f"/api/projects/{project['id']}/production-pack.zip")
    assert r.status_code==200,r.text
    assert r.headers['content-type']=='application/zip'
    with zipfile.ZipFile(io.BytesIO(r.content)) as archive:
        names=archive.namelist()
        assert any(x.endswith('production-book.pdf') for x in names)
        assert any(x.endswith('comic-book.pdf') for x in names)
        assert any(x.endswith('project.json') for x in names)
        assert not any(x.endswith('.env') for x in names)
        for x in names:
            if x.endswith('.pdf'):assert archive.read(x).startswith(b'%PDF-')


def test_batch_scope_job_and_cancel(test_server):
    client,tmp,monkeypatch=test_server
    project=demo(client)
    requested=[]
    def fake_render(pid,sid,shid,body):
        requested.append(shid)
        return {'project':wa.STORE.get(pid)}
    monkeypatch.setattr(wa,'render_shot',fake_render)
    response=client.post('/api/jobs/generate',json={'project_id':project['id'],'scope':'page','page':1})
    assert response.status_code==202,response.text
    job_id=response.json()['id']
    for _ in range(80):
        job=client.get(f'/api/jobs/{job_id}').json()
        if job['state'] not in ('queued','running','cancel_requested'):break
        time.sleep(.03)
    assert job['state']=='completed',job
    assert job['done']==job['total']==len(requested)
    assert job['failures']==0
    bad=client.post('/api/jobs/generate',json={'project_id':project['id'],'scope':'page','page':999})
    assert bad.status_code==422


def test_accounts_private_projects_and_sessions(test_server):
    _client,tmp,monkeypatch=test_server
    monkeypatch.setattr(auth,'AUTH_MODE','accounts')
    a=TestClient(app);b=TestClient(app)
    assert a.get('/api/projects').status_code==401
    def signup(client,email):
        r=client.post('/api/auth/register',json={'name':'Test User','email':email,'password':'very-secure-12345'})
        assert r.status_code==201,r.text
        r=client.post('/api/auth/login',json={'email':email,'password':'very-secure-12345'})
        assert r.status_code==200,r.text
    signup(a,'alpha@example.com');signup(b,'beta@example.com')
    project=demo(a)
    assert a.get(f"/api/projects/{project['id']}").status_code==200
    assert b.get(f"/api/projects/{project['id']}").status_code==404
    assert not b.get('/api/projects').json()['projects']
    assert a.post('/api/auth/logout').status_code==200
    assert a.get('/api/projects').status_code==401
    assert b.get(f"/api/projects/{project['id']}/production-pack.zip").status_code==404


def test_account_mode_rejects_public_asset(test_server):
    client,tmp,monkeypatch=test_server
    monkeypatch.setattr(auth,'AUTH_MODE','accounts')
    assert client.get('/static/generated/some-frame.png').status_code==401
    assert client.post('/api/jobs/generate',json={'project_id':'none','scope':'page','page':1}).status_code==401
