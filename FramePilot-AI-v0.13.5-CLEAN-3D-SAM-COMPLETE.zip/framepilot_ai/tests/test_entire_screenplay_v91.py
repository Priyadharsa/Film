"""Whole-screenplay import, credit-free shot planning, and tracked render queue."""
from __future__ import annotations
import time
import pytest
from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app
from app import workspace_api as wa, generation_jobs as jobs, auth
from app.project_store import ProjectStore
from app.storyboard_planner import expand_scenes, split_beats
from app.screenplay_parser import parse_scenes

@pytest.fixture
def server(tmp_path,monkeypatch):
    monkeypatch.setattr(wa,'STORE',ProjectStore(tmp_path/'private'))
    monkeypatch.setattr(jobs,'DB',tmp_path/'generation.sqlite3')
    monkeypatch.setattr(jobs,'pace_inference',lambda:None) # model is mocked in these tests
    monkeypatch.setattr(auth,'AUTH_MODE','local')
    return TestClient(app),monkeypatch

def test_beat_plan_covers_dialogue_and_action_and_is_idempotent():
    script='INT. ROOM - DAY\n\n'+'\n\n'.join(f'Character speaks about plan {i}.\n\nThey cross the room and look out the window {i}.' for i in range(30))
    scenes=parse_scenes(script)
    coverage=expand_scenes(scenes,fresh=True)
    assert coverage['total_shots']>=15
    all_text=' '.join(s['description'] for sc in scenes for s in sc['shots'])
    assert 'Character speaks about plan 0' in all_text
    assert 'window 29' in all_text
    assert expand_scenes(scenes)['added']==0

def test_entire_screenplay_confirmed_model_calls(server):
    client,patch=server
    script='\n\n'.join(f'INT. ROOM {i} - DAY\n\nActor enters room.\n\nShe looks at the door and sits down.' for i in range(90))
    r=client.post('/api/projects/import',data={'title':'Sample','screenplay_text':script})
    assert r.status_code==200,r.text
    p=r.json()['project'];pid=p['id'];total=sum(len(s['shots']) for s in p['scenes'])
    assert total>=90
    plan=client.post(f'/api/projects/{pid}/plan-entire-book')
    assert plan.status_code==200,plan.text
    assert plan.json()['coverage']['added']==0
    est=client.get(f'/api/jobs/estimate?project_id={pid}&scope=book')
    assert est.status_code==200,est.text
    assert est.json()['model_calls']==total
    req={'scope':'book','project_id':pid}
    assert client.post('/api/jobs/generate',json=req).status_code==422
    rendered=[]
    patch.setattr(wa,'render_shot',lambda p,s,sh,b: rendered.append(sh))
    r=client.post('/api/jobs/generate',json={**req,'confirmed_count':total})
    assert r.status_code==202,r.text
    job_id=r.json()['id']
    for _ in range(150):
        status=client.get(f'/api/jobs/{job_id}').json()
        if status['state'] not in ('queued','running','cancel_requested'):break
        time.sleep(.02)
    assert status['state']=='completed',status
    assert status['done']==total==len(rendered)
    assert status['failures']==0
    assert status['pending']==0


def test_skip_rendered_in_estimate(server):
    client,_=server
    script='INT. HOUSE - NIGHT\n\nSomebody opens the door.\n\nSomebody sits at the table.\n\nA storm begins outside.'
    r=client.post('/api/projects/import',data={'screenplay_text':script})
    p=r.json()['project']
    shot=p['scenes'][0]['shots'][0]
    p=wa.STORE.mutate(p['id'],lambda project:project['scenes'][0]['shots'][0].update({'image_url':'/static/generated/shot-1-123456789a.png'}))
    est=client.get(f"/api/jobs/estimate?project_id={p['id']}&scope=book")
    assert est.status_code==200
    assert est.json()['model_calls']==sum(len(s['shots']) for s in p['scenes'])-1
