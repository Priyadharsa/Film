#!/usr/bin/env python3
"""Non-destructive release smoke check; no Meta inference or private content access.

Run from any directory: python tools/release_check.py [--full]
"""
from __future__ import annotations
import argparse
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))


def main():
    parser=argparse.ArgumentParser(description='Verify FramePilot API, UI routes and optional tests')
    parser.add_argument('--full',action='store_true',help='also run full pytest and Node test suites')
    args=parser.parse_args()
    try:
        from fastapi.testclient import TestClient
        from app.main import app
    except ImportError as exc:
        print(f'Cannot import installed requirements: {exc}. Install with python -m pip install -r requirements.txt',file=sys.stderr)
        return 2

    routes=('/health','/health/live','/book','/production','/studio','/shotlab','/api/styles','/api/auth/me')
    with TestClient(app) as client:
        for route in routes:
            response=client.get(route)
            if response.status_code!=200:
                print(f'FAIL: {route}: HTTP {response.status_code}: {response.text[:160]}',file=sys.stderr)
                return 1
            print(f'PASS: GET {route} -> 200')
        if client.get('/health').json().get('version')!='0.12.5':
            print('FAIL: unexpected application version',file=sys.stderr)
            return 1
        if not client.get('/api/styles').json().get('styles'):
            print('FAIL: visual styles not loaded',file=sys.stderr)
            return 1
        for asset in ('book.js','book.css','framepilot_teal.css','cinema_utils.js'):
            response=client.get('/static/'+asset)
            if response.status_code!=200 or not response.content:
                print(f'FAIL: static asset {asset}',file=sys.stderr)
                return 1
            print(f'PASS: /static/{asset}')
    for filename in ('static/demo/demo-master.png','static/demo/demo-cassette.png',
                     'static/demo/demo-street.png','examples/the_last_signal.txt',
                     'START_FRAMEPILOT.bat','START_FRAMEPILOT.sh'):
        if not (ROOT/filename).is_file():
            print(f'FAIL: missing {filename}',file=sys.stderr)
            return 1
    print('PASS: original demo artwork, screenplay and launchers present')

    if args.full:
        commands=[[sys.executable,'-m','pytest','-q'],['npm','test']]
        for command in commands:
            print('RUN:', ' '.join(command),flush=True)
            try:rc=subprocess.run(command,cwd=ROOT,check=False).returncode
            except FileNotFoundError:
                print(f'ERROR: {command[0]} is not installed; install it to run the full suite.',file=sys.stderr)
                return 2
            if rc:return rc
    print('FramePilot release check passed. Paid Muse/SAM calls and browser/WebGL are not included.')
    return 0


if __name__=='__main__':
    raise SystemExit(main())
