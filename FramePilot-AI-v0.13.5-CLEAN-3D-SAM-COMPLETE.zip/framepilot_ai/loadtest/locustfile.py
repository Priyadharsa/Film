"""FramePilot HTTP load profile: requires `pip install locust`.

EXAMPLE (NON-PRODUCTION, READ ONLY):
  locust -f loadtest/locustfile.py --headless -u 100 -r 10 -t 60s --host http://127.0.0.1:8011
Never run this against a public service without explicit load-test authorization.
DO NOT point 2 million load clients at a laptop; use a distributed load-test
fleet and production-like infrastructure under a pre-approved test window.
"""
from locust import HttpUser, between, task

class FramePilotReads(HttpUser):
    wait_time=between(0.25,1.0)
    @task(8)
    def health(self):
        self.client.get('/health',name='GET /health')
    @task(2)
    def art_styles(self):
        self.client.get('/api/styles',name='GET /api/styles')

# Endpoints that trigger Muse/SAM are deliberately excluded: load tests must
# use a mocked provider or the charges and provider rate limits will dominate.
