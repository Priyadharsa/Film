"""Small, read-only load check against YOUR OWN localhost instance.

Usage: python loadtest/bounded_probe.py --requests 1000 --concurrency 32 --port 8013
The upper bounds protect laptops. NOT a 2-million concurrency test.
"""
from __future__ import annotations
import argparse
import asyncio
import statistics
import time
from collections import Counter
import httpx

async def run(requests: int, concurrency: int, port: int):
    url=f'http://127.0.0.1:{port}/api/styles'
    semaphore=asyncio.Semaphore(concurrency)
    durations=[]
    statuses=Counter()
    async with httpx.AsyncClient(timeout=12.0, limits=httpx.Limits(max_connections=concurrency, max_keepalive_connections=concurrency)) as client:
        async def one():
            async with semaphore:
                start=time.perf_counter()
                try:
                    response=await client.get(url)
                    statuses[response.status_code]+=1
                except httpx.RequestError:
                    statuses['transport_error']+=1
                durations.append((time.perf_counter()-start)*1000)
        start=time.perf_counter()
        await asyncio.gather(*(one() for _ in range(requests)))
    ms=sorted(durations)
    pct=lambda p:round(ms[min(len(ms)-1,int((len(ms)-1)*p))],1)
    print({'requests':requests,'concurrency':concurrency,'status_counts':dict(statuses),
           'rps':round(requests/max(.001,time.perf_counter()-start),1),
           'p50_ms':pct(.50),'p95_ms':pct(.95),'p99_ms':pct(.99),
           'target':'localhost only; no Meta calls'})

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--requests',type=int,default=1000)
    parser.add_argument('--concurrency',type=int,default=32)
    parser.add_argument('--port',type=int,default=8013)
    args=parser.parse_args()
    if not (1<=args.requests<=20000 and 1<=args.concurrency<=256 and 1<=args.port<=65535):
        parser.error('Use 1-20000 requests, 1-256 concurrency, and a valid port')
    asyncio.run(run(args.requests,args.concurrency,args.port))
